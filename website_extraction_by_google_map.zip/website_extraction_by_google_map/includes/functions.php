<?php

function isApiKeyConfigured(): bool
{
    return defined('GOOGLE_API_KEY')
        && GOOGLE_API_KEY !== ''
        && GOOGLE_API_KEY !== 'YOUR_GOOGLE_API_KEY_HERE';
}

function extractLocationFromQuery(string $query): string
{
    $query = trim($query);

    if (preg_match('/\b(?:in|near|at|around)\s+(.+)$/iu', $query, $matches)) {
        return trim($matches[1]);
    }

    return $query;
}

function googleGeocodeSearchArea(string $query): ?array
{
    $locationHint = extractLocationFromQuery($query);
    $area = googleGeocodeClassic($locationHint);

    if ($area) {
        return $area;
    }

    return googlePlacesLocationFallback($locationHint);
}

function googleGeocodeClassic(string $locationHint): ?array
{
    $url = 'https://maps.googleapis.com/maps/api/geocode/json?' . http_build_query([
        'address' => $locationHint,
        'key' => GOOGLE_API_KEY,
    ]);

    $response = curlRequest($url, [], null, 10);

    if ($response['error']) {
        return null;
    }

    $data = json_decode($response['body'], true);

    if (!is_array($data) || ($data['status'] ?? '') !== 'OK' || empty($data['results'])) {
        return null;
    }

    $result = $data['results'][0];
    $location = $result['geometry']['location'] ?? null;

    if (!$location) {
        return null;
    }

    $area = [
        'lat' => (float) $location['lat'],
        'lng' => (float) $location['lng'],
        'formatted_address' => $result['formatted_address'] ?? $locationHint,
        'viewport' => null,
    ];

    $viewport = $result['geometry']['viewport'] ?? null;

    if ($viewport) {
        $area['viewport'] = [
            'north' => (float) $viewport['northeast']['lat'],
            'east' => (float) $viewport['northeast']['lng'],
            'south' => (float) $viewport['southwest']['lat'],
            'west' => (float) $viewport['southwest']['lng'],
        ];
    }

    return $area;
}

function googlePlacesLocationFallback(string $locationHint): ?array
{
    $url = 'https://places.googleapis.com/v1/places:searchText';

    $payload = json_encode([
        'textQuery' => $locationHint,
        'languageCode' => 'en',
        'maxResultCount' => 1,
    ]);

    $response = curlRequest($url, [
        'Content-Type: application/json',
        'X-Goog-Api-Key: ' . GOOGLE_API_KEY,
        'X-Goog-FieldMask: places.location,places.formattedAddress,places.displayName',
    ], $payload, 15);

    if ($response['error']) {
        return null;
    }

    $data = json_decode($response['body'], true);
    $place = $data['places'][0] ?? null;

    if (!$place || !isset($place['location']['latitude'], $place['location']['longitude'])) {
        return null;
    }

    return [
        'lat' => (float) $place['location']['latitude'],
        'lng' => (float) $place['location']['longitude'],
        'formatted_address' => $place['formattedAddress']
            ?? ($place['displayName']['text'] ?? $locationHint),
        'viewport' => null,
        'from_places' => true,
    ];
}

function computeAreaFromPlaces(array $places): ?array
{
    $lats = [];
    $lngs = [];

    foreach ($places as $place) {
        if ($place['lat'] !== null && $place['lng'] !== null) {
            $lats[] = (float) $place['lat'];
            $lngs[] = (float) $place['lng'];
        }
    }

    if ($lats === []) {
        return null;
    }

    $minLat = min($lats);
    $maxLat = max($lats);
    $minLng = min($lngs);
    $maxLng = max($lngs);

    return [
        'lat' => array_sum($lats) / count($lats),
        'lng' => array_sum($lngs) / count($lngs),
        'formatted_address' => '',
        'viewport' => [
            'north' => $maxLat,
            'east' => $maxLng,
            'south' => $minLat,
            'west' => $minLng,
        ],
        'from_results' => true,
    ];
}

function googlePlacesTextSearch(string $query, ?array $searchArea = null): array
{
    $url = 'https://places.googleapis.com/v1/places:searchText';

    $body = [
        'textQuery' => $query,
        'languageCode' => 'en',
        'maxResultCount' => 50,
    ];

    if ($searchArea && isset($searchArea['lat'], $searchArea['lng'])) {
        $body['locationBias'] = [
            'circle' => [
                'center' => [
                    'latitude' => $searchArea['lat'],
                    'longitude' => $searchArea['lng'],
                ],
                'radius' => 50000.0,
            ],
        ];
    }

    $payload = json_encode($body);

    $fieldMask = implode(',', [
        'places.id',
        'places.displayName',
        'places.formattedAddress',
        'places.location',
        'places.nationalPhoneNumber',
        'places.internationalPhoneNumber',
        'places.websiteUri',
        'places.rating',
        'places.userRatingCount',
        'places.googleMapsUri',
    ]);

    $response = curlRequest($url, [
        'Content-Type: application/json',
        'X-Goog-Api-Key: ' . GOOGLE_API_KEY,
        'X-Goog-FieldMask: ' . $fieldMask,
    ], $payload);

    if ($response['error']) {
        return ['error' => $response['error'], 'places' => []];
    }

    $data = json_decode($response['body'], true);

    if (!is_array($data)) {
        return ['error' => 'Invalid response from Google Places API.', 'places' => []];
    }

    if (isset($data['error'])) {
        $message = $data['error']['message'] ?? 'Google Places API error.';
        return ['error' => $message, 'places' => []];
    }

    return ['error' => null, 'places' => $data['places'] ?? []];
}

function normalizePlace(array $place): array
{
    $lat = $place['location']['latitude'] ?? null;
    $lng = $place['location']['longitude'] ?? null;

    return [
        'id' => $place['id'] ?? '',
        'name' => $place['displayName']['text'] ?? 'Unknown',
        'address' => $place['formattedAddress'] ?? '',
        'phone' => $place['nationalPhoneNumber']
            ?? $place['internationalPhoneNumber']
            ?? null,
        'website' => $place['websiteUri'] ?? null,
        'email' => null,
        'rating' => $place['rating'] ?? null,
        'review_count' => $place['userRatingCount'] ?? null,
        'maps_url' => $place['googleMapsUri'] ?? null,
        'lat' => $lat,
        'lng' => $lng,
    ];
}

function extractEmailFromWebsite(?string $url): ?string
{
    if (!$url) {
        return null;
    }

    $response = curlRequest($url, [
        'User-Agent: Mozilla/5.0 (compatible; LocationSearchBot/1.0)',
        'Accept: text/html',
    ], null, 4);

    if ($response['error'] || $response['body'] === '') {
        return null;
    }

    $html = $response['body'];

    if (preg_match_all(
        '/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/',
        $html,
        $matches
    )) {
        foreach ($matches[0] as $email) {
            $email = strtolower($email);

            if (isLikelyValidEmail($email)) {
                return $email;
            }
        }
    }

    return null;
}

function isLikelyValidEmail(string $email): bool
{
    $blocked = [
        'example.com',
        'wixpress.com',
        'sentry.io',
        'schema.org',
        'w3.org',
        'google.com',
        'facebook.com',
        'twitter.com',
        'instagram.com',
        'youtube.com',
        'png',
        'jpg',
        'jpeg',
        'gif',
        'svg',
        'webp',
    ];

    foreach ($blocked as $fragment) {
        if (str_contains($email, $fragment)) {
            return false;
        }
    }

    return (bool) filter_var($email, FILTER_VALIDATE_EMAIL);
}

function curlRequest(
    string $url,
    array $headers = [],
    ?string $body = null,
    int $timeout = 20
): array {
    if (!function_exists('curl_init')) {
        return ['error' => 'PHP cURL extension is not enabled.', 'body' => ''];
    }

    $ch = curl_init($url);

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);

    if ($body !== null) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }

    $result = curl_exec($ch);
    $errno = curl_errno($ch);
    $error = $errno ? curl_error($ch) : null;
    curl_close($ch);

    return [
        'error' => $error,
        'body' => is_string($result) ? $result : '',
    ];
}

function jsonResponse(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function xlsxColumnLetter(int $index): string
{
    $letter = '';

    while ($index >= 0) {
        $letter = chr(65 + ($index % 26)) . $letter;
        $index = intdiv($index, 26) - 1;
    }

    return $letter;
}

function xlsxEscape(string $value): string
{
    return htmlspecialchars($value, ENT_XML1 | ENT_QUOTES, 'UTF-8');
}

function buildXlsxSheetXml(array $rows): string
{
    $sheetRows = '';

    foreach ($rows as $rowIndex => $row) {
        $rowNumber = $rowIndex + 1;
        $cells = '';

        foreach ($row as $colIndex => $value) {
            $cellRef = xlsxColumnLetter($colIndex) . $rowNumber;
            $text = xlsxEscape((string) $value);
            $cells .= '<c r="' . $cellRef . '" t="inlineStr"><is><t>' . $text . '</t></is></c>';
        }

        $sheetRows .= '<row r="' . $rowNumber . '">' . $cells . '</row>';
    }

    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        . '<sheetData>' . $sheetRows . '</sheetData>'
        . '</worksheet>';
}

function buildResultsSpreadsheetRows(string $query, array $results): array
{
    $rows = [
        ['Search Query', $query],
        ['Exported At', date('Y-m-d H:i:s')],
        ['Total Results', (string) count($results)],
        [],
        [
            'Name',
            'Address',
            'Phone',
            'Email',
            'Website',
            'Rating',
            'Review Count',
            'Latitude',
            'Longitude',
            'Google Maps URL',
        ],
    ];

    foreach ($results as $place) {
        $rows[] = [
            $place['name'] ?? '',
            $place['address'] ?? '',
            $place['phone'] ?? '',
            $place['email'] ?? '',
            $place['website'] ?? '',
            $place['rating'] ?? '',
            $place['review_count'] ?? '',
            $place['lat'] ?? '',
            $place['lng'] ?? '',
            $place['maps_url'] ?? '',
        ];
    }

    return $rows;
}

function sanitizeExportFilename(string $query): string
{
    $slug = preg_replace('/[^a-zA-Z0-9\-]+/', '-', strtolower(trim($query)));
    $slug = trim($slug, '-');

    if ($slug === '') {
        $slug = 'search-results';
    }

    return substr($slug, 0, 50) . '-' . date('Y-m-d-His') . '.xlsx';
}

function sendResultsXlsx(string $query, array $results): void
{
    if (!class_exists('ZipArchive')) {
        sendResultsCsv($query, $results);
        return;
    }

    $rows = buildResultsSpreadsheetRows($query, $results);
    $sheetXml = buildXlsxSheetXml($rows);
    $filename = sanitizeExportFilename($query);

    $tempFile = tempnam(sys_get_temp_dir(), 'xlsx_');
    $zip = new ZipArchive();

    if ($zip->open($tempFile, ZipArchive::OVERWRITE) !== true) {
        sendResultsCsv($query, $results);
        return;
    }

    $zip->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        . '<Default Extension="xml" ContentType="application/xml"/>'
        . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        . '</Types>');

    $zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        . '</Relationships>');

    $zip->addFromString('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
        . '</Relationships>');

    $zip->addFromString('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        . 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        . '<sheets><sheet name="Search Results" sheetId="1" r:id="rId1"/></sheets>'
        . '</workbook>');

    $zip->addFromString('xl/worksheets/sheet1.xml', $sheetXml);
    $zip->close();

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . filesize($tempFile));
    header('Cache-Control: no-store, no-cache, must-revalidate');

    readfile($tempFile);
    unlink($tempFile);
    exit;
}

function sendResultsCsv(string $query, array $results): void
{
    $rows = buildResultsSpreadsheetRows($query, $results);
    $filename = str_replace('.xlsx', '.csv', sanitizeExportFilename($query));

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-store, no-cache, must-revalidate');

    echo "\xEF\xBB\xBF";

    $output = fopen('php://output', 'w');

    foreach ($rows as $row) {
        fputcsv($output, $row);
    }

    fclose($output);
    exit;
}
