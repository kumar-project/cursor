<?php

ini_set('display_errors', '0');
set_time_limit(120);

require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/includes/functions.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

$requestMethod = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($requestMethod === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($requestMethod !== 'POST') {
    jsonResponse(['success' => false, 'error' => 'POST request required.', 'emails' => []], 405);
}

if (!isApiKeyConfigured()) {
    jsonResponse([
        'success' => false,
        'error' => 'Google API key is not configured.',
        'emails' => [],
    ], 500);
}

$rawInput = file_get_contents('php://input');
$payload = json_decode($rawInput, true);
$places = $payload['places'] ?? [];

if (!is_array($places) || $places === []) {
    jsonResponse(['success' => false, 'error' => 'No places provided.', 'emails' => []], 400);
}

$emails = [];
$limit = min(count($places), 20);

for ($i = 0; $i < $limit; $i++) {
    $place = $places[$i];
    $id = $place['id'] ?? '';
    $website = $place['website'] ?? null;

    if ($id === '' || !$website) {
        continue;
    }

    $emails[$id] = extractEmailFromWebsite($website);
}

jsonResponse([
    'success' => true,
    'emails' => $emails,
]);
