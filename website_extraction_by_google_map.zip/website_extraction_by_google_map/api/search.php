<?php

ini_set('display_errors', '0');
set_time_limit(180);

require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/includes/functions.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');

$requestMethod = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($requestMethod === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$query = trim($_GET['q'] ?? $_POST['q'] ?? '');
$extractEmails = ($_GET['extract_emails'] ?? $_POST['extract_emails'] ?? '1') !== '0';

if ($query === '') {
    jsonResponse(['success' => false, 'error' => 'Search query is required.', 'results' => []], 400);
}

if (!isApiKeyConfigured()) {
    jsonResponse([
        'success' => false,
        'error' => 'Google API key is not configured. Edit config.php and add your key.',
        'results' => [],
    ], 500);
}

$searchArea = googleGeocodeSearchArea($query);
$search = googlePlacesTextSearch($query, $searchArea);

if ($search['error']) {
    jsonResponse(['success' => false, 'error' => $search['error'], 'results' => []], 502);
}

$results = [];

foreach ($search['places'] as $place) {
    $normalized = normalizePlace($place);

    if ($extractEmails && $normalized['website']) {
        $normalized['email'] = extractEmailFromWebsite($normalized['website']);
    }

    $results[] = $normalized;
}

if (!$searchArea) {
    $searchArea = computeAreaFromPlaces($results);
}

jsonResponse([
    'success' => true,
    'query' => $query,
    'count' => count($results),
    'search_area' => $searchArea,
    'results' => $results,
]);
