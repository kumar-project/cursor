# Google Maps Location Search

A web application that lets you search for businesses and places using Google Maps, then displays results on an interactive map with contact details including phone numbers and emails.

**Technologies:** HTML, CSS, JavaScript, PHP

---

## Live URL (XAMPP)

```
http://localhost/website%20extraction/
```

---

## Page Overview

The main page (`index.php`) is split into two sections:

| Section | Description |
|---------|-------------|
| **Header** | Title, search box, and Search button |
| **Map (left)** | Embedded Google Map with numbered markers for each result |
| **Results panel (right)** | List of places with phone, email, address, website, and ratings |

### Page layout

```
┌─────────────────────────────────────────────────────────────┐
│  Google Maps Location Search                                │
│  [ Search box: e.g. restaurants in Delhi ]  [ Search ]      │
├──────────────────────────────┬──────────────────────────────┤
│                              │  Search Results              │
│                              │  12 results                  │
│        Google Map            │  Lat: 28.613900, Lng: 77.209 │
│     (markers + info popup)   │  Search area: Delhi, India   │
│                              │  ┌────────────────────────┐  │
│                              │  │ Result card 1          │  │
│                              │  │ Phone / Email / Web  │  │
│                              │  └────────────────────────┘  │
│                              │  ┌────────────────────────┐  │
│                              │  │ Result card 2          │  │
│                              │  └────────────────────────┘  │
└──────────────────────────────┴──────────────────────────────┘
```

---

## Features

- **Search box** — Search any place or business (e.g. `restaurants in Mumbai`, `hospitals near Delhi`)
- **Google Maps integration** — Interactive map with dark theme and numbered markers
- **Dynamic map center** — Latitude and longitude update automatically based on the searched area
- **Contact information**
  - **Phone** — Fetched from Google Places API
  - **Email** — Extracted from the business website when Google lists one
  - **Website** — Direct link when available
- **Ratings** — Star rating and review count from Google
- **Click interactions** — Click a result card or map marker to view full details in a popup
- **Responsive design** — Works on desktop and mobile

---

## How It Works

### Search flow

```
User types query
      ↓
Frontend (app.js) → GET api/search.php?q=...
      ↓
PHP Backend
  1. Geocode search area (e.g. "Mumbai" from "cafes in Mumbai")
  2. Call Google Places Text Search API (biased to that area)
  3. For each place: fetch phone, address, website from Google
  4. If website exists: scan page HTML for email address
  5. Return JSON with results + search_area coordinates
      ↓
Frontend renders markers on map + result cards in panel
Map pans/zooms to fit the search area and results
```

### Map location behavior

| Search example | Map behavior |
|----------------|--------------|
| `hospitals in Delhi` | Map centers on Delhi |
| `cafes near Mumbai` | Map centers on Mumbai |
| `hotels in London` | Map centers on London |

The app detects location keywords (`in`, `near`, `at`, `around`) in the query, geocodes that area, and moves the map accordingly. If geocoding fails, it calculates the center from the returned place markers.

---

## Project Structure

```
website extraction/
├── index.php              # Main page (HTML + PHP)
├── config.php             # API key and default map settings
├── config.example.php     # Configuration template
├── README.md              # This file
├── api/
│   └── search.php         # Backend search API endpoint
├── includes/
│   └── functions.php      # Google API helpers and email extraction
└── assets/
    ├── css/
    │   └── style.css      # Page styling
    └── js/
        └── app.js         # Map, search, and UI logic
```

---

## Setup Instructions

### 1. Requirements

- XAMPP (Apache + PHP)
- PHP **cURL** extension enabled
- Google Cloud account with billing enabled (free tier available)

### 2. Google Cloud APIs

Create an API key in [Google Cloud Console](https://console.cloud.google.com/) and enable:

| API | Purpose |
|-----|---------|
| Maps JavaScript API | Display the map on the page |
| Places API (New) | Search businesses and get place details |
| Geocoding API | Convert search area names to latitude/longitude |

### 3. Configure API key

1. Copy `config.example.php` to `config.php` (if not already done)
2. Open `config.php`
3. Replace `YOUR_GOOGLE_API_KEY_HERE` with your Google API key

```php
define('GOOGLE_API_KEY', 'your-actual-api-key-here');
```

### 4. Optional: default map center

Edit these values in `config.php` to set the initial map position before any search:

```php
define('DEFAULT_MAP_LAT', 28.6139);   // Default latitude
define('DEFAULT_MAP_LNG', 77.2090);   // Default longitude
define('DEFAULT_MAP_ZOOM', 12);       // Default zoom level
```

### 5. Run the app

1. Start **Apache** in XAMPP
2. Open `http://localhost/website%20extraction/` in your browser
3. Type a search query and click **Search**

---

## API Reference

### `GET api/search.php`

Search for places and return contact details.

**Parameters**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `q` | string | Yes | Search query (e.g. `restaurants in Delhi`) |
| `extract_emails` | `0` or `1` | No | Whether to scan websites for emails (default: `1`) |

**Example request**

```
GET /api/search.php?q=restaurants%20in%20Delhi&extract_emails=1
```

**Example response**

```json
{
  "success": true,
  "query": "restaurants in Delhi",
  "count": 20,
  "search_area": {
    "lat": 28.6139298,
    "lng": 77.2088282,
    "formatted_address": "Delhi, India",
    "viewport": {
      "north": 28.8835,
      "east": 77.3479,
      "south": 28.4041,
      "west": 76.8388
    }
  },
  "results": [
    {
      "id": "ChIJ...",
      "name": "Restaurant Name",
      "address": "123 Main St, Delhi, India",
      "phone": "+91 98765 43210",
      "website": "https://example.com",
      "email": "info@example.com",
      "rating": 4.5,
      "review_count": 120,
      "maps_url": "https://maps.google.com/...",
      "lat": 28.6140,
      "lng": 77.2090
    }
  ]
}
```

**Error response**

```json
{
  "success": false,
  "error": "Search query is required.",
  "results": []
}
```

---

## UI Components

### Header

- **Title:** Google Maps Location Search
- **Search input:** Text field with placeholder examples
- **Search button:** Triggers the search
- **API notice:** Shown when the API key is not configured

### Map panel

- Dark-themed Google Map
- Numbered markers for each search result
- Info popup on marker click (name, address, phone, email, website)
- Auto zoom to fit all results or the search area

### Results panel

Each result card shows:

| Field | Source |
|-------|--------|
| Name | Google Places |
| Address | Google Places |
| Phone | Google Places |
| Email | Scraped from business website |
| Website | Google Places |
| Rating | Google Places |

Below the result count, the panel also shows:

- **Live coordinates** — `Lat: …, Lng: …`
- **Search area label** — e.g. `Search area: Mumbai, Maharashtra, India`

---

## Important Notes

### Email availability

Google Places API does **not** provide email addresses. This app attempts to find emails by:

1. Reading the business website URL from Google
2. Fetching the website HTML
3. Extracting the first valid email address found

Emails are **not guaranteed** — many businesses do not publish emails on their homepage.

### API billing

Google Maps Platform APIs may incur charges after the free monthly credit. Monitor usage in Google Cloud Console and set budget alerts.

### Security (production)

- Restrict your API key to your domain in Google Cloud Console
- Do not commit `config.php` with a real API key to public repositories
- Use HTTPS in production

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Map does not load | Add your API key in `config.php` and enable Maps JavaScript API |
| No search results | Enable Places API (New) and check API key restrictions |
| Map stays on default location | Enable Geocoding API; include a location in your query (e.g. `in Delhi`) |
| No emails shown | Normal — emails depend on the business website; not all sites list emails |
| `Network error` message | Ensure Apache is running and PHP cURL is enabled in `php.ini` |
| `PHP cURL extension is not enabled` | Uncomment `extension=curl` in XAMPP `php.ini` and restart Apache |

---

## Example Searches

```
restaurants in Delhi
hospitals near Mumbai
hotels in London
pharmacies in Bangalore
coffee shops near Connaught Place Delhi
```

---

## License

This project is provided as-is for local development and learning purposes.
