<?php
/**
 * Copy this file to config.php and add your Google API key.
 *
 * Enable these APIs in Google Cloud Console:
 * - Maps JavaScript API
 * - Places API (New)
 * - Geocoding API
 *
 * Restrict the key to your domain in production.
 */
define('GOOGLE_API_KEY', 'YOUR_GOOGLE_API_KEY_HERE');

// Optional: default map center when no results yet (latitude, longitude)
define('DEFAULT_MAP_LAT', 28.6139);
define('DEFAULT_MAP_LNG', 77.2090);
define('DEFAULT_MAP_ZOOM', 12);
