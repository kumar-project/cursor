(function () {
    'use strict';

    const config = window.APP_CONFIG || {};
    const searchForm = document.getElementById('searchForm');
    const searchInput = document.getElementById('searchInput');
    const searchBtn = document.getElementById('searchBtn');
    const resultsList = document.getElementById('resultsList');
    const resultsCount = document.getElementById('resultsCount');
    const mapCoords = document.getElementById('mapCoords');
    const downloadBtn = document.getElementById('downloadBtn');

    let map = null;
    let markers = [];
    let areaMarker = null;
    let infoWindow = null;
    let currentPlaces = [];

    function apiUrl(path) {
        const base = (config.apiBase || '').replace(/\/$/, '');
        return `${base}/${path.replace(/^\//, '')}`;
    }

    function initMap() {
        const center = {
            lat: config.defaultLat || 28.6139,
            lng: config.defaultLng || 77.2090,
        };

        map = new google.maps.Map(document.getElementById('map'), {
            center,
            zoom: config.defaultZoom || 12,
            mapTypeControl: false,
            streetViewControl: false,
            fullscreenControl: true,
            styles: [
                { elementType: 'geometry', stylers: [{ color: '#1d2c4d' }] },
                { elementType: 'labels.text.stroke', stylers: [{ color: '#1d2c4d' }] },
                { elementType: 'labels.text.fill', stylers: [{ color: '#8ec3b9' }] },
                { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#304a7d' }] },
                { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#0e1626' }] },
            ],
        });

        infoWindow = new google.maps.InfoWindow();

        map.addListener('idle', () => {
            updateCoordDisplay(map.getCenter().lat(), map.getCenter().lng());
        });
    }

    function clearMarkers() {
        markers.forEach((marker) => marker.setMap(null));
        markers = [];
    }

    function clearAreaMarker() {
        if (areaMarker) {
            areaMarker.setMap(null);
            areaMarker = null;
        }
    }

    function updateCoordDisplay(lat, lng, areaLabel) {
        mapCoords.textContent = `Lat: ${Number(lat).toFixed(6)}, Lng: ${Number(lng).toFixed(6)}`;

        const existingLabel = document.getElementById('searchAreaLabel');
        if (existingLabel) {
            existingLabel.remove();
        }

        if (areaLabel) {
            const label = document.createElement('p');
            label.id = 'searchAreaLabel';
            label.className = 'search-area-label';
            label.textContent = areaLabel;
            mapCoords.insertAdjacentElement('afterend', label);
        }
    }

    function fitMapToArea(searchArea, places) {
        const bounds = new google.maps.LatLngBounds();
        let hasBounds = false;

        places.forEach((place) => {
            if (place.lat == null || place.lng == null) {
                return;
            }

            bounds.extend({ lat: place.lat, lng: place.lng });
            hasBounds = true;
        });

        if (!hasBounds && searchArea?.viewport) {
            bounds.extend({ lat: searchArea.viewport.south, lng: searchArea.viewport.west });
            bounds.extend({ lat: searchArea.viewport.north, lng: searchArea.viewport.east });
            hasBounds = true;
        }

        clearAreaMarker();

        if (hasBounds) {
            map.fitBounds(bounds, { top: 40, right: 40, bottom: 40, left: 40 });

            if (places.length === 1) {
                google.maps.event.addListenerOnce(map, 'idle', () => {
                    map.setZoom(15);
                });
            }

            return;
        }

        if (searchArea?.lat != null && searchArea?.lng != null) {
            map.panTo({ lat: searchArea.lat, lng: searchArea.lng });
            map.setZoom(places.length ? 13 : 11);

            areaMarker = new google.maps.Marker({
                position: { lat: searchArea.lat, lng: searchArea.lng },
                map,
                title: searchArea.formatted_address || 'Search area',
                icon: {
                    path: google.maps.SymbolPath.CIRCLE,
                    scale: 8,
                    fillColor: '#3b82f6',
                    fillOpacity: 0.9,
                    strokeColor: '#ffffff',
                    strokeWeight: 2,
                },
            });
        }
    }

    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text ?? '';
        return div.innerHTML;
    }

    function buildInfoContent(place) {
        const phone = place.phone
            ? `<a href="tel:${escapeHtml(place.phone)}">${escapeHtml(place.phone)}</a>`
            : '<span class="missing">Not available</span>';

        const email = place.email
            ? `<a href="mailto:${escapeHtml(place.email)}">${escapeHtml(place.email)}</a>`
            : (place.email_pending
                ? '<span class="missing">Looking up…</span>'
                : '<span class="missing">Not found on website</span>');

        const website = place.website
            ? `<a href="${escapeHtml(place.website)}" target="_blank" rel="noopener">Visit website</a>`
            : '';

        return `
            <div style="max-width:260px;font-family:Segoe UI,sans-serif;">
                <strong>${escapeHtml(place.name)}</strong>
                <p style="margin:6px 0;font-size:12px;color:#555;">${escapeHtml(place.address)}</p>
                <p style="margin:4px 0;font-size:13px;"><strong>Phone:</strong> ${phone}</p>
                <p style="margin:4px 0;font-size:13px;"><strong>Email:</strong> ${email}</p>
                ${website ? `<p style="margin:4px 0;">${website}</p>` : ''}
            </div>
        `;
    }

    function emailHtml(place) {
        if (place.email) {
            return `<a href="mailto:${escapeHtml(place.email)}">${escapeHtml(place.email)}</a>`;
        }

        if (place.email_pending) {
            return '<span class="missing">Looking up…</span>';
        }

        return '<span class="missing">Not found on website</span>';
    }

    function updatePlaceEmail(placeId, email) {
        const place = currentPlaces.find((item) => item.id === placeId);

        if (!place) {
            return;
        }

        place.email = email || null;
        place.email_pending = false;

        const index = currentPlaces.indexOf(place);
        const card = document.querySelector(`.result-card[data-index="${index}"]`);

        if (card) {
            const emailRow = card.querySelector('.contact-row .email-value');
            if (emailRow) {
                emailRow.innerHTML = emailHtml(place);
            }
        }

        if (infoWindow.getMap()) {
            infoWindow.setContent(buildInfoContent(place));
        }
    }

    function renderResults(places, searchArea) {
        currentPlaces = places.map((place) => ({ ...place }));
        resultsList.innerHTML = '';
        clearMarkers();

        if (searchArea?.lat != null && searchArea?.lng != null) {
            const areaName = searchArea.formatted_address || 'Detected from search results';
            updateCoordDisplay(searchArea.lat, searchArea.lng, `Search area: ${areaName}`);
            fitMapToArea(searchArea, currentPlaces);
        }

        if (!places.length) {
            resultsList.innerHTML = '<div class="status-message">No places found for this search.</div>';
            resultsCount.textContent = '0 results';
            setDownloadEnabled(false);
            return;
        }

        resultsCount.textContent = `${places.length} result${places.length === 1 ? '' : 's'}`;
        setDownloadEnabled(true);

        currentPlaces.forEach((place, index) => {
            if (place.lat == null || place.lng == null) {
                return;
            }

            const position = { lat: place.lat, lng: place.lng };

            const marker = new google.maps.Marker({
                position,
                map,
                title: place.name,
                label: String(index + 1),
            });

            marker.addListener('click', () => {
                infoWindow.setContent(buildInfoContent(place));
                infoWindow.open(map, marker);
                highlightCard(index);
            });

            markers.push(marker);

            const card = document.createElement('article');
            card.className = 'result-card';
            card.dataset.index = String(index);

            const ratingHtml = place.rating
                ? `<span class="rating-badge">★ ${place.rating}${place.review_count ? ` (${place.review_count})` : ''}</span>`
                : '';

            card.innerHTML = `
                ${ratingHtml}
                <h3>${escapeHtml(place.name)}</h3>
                <p class="address">${escapeHtml(place.address)}</p>
                <div class="contact-row">
                    <span class="label">Phone</span>
                    <span>${place.phone
                        ? `<a href="tel:${escapeHtml(place.phone)}">${escapeHtml(place.phone)}</a>`
                        : '<span class="missing">Not available</span>'}</span>
                </div>
                <div class="contact-row">
                    <span class="label">Email</span>
                    <span class="email-value">${emailHtml(place)}</span>
                </div>
                ${place.website ? `
                <div class="contact-row">
                    <span class="label">Web</span>
                    <span><a href="${escapeHtml(place.website)}" target="_blank" rel="noopener">${escapeHtml(place.website)}</a></span>
                </div>` : ''}
            `;

            card.addEventListener('click', () => {
                map.panTo(position);
                map.setZoom(15);
                infoWindow.setContent(buildInfoContent(place));
                infoWindow.open(map, marker);
                highlightCard(index);
            });

            resultsList.appendChild(card);
        });
    }

    function highlightCard(index) {
        document.querySelectorAll('.result-card').forEach((card) => {
            card.classList.toggle('active', card.dataset.index === String(index));
        });
    }

    function setDownloadEnabled(enabled) {
        if (downloadBtn) {
            downloadBtn.disabled = !enabled;
        }
    }

    async function downloadExcel() {
        if (!currentPlaces.length) {
            return;
        }

        const originalText = downloadBtn.textContent;
        downloadBtn.disabled = true;
        downloadBtn.textContent = 'Preparing…';

        try {
            const response = await fetch(apiUrl('api/export.php'), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    query: searchInput.value.trim() || 'search-results',
                    results: currentPlaces,
                }),
            });

            if (!response.ok) {
                let message = 'Failed to generate Excel file.';
                try {
                    const errorData = await response.json();
                    message = errorData.error || message;
                } catch (parseError) {
                    // Keep default message when response is not JSON.
                }
                throw new Error(message);
            }

            const blob = await response.blob();
            const disposition = response.headers.get('Content-Disposition') || '';
            const match = disposition.match(/filename="?([^"]+)"?/i);
            const filename = match ? match[1] : `search-results-${Date.now()}.xlsx`;

            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            link.remove();
            URL.revokeObjectURL(url);
        } catch (err) {
            alert(err.message || 'Could not download Excel file.');
        } finally {
            downloadBtn.textContent = originalText;
            setDownloadEnabled(currentPlaces.length > 0);
        }
    }

    function setLoading(isLoading) {
        searchBtn.disabled = isLoading;
        searchInput.disabled = isLoading;
        setDownloadEnabled(!isLoading && currentPlaces.length > 0);

        if (isLoading) {
            resultsList.innerHTML = `
                <div class="status-message">
                    <div class="spinner"></div>
                    <p>Searching Google Maps and extracting contact details…</p>
                </div>
            `;
            resultsCount.textContent = 'Searching…';
        }
    }

    async function fetchEmails(places) {
        const withWebsites = places.filter((place) => place.website);

        if (!withWebsites.length) {
            return;
        }

        withWebsites.forEach((place) => {
            place.email_pending = true;
        });

        try {
            const response = await fetch(apiUrl('api/enrich-emails.php'), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    places: withWebsites.map((place) => ({
                        id: place.id,
                        website: place.website,
                    })),
                }),
            });

            const text = await response.text();
            let data;

            try {
                data = JSON.parse(text);
            } catch (parseError) {
                console.error('Email enrich response:', text);
                return;
            }

            if (!data.success) {
                return;
            }

            Object.entries(data.emails || {}).forEach(([placeId, email]) => {
                updatePlaceEmail(placeId, email);
            });

            withWebsites.forEach((place) => {
                if (place.email_pending) {
                    updatePlaceEmail(place.id, null);
                }
            });
        } catch (err) {
            withWebsites.forEach((place) => {
                updatePlaceEmail(place.id, null);
            });
        }
    }

    async function performSearch(query) {
        setLoading(true);

        try {
            const url = `${apiUrl('api/search.php')}?q=${encodeURIComponent(query)}&extract_emails=0`;
            const response = await fetch(url);
            const text = await response.text();
            let data;

            try {
                data = JSON.parse(text);
            } catch (parseError) {
                throw new Error('Server returned an invalid response. Ensure Apache and PHP are running.');
            }

            if (!data.success) {
                resultsList.innerHTML = `<div class="status-message error">${escapeHtml(data.error || 'Search failed.')}</div>`;
                resultsCount.textContent = 'Error';
                setDownloadEnabled(false);
                return;
            }

            renderResults(data.results || [], data.search_area || null);
            fetchEmails(currentPlaces);
        } catch (err) {
            resultsList.innerHTML = `<div class="status-message error">${escapeHtml(err.message || 'Network error. Check that Apache, PHP, and cURL are enabled in XAMPP.')}</div>`;
            resultsCount.textContent = 'Error';
            setDownloadEnabled(false);
        } finally {
            setLoading(false);
        }
    }

    if (downloadBtn) {
        downloadBtn.addEventListener('click', downloadExcel);
    }

    searchForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const query = searchInput.value.trim();

        if (!query) {
            return;
        }

        performSearch(query);
    });

    window.initApp = function () {
        initMap();

        const defaultQuery = searchInput.value.trim();
        if (defaultQuery) {
            performSearch(defaultQuery);
        }
    };
})();
