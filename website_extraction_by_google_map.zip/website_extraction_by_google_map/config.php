<?php
/**
 * Google Maps / Places API configuration.
 * Replace YOUR_GOOGLE_API_KEY_HERE with your key from Google Cloud Console.
 */
define('GOOGLE_API_KEY', 'AIzaSyA5WnNakJcnkzhCT9RxzAyJqMuFBK1se48');

define('DEFAULT_MAP_LAT', 28.6139);
define('DEFAULT_MAP_LNG', 77.2090);
define('DEFAULT_MAP_ZOOM', 12);
