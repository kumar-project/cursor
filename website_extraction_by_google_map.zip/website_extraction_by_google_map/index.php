<?php
require_once __DIR__ . '/config.php';

$apiKeyConfigured = defined('GOOGLE_API_KEY')
    && GOOGLE_API_KEY !== ''
    && GOOGLE_API_KEY !== 'YOUR_GOOGLE_API_KEY_HERE';

$basePath = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Google Maps Location Search</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header class="app-header">
        <h1>Google Maps Location Search</h1>
        <p>Search businesses and places — view phone numbers, emails, and locations on the map.</p>

        <form class="search-bar" id="searchForm" role="search">
            <input
                type="search"
                id="searchInput"
                name="q"
                placeholder="e.g. restaurants in Delhi, hospitals near Mumbai"
                autocomplete="off"
                required
            >
            <button type="submit" id="searchBtn">Search</button>
        </form>

        <?php if (!$apiKeyConfigured): ?>
        <div class="api-notice">
            API key not set. Open <strong>config.php</strong> and replace
            <code>YOUR_GOOGLE_API_KEY_HERE</code> with your Google Cloud API key.
            Enable <strong>Maps JavaScript API</strong>, <strong>Places API (New)</strong>, and <strong>Geocoding API</strong>.
        </div>
        <?php endif; ?>
    </header>

    <main class="main-layout">
        <div id="map" aria-label="Google Map"></div>

        <aside class="results-panel">
            <div class="results-header">
                <div class="results-header-top">
                    <h2>Search Results</h2>
                    <button type="button" id="downloadBtn" class="download-btn" disabled>
                        Download Excel
                    </button>
                </div>
                <p class="results-count" id="resultsCount">Enter a search to begin</p>
                <p class="map-coords" id="mapCoords">Lat: —, Lng: —</p>
            </div>
            <div class="results-list" id="resultsList">
                <div class="status-message">
                    Search for restaurants, shops, offices, or any place on Google Maps.
                    Phone numbers come from Google; emails are extracted from business websites when available.
                </div>
            </div>
            <div class="info-footer">
                Google does not provide email addresses directly — we scan the business website when listed.
            </div>
        </aside>
    </main>

    <script>
        window.APP_CONFIG = {
            apiBase: <?= json_encode($basePath) ?>,
            defaultLat: <?= json_encode((float) DEFAULT_MAP_LAT) ?>,
            defaultLng: <?= json_encode((float) DEFAULT_MAP_LNG) ?>,
            defaultZoom: <?= json_encode((int) DEFAULT_MAP_ZOOM) ?>,
        };
    </script>
    <script src="assets/js/app.js"></script>
    <?php if ($apiKeyConfigured): ?>
    <script
        async
        defer
        src="https://maps.googleapis.com/maps/api/js?key=<?= htmlspecialchars(GOOGLE_API_KEY, ENT_QUOTES, 'UTF-8') ?>&callback=initApp"
    ></script>
    <?php else: ?>
    <script>
        document.getElementById('resultsList').innerHTML =
            '<div class="status-message error">Configure your Google API key in config.php to load the map.</div>';
    </script>
    <?php endif; ?>
</body>
</html>
