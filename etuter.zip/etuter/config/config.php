<?php

return [
    'google_cloud' => [
        'project_id' => getenv('GOOGLE_CLOUD_PROJECT_ID') ?: '',
        'credentials_path' => getenv('GOOGLE_CLOUD_CREDENTIALS_PATH') ?: '',
    ],
    'nlp_cloud' => [
        'api_key' => getenv('NLP_CLOUD_API_KEY') ?: '',
        'model' => getenv('NLP_CLOUD_MODEL') ?: 'paraphrase-multilingual-MiniLM-L12-v2',
    ],
    'azure_speech' => [
        'key' => getenv('AZURE_SPEECH_KEY') ?: '',
        'region' => getenv('AZURE_SPEECH_REGION') ?: '',
    ],
    'rev_ai' => [
        'api_key' => getenv('REV_AI_API_KEY') ?: '',
    ],
    'upload' => [
        'max_size' => (int)(getenv('UPLOAD_MAX_SIZE') ?: 10485760), // 10MB default
        'allowed_types' => explode(',', getenv('ALLOWED_AUDIO_TYPES') ?: 'audio/wav,audio/mp3,audio/webm,audio/ogg,audio/flac'),
        'upload_dir' => __DIR__ . '/../uploads/',
    ],
];
