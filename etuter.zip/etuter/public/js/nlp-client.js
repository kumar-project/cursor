/**
 * NLP Client Library
 * Handles embeddings and similar text matching
 */

class NLPClient {
    constructor(apiBaseUrl = '') {
        this.apiBaseUrl = apiBaseUrl;
    }

    /**
     * Generate embeddings for text
     */
    async generateEmbeddings(text, model = null) {
        try {
            const payload = {
                text: text,
            };

            if (model) {
                payload.model = model;
            }

            const response = await fetch(`${this.apiBaseUrl}/api/embeddings.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload),
            });

            const result = await response.json();
            return result;
        } catch (error) {
            return {
                success: false,
                error: error.message || 'Embedding generation failed',
            };
        }
    }

    /**
     * Generate embeddings for multiple texts
     */
    async generateBatchEmbeddings(texts, model = null) {
        try {
            const payload = {
                texts: texts,
            };

            if (model) {
                payload.model = model;
            }

            const response = await fetch(`${this.apiBaseUrl}/api/embeddings.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload),
            });

            const result = await response.json();
            return result;
        } catch (error) {
            return {
                success: false,
                error: error.message || 'Batch embedding generation failed',
            };
        }
    }

    /**
     * Find similar texts
     */
    async findSimilarTexts(queryText, candidateTexts, threshold = 0.7) {
        try {
            const payload = {
                query_text: queryText,
                candidate_texts: candidateTexts,
                threshold: threshold,
            };

            const response = await fetch(`${this.apiBaseUrl}/api/similar-texts.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload),
            });

            const result = await response.json();
            return result;
        } catch (error) {
            return {
                success: false,
                error: error.message || 'Similar text search failed',
            };
        }
    }
}

// Export for use in modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = NLPClient;
}
