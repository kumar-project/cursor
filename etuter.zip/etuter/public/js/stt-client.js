/**
 * Speech-to-Text Client Library
 * Handles audio recording and API communication
 */

class STTClient {
    constructor(apiBaseUrl = '') {
        this.apiBaseUrl = apiBaseUrl;
        this.mediaRecorder = null;
        this.audioChunks = [];
        this.isRecording = false;
    }

    /**
     * Initialize audio recording
     */
    async initializeRecording() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                audio: {
                    channelCount: 1,
                    sampleRate: 16000,
                    echoCancellation: true,
                    noiseSuppression: true,
                }
            });

            // Use MediaRecorder API
            const options = {
                mimeType: 'audio/webm;codecs=opus',
            };

            // Fallback to default if webm not supported
            if (!MediaRecorder.isTypeSupported(options.mimeType)) {
                options.mimeType = 'audio/webm';
            }

            this.mediaRecorder = new MediaRecorder(stream, options);
            
            this.audioChunks = [];
            
            this.mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) {
                    this.audioChunks.push(event.data);
                }
            };

            return { success: true, stream };
        } catch (error) {
            return {
                success: false,
                error: error.message || 'Failed to access microphone',
            };
        }
    }

    /**
     * Start recording
     */
    startRecording() {
        if (!this.mediaRecorder) {
            throw new Error('Recording not initialized. Call initializeRecording() first.');
        }

        if (this.isRecording) {
            return { success: false, error: 'Already recording' };
        }

        this.audioChunks = [];
        this.mediaRecorder.start();
        this.isRecording = true;

        return { success: true };
    }

    /**
     * Stop recording and get audio blob
     */
    stopRecording() {
        return new Promise((resolve) => {
            if (!this.isRecording) {
                resolve({ success: false, error: 'Not currently recording' });
                return;
            }

            this.mediaRecorder.onstop = () => {
                const audioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });
                this.isRecording = false;
                
                resolve({
                    success: true,
                    audioBlob: audioBlob,
                });
            };

            this.mediaRecorder.stop();
        });
    }

    /**
     * Convert blob to base64
     */
    blobToBase64(blob) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                const base64data = reader.result;
                resolve(base64data);
            };
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });
    }

    /**
     * Transcribe audio
     */
    async transcribe(audioBlob, options = {}) {
        try {
            const formData = new FormData();
            formData.append('audio', audioBlob, 'recording.webm');
            formData.append('language', options.language || 'en-US');
            formData.append('provider', options.provider || 'google');
            formData.append('punctuation', options.punctuation !== false);
            formData.append('word_timestamps', options.word_timestamps !== false);

            const response = await fetch(`${this.apiBaseUrl}/api/transcribe.php`, {
                method: 'POST',
                body: formData,
            });

            const result = await response.json();
            return result;
        } catch (error) {
            return {
                success: false,
                error: error.message || 'Transcription request failed',
            };
        }
    }

    /**
     * Transcribe audio using base64 (alternative method)
     */
    async transcribeBase64(audioBlob, options = {}) {
        try {
            const base64Data = await this.blobToBase64(audioBlob);
            
            const formData = new FormData();
            formData.append('audio_data', base64Data);
            formData.append('format', 'webm');
            formData.append('language', options.language || 'en-US');
            formData.append('provider', options.provider || 'google');
            formData.append('punctuation', options.punctuation !== false);
            formData.append('word_timestamps', options.word_timestamps !== false);

            const response = await fetch(`${this.apiBaseUrl}/api/transcribe.php`, {
                method: 'POST',
                body: formData,
            });

            const result = await response.json();
            return result;
        } catch (error) {
            return {
                success: false,
                error: error.message || 'Transcription request failed',
            };
        }
    }

    /**
     * Get pronunciation score
     */
    async getPronunciationScore(audioBlob, referenceText, options = {}) {
        try {
            const formData = new FormData();
            formData.append('audio', audioBlob, 'recording.webm');
            formData.append('reference_text', referenceText);
            formData.append('language', options.language || 'en-US');
            formData.append('grading_system', options.grading_system || 'HundredMark');
            formData.append('dimension', options.dimension || 'Comprehensive');

            const response = await fetch(`${this.apiBaseUrl}/api/pronunciation-score.php`, {
                method: 'POST',
                body: formData,
            });

            const result = await response.json();
            return result;
        } catch (error) {
            return {
                success: false,
                error: error.message || 'Pronunciation scoring request failed',
            };
        }
    }

    /**
     * Stop all tracks (cleanup)
     */
    stopAllTracks() {
        if (this.mediaRecorder && this.mediaRecorder.stream) {
            this.mediaRecorder.stream.getTracks().forEach(track => track.stop());
        }
    }
}

// Export for use in modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = STTClient;
}
