# Installation Guide

## Quick Start

1. **Install Composer dependencies**
   ```bash
   composer install
   ```

2. **Set up environment variables**
   - Copy `config.env.example` to `.env` in the root directory
   - Fill in your API credentials

3. **Create uploads directory** (if not exists)
   ```bash
   mkdir uploads
   chmod 755 uploads
   ```

4. **Configure web server**
   - Point document root to `public/` directory, OR
   - Configure URL rewriting to route `/api/*` to `api/*`

## Detailed Setup

### Step 1: Install PHP Dependencies

Make sure you have Composer installed, then run:

```bash
composer install
```

This will install:
- `guzzlehttp/guzzle` - HTTP client for API requests
- `vlucas/phpdotenv` - Environment variable management

### Step 2: Configure API Credentials

Create a `.env` file in the root directory:

```bash
cp config.env.example .env
```

Edit `.env` and add your API credentials:

#### Google Cloud Speech-to-Text
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing
3. Enable the Speech-to-Text API
4. Create a service account and download the JSON key file
5. Set `GOOGLE_CLOUD_PROJECT_ID` to your project ID
6. Set `GOOGLE_CLOUD_CREDENTIALS_PATH` to the path of your credentials JSON file

#### Microsoft Azure Speech Service (for pronunciation scoring)
1. Go to [Azure Portal](https://portal.azure.com/)
2. Create a Speech resource
3. Copy the API key and region
4. Set `AZURE_SPEECH_KEY` and `AZURE_SPEECH_REGION` in `.env`

#### NLP Cloud (for embeddings)
1. Sign up at [NLP Cloud](https://nlpcloud.io/)
2. Get your API key from the dashboard
3. Set `NLP_CLOUD_API_KEY` in `.env`

#### Rev AI (optional alternative STT provider)
1. Sign up at [Rev AI](https://rev.ai/)
2. Get your API key
3. Set `REV_AI_API_KEY` in `.env`

### Step 3: Set Up Upload Directory

The API needs a directory to temporarily store uploaded audio files:

```bash
mkdir uploads
chmod 755 uploads  # On Linux/Mac
```

On Windows, ensure the directory has write permissions.

### Step 4: Configure Web Server

#### Option A: Apache with .htaccess

If using Apache, the included `.htaccess` file should handle routing. Ensure:
- `mod_rewrite` is enabled
- `.htaccess` files are allowed
- Document root points to the project root

#### Option B: Nginx

Add to your Nginx configuration:

```nginx
location /api/ {
    try_files $uri $uri/ /api/$uri.php?$query_string;
}

location / {
    root /path/to/etuter/public;
    try_files $uri $uri/ /index.html;
}
```

#### Option C: PHP Built-in Server (Development)

For development/testing:

```bash
php -S localhost:8000 -t public
```

Then access: `http://localhost:8000`

### Step 5: Test the Installation

1. Open `public/index.html` in your browser
2. Click "Initialize Recording" and allow microphone access
3. Test the transcription feature

## Troubleshooting

### "Class not found" errors
- Run `composer install` to ensure dependencies are installed
- Check that `vendor/autoload.php` exists

### "Environment variable not found" errors
- Ensure `.env` file exists in the root directory
- Check that `vlucas/phpdotenv` is installed
- Verify `.env` file syntax (no spaces around `=`)

### Upload errors
- Check `uploads/` directory exists and is writable
- Verify `UPLOAD_MAX_SIZE` in `.env` matches PHP `upload_max_filesize`
- Check PHP `post_max_size` is sufficient

### API authentication errors
- Verify API keys are correct in `.env`
- Check API service status (Google Cloud, Azure, etc.)
- Ensure credentials file path is correct (for Google Cloud)

### CORS errors
- Adjust CORS headers in `src/Utils/ResponseHelper.php` if needed
- For production, replace `*` with specific allowed origins

## Production Deployment

### Security Considerations

1. **Environment Variables**: Never commit `.env` to version control
2. **API Keys**: Rotate keys regularly
3. **File Uploads**: Implement additional validation and virus scanning
4. **Rate Limiting**: Add rate limiting to prevent abuse
5. **HTTPS**: Always use HTTPS in production
6. **Error Handling**: Don't expose sensitive error details to clients

### Performance Optimization

1. **Caching**: Implement caching for embeddings and similar text results
2. **Queue System**: Use a job queue for long-running transcriptions
3. **CDN**: Serve static assets via CDN
4. **Database**: Store transcripts and embeddings in a database for reuse

### Monitoring

- Set up logging for API requests
- Monitor API usage and costs
- Track error rates and response times
- Set up alerts for API failures
