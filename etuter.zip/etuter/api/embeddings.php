<?php

require_once __DIR__ . '/../vendor/autoload.php';

use Dotenv\Dotenv;
use Etuter\STT\Services\NLPEmbeddingService;
use Etuter\STT\Utils\ResponseHelper;

// Load environment variables
$dotenv = Dotenv::createImmutable(__DIR__ . '/..');
$dotenv->load();

// Load configuration
$config = require __DIR__ . '/../config/config.php';

// Handle CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ResponseHelper::success();
}

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    ResponseHelper::error('Method not allowed', 405);
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        $input = $_POST;
    }

    if (empty($input['text']) && empty($input['texts'])) {
        ResponseHelper::error('Text or texts parameter is required');
    }

    $embeddingService = new NLPEmbeddingService($config);
    $model = $input['model'] ?? null;

    // Handle single text
    if (!empty($input['text'])) {
        $result = $embeddingService->generateEmbeddings($input['text'], $model);
        
        if (!$result['success']) {
            ResponseHelper::error($result['error'] ?? 'Failed to generate embeddings');
        }

        ResponseHelper::success([
            'embeddings' => $result['embeddings'],
            'dimension' => $result['dimension'],
        ]);
    }

    // Handle multiple texts
    if (!empty($input['texts']) && is_array($input['texts'])) {
        $result = $embeddingService->generateBatchEmbeddings($input['texts'], $model);
        
        if (!$result['success']) {
            ResponseHelper::error($result['error'] ?? 'Failed to generate embeddings');
        }

        ResponseHelper::success([
            'embeddings' => $result['embeddings'],
        ]);
    }

} catch (\Exception $e) {
    ResponseHelper::error($e->getMessage(), 500);
}
