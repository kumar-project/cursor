<?php

require_once __DIR__ . '/../vendor/autoload.php';

use Dotenv\Dotenv;
use Etuter\STT\Services\NLPEmbeddingService;
use Etuter\STT\Utils\ResponseHelper;

// Load environment variables
$dotenv = Dotenv::createImmutable(__DIR__ . '/..');
$dotenv->load();

// Load configuration
$config = require __DIR__ . '/../config/config.php';

// Handle CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ResponseHelper::success();
}

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    ResponseHelper::error('Method not allowed', 405);
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        $input = $_POST;
    }

    if (empty($input['query_text'])) {
        ResponseHelper::error('query_text parameter is required');
    }

    if (empty($input['candidate_texts']) || !is_array($input['candidate_texts'])) {
        ResponseHelper::error('candidate_texts parameter is required and must be an array');
    }

    $embeddingService = new NLPEmbeddingService($config);
    $threshold = isset($input['threshold']) ? (float)$input['threshold'] : 0.7;

    $result = $embeddingService->findSimilarTexts(
        $input['query_text'],
        $input['candidate_texts'],
        $threshold
    );

    if (!$result['success']) {
        ResponseHelper::error($result['error'] ?? 'Failed to find similar texts');
    }

    ResponseHelper::success([
        'results' => $result['results'],
    ]);

} catch (\Exception $e) {
    ResponseHelper::error($e->getMessage(), 500);
}
