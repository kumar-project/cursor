<?php

require_once __DIR__ . '/../vendor/autoload.php';

use Dotenv\Dotenv;
use Etuter\STT\Services\STTService;
use Etuter\STT\Utils\FileUploadHandler;
use Etuter\STT\Utils\ResponseHelper;

// Load environment variables
$dotenv = Dotenv::createImmutable(__DIR__ . '/..');
$dotenv->load();

// Load configuration
$config = require __DIR__ . '/../config/config.php';

// Handle CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ResponseHelper::success();
}

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    ResponseHelper::error('Method not allowed', 405);
}

try {
    // Handle file upload
    $uploadHandler = new FileUploadHandler($config);
    
    $uploadResult = null;
    
    // Check if audio is sent as base64
    if (isset($_POST['audio_data']) && !empty($_POST['audio_data'])) {
        $format = $_POST['format'] ?? 'webm';
        $uploadResult = $uploadHandler->handleBase64Audio($_POST['audio_data'], $format);
    } elseif (isset($_FILES['audio'])) {
        $uploadResult = $uploadHandler->handleUpload($_FILES);
    } else {
        ResponseHelper::error('No audio file provided');
    }

    if (!$uploadResult['success']) {
        ResponseHelper::error($uploadResult['error'] ?? 'Upload failed');
    }

    // Get transcription options
    $options = [
        'language' => $_POST['language'] ?? 'en-US',
        'sample_rate' => isset($_POST['sample_rate']) ? (int)$_POST['sample_rate'] : 16000,
        'punctuation' => isset($_POST['punctuation']) ? filter_var($_POST['punctuation'], FILTER_VALIDATE_BOOLEAN) : true,
        'word_timestamps' => isset($_POST['word_timestamps']) ? filter_var($_POST['word_timestamps'], FILTER_VALIDATE_BOOLEAN) : true,
        'model' => $_POST['model'] ?? 'default',
    ];

    // Select provider
    $provider = $_POST['provider'] ?? 'google';
    
    // Initialize STT service
    $sttService = new STTService($config, $provider);
    
    // Transcribe audio
    $transcriptionResult = $sttService->transcribe($uploadResult['file_path'], $options);

    // Cleanup uploaded file
    $uploadHandler->cleanup($uploadResult['file_path']);

    if (!$transcriptionResult['success']) {
        ResponseHelper::error($transcriptionResult['error'] ?? 'Transcription failed');
    }

    // Return transcription result
    ResponseHelper::success([
        'transcript' => $transcriptionResult['transcript'] ?? '',
        'confidence' => $transcriptionResult['confidence'] ?? 0,
        'words' => $transcriptionResult['words'] ?? [],
        'provider' => $transcriptionResult['provider'] ?? $provider,
    ]);

} catch (\Exception $e) {
    ResponseHelper::error($e->getMessage(), 500);
}
