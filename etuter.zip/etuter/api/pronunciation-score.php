<?php

require_once __DIR__ . '/../vendor/autoload.php';

use Dotenv\Dotenv;
use Etuter\STT\Services\PronunciationScoringService;
use Etuter\STT\Services\STTService;
use Etuter\STT\Utils\FileUploadHandler;
use Etuter\STT\Utils\ResponseHelper;

// Load environment variables
$dotenv = Dotenv::createImmutable(__DIR__ . '/..');
$dotenv->load();

// Load configuration
$config = require __DIR__ . '/../config/config.php';

// Handle CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ResponseHelper::success();
}

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    ResponseHelper::error('Method not allowed', 405);
}

try {
    if (empty($_POST['reference_text'])) {
        ResponseHelper::error('reference_text parameter is required');
    }

    $referenceText = $_POST['reference_text'];
    $options = [
        'language' => $_POST['language'] ?? 'en-US',
        'grading_system' => $_POST['grading_system'] ?? 'HundredMark',
        'dimension' => $_POST['dimension'] ?? 'Comprehensive',
        'enable_miscue' => isset($_POST['enable_miscue']) ? filter_var($_POST['enable_miscue'], FILTER_VALIDATE_BOOLEAN) : true,
    ];

    // Handle file upload
    $uploadHandler = new FileUploadHandler($config);
    
    $uploadResult = null;
    
    // Check if audio is sent as base64
    if (isset($_POST['audio_data']) && !empty($_POST['audio_data'])) {
        $format = $_POST['format'] ?? 'webm';
        $uploadResult = $uploadHandler->handleBase64Audio($_POST['audio_data'], $format);
    } elseif (isset($_FILES['audio'])) {
        $uploadResult = $uploadHandler->handleUpload($_FILES);
    } else {
        ResponseHelper::error('No audio file provided');
    }

    if (!$uploadResult['success']) {
        ResponseHelper::error($uploadResult['error'] ?? 'Upload failed');
    }

    $pronunciationService = new PronunciationScoringService($config);

    // Try to use Azure Speech Service for advanced scoring
    try {
        $scoreResult = $pronunciationService->scorePronunciation(
            $uploadResult['file_path'],
            $referenceText,
            $options
        );
    } catch (\Exception $e) {
        // Fallback to basic scoring if Azure is not configured
        // First, transcribe the audio
        $sttService = new STTService($config);
        $transcriptionResult = $sttService->transcribe($uploadResult['file_path'], [
            'language' => $options['language'],
        ]);

        if (!$transcriptionResult['success']) {
            $uploadHandler->cleanup($uploadResult['file_path']);
            ResponseHelper::error('Failed to transcribe audio for pronunciation scoring');
        }

        // Use basic scoring
        $scoreResult = $pronunciationService->basicPronunciationScore(
            $transcriptionResult['transcript'] ?? '',
            $referenceText
        );
    }

    // Cleanup uploaded file
    $uploadHandler->cleanup($uploadResult['file_path']);

    if (!$scoreResult['success']) {
        ResponseHelper::error($scoreResult['error'] ?? 'Pronunciation scoring failed');
    }

    ResponseHelper::success([
        'overall_score' => $scoreResult['overall_score'] ?? 0,
        'accuracy_score' => $scoreResult['accuracy_score'] ?? 0,
        'fluency_score' => $scoreResult['fluency_score'] ?? 0,
        'completeness_score' => $scoreResult['completeness_score'] ?? 0,
        'words' => $scoreResult['words'] ?? [],
        'provider' => $scoreResult['provider'] ?? 'basic',
    ]);

} catch (\Exception $e) {
    ResponseHelper::error($e->getMessage(), 500);
}
