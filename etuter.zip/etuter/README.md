# Speech-to-Text API with NLP Embeddings & Pronunciation Scoring

A comprehensive PHP-based Speech-to-Text (STT) API solution with advanced features including NLP embeddings and pronunciation scoring. This solution integrates with external cloud APIs to provide powerful speech recognition and natural language processing capabilities.

## Features

- 🎤 **Audio Transcription**: Convert speech to text using Google Cloud Speech-to-Text or Rev AI
- 📊 **Pronunciation Scoring**: Evaluate pronunciation accuracy using Microsoft Azure Speech Service
- 🔍 **NLP Embeddings**: Generate semantic embeddings for text using NLP Cloud API
- 🎯 **Similar Text Matching**: Find semantically similar texts using cosine similarity on embeddings
- 🌐 **RESTful API**: Clean, well-structured API endpoints
- 💻 **Client Library**: JavaScript client for easy browser integration

## Architecture

The solution follows a client-server architecture:

- **Client-Side**: JavaScript captures audio using Web Media Streams API and sends it to the PHP backend
- **Server-Side**: PHP backend acts as an intermediary, forwarding audio to specialized cloud APIs
- **External APIs**: Google Cloud Speech-to-Text, Microsoft Azure Speech Service, NLP Cloud, Rev AI

## Requirements

- PHP 7.4 or higher
- Composer (PHP dependency manager)
- Web server (Apache/Nginx) with PHP support
- API credentials for:
  - Google Cloud Speech-to-Text (or Rev AI)
  - Microsoft Azure Speech Service (for pronunciation scoring)
  - NLP Cloud (for embeddings)

## Installation

1. **Clone or download the project**

```bash
cd etuter
```

2. **Install dependencies**

```bash
composer install
```

3. **Configure environment variables**

Create a `.env` file in the root directory (copy from `.env.example`):

```env
# Google Cloud Speech-to-Text API
GOOGLE_CLOUD_PROJECT_ID=your-project-id
GOOGLE_CLOUD_CREDENTIALS_PATH=path/to/credentials.json

# NLP Cloud API (for embeddings)
NLP_CLOUD_API_KEY=your-nlp-cloud-api-key
NLP_CLOUD_MODEL=paraphrase-multilingual-MiniLM-L12-v2

# Microsoft Azure Speech Service (for pronunciation scoring)
AZURE_SPEECH_KEY=your-azure-speech-key
AZURE_SPEECH_REGION=your-azure-region

# Rev AI (alternative STT service)
REV_AI_API_KEY=your-rev-ai-key

# Application Settings
UPLOAD_MAX_SIZE=10485760
ALLOWED_AUDIO_TYPES=audio/wav,audio/mp3,audio/webm,audio/ogg,audio/flac
API_BASE_URL=http://localhost/etuter
```

4. **Set up upload directory**

Ensure the `uploads/` directory exists and is writable:

```bash
mkdir uploads
chmod 755 uploads
```

5. **Configure web server**

Point your web server document root to the `public/` directory, or configure URL rewriting to route API requests to the `api/` directory.

## API Endpoints

### 1. Transcribe Audio

**Endpoint**: `POST /api/transcribe.php`

**Request**:
- `audio` (file): Audio file to transcribe
- `language` (optional): Language code (default: `en-US`)
- `provider` (optional): STT provider (`google` or `rev`, default: `google`)
- `punctuation` (optional): Enable punctuation (default: `true`)
- `word_timestamps` (optional): Include word timestamps (default: `true`)

**Response**:
```json
{
  "success": true,
  "transcript": "Hello, how are you?",
  "confidence": 0.95,
  "words": [
    {
      "word": "Hello",
      "start_time": 0.0,
      "end_time": 0.5,
      "confidence": 0.98
    }
  ],
  "provider": "google_cloud"
}
```

### 2. Generate Embeddings

**Endpoint**: `POST /api/embeddings.php`

**Request** (JSON):
```json
{
  "text": "Hello, how are you?",
  "model": "paraphrase-multilingual-MiniLM-L12-v2"
}
```

**Response**:
```json
{
  "success": true,
  "embeddings": [0.123, -0.456, ...],
  "dimension": 384
}
```

### 3. Find Similar Texts

**Endpoint**: `POST /api/similar-texts.php`

**Request** (JSON):
```json
{
  "query_text": "How are you?",
  "candidate_texts": [
    "Hello, how are you?",
    "What's the weather like?",
    "How do you do?"
  ],
  "threshold": 0.7
}
```

**Response**:
```json
{
  "success": true,
  "results": [
    {
      "text": "Hello, how are you?",
      "similarity": 0.95,
      "index": 0
    }
  ]
}
```

### 4. Pronunciation Scoring

**Endpoint**: `POST /api/pronunciation-score.php`

**Request**:
- `audio` (file): Audio file to score
- `reference_text`: Expected text
- `language` (optional): Language code (default: `en-US`)
- `grading_system` (optional): Grading system (default: `HundredMark`)
- `dimension` (optional): Assessment dimension (default: `Comprehensive`)

**Response**:
```json
{
  "success": true,
  "overall_score": 85.5,
  "accuracy_score": 88.0,
  "fluency_score": 82.0,
  "completeness_score": 86.0,
  "words": [
    {
      "word": "Hello",
      "accuracy_score": 90,
      "error_type": "None"
    }
  ],
  "provider": "azure_speech"
}
```

## Client-Side Usage

### JavaScript Client Library

Include the client libraries in your HTML:

```html
<script src="js/stt-client.js"></script>
<script src="js/nlp-client.js"></script>
```

### Example: Transcribe Audio

```javascript
const sttClient = new STTClient('http://your-api-url');

// Initialize recording
await sttClient.initializeRecording();

// Start recording
sttClient.startRecording();

// Stop recording and get blob
const result = await sttClient.stopRecording();
const audioBlob = result.audioBlob;

// Transcribe
const transcription = await sttClient.transcribe(audioBlob, {
  language: 'en-US',
  punctuation: true
});

console.log(transcription.transcript);
```

### Example: Pronunciation Scoring

```javascript
const score = await sttClient.getPronunciationScore(
  audioBlob,
  "Hello, how are you?",
  { language: 'en-US' }
);

console.log(score.overall_score);
```

### Example: Find Similar Texts

```javascript
const nlpClient = new NLPClient('http://your-api-url');

const result = await nlpClient.findSimilarTexts(
  "How are you?",
  ["Hello, how are you?", "What's up?", "Good morning"],
  0.7
);

console.log(result.results);
```

## Demo

A complete demo is available in `public/index.html`. Open it in a browser to test all features:

1. **Audio Transcription**: Record and transcribe audio
2. **Pronunciation Scoring**: Record audio and compare against reference text
3. **Similar Text Matching**: Find semantically similar texts

## Project Structure

```
etuter/
├── api/                    # API endpoints
│   ├── transcribe.php
│   ├── embeddings.php
│   ├── similar-texts.php
│   └── pronunciation-score.php
├── config/                 # Configuration files
│   └── config.php
├── public/                 # Public web files
│   ├── index.html         # Demo page
│   └── js/                # Client libraries
│       ├── stt-client.js
│       └── nlp-client.js
├── src/                   # Source code
│   ├── Services/         # Service classes
│   │   ├── STTService.php
│   │   ├── NLPEmbeddingService.php
│   │   └── PronunciationScoringService.php
│   └── Utils/            # Utility classes
│       ├── FileUploadHandler.php
│       └── ResponseHelper.php
├── uploads/              # Temporary audio uploads
├── vendor/               # Composer dependencies
├── composer.json
├── .env.example
└── README.md
```

## Configuration

### Google Cloud Speech-to-Text

1. Create a project in Google Cloud Console
2. Enable Speech-to-Text API
3. Create a service account and download credentials JSON
4. Set `GOOGLE_CLOUD_PROJECT_ID` and `GOOGLE_CLOUD_CREDENTIALS_PATH` in `.env`

### Microsoft Azure Speech Service

1. Create a Speech resource in Azure Portal
2. Get your API key and region
3. Set `AZURE_SPEECH_KEY` and `AZURE_SPEECH_REGION` in `.env`

### NLP Cloud

1. Sign up at https://nlpcloud.io
2. Get your API key
3. Set `NLP_CLOUD_API_KEY` in `.env`

### Rev AI (Alternative)

1. Sign up at https://rev.ai
2. Get your API key
3. Set `REV_AI_API_KEY` in `.env`

## Notes

- **Authentication**: The current Google Cloud implementation uses a simplified approach. For production, use the official `google/cloud-speech` PHP client library with proper OAuth2 or service account authentication.

- **File Cleanup**: Uploaded audio files are automatically cleaned up after processing. Ensure the `uploads/` directory has proper write permissions.

- **CORS**: The API includes CORS headers for cross-origin requests. Adjust as needed for your security requirements.

- **Error Handling**: All endpoints return consistent JSON error responses with appropriate HTTP status codes.

## License

This project is provided as-is for educational and development purposes.

## Support

For issues or questions, please refer to the documentation of the respective cloud APIs:
- [Google Cloud Speech-to-Text](https://cloud.google.com/speech-to-text/docs)
- [Microsoft Azure Speech Service](https://docs.microsoft.com/azure/cognitive-services/speech-service/)
- [NLP Cloud](https://docs.nlpcloud.io/)
- [Rev AI](https://docs.rev.ai/)
