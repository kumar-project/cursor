<?php

namespace Etuter\STT\Services;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;

class STTService
{
    private $client;
    private $config;
    private $provider;

    public function __construct(array $config, string $provider = 'google')
    {
        $this->client = new Client();
        $this->config = $config;
        $this->provider = $provider;
    }

    /**
     * Transcribe audio file using Google Cloud Speech-to-Text
     */
    public function transcribeGoogleCloud(string $audioPath, array $options = []): array
    {
        $projectId = $this->config['google_cloud']['project_id'] ?? '';
        
        if (empty($projectId)) {
            throw new \Exception('Google Cloud Project ID not configured');
        }

        $audioContent = base64_encode(file_get_contents($audioPath));
        $audioFormat = $this->detectAudioFormat($audioPath);
        
        $requestBody = [
            'config' => [
                'encoding' => $audioFormat['encoding'],
                'sampleRateHertz' => $options['sample_rate'] ?? 16000,
                'languageCode' => $options['language'] ?? 'en-US',
                'enableAutomaticPunctuation' => $options['punctuation'] ?? true,
                'enableWordTimeOffsets' => $options['word_timestamps'] ?? true,
                'model' => $options['model'] ?? 'default',
            ],
            'audio' => [
                'content' => $audioContent,
            ],
        ];

        try {
            // For Google Cloud, you would typically use their PHP client library
            // This is a simplified HTTP approach - in production, use google/cloud-speech
            $response = $this->client->post("https://speech.googleapis.com/v1/projects/{$projectId}/locations/global/recognize", [
                'headers' => [
                    'Authorization' => 'Bearer ' . $this->getGoogleAccessToken(),
                    'Content-Type' => 'application/json',
                ],
                'json' => $requestBody,
            ]);

            $result = json_decode($response->getBody()->getContents(), true);
            
            return [
                'success' => true,
                'transcript' => $result['results'][0]['alternatives'][0]['transcript'] ?? '',
                'confidence' => $result['results'][0]['alternatives'][0]['confidence'] ?? 0,
                'words' => $this->extractWords($result['results'][0]['alternatives'][0]['words'] ?? []),
                'provider' => 'google_cloud',
            ];
        } catch (GuzzleException $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }

    /**
     * Transcribe audio using Rev AI
     */
    public function transcribeRevAI(string $audioPath, array $options = []): array
    {
        $apiKey = $this->config['rev_ai']['api_key'] ?? '';
        
        if (empty($apiKey)) {
            throw new \Exception('Rev AI API key not configured');
        }

        try {
            // Upload audio file
            $uploadResponse = $this->client->post('https://api.rev.ai/speechtotext/v1/jobs', [
                'headers' => [
                    'Authorization' => 'Bearer ' . $apiKey,
                ],
                'multipart' => [
                    [
                        'name' => 'media',
                        'contents' => fopen($audioPath, 'r'),
                        'filename' => basename($audioPath),
                    ],
                    [
                        'name' => 'options',
                        'contents' => json_encode([
                            'language' => $options['language'] ?? 'en',
                            'remove_disfluencies' => $options['remove_disfluencies'] ?? true,
                        ]),
                    ],
                ],
            ]);

            $job = json_decode($uploadResponse->getBody()->getContents(), true);
            $jobId = $job['id'];

            // Poll for completion
            $maxAttempts = 60;
            $attempt = 0;
            while ($attempt < $maxAttempts) {
                sleep(2);
                $statusResponse = $this->client->get("https://api.rev.ai/speechtotext/v1/jobs/{$jobId}", [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $apiKey,
                    ],
                ]);

                $status = json_decode($statusResponse->getBody()->getContents(), true);
                
                if ($status['status'] === 'transcribed') {
                    // Get transcript
                    $transcriptResponse = $this->client->get("https://api.rev.ai/speechtotext/v1/jobs/{$jobId}/transcript", [
                        'headers' => [
                            'Authorization' => 'Bearer ' . $apiKey,
                            'Accept' => 'application/vnd.rev.transcript.v1.0+json',
                        ],
                    ]);

                    $transcript = json_decode($transcriptResponse->getBody()->getContents(), true);
                    
                    return [
                        'success' => true,
                        'transcript' => $transcript['monologues'][0]['elements'][0]['value'] ?? '',
                        'words' => $this->extractRevWords($transcript['monologues'][0]['elements'] ?? []),
                        'provider' => 'rev_ai',
                    ];
                }
                
                $attempt++;
            }

            return [
                'success' => false,
                'error' => 'Transcription timeout',
            ];
        } catch (GuzzleException $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }

    /**
     * Main transcription method that routes to the appropriate provider
     */
    public function transcribe(string $audioPath, array $options = []): array
    {
        switch ($this->provider) {
            case 'google':
                return $this->transcribeGoogleCloud($audioPath, $options);
            case 'rev':
                return $this->transcribeRevAI($audioPath, $options);
            default:
                return $this->transcribeGoogleCloud($audioPath, $options);
        }
    }

    private function detectAudioFormat(string $audioPath): array
    {
        $extension = strtolower(pathinfo($audioPath, PATHINFO_EXTENSION));
        
        $formats = [
            'wav' => ['encoding' => 'LINEAR16', 'mime' => 'audio/wav'],
            'mp3' => ['encoding' => 'MP3', 'mime' => 'audio/mp3'],
            'flac' => ['encoding' => 'FLAC', 'mime' => 'audio/flac'],
            'webm' => ['encoding' => 'WEBM_OPUS', 'mime' => 'audio/webm'],
            'ogg' => ['encoding' => 'OGG_OPUS', 'mime' => 'audio/ogg'],
        ];

        return $formats[$extension] ?? $formats['wav'];
    }

    private function extractWords(array $words): array
    {
        $result = [];
        foreach ($words as $word) {
            $result[] = [
                'word' => $word['word'] ?? '',
                'start_time' => $word['startTime'] ?? 0,
                'end_time' => $word['endTime'] ?? 0,
                'confidence' => $word['confidence'] ?? 0,
            ];
        }
        return $result;
    }

    private function extractRevWords(array $elements): array
    {
        $result = [];
        foreach ($elements as $element) {
            if (isset($element['type']) && $element['type'] === 'text') {
                $result[] = [
                    'word' => $element['value'] ?? '',
                    'start_time' => $element['ts'] ?? 0,
                    'end_time' => ($element['ts'] ?? 0) + ($element['end_ts'] ?? 0) - ($element['ts'] ?? 0),
                    'confidence' => $element['confidence'] ?? 0,
                ];
            }
        }
        return $result;
    }

    private function getGoogleAccessToken(): string
    {
        // In production, use Google's PHP client library for proper authentication
        // This is a placeholder - you should implement OAuth2 or service account authentication
        $credentialsPath = $this->config['google_cloud']['credentials_path'] ?? '';
        
        if (empty($credentialsPath) || !file_exists($credentialsPath)) {
            throw new \Exception('Google Cloud credentials file not found');
        }

        // Simplified token retrieval - use google/auth library in production
        return 'PLACEHOLDER_TOKEN';
    }
}
