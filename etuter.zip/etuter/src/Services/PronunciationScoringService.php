<?php

namespace Etuter\STT\Services;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;

class PronunciationScoringService
{
    private $client;
    private $config;

    public function __construct(array $config)
    {
        $this->client = new Client();
        $this->config = $config;
    }

    /**
     * Score pronunciation using Microsoft Azure Speech Service
     */
    public function scorePronunciation(string $audioPath, string $referenceText, array $options = []): array
    {
        $apiKey = $this->config['azure_speech']['key'] ?? '';
        $region = $this->config['azure_speech']['region'] ?? '';
        
        if (empty($apiKey) || empty($region)) {
            throw new \Exception('Azure Speech Service credentials not configured');
        }

        try {
            // Get access token
            $tokenResponse = $this->client->post("https://{$region}.api.cognitive.microsoft.com/sts/v1.0/issueToken", [
                'headers' => [
                    'Ocp-Apim-Subscription-Key' => $apiKey,
                ],
            ]);

            $accessToken = $tokenResponse->getBody()->getContents();

            // Prepare audio data
            $audioContent = file_get_contents($audioPath);
            $audioFormat = $this->detectAudioFormat($audioPath);

            // Pronunciation assessment endpoint
            $language = $options['language'] ?? 'en-US';
            $endpoint = "https://{$region}.stt.speech.microsoft.com/speech/recognition/conversation/cognitiveservices/v1?language={$language}";

            // For pronunciation assessment, we need to use the specific assessment API
            // This is a simplified version - Azure's pronunciation assessment requires specific parameters
            $requestBody = [
                'ReferenceText' => $referenceText,
                'GradingSystem' => $options['grading_system'] ?? 'HundredMark',
                'Dimension' => $options['dimension'] ?? 'Comprehensive',
                'EnableMiscue' => $options['enable_miscue'] ?? true,
            ];

            // Note: Azure's pronunciation assessment API has specific requirements
            // This is a conceptual implementation - actual API may differ
            $response = $this->client->post("https://{$region}.stt.speech.microsoft.com/speech/recognition/conversation/cognitiveservices/v1?language={$language}", [
                'headers' => [
                    'Authorization' => 'Bearer ' . $accessToken,
                    'Content-Type' => 'audio/wav; codecs=audio/pcm; samplerate=16000',
                    'Pronunciation-Assessment' => json_encode($requestBody),
                ],
                'body' => $audioContent,
            ]);

            $result = json_decode($response->getBody()->getContents(), true);
            
            return [
                'success' => true,
                'overall_score' => $result['PronunciationAssessment']['PronScore'] ?? 0,
                'accuracy_score' => $result['PronunciationAssessment']['AccuracyScore'] ?? 0,
                'fluency_score' => $result['PronunciationAssessment']['FluencyScore'] ?? 0,
                'completeness_score' => $result['PronunciationAssessment']['CompletenessScore'] ?? 0,
                'words' => $this->extractWordScores($result['Words'] ?? []),
                'provider' => 'azure_speech',
            ];
        } catch (GuzzleException $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }

    /**
     * Basic pronunciation scoring using word-level comparison
     * This is a fallback method when cloud services are not available
     */
    public function basicPronunciationScore(string $transcribedText, string $referenceText): array
    {
        $transcribedWords = $this->normalizeText($transcribedText);
        $referenceWords = $this->normalizeText($referenceText);

        $matchedWords = 0;
        $totalWords = count($referenceWords);
        $wordScores = [];

        foreach ($referenceWords as $index => $refWord) {
            $transcribedWord = $transcribedWords[$index] ?? '';
            $isMatch = strtolower($refWord) === strtolower($transcribedWord);
            
            if ($isMatch) {
                $matchedWords++;
            }

            $wordScores[] = [
                'reference' => $refWord,
                'transcribed' => $transcribedWord,
                'match' => $isMatch,
                'score' => $isMatch ? 100 : 0,
            ];
        }

        $overallScore = $totalWords > 0 ? ($matchedWords / $totalWords) * 100 : 0;

        return [
            'success' => true,
            'overall_score' => round($overallScore, 2),
            'accuracy_score' => round($overallScore, 2),
            'matched_words' => $matchedWords,
            'total_words' => $totalWords,
            'words' => $wordScores,
            'provider' => 'basic',
        ];
    }

    private function detectAudioFormat(string $audioPath): array
    {
        $extension = strtolower(pathinfo($audioPath, PATHINFO_EXTENSION));
        
        $formats = [
            'wav' => ['mime' => 'audio/wav', 'codec' => 'audio/pcm'],
            'mp3' => ['mime' => 'audio/mp3', 'codec' => 'audio/mp3'],
            'flac' => ['mime' => 'audio/flac', 'codec' => 'audio/flac'],
        ];

        return $formats[$extension] ?? $formats['wav'];
    }

    private function extractWordScores(array $words): array
    {
        $result = [];
        foreach ($words as $word) {
            $result[] = [
                'word' => $word['Word'] ?? '',
                'accuracy_score' => $word['PronunciationAssessment']['AccuracyScore'] ?? 0,
                'error_type' => $word['PronunciationAssessment']['ErrorType'] ?? 'None',
            ];
        }
        return $result;
    }

    private function normalizeText(string $text): array
    {
        // Remove punctuation and convert to lowercase
        $text = preg_replace('/[^\p{L}\p{N}\s]/u', '', $text);
        $words = explode(' ', strtolower(trim($text)));
        return array_filter($words, function($word) {
            return !empty($word);
        });
    }
}
