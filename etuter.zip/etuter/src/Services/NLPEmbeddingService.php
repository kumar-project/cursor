<?php

namespace Etuter\STT\Services;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;

class NLPEmbeddingService
{
    private $client;
    private $config;

    public function __construct(array $config)
    {
        $this->client = new Client();
        $this->config = $config;
    }

    /**
     * Generate embeddings for text using NLP Cloud API
     */
    public function generateEmbeddings(string $text, string $model = null): array
    {
        $apiKey = $this->config['nlp_cloud']['api_key'] ?? '';
        $model = $model ?? $this->config['nlp_cloud']['model'] ?? 'paraphrase-multilingual-MiniLM-L12-v2';
        
        if (empty($apiKey)) {
            throw new \Exception('NLP Cloud API key not configured');
        }

        try {
            $response = $this->client->post('https://api.nlpcloud.io/v1/' . $model . '/embeddings', [
                'headers' => [
                    'Authorization' => 'Token ' . $apiKey,
                    'Content-Type' => 'application/json',
                ],
                'json' => [
                    'sentences' => [$text],
                ],
            ]);

            $result = json_decode($response->getBody()->getContents(), true);
            
            return [
                'success' => true,
                'embeddings' => $result['embeddings'][0] ?? [],
                'dimension' => count($result['embeddings'][0] ?? []),
            ];
        } catch (GuzzleException $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }

    /**
     * Generate embeddings for multiple texts
     */
    public function generateBatchEmbeddings(array $texts, string $model = null): array
    {
        $apiKey = $this->config['nlp_cloud']['api_key'] ?? '';
        $model = $model ?? $this->config['nlp_cloud']['model'] ?? 'paraphrase-multilingual-MiniLM-L12-v2';
        
        if (empty($apiKey)) {
            throw new \Exception('NLP Cloud API key not configured');
        }

        try {
            $response = $this->client->post('https://api.nlpcloud.io/v1/' . $model . '/embeddings', [
                'headers' => [
                    'Authorization' => 'Token ' . $apiKey,
                    'Content-Type' => 'application/json',
                ],
                'json' => [
                    'sentences' => $texts,
                ],
            ]);

            $result = json_decode($response->getBody()->getContents(), true);
            
            return [
                'success' => true,
                'embeddings' => $result['embeddings'] ?? [],
            ];
        } catch (GuzzleException $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }

    /**
     * Calculate cosine similarity between two embeddings
     */
    public function cosineSimilarity(array $embedding1, array $embedding2): float
    {
        if (count($embedding1) !== count($embedding2)) {
            throw new \Exception('Embeddings must have the same dimension');
        }

        $dotProduct = 0;
        $norm1 = 0;
        $norm2 = 0;

        for ($i = 0; $i < count($embedding1); $i++) {
            $dotProduct += $embedding1[$i] * $embedding2[$i];
            $norm1 += $embedding1[$i] * $embedding1[$i];
            $norm2 += $embedding2[$i] * $embedding2[$i];
        }

        $norm1 = sqrt($norm1);
        $norm2 = sqrt($norm2);

        if ($norm1 == 0 || $norm2 == 0) {
            return 0;
        }

        return $dotProduct / ($norm1 * $norm2);
    }

    /**
     * Find similar texts by comparing embeddings
     */
    public function findSimilarTexts(string $queryText, array $candidateTexts, float $threshold = 0.7): array
    {
        $queryEmbedding = $this->generateEmbeddings($queryText);
        
        if (!$queryEmbedding['success']) {
            return [
                'success' => false,
                'error' => 'Failed to generate query embedding',
            ];
        }

        $candidateEmbeddings = $this->generateBatchEmbeddings($candidateTexts);
        
        if (!$candidateEmbeddings['success']) {
            return [
                'success' => false,
                'error' => 'Failed to generate candidate embeddings',
            ];
        }

        $results = [];
        foreach ($candidateEmbeddings['embeddings'] as $index => $candidateEmbedding) {
            $similarity = $this->cosineSimilarity($queryEmbedding['embeddings'], $candidateEmbedding);
            
            if ($similarity >= $threshold) {
                $results[] = [
                    'text' => $candidateTexts[$index],
                    'similarity' => $similarity,
                    'index' => $index,
                ];
            }
        }

        // Sort by similarity descending
        usort($results, function($a, $b) {
            return $b['similarity'] <=> $a['similarity'];
        });

        return [
            'success' => true,
            'results' => $results,
        ];
    }
}
