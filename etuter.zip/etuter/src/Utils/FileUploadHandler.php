<?php

namespace Etuter\STT\Utils;

class FileUploadHandler
{
    private $config;
    private $uploadDir;

    public function __construct(array $config)
    {
        $this->config = $config;
        $this->uploadDir = $config['upload']['upload_dir'] ?? __DIR__ . '/../../uploads/';
        
        // Create upload directory if it doesn't exist
        if (!is_dir($this->uploadDir)) {
            mkdir($this->uploadDir, 0755, true);
        }
    }

    /**
     * Handle uploaded audio file
     */
    public function handleUpload(array $file, string $fieldName = 'audio'): array
    {
        if (!isset($file[$fieldName])) {
            return [
                'success' => false,
                'error' => 'No file uploaded',
            ];
        }

        $uploadedFile = $file[$fieldName];

        // Check for upload errors
        if ($uploadedFile['error'] !== UPLOAD_ERR_OK) {
            return [
                'success' => false,
                'error' => $this->getUploadErrorMessage($uploadedFile['error']),
            ];
        }

        // Validate file size
        if ($uploadedFile['size'] > $this->config['upload']['max_size']) {
            return [
                'success' => false,
                'error' => 'File size exceeds maximum allowed size',
            ];
        }

        // Validate file type
        $mimeType = $uploadedFile['type'];
        $allowedTypes = $this->config['upload']['allowed_types'];
        
        if (!in_array($mimeType, $allowedTypes)) {
            return [
                'success' => false,
                'error' => 'Invalid file type. Allowed types: ' . implode(', ', $allowedTypes),
            ];
        }

        // Generate unique filename
        $extension = pathinfo($uploadedFile['name'], PATHINFO_EXTENSION);
        $filename = uniqid('audio_', true) . '.' . $extension;
        $filePath = $this->uploadDir . $filename;

        // Move uploaded file
        if (!move_uploaded_file($uploadedFile['tmp_name'], $filePath)) {
            return [
                'success' => false,
                'error' => 'Failed to save uploaded file',
            ];
        }

        return [
            'success' => true,
            'file_path' => $filePath,
            'filename' => $filename,
            'size' => $uploadedFile['size'],
            'type' => $mimeType,
        ];
    }

    /**
     * Handle base64 encoded audio data
     */
    public function handleBase64Audio(string $base64Data, string $format = 'webm'): array
    {
        // Remove data URL prefix if present
        $base64Data = preg_replace('/^data:audio\/\w+;base64,/', '', $base64Data);
        $audioData = base64_decode($base64Data, true);

        if ($audioData === false) {
            return [
                'success' => false,
                'error' => 'Invalid base64 data',
            ];
        }

        // Validate size
        if (strlen($audioData) > $this->config['upload']['max_size']) {
            return [
                'success' => false,
                'error' => 'File size exceeds maximum allowed size',
            ];
        }

        // Generate unique filename
        $filename = uniqid('audio_', true) . '.' . $format;
        $filePath = $this->uploadDir . $filename;

        // Save file
        if (file_put_contents($filePath, $audioData) === false) {
            return [
                'success' => false,
                'error' => 'Failed to save audio file',
            ];
        }

        return [
            'success' => true,
            'file_path' => $filePath,
            'filename' => $filename,
            'size' => strlen($audioData),
            'type' => 'audio/' . $format,
        ];
    }

    /**
     * Clean up temporary file
     */
    public function cleanup(string $filePath): bool
    {
        if (file_exists($filePath) && strpos($filePath, $this->uploadDir) === 0) {
            return unlink($filePath);
        }
        return false;
    }

    private function getUploadErrorMessage(int $errorCode): string
    {
        $messages = [
            UPLOAD_ERR_INI_SIZE => 'File exceeds upload_max_filesize directive',
            UPLOAD_ERR_FORM_SIZE => 'File exceeds MAX_FILE_SIZE directive',
            UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
            UPLOAD_ERR_NO_FILE => 'No file was uploaded',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
            UPLOAD_ERR_EXTENSION => 'File upload stopped by extension',
        ];

        return $messages[$errorCode] ?? 'Unknown upload error';
    }
}
