<?php

namespace Etuter\STT\Utils;

class ResponseHelper
{
    /**
     * Send JSON response
     */
    public static function json(array $data, int $statusCode = 200): void
    {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');
        
        echo json_encode($data, JSON_PRETTY_PRINT);
        exit;
    }

    /**
     * Send error response
     */
    public static function error(string $message, int $statusCode = 400): void
    {
        self::json([
            'success' => false,
            'error' => $message,
        ], $statusCode);
    }

    /**
     * Send success response
     */
    public static function success(array $data = [], int $statusCode = 200): void
    {
        self::json(array_merge([
            'success' => true,
        ], $data), $statusCode);
    }
}
