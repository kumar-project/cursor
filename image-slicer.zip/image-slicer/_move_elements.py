# -*- coding: utf-8 -*-
import pathlib

p = pathlib.Path(__file__).with_name("index.php")
t = p.read_text(encoding="utf-8")
start = t.find('<div id="wsPanelElements"')
end = t.find('<div id="wsPanelText"')
if start == -1 or end == -1:
    raise SystemExit(f"markers not found start={start} end={end}")

block = t[start:end]
lines = block.splitlines()
if not lines[0].strip().startswith('<div id="wsPanelElements"'):
    raise SystemExit("unexpected start line: " + lines[0][:80])
while lines and not lines[-1].strip():
    lines.pop()
if not lines or lines[-1].strip() != "</div>":
    raise SystemExit("unexpected block end: " + repr(lines[-1] if lines else ""))

inner = "\n".join(lines[1:-1])
inner = inner.replace(
    '<h2 class="ws-panel-title">Elements</h2>',
    '<h2 class="dash-elements-h" id="dashElementsHeading">Elements</h2>',
    1,
)
inner = inner.replace(
    "                </div>\n                <h3 class=\"el-browse-heading\">Browse categories</h3>",
    "                </div>\n            </div>\n            <div class=\"dash-elements-col-tiles\">\n                <h3 class=\"el-browse-heading\">Browse categories</h3>",
    1,
)

wrapped = (
    '<section class="dash-elements-intro" aria-labelledby="dashElementsHeading">\n'
    '    <div id="wsPanelElements" class="dash-elements-panel" role="region" aria-labelledby="dashElementsHeading">\n'
    '        <div class="dash-elements-row">\n'
    '            <div class="dash-elements-col-main">\n'
    + inner
    + "\n            </div>\n        </div>\n    </div>\n</section>\n"
)

t2 = t[:start] + t[end:]

marker = "    </div>\n    </div>\n</div>\n<div class=\"dash-home-lower\">"
if marker not in t2:
    raise SystemExit("dash-home-lower marker not found")
t3 = t2.replace(marker, "    </div>\n    </div>\n</div>\n" + wrapped + "<div class=\"dash-home-lower\">", 1)

p.write_text(t3, encoding="utf-8")
print("ok")
