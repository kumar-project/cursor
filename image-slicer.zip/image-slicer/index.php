<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Image Slicer</title>
    <style>
        body { font-family: system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif; margin: 0; background: #f1f5f9; }
        .app-shell {
            display: flex;
            min-height: calc(100vh - 53px);
            align-items: stretch;
        }
        .app-sidebar {
            width: 72px;
            flex-shrink: 0;
            background: #fff;
            border-right: 1px solid #e8e8ef;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 14px 0 20px;
            gap: 6px;
        }
        .sb-item {
            width: 48px;
            height: 48px;
            border: none;
            border-radius: 12px;
            background: transparent;
            cursor: pointer;
            color: #374151;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.15s ease, color 0.15s ease;
        }
        .sb-item:hover { background: #f3f4f6; color: #111; }
        .sb-item:focus-visible { outline: 2px solid #6366f1; outline-offset: 2px; }
        .sb-item svg { width: 22px; height: 22px; }
        .sb-create {
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: #fff;
            margin-bottom: 8px;
            box-shadow: 0 4px 14px rgba(99, 102, 241, 0.45);
        }
        .sb-create:hover { filter: brightness(1.06); color: #fff; }
        .sb-plus { font-size: 26px; font-weight: 300; line-height: 1; margin-top: -2px; }
        .sb-spacer { flex: 1; min-height: 8px; }
        .app-main {
            flex: 1;
            min-width: 0;
            overflow-x: hidden;
            display: flex;
            flex-direction: column;
        }
        .dash-home {
            flex: 1 0 auto;
            min-width: 0;
            display: flex;
            flex-direction: column;
            background: #f1f5f9;
        }
        .dash-hero {
            background: linear-gradient(165deg, #eef2ff 0%, #faf5ff 42%, #ecfeff 100%);
            padding: 36px clamp(16px, 4vw, 28px) 40px;
            text-align: center;
            border-bottom: 1px solid rgba(99, 102, 241, 0.1);
        }
        .dash-hero-inner { max-width: 1120px; margin: 0 auto; }
        .dash-headline {
            margin: 0;
            font-size: clamp(1.75rem, 4vw, 2.65rem);
            font-weight: 700;
            letter-spacing: -0.03em;
            color: #1e3a8a;
            line-height: 1.15;
        }
        .dash-sub {
            margin: 12px auto 0;
            max-width: 520px;
            font-size: 1.05rem;
            color: #64748b;
            line-height: 1.45;
        }
        .dash-search-row {
            margin-top: 28px;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }
        .dash-search {
            flex: 1 1 320px;
            max-width: 640px;
            display: flex;
            align-items: center;
            gap: 12px;
            background: #fff;
            border-radius: 999px;
            padding: 6px 8px 6px 18px;
            box-shadow: 0 8px 32px rgba(15, 23, 42, 0.08), 0 2px 8px rgba(15, 23, 42, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.8);
        }
        .dash-search-svg { width: 22px; height: 22px; color: #94a3b8; flex-shrink: 0; }
        .dash-search-input {
            flex: 1;
            min-width: 0;
            border: none;
            font: inherit;
            font-size: 1rem;
            padding: 12px 8px;
            background: transparent;
            outline: none;
            color: #0f172a;
        }
        .dash-search-input::placeholder { color: #94a3b8; }
        .dash-upload-btn {
            flex-shrink: 0;
            padding: 12px 22px;
            border: none;
            border-radius: 999px;
            font: inherit;
            font-weight: 600;
            font-size: 0.95rem;
            cursor: pointer;
            background: linear-gradient(135deg, #2563eb, #4f46e5);
            color: #fff;
            box-shadow: 0 4px 16px rgba(37, 99, 235, 0.35);
        }
        .dash-upload-btn:hover { filter: brightness(1.05); }
        .dash-quick-wrap {
            background: #fff;
            padding: 0;
            border-bottom: 1px solid #e2e8f0;
        }
        .dash-quick-inner {
            max-width: 1120px;
            margin: 0 auto;
            padding: 14px clamp(16px, 4vw, 28px) 18px;
            box-sizing: border-box;
        }
        .dash-quick-scroll {
            display: flex;
            gap: 14px;
            overflow-x: auto;
            padding: 4px 0 2px;
            scroll-snap-type: x proximity;
            -webkit-overflow-scrolling: touch;
            scrollbar-width: thin;
            scrollbar-color: #cbd5e1 #f1f5f9;
        }
        .dash-quick-scroll::-webkit-scrollbar { height: 8px; }
        .dash-quick-scroll::-webkit-scrollbar-track { background: #f1f5f9; border-radius: 99px; }
        .dash-quick-scroll::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 99px; }
        .dash-quick-scroll::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
        .quick-orb {
            flex: 0 0 auto;
            scroll-snap-align: start;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
            width: 88px;
            border: none;
            background: none;
            cursor: pointer;
            padding: 4px;
            font: inherit;
            color: #334155;
        }
        .quick-orb-circle {
            width: 72px;
            height: 72px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            line-height: 1;
            box-shadow: 0 6px 20px rgba(15, 23, 42, 0.1);
            transition: transform 0.15s ease, box-shadow 0.15s ease;
        }
        .quick-orb:hover .quick-orb-circle { transform: translateY(-3px); box-shadow: 0 10px 28px rgba(15, 23, 42, 0.14); }
        .quick-orb-circle--txt { font-size: 14px; font-weight: 800; letter-spacing: 0.04em; color: #fff; }
        .quick-orb-label { font-size: 12px; font-weight: 600; text-align: center; max-width: 88px; line-height: 1.25; }
        .quick-orb--u .quick-orb-circle { background: linear-gradient(145deg, #f472b6, #ec4899); }
        .quick-orb--s .quick-orb-circle { background: linear-gradient(145deg, #a78bfa, #7c3aed); }
        .quick-orb--c .quick-orb-circle { background: linear-gradient(145deg, #fb923c, #ea580c); }
        .quick-orb--e .quick-orb-circle { background: linear-gradient(145deg, #34d399, #059669); }
        .quick-orb--g .quick-orb-circle { background: linear-gradient(145deg, #38bdf8, #0284c7); }
        .quick-orb--z .quick-orb-circle { background: linear-gradient(145deg, #94a3b8, #475569); }
        .quick-orb--d .quick-orb-circle { background: linear-gradient(145deg, #818cf8, #4f46e5); }
        .quick-badge {
            position: absolute;
            top: -4px;
            right: -4px;
            font-size: 9px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            background: #7c3aed;
            color: #fff;
            padding: 2px 6px;
            border-radius: 999px;
        }
        .quick-orb { position: relative; }
        .dash-upload-row {
            width: 100%;
            max-width: 1120px;
            margin: 0 auto;
            padding: 16px clamp(16px, 4vw, 28px) 8px;
            box-sizing: border-box;
        }
        .dash-home-lower {
            flex: 1 1 auto;
            width: 100%;
            max-width: 1120px;
            margin: 0 auto;
            padding: 12px clamp(16px, 4vw, 28px) 36px;
            box-sizing: border-box;
        }
        .dash-start-col {
            min-width: 0;
        }
        .dash-start-card.panel {
            margin: 0 0 14px;
            padding: 18px 18px 20px;
            border-radius: 14px;
            border: 1px solid #e2e8f0;
            background: #fff;
            box-shadow: 0 4px 22px rgba(15, 23, 42, 0.06);
        }
        @media (min-width: 900px) {
            .dash-start-card.panel {
                margin-bottom: 0;
            }
        }
        .dash-section.dash-features {
            padding: 0;
            margin: 0;
            background: transparent;
            min-width: 0;
        }
        .dash-section.dash-features .dash-section-h {
            margin: 0 0 12px;
            font-size: 1.05rem;
            font-weight: 700;
            letter-spacing: -0.02em;
            color: #0f172a;
        }
        .dash-cards {
            display: grid;
            grid-template-columns: 1fr;
            gap: 14px;
            overflow: visible;
            padding-bottom: 0;
        }
        @media (min-width: 520px) {
            .dash-cards {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }
        @media (min-width: 1100px) {
            .dash-cards {
                grid-template-columns: repeat(3, minmax(0, 1fr));
            }
        }
        .dash-card {
            min-width: 0;
            border-radius: 14px;
            overflow: hidden;
            background: #fff;
            border: 1px solid #e8e8ef;
            box-shadow: 0 2px 14px rgba(15, 23, 42, 0.05);
            text-align: left;
            display: flex;
            flex-direction: column;
        }
        .dash-card-visual {
            height: 100px;
            background: linear-gradient(135deg, #c4b5fd, #93c5fd);
        }
        .dash-card-visual--2 { background: linear-gradient(135deg, #fbcfe8, #fcd34d); }
        .dash-card-visual--3 { background: linear-gradient(135deg, #a5f3fc, #6ee7b7); }
        .dash-card-body { padding: 16px 18px 20px; flex: 1 1 auto; display: flex; flex-direction: column; }
        .dash-card-body h3 { margin: 0 0 8px; font-size: 1rem; color: #0f172a; line-height: 1.35; }
        .dash-card-body p { margin: 0; font-size: 13px; color: #64748b; line-height: 1.45; }
        .thumb-design-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(158px, 1fr));
            gap: 12px;
            align-items: stretch;
        }
        .thumb-preset-btn {
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 14px 12px;
            text-align: left;
            cursor: pointer;
            font: inherit;
            background: #fff;
            transition: border-color 0.15s ease, box-shadow 0.15s ease, transform 0.12s ease;
            display: flex;
            flex-direction: column;
            gap: 6px;
            min-height: 96px;
        }
        .thumb-preset-btn:hover {
            border-color: #c7d2fe;
            box-shadow: 0 6px 18px rgba(79, 70, 229, 0.12);
            transform: translateY(-1px);
        }
        .thumb-preset-btn:focus-visible {
            outline: 2px solid #4f46e5;
            outline-offset: 2px;
        }
        .thumb-preset-name {
            font-size: 14px;
            font-weight: 700;
            color: #0f172a;
        }
        .thumb-preset-meta {
            font-size: 12px;
            color: #64748b;
            line-height: 1.35;
        }
        .thumb-preset-badge {
            align-self: flex-start;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            color: #4f46e5;
            background: #eef2ff;
            padding: 3px 8px;
            border-radius: 999px;
        }
        .thumb-preset--yt .thumb-preset-badge { color: #b91c1c; background: #fef2f2; }
        .thumb-preset--ig .thumb-preset-badge { color: #c026d3; background: #fdf4ff; }
        .thumb-preset--li .thumb-preset-badge { color: #0369a1; background: #f0f9ff; }
        .thumb-custom-card {
            border: 1px dashed #cbd5e1;
            border-radius: 12px;
            padding: 14px 12px;
            background: #fafafa;
            display: flex;
            flex-direction: column;
            gap: 10px;
            min-height: 96px;
        }
        .thumb-custom-row {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            align-items: flex-end;
        }
        .thumb-custom-row .field { margin: 0; min-width: 0; }
        .thumb-custom-row input[type="number"] { width: 88px; }
        .thumb-custom-apply {
            padding: 8px 14px;
            font-weight: 600;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            background: linear-gradient(135deg, #4f46e5, #7c3aed);
            color: #fff;
        }
        .thumb-custom-apply:hover { filter: brightness(1.05); }
        .new-doc-dialog {
            width: min(480px, calc(100vw - 32px));
            max-height: min(90vh, 720px);
        }
        .new-doc-thumb-section {
            margin-top: 2px;
            padding: 12px 12px 14px;
            border: 1px solid #e8e8ef;
            border-radius: 12px;
            background: linear-gradient(165deg, #fff 0%, #f8fafc 100%);
        }
        .new-doc-thumb-heading {
            margin: 0 0 4px;
            font-size: 0.95rem;
            font-weight: 700;
            letter-spacing: -0.02em;
            color: #0f172a;
        }
        .new-doc-thumb-section .thumb-design-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 8px;
        }
        .new-doc-thumb-section .thumb-preset-btn {
            min-height: 86px;
            padding: 10px 10px;
        }
        .new-doc-thumb-section .thumb-preset-meta {
            font-size: 11px;
        }
        .new-doc-thumb-section .thumb-custom-card {
            grid-column: 1 / -1;
            min-height: auto;
            padding: 10px 10px 12px;
        }
        .new-doc-thumb-section .thumb-custom-row input[type="number"] {
            width: 76px;
        }
        .new-doc-body { padding: 16px 22px 22px; overflow-y: auto; }
        .new-doc-form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px 14px;
            align-items: start;
        }
        .new-doc-span2 { grid-column: 1 / -1; }
        .new-doc-muted { font-size: 12px; color: #64748b; margin: 0 0 4px; line-height: 1.4; }
        .new-doc-contents { display: flex; flex-direction: column; gap: 8px; margin-top: 4px; }
        .new-doc-contents label { font-weight: normal; font-size: 13px; cursor: pointer; display: flex; align-items: center; gap: 8px; }
        .new-doc-actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 18px; padding-top: 16px; border-top: 1px solid #f0f0f5; }
        .new-doc-btn-secondary {
            padding: 10px 16px;
            border-radius: 10px;
            border: 1px solid #d1d5db;
            background: #fff;
            font: inherit;
            font-weight: 600;
            cursor: pointer;
        }
        .new-doc-btn-primary {
            padding: 10px 18px;
            border-radius: 10px;
            border: none;
            background: linear-gradient(135deg, #2563eb, #4f46e5);
            color: #fff;
            font: inherit;
            font-weight: 600;
            cursor: pointer;
        }
        .new-doc-btn-primary:hover { filter: brightness(1.05); }
        .panel-upload-actions { display: flex; flex-wrap: wrap; gap: 10px; align-items: center; margin-top: 10px; }
        .app-menubar {
            background: linear-gradient(180deg, #ece9d5 0%, #d4d0c8 45%, #c9c4bc 100%);
            border-bottom: 1px solid #6d6d6d;
            font-size: 12px;
            font-family: Tahoma, "Segoe UI", Verdana, sans-serif;
            user-select: none;
            -webkit-user-select: none;
            box-shadow: inset 0 1px 0 #fff;
        }
        .menu-bar-inner {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 0;
            padding: 2px 4px 3px 6px;
            min-height: 36px;
        }
        .menu-root { position: relative; }
        .menu-top {
            font: inherit;
            font-weight: 400;
            letter-spacing: 0;
            padding: 4px 10px;
            border: none;
            border-radius: 0;
            background: transparent;
            cursor: pointer;
            color: #000;
        }
        .menu-top:hover {
            background: #c9d1ef;
            color: #000;
        }
        .menu-top[aria-expanded="true"] {
            background: #0a246a;
            color: #fff;
        }
        .menu-top:focus-visible {
            outline: 1px dotted #000;
            outline-offset: -2px;
        }
        .menu-dropdown {
            position: absolute;
            top: calc(100% + 6px);
            left: 0;
            min-width: 300px;
            max-width: min(360px, calc(100vw - 24px));
            max-height: min(72vh, 520px);
            overflow-x: visible;
            overflow-y: auto;
            background: #fff;
            border: 1px solid rgba(0, 0, 0, 0.08);
            border-radius: 12px;
            box-shadow: 0 12px 40px rgba(15, 23, 42, 0.18), 0 4px 12px rgba(15, 23, 42, 0.08);
            z-index: 2000;
            padding: 8px 0;
        }
        .menu-dropdown[hidden] { display: none !important; }
        .menu-submenu-parent {
            position: relative;
            width: 100%;
        }
        .menu-flyout {
            display: none;
            position: absolute;
            left: 100%;
            top: -8px;
            margin-left: 4px;
            min-width: 240px;
            max-width: min(320px, calc(100vw - 24px));
            padding: 8px 0;
            background: #fff;
            border: 1px solid rgba(0, 0, 0, 0.08);
            border-radius: 12px;
            box-shadow: 0 12px 40px rgba(15, 23, 42, 0.18), 0 4px 12px rgba(15, 23, 42, 0.08);
            z-index: 2100;
        }
        .menu-submenu-parent:hover > .menu-flyout,
        .menu-submenu-parent:focus-within > .menu-flyout {
            display: block;
        }
        .menu-flyout .menu-row {
            grid-template-columns: 1fr auto;
            padding-left: 14px;
        }
        .menu-flyout .menu-row .menu-icon {
            display: none;
        }
        .menu-dropdown-head {
            padding: 12px 16px 10px;
        }
        .menu-dropdown-title {
            font-weight: 700;
            font-size: 15px;
            color: #111827;
            letter-spacing: -0.02em;
        }
        .menu-dropdown-sub {
            margin-top: 4px;
            font-size: 12px;
            color: #6b7280;
        }
        .menu-sep-head {
            height: 1px;
            background: #e5e7eb;
            margin: 4px 0 6px;
        }
        .menu-row {
            display: grid;
            grid-template-columns: 38px 1fr auto;
            align-items: center;
            gap: 0 6px;
            width: 100%;
            padding: 9px 14px 9px 10px;
            border: none;
            background: transparent;
            cursor: pointer;
            text-align: left;
            font: inherit;
            font-size: 14px;
            color: #111827;
        }
        .menu-row:hover:not(:disabled) {
            background: #f3f4f6;
        }
        .menu-row:disabled {
            opacity: 0.42;
            cursor: not-allowed;
        }
        .menu-row:disabled .menu-icon { color: #9ca3af; }
        .menu-row:focus-visible {
            outline: 2px solid #1f6feb;
            outline-offset: -2px;
        }
        .menu-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 38px;
            height: 36px;
            color: #374151;
        }
        .menu-icon svg {
            width: 20px;
            height: 20px;
            flex-shrink: 0;
        }
        .menu-row-label {
            min-width: 0;
            line-height: 1.35;
        }
        .menu-kbd {
            font-family: ui-monospace, Consolas, monospace;
            font-size: 11px;
            font-weight: 500;
            color: #9ca3af;
            white-space: nowrap;
            margin-left: 12px;
        }
        .menu-chevron {
            color: #d1d5db;
            font-size: 14px;
            font-weight: 300;
            margin-left: 8px;
        }
        .menu-sep {
            height: 1px;
            background: #e5e7eb;
            margin: 6px 12px;
        }
        .panel { border: 1px solid #ddd; padding: 14px; margin-bottom: 14px; border-radius: 8px; }
        .row { display: flex; gap: 18px; flex-wrap: wrap; align-items: flex-end; }
        .field { display: flex; flex-direction: column; gap: 6px; min-width: 140px; }
        input[type="number"] { width: 120px; padding: 4px; }
        input[type="range"] { width: 180px; }
        button { padding: 8px 12px; cursor: pointer; }
        #previewCanvas { border: 1px solid #bbb; background: #f7f7f7; display: block; touch-action: none; }
        .preview-wrap {
            max-width: 100%;
            max-height: 70vh;
            overflow: auto;
            border: 1px solid #e0e0e0;
            background: #fcfcfc;
            -webkit-overflow-scrolling: touch;
            scrollbar-width: thin;
            scrollbar-color: #cbd5e1 #f1f5f9;
        }
        .preview-wrap::-webkit-scrollbar {
            width: 10px;
            height: 10px;
        }
        .preview-wrap::-webkit-scrollbar-track {
            background: #f1f5f9;
            border-radius: 6px;
        }
        .preview-wrap::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 6px;
        }
        .preview-wrap::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }
        #sliceContainer { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 12px; margin-top: 14px; }
        .slice-card { border: 1px solid #ddd; border-radius: 8px; padding: 10px; text-align: center; }
        .slice-card img { max-width: 100%; border: 1px solid #ccc; margin-bottom: 8px; }
        .muted { color: #666; font-size: 13px; }
        .hidden { display: none; }
        .preset-wrap { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 6px; }
        .preset-btn { border: 1px solid #bbb; background: #f4f4f4; border-radius: 999px; padding: 5px 10px; cursor: pointer; }
        .preset-btn.active { background: #1f6feb; border-color: #1f6feb; color: #fff; }
        .workspace-studio {
            display: flex;
            align-items: stretch;
            gap: 14px;
            min-width: 0;
            margin-bottom: 14px;
        }
        .studio-tool-rail {
            flex: 0 0 58px;
            width: 58px;
            align-self: stretch;
            box-sizing: border-box;
            background: #fff;
            border: 1px solid #e5e7eb;
            border-radius: 14px;
            padding: 10px 5px 12px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0;
            box-shadow: 0 1px 2px rgba(15, 23, 42, 0.04), 0 6px 20px rgba(15, 23, 42, 0.06);
            font-family: inherit;
            max-height: calc(100vh - 100px);
            overflow-x: hidden;
            overflow-y: auto;
            scrollbar-width: thin;
            scrollbar-color: #cbd5e1 #f1f5f9;
        }
        .studio-tool-rail::-webkit-scrollbar {
            width: 6px;
        }
        .studio-tool-rail::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 99px;
        }
        .studio-tool-rail-title {
            margin: 0 0 8px;
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            color: #64748b;
            text-align: center;
            width: 100%;
        }
        .studio-tool-primary {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 3px;
            width: 100%;
            margin-bottom: 8px;
        }
        .studio-tool-primary .ps-tool {
            width: 28px;
            height: 28px;
        }
        .studio-tool-undo {
            display: flex;
            flex-direction: column;
            gap: 5px;
            width: 100%;
            margin-bottom: 6px;
        }
        .studio-tool-undo .tiny-btn {
            width: 100%;
            box-sizing: border-box;
            text-align: center;
            justify-content: center;
            font-size: 10px;
            padding: 6px 3px;
            line-height: 1.15;
        }
        .studio-tool-divider {
            width: 100%;
            height: 1px;
            margin: 2px 0 8px;
            background: linear-gradient(90deg, transparent, #e2e8f0 12%, #e2e8f0 88%, transparent);
            flex-shrink: 0;
        }
        .ws-nav-rail {
            flex: 0 0 76px;
            width: 76px;
            min-height: 320px;
            background: #fff;
            border: 1px solid #e5e7eb;
            border-radius: 14px;
            padding: 12px 6px 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
            box-shadow: 0 1px 2px rgba(15, 23, 42, 0.04), 0 6px 20px rgba(15, 23, 42, 0.06);
        }
        .ws-nav-item {
            width: 100%;
            max-width: 64px;
            border: none;
            border-radius: 10px;
            background: transparent;
            cursor: pointer;
            padding: 8px 4px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
            font-size: 10px;
            font-weight: 600;
            color: #64748b;
            line-height: 1.15;
        }
        .ws-nav-item:hover { background: #f1f5f9; color: #0f172a; }
        .ws-nav-item.is-active {
            background: #eff6ff;
            color: #2563eb;
        }
        .ws-nav-item .ws-nav-ico {
            width: 28px;
            height: 28px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 15px;
            color: inherit;
        }
        .ws-nav-item .ws-nav-ico svg { display: block; width: 18px; height: 18px; }
        .ws-nav-ico--elements svg { width: 22px !important; height: 22px !important; }
        .ws-nav-item.is-active .ws-nav-ico,
        .ws-nav-item.is-active .ws-nav-brand-ico { background: rgba(37, 99, 235, 0.12); }
        .ws-nav-divider {
            width: 72%;
            height: 1px;
            margin: 10px auto 8px;
            background: #e2e8f0;
            border: none;
            flex-shrink: 0;
        }
        .ws-nav-spacer { flex: 1 1 auto; min-height: 8px; width: 100%; }
        .ws-nav-footer {
            width: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 6px;
            padding: 8px 0 4px;
            margin-top: auto;
            border-top: 1px solid #f1f5f9;
        }
        .ws-nav-foot-item {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            border: none;
            background: transparent;
            cursor: pointer;
            font: inherit;
            font-size: 10px;
            font-weight: 600;
            color: #94a3b8;
            padding: 4px 2px;
            border-radius: 8px;
        }
        .ws-nav-foot-item:hover { color: #475569; background: rgba(255, 255, 255, 0.7); }
        .ws-nav-foot-item svg { width: 14px; height: 14px; flex-shrink: 0; opacity: 0.85; }
        .ws-nav-brand-ico {
            position: relative;
            width: 28px;
            height: 28px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(100, 116, 139, 0.12);
        }
        .ws-nav-brand-ico .ws-nav-crown-corner {
            position: absolute;
            top: -5px;
            right: -4px;
            font-size: 9px;
            line-height: 1;
            color: #ea580c;
            filter: drop-shadow(0 0 1px #fff);
        }
        .ws-nav-brand-ico-inner {
            font-size: 9px;
            font-weight: 800;
            letter-spacing: -0.04em;
            color: #475569;
        }
        .ws-crown-wrap { display: flex; flex-direction: column; align-items: center; gap: 0; }
        .ws-crown { font-size: 9px; line-height: 1; color: #ca8a04; }
        .ps-tools-grid {
            display: grid;
            grid-template-columns: 24px 24px;
            gap: 2px 3px;
            justify-content: center;
        }
        .ps-tool {
            width: 24px;
            height: 24px;
            padding: 0;
            margin: 0;
            border: 1px solid transparent;
            border-radius: 6px;
            background: transparent;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            color: #334155;
            flex-shrink: 0;
        }
        .ps-tool svg {
            display: block;
            width: 18px;
            height: 18px;
        }
        .ps-tool:hover {
            border-color: #cbd5e1;
            background: #f1f5f9;
        }
        .ps-tool.ps-tool-active {
            border-color: #2563eb;
            background: linear-gradient(180deg, #dbeafe 0%, #bfdbfe 100%);
            box-shadow: 0 1px 2px rgba(37, 99, 235, 0.2);
        }
        .ps-tool.ps-tool-active svg {
            filter: none;
            color: #1e40af;
        }
        .ps-tool-flyout::after {
            content: '';
            position: absolute;
            right: 2px;
            bottom: 2px;
            width: 0;
            height: 0;
            border-style: solid;
            border-width: 0 0 4px 4px;
            border-color: transparent transparent #64748b transparent;
        }
        .ps-tool-mini-row {
            display: flex;
            justify-content: center;
            gap: 2px;
            margin-top: 4px;
            width: 100%;
        }
        .ps-tool-mini {
            width: 14px;
            height: 12px;
            padding: 0;
            border: 1px solid transparent;
            background: transparent;
            cursor: pointer;
            font-size: 9px;
            line-height: 1;
            color: #222;
        }
        .ps-tool-mini:hover { border-color: #cbd5e1; background: #f1f5f9; }
        .ps-swatch-stack {
            position: relative;
            width: 34px;
            height: 34px;
            margin: 6px auto 2px;
            flex-shrink: 0;
        }
        .ps-swatch {
            position: absolute;
            width: 20px;
            height: 20px;
            border: 1px solid #1a1a1a;
            box-sizing: border-box;
            pointer-events: none;
        }
        .ps-swatch-fg { left: 0; top: 0; z-index: 2; background: #000; }
        .ps-swatch-bg { right: 0; bottom: 0; z-index: 1; background: #fff; }
        .ps-swatch-stack.ps-swapped .ps-swatch-fg {
            left: auto;
            top: auto;
            right: 0;
            bottom: 0;
            z-index: 1;
        }
        .ps-swatch-stack.ps-swapped .ps-swatch-bg {
            right: auto;
            bottom: auto;
            left: 0;
            top: 0;
            z-index: 2;
        }
        .ps-bottom-tools {
            display: grid;
            grid-template-columns: 24px 24px;
            gap: 2px 3px;
            margin-top: 4px;
            justify-content: center;
        }
        .workspace-studio .workspace-layout {
            flex: 1 1 auto;
            min-width: 0;
        }
        .dash-elements-intro {
            width: 100%;
            max-width: 1120px;
            margin: 0 auto;
            padding: 8px clamp(16px, 4vw, 28px) 28px;
            box-sizing: border-box;
        }
        .dash-elements-panel {
            background: #fff;
            border: 1px solid #e2e8f0;
            border-radius: 16px;
            padding: 22px clamp(16px, 3vw, 24px) 24px;
            box-shadow: 0 4px 22px rgba(15, 23, 42, 0.06);
        }
        .dash-elements-row {
            display: flex;
            flex-direction: column;
            gap: 24px;
            align-items: stretch;
        }
        @media (min-width: 900px) {
            .dash-elements-row {
                flex-direction: row;
                align-items: flex-start;
                gap: 32px;
            }
        }
        .dash-elements-col-main {
            flex: 1 1 auto;
            min-width: 0;
        }
        .dash-elements-col-tiles {
            flex: 0 0 auto;
            width: 100%;
            min-width: 0;
        }
        @media (min-width: 900px) {
            .dash-elements-col-tiles {
                width: min(280px, 32vw);
                margin-left: auto;
            }
        }
        .dash-elements-h {
            margin: 0 0 14px;
            font-size: 1.35rem;
            font-weight: 700;
            letter-spacing: -0.02em;
            color: #0f172a;
        }
        .el-desc-wrap {
            position: relative;
            border: 1px solid #d1d5db;
            border-radius: 12px;
            background: #fafafa;
            margin-bottom: 10px;
            min-height: 120px;
        }
        .el-desc-wrap textarea {
            width: 100%;
            min-height: 104px;
            border: none;
            background: transparent;
            resize: vertical;
            font: inherit;
            font-size: 14px;
            padding: 12px 12px 36px;
            outline: none;
            box-sizing: border-box;
            color: #111827;
        }
        .el-desc-toolbar {
            position: absolute;
            left: 0;
            right: 0;
            bottom: 0;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 8px;
            border-top: 1px solid #e5e7eb;
            background: #fff;
            border-radius: 0 0 11px 11px;
        }
        .el-desc-toolbar button {
            border: none;
            background: transparent;
            cursor: pointer;
            font-size: 18px;
            color: #64748b;
            padding: 4px 6px;
            border-radius: 6px;
        }
        .el-desc-toolbar button:hover { background: #f1f5f9; color: #0f172a; }
        .el-desc-toolbar button svg { display: block; }
        .el-actions { display: flex; gap: 8px; margin-bottom: 16px; align-items: stretch; }
        .el-btn-generate {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            border: 1px solid #d1d5db;
            border-radius: 10px;
            padding: 10px 10px;
            font: inherit;
            font-size: 13px;
            font-weight: 600;
            background: #fff;
            cursor: pointer;
            color: #111827;
        }
        .el-btn-generate:hover { background: #f9fafb; }
        .el-btn-generate .el-chev { font-size: 10px; opacity: 0.6; margin-left: 2px; }
        .el-btn-search {
            flex: 0 0 auto;
            min-width: 92px;
            border: none;
            border-radius: 10px;
            padding: 10px 16px;
            font: inherit;
            font-size: 14px;
            font-weight: 600;
            background: linear-gradient(180deg, #8b5cf6 0%, #7c3aed 100%);
            color: #fff;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(124, 58, 237, 0.3);
        }
        .el-btn-search:hover { filter: brightness(1.05); }
        .el-browse-heading {
            margin: 0 0 12px;
            font-size: 15px;
            font-weight: 700;
            letter-spacing: -0.02em;
            color: #0f172a;
        }
        .el-cat-grid {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .elem-cat-tile {
            border: none;
            border-radius: 16px;
            padding: 12px 14px;
            cursor: pointer;
            color: #fff;
            font: inherit;
            text-align: left;
            box-shadow:
                0 1px 0 rgba(255, 255, 255, 0.22) inset,
                0 8px 18px rgba(15, 23, 42, 0.18),
                0 2px 6px rgba(15, 23, 42, 0.1);
            transition: transform 0.15s ease, box-shadow 0.15s ease;
            min-height: 72px;
            width: 100%;
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: flex-start;
            gap: 12px;
        }
        .elem-cat-tile:hover {
            transform: translateY(-3px);
            box-shadow:
                0 1px 0 rgba(255, 255, 255, 0.25) inset,
                0 14px 28px rgba(15, 23, 42, 0.22),
                0 4px 10px rgba(15, 23, 42, 0.12);
        }
        .elem-cat-tile.is-selected {
            outline: 3px solid rgba(255, 255, 255, 0.95);
            outline-offset: 2px;
            box-shadow:
                0 0 0 2px #1f6feb,
                0 1px 0 rgba(255, 255, 255, 0.25) inset,
                0 14px 28px rgba(15, 23, 42, 0.22);
        }
        .elem-cat-tile[hidden] { display: none !important; }
        .element-browse-status {
            margin: 0 0 12px;
            font-size: 13px;
            color: #64748b;
            line-height: 1.45;
            min-height: 1.45em;
        }
        .element-results-panel {
            margin-top: 16px;
            padding-top: 14px;
            border-top: 1px solid #e5e7eb;
        }
        .element-results-panel[hidden] { display: none !important; }
        .element-results-heading {
            margin: 0 0 10px;
            font-size: 13px;
            font-weight: 700;
            color: #0f172a;
        }
        .element-results-grid {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .element-result-card {
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 10px 12px;
            background: #f8fafc;
            font: inherit;
            font-size: 13px;
            font-weight: 600;
            color: #1e293b;
            text-align: left;
            cursor: pointer;
            transition: border-color 0.15s ease, background 0.15s ease, box-shadow 0.15s ease;
        }
        .element-result-card:hover {
            border-color: #c7d2fe;
            background: #fff;
            box-shadow: 0 4px 14px rgba(79, 70, 229, 0.1);
        }
        .element-result-card.is-picked {
            border-color: #6366f1;
            background: #eef2ff;
            color: #3730a3;
        }
        .elem-cat-tile .elem-cat-ico {
            flex-shrink: 0;
            width: 46px;
            height: 46px;
            border-radius: 13px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255, 255, 255, 0.2);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.12);
        }
        .elem-cat-tile .elem-cat-ico svg { display: block; width: 30px; height: 30px; }
        .elem-cat-label {
            flex: 1;
            min-width: 0;
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 0.02em;
            text-shadow: 0 1px 3px rgba(0, 0, 0, 0.18);
            line-height: 1.25;
        }
        .elem-cat--headers { background: linear-gradient(155deg, #a78bfa 0%, #7c3aed 45%, #5b21b6 100%); }
        .elem-cat--footers { background: linear-gradient(155deg, #f87171 0%, #dc2626 50%, #991b1b 100%); }
        .elem-cat--ui-buttons { background: linear-gradient(155deg, #5eead4 0%, #14b8a6 50%, #0f766e 100%); }
        .elem-cat--icon-blocks { background: linear-gradient(155deg, #f9a8d4 0%, #ec4899 45%, #be185d 100%); }
        .elem-cat--columns { background: linear-gradient(155deg, #86efac 0%, #22c55e 50%, #166534 100%); }
        .elem-cat--highlight { background: linear-gradient(155deg, #93c5fd 0%, #3b82f6 50%, #1e40af 100%); }
        .elem-cat--graphics { background: linear-gradient(155deg, #fdba74 0%, #fb923c 45%, #c2410c 100%); }
        .elem-cat--photos { background: linear-gradient(155deg, #7dd3fc 0%, #3b82f6 40%, #1e3a8a 100%); }
        .elem-cat--videos { background: linear-gradient(155deg, #f0abfc 0%, #d946ef 45%, #a21caf 100%); }
        .workspace-layout { display: flex; gap: 14px; align-items: flex-start; }
        .image-area { flex: 0 0 var(--image-panel-width, 70%); max-width: var(--image-panel-width, 70%); }
        .settings-area { flex: 1 1 auto; min-width: 260px; }

        /* Workspace (editor) — unified studio chrome */
        #workspace:not(.hidden) {
            padding: 14px clamp(10px, 1.5vw, 18px) 28px;
            background: linear-gradient(180deg, #f8fafc 0%, #f1f5f9 55%, #eef2f7 100%);
            border-top: 1px solid #e2e8f0;
            box-sizing: border-box;
        }
        #workspace:not(.hidden) .workspace-studio {
            gap: 12px;
        }
        #workspace:not(.hidden) .workspace-layout {
            gap: 16px;
            align-items: stretch;
        }
        #workspace:not(.hidden) .panel,
        #workspace:not(.hidden) .section-panel {
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            background: #fff;
            box-shadow: 0 1px 2px rgba(15, 23, 42, 0.04), 0 8px 24px rgba(15, 23, 42, 0.06);
            padding: 18px 18px 20px;
            margin-bottom: 14px;
        }
        #workspace:not(.hidden) .panel > h3:first-child {
            margin: 0 0 14px;
            padding-bottom: 10px;
            border-bottom: 1px solid #f1f5f9;
            font-size: 0.95rem;
            font-weight: 700;
            letter-spacing: -0.02em;
            color: #0f172a;
            line-height: 1.3;
        }
        #workspace:not(.hidden) .section-panel > .section-head {
            margin: 0 0 14px;
            padding-bottom: 12px;
            border-bottom: 1px solid #f1f5f9;
        }
        #workspace:not(.hidden) .section-head h3 {
            margin: 0;
            font-size: 0.95rem;
            font-weight: 700;
            letter-spacing: -0.02em;
            color: #0f172a;
            line-height: 1.3;
        }
        #workspace:not(.hidden) .tool-row {
            gap: 10px;
            margin-bottom: 12px;
            padding: 10px 12px;
            background: #f8fafc;
            border-radius: 10px;
            border: 1px solid #f1f5f9;
            box-sizing: border-box;
        }
        #workspace:not(.hidden) .layout-element-row select#layoutElementSelect {
            border-color: #cbd5e1;
            border-radius: 8px;
            padding: 8px 10px;
            background: #fff;
            min-width: 0;
            flex: 1 1 200px;
        }
        #workspace:not(.hidden) .tool-btn {
            border: 1px solid #cbd5e1;
            background: #fff;
            border-radius: 8px;
            padding: 7px 12px;
            font-size: 13px;
            font-weight: 500;
            color: #334155;
            transition: background 0.15s ease, border-color 0.15s ease, box-shadow 0.15s ease;
        }
        #workspace:not(.hidden) .tool-btn:hover {
            background: #f8fafc;
            border-color: #94a3b8;
        }
        #workspace:not(.hidden) .tool-btn.active {
            background: linear-gradient(180deg, #3b82f6 0%, #2563eb 100%);
            border-color: #2563eb;
            color: #fff;
            box-shadow: 0 2px 8px rgba(37, 99, 235, 0.3);
        }
        #workspace:not(.hidden) .tiny-btn {
            border-radius: 8px;
            border: 1px solid #cbd5e1;
            background: #fff;
            color: #475569;
            font-weight: 500;
            padding: 6px 11px;
        }
        #workspace:not(.hidden) .tiny-btn:hover:not(:disabled) {
            background: #f1f5f9;
            border-color: #94a3b8;
        }
        #workspace:not(.hidden) .preview-wrap {
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            background: #fafbfc;
        }
        #workspace:not(.hidden) #previewCanvas {
            border-color: #e2e8f0;
        }
        .tool-row { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; margin-bottom: 10px; }
        .layout-element-row { align-items: center; gap: 10px; }
        .layout-element-row select#layoutElementSelect {
            min-width: 220px;
            max-width: 100%;
            padding: 6px 8px;
            font-size: 13px;
            border-radius: 6px;
            border: 1px solid #bbb;
        }
        .layout-element-row label { font-size: 13px; }
        .tool-btn { border: 1px solid #bbb; background: #f8f8f8; border-radius: 6px; padding: 6px 10px; }
        .tool-btn.active { background: #1f6feb; border-color: #1f6feb; color: #fff; }
        .preview-with-text-panel { display: flex; gap: 12px; align-items: stretch; }
        .preview-with-text-panel .preview-wrap { flex: 1 1 auto; min-width: 0; }
        .text-design-panel-wrap {
            max-height: 70vh;
            overflow: auto;
            background: #fff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            padding: 14px 12px 12px;
            box-sizing: border-box;
            box-shadow: 0 1px 3px rgba(15, 23, 42, 0.06);
        }
        .tdp-search-wrap {
            display: flex;
            align-items: center;
            gap: 8px;
            border: 1px solid #d1d5db;
            border-radius: 10px;
            padding: 8px 10px;
            margin-bottom: 12px;
            background: #fafafa;
        }
        .tdp-search-wrap svg { flex-shrink: 0; color: #9ca3af; }
        .tdp-search-input {
            flex: 1;
            min-width: 0;
            border: none;
            background: transparent;
            font: inherit;
            font-size: 13px;
            outline: none;
            color: #111827;
        }
        .tdp-search-input::placeholder { color: #9ca3af; }
        .tdp-btn-primary {
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            border: none;
            border-radius: 10px;
            padding: 12px 14px;
            font: inherit;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            color: #fff;
            background: linear-gradient(180deg, #8b5cf6 0%, #7c3aed 100%);
            box-shadow: 0 2px 8px rgba(124, 58, 237, 0.35);
            margin-bottom: 8px;
        }
        .tdp-btn-primary:hover { filter: brightness(1.05); }
        .tdp-btn-primary .tdp-t-icon {
            width: 26px;
            height: 26px;
            border-radius: 6px;
            background: rgba(255, 255, 255, 0.22);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 15px;
        }
        .tdp-btn-outline {
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            border: 1px solid #111827;
            border-radius: 10px;
            padding: 11px 14px;
            font: inherit;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            color: #111827;
            background: #fff;
            margin-bottom: 16px;
        }
        .tdp-btn-outline:hover { background: #f9fafb; }
        .tdp-section-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 13px;
            font-weight: 600;
            color: #111827;
        }
        .tdp-section-head a {
            font-size: 12px;
            font-weight: 600;
            color: #4f46e5;
            text-decoration: none;
            cursor: pointer;
        }
        .tdp-section-head a:hover { text-decoration: underline; }
        .tdp-crown { font-size: 12px; margin-left: 4px; opacity: 0.85; }
        .tdp-brand-btn {
            width: 100%;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
            padding: 10px 12px;
            font: inherit;
            font-size: 13px;
            cursor: pointer;
            background: #fff;
            color: #374151;
            margin-bottom: 18px;
            text-align: center;
        }
        .tdp-brand-btn:hover { background: #f9fafb; }
        .tdp-style-card {
            width: 100%;
            text-align: left;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
            padding: 12px 14px;
            margin-bottom: 8px;
            cursor: pointer;
            background: #fff;
            font: inherit;
            color: #111827;
            transition: border-color 0.15s ease, box-shadow 0.15s ease;
        }
        .tdp-style-card:hover {
            border-color: #c4b5fd;
            box-shadow: 0 2px 8px rgba(124, 58, 237, 0.12);
        }
        .tdp-style-card:focus-visible {
            outline: 2px solid #7c3aed;
            outline-offset: 2px;
        }
        .tdp-style-heading { font-size: 22px; font-weight: 700; line-height: 1.2; letter-spacing: -0.02em; }
        .tdp-style-sub { font-size: 16px; font-weight: 600; line-height: 1.3; color: #1f2937; }
        .tdp-style-body { font-size: 13px; font-weight: 400; line-height: 1.45; color: #4b5563; }
        .tdp-footer {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 14px;
            padding-top: 12px;
            border-top: 1px solid #f3f4f6;
            font-size: 11px;
            color: #9ca3af;
        }
        .tdp-footer span { display: inline-flex; align-items: center; gap: 4px; }
        @media (max-width: 1100px) {
            .workspace-studio { flex-wrap: wrap; }
            .studio-tool-rail {
                flex: 1 1 100%;
                width: 100%;
                align-self: flex-start;
                max-height: min(520px, 70vh);
                flex-direction: row;
                flex-wrap: wrap;
                align-items: flex-start;
                align-content: flex-start;
                padding: 10px 12px 12px;
                gap: 8px 10px;
            }
            .studio-tool-rail-title {
                flex: 1 0 100%;
                margin: 0 0 4px;
                text-align: left;
            }
            .studio-tool-primary {
                flex-direction: row;
                flex-wrap: wrap;
                width: auto;
                margin-bottom: 0;
                gap: 4px;
            }
            .studio-tool-undo {
                flex-direction: row;
                flex-wrap: wrap;
                width: auto;
                margin-bottom: 0;
                gap: 6px;
            }
            .studio-tool-undo .tiny-btn {
                width: auto;
                flex: 0 0 auto;
            }
            .studio-tool-divider {
                display: none;
            }
            .studio-tool-rail .ps-tools-grid {
                margin-left: auto;
            }
            .studio-tool-rail .ps-tool-mini-row,
            .studio-tool-rail .ps-swatch-stack,
            .studio-tool-rail .ps-bottom-tools {
                align-self: center;
            }
            .ws-nav-rail {
                flex: 1 1 100%;
                width: 100%;
                flex-direction: row;
                flex-wrap: nowrap;
                justify-content: flex-start;
                overflow-x: auto;
                padding: 8px 8px 10px;
                gap: 4px;
                -webkit-overflow-scrolling: touch;
                scrollbar-width: thin;
                scrollbar-color: #cbd5e1 #f1f5f9;
            }
            .ws-nav-rail::-webkit-scrollbar {
                height: 8px;
            }
            .ws-nav-rail::-webkit-scrollbar-track {
                background: #f1f5f9;
                border-radius: 99px;
            }
            .ws-nav-rail::-webkit-scrollbar-thumb {
                background: #cbd5e1;
                border-radius: 99px;
            }
            .ws-nav-rail::-webkit-scrollbar-thumb:hover {
                background: #94a3b8;
            }
            .ws-nav-item { flex: 0 0 auto; max-width: none; width: auto; padding: 8px 10px; }
            .ws-nav-spacer { display: none; }
            .ws-nav-divider {
                width: 1px;
                height: 28px;
                margin: 0 6px;
                align-self: center;
            }
            .ws-nav-footer {
                flex-direction: row;
                border-top: none;
                border-left: 1px solid #e2e4e9;
                margin-top: 0;
                margin-left: 4px;
                padding: 0 4px 0 10px;
                gap: 10px;
            }
        }
        @media (max-width: 980px) {
            .preview-with-text-panel { flex-direction: column; }
        }
        .tiny-btn { padding: 5px 8px; font-size: 12px; }
        .section-head { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 10px; }
        .section-head h3 { margin: 0; }
        .section-switch-label { font-size: 13px; color: #444; user-select: none; display: inline-flex; align-items: center; gap: 10px; cursor: pointer; }
        .section-switch { position: relative; display: inline-block; width: 44px; height: 24px; flex-shrink: 0; vertical-align: middle; }
        .section-switch-input { position: absolute; opacity: 0; width: 44px; height: 24px; margin: 0; cursor: pointer; z-index: 1; }
        .section-switch-input:focus-visible + .section-switch-track { outline: 2px solid #1f6feb; outline-offset: 2px; }
        .section-switch-track { display: block; width: 100%; height: 100%; background: #c4c4c4; border-radius: 999px; transition: background 0.2s ease; cursor: pointer; position: relative; }
        .section-switch-track::after { content: ''; position: absolute; top: 2px; left: 2px; width: 20px; height: 20px; background: #fff; border-radius: 50%; box-shadow: 0 1px 3px rgba(0,0,0,0.2); transition: transform 0.2s ease; }
        .section-switch-input:checked + .section-switch-track { background: #1f6feb; }
        .section-switch-input:checked + .section-switch-track::after { transform: translateX(20px); }
        .section-panel.is-closed { opacity: 0.92; }
        .section-body.is-closed { display: none; }
        .slice-preview-block { margin-top: 12px; padding-top: 12px; border-top: 1px solid #eee; }
        .slice-preview-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); gap: 8px; max-height: 280px; overflow: auto; margin-top: 8px; }
        .slice-preview-card { border: 1px dashed #bbb; border-radius: 6px; padding: 6px; text-align: center; font-size: 11px; background: #fafafa; }
        .slice-preview-card img { display: block; margin: 0 auto 4px; max-width: 100%; max-height: 72px; object-fit: contain; }
        .slice-preview-pick { display: flex; align-items: center; justify-content: center; gap: 5px; margin-bottom: 4px; cursor: pointer; user-select: none; }
        .slice-preview-toolbar { margin-top: 8px; }
        .layer-list { list-style: none; padding: 0; margin: 8px 0 0 0; max-height: 240px; overflow: auto; border: 1px solid #e5e5e5; border-radius: 6px; background: #fafafa; }
        .layer-list li { display: flex; align-items: center; gap: 8px; padding: 8px 10px; border-bottom: 1px solid #eee; font-size: 13px; flex-wrap: wrap; }
        .layer-list li:last-child { border-bottom: none; }
        .layer-list .layer-list-sub { font-weight: 600; font-size: 12px; color: #444; background: #f0f0f0; }
        .layer-list .layer-spacer { margin-left: auto; }
        @media (max-width: 980px) {
            .workspace-layout { flex-direction: column; }
            .image-area, .settings-area { max-width: 100%; flex-basis: 100%; }
            .app-shell { flex-direction: column; }
            .app-sidebar {
                width: 100%;
                flex-direction: row;
                flex-wrap: wrap;
                justify-content: center;
                padding: 10px 12px;
                border-right: none;
                border-bottom: 1px solid #e8e8ef;
            }
            .sb-spacer { display: none; }
            .sb-create { margin-bottom: 0; }
        }
        .create-modal {
            position: fixed;
            inset: 0;
            z-index: 4000;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 16px;
        }
        .create-modal.hidden { display: none !important; }
        .create-modal-backdrop {
            position: absolute;
            inset: 0;
            background: rgba(15, 23, 42, 0.52);
            cursor: pointer;
        }
        .create-modal-dialog {
            position: relative;
            z-index: 1;
            width: min(1040px, 100%);
            max-height: min(86vh, 760px);
            background: #fff;
            border-radius: 16px;
            border: 1px solid #e5e7eb;
            box-shadow: 0 24px 64px rgba(0, 0, 0, 0.22);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        .create-modal-top {
            flex-shrink: 0;
            padding: 20px 22px 14px;
            border-bottom: 1px solid #f0f0f5;
        }
        .create-modal-title-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 14px;
        }
        .create-modal-title {
            margin: 0;
            font-size: 1.35rem;
            font-weight: 700;
            color: #111827;
            letter-spacing: -0.02em;
        }
        .create-modal-close {
            width: 40px;
            height: 40px;
            border: none;
            border-radius: 10px;
            background: #f3f4f6;
            color: #374151;
            font-size: 22px;
            line-height: 1;
            cursor: pointer;
        }
        .create-modal-close:hover { background: #e5e7eb; }
        .create-modal-search {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 14px;
            border-radius: 12px;
            border: 2px solid #e9d5ff;
            background: #fafafa;
            transition: border-color 0.15s ease, box-shadow 0.15s ease;
        }
        .create-modal-search:focus-within {
            border-color: #a78bfa;
            box-shadow: 0 0 0 3px rgba(167, 139, 250, 0.25);
            background: #fff;
        }
        .create-modal-search svg {
            width: 20px;
            height: 20px;
            color: #9ca3af;
            flex-shrink: 0;
        }
        .create-modal-search-input {
            flex: 1;
            min-width: 0;
            border: none;
            background: transparent;
            font: inherit;
            font-size: 0.95rem;
            outline: none;
            color: #111827;
        }
        .create-modal-search-input::placeholder { color: #9ca3af; }
        .create-modal-body {
            display: flex;
            flex: 1;
            min-height: 0;
        }
        .create-modal-sidebar {
            width: 220px;
            flex-shrink: 0;
            border-right: 1px solid #eceef4;
            overflow-y: auto;
            padding: 10px 8px 16px;
            background: #fcfcfd;
        }
        .create-nav-item {
            display: flex;
            align-items: center;
            gap: 10px;
            width: 100%;
            padding: 10px 12px;
            margin-bottom: 2px;
            border: none;
            border-radius: 10px;
            background: transparent;
            cursor: pointer;
            text-align: left;
            font: inherit;
            font-size: 13px;
            color: #374151;
        }
        .create-nav-item:hover { background: #f3f4f6; }
        .create-nav-item.is-active {
            background: #ede9fe;
            color: #5b21b6;
            font-weight: 600;
        }
        .create-nav-icon {
            width: 26px;
            height: 26px;
            border-radius: 8px;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }
        .create-nav-icon--spark { background: linear-gradient(135deg, #c4b5fd, #a78bfa); color: #fff; }
        .create-nav-icon--mail { background: linear-gradient(135deg, #f9a8d4, #ec4899); color: #fff; }
        .create-nav-icon--sheet { background: linear-gradient(135deg, #86efac, #22c55e); color: #fff; }
        .create-nav-icon--doc { background: linear-gradient(135deg, #7dd3fc, #0ea5e9); color: #fff; }
        .create-nav-icon--board { background: linear-gradient(135deg, #fde047, #eab308); color: #422006; }
        .create-nav-icon--pres { background: linear-gradient(135deg, #fb923c, #ea580c); color: #fff; }
        .create-nav-icon--social { background: linear-gradient(135deg, #f472b6, #db2777); color: #fff; }
        .create-nav-icon--video { background: linear-gradient(135deg, #c084fc, #7c3aed); color: #fff; }
        .create-nav-icon--print { background: linear-gradient(135deg, #94a3b8, #475569); color: #fff; }
        .create-nav-icon--web { background: linear-gradient(135deg, #67e8f9, #0891b2); color: #fff; }
        .create-nav-icon--size { background: linear-gradient(135deg, #e5e7eb, #9ca3af); color: #1f2937; }
        .create-modal-main {
            flex: 1;
            min-width: 0;
            overflow-y: auto;
            padding: 18px 22px 24px;
            background: #fff;
        }
        .create-sec { margin-bottom: 28px; scroll-margin-top: 12px; }
        .create-sec h3 {
            margin: 0 0 14px;
            font-size: 0.95rem;
            font-weight: 700;
            color: #111827;
        }
        .create-card-row {
            display: flex;
            flex-wrap: wrap;
            gap: 16px;
        }
        .create-tile {
            flex: 0 0 auto;
            width: 140px;
            border: none;
            padding: 0;
            background: none;
            cursor: pointer;
            text-align: center;
            font: inherit;
            color: #374151;
        }
        .create-tile-thumb {
            height: 112px;
            border-radius: 12px;
            background: linear-gradient(180deg, #f4f4f5 0%, #e8e8ec 100%);
            border: 1px solid #e5e7eb;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: box-shadow 0.15s ease, transform 0.15s ease;
        }
        .create-tile:hover .create-tile-thumb {
            box-shadow: 0 8px 24px rgba(15, 23, 42, 0.1);
            transform: translateY(-2px);
        }
        .create-tile-thumb--mail::before {
            content: '';
            width: 72%;
            height: 58%;
            border-radius: 6px;
            background: #fff;
            border: 1px solid #ddd;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
        }
        .create-tile-thumb--grid::before {
            content: '';
            width: 64%;
            height: 64%;
            background: repeating-linear-gradient(90deg, #ddd 0, #ddd 1px, transparent 1px, transparent 33.33%),
                repeating-linear-gradient(#ddd 0, #ddd 1px, transparent 1px, transparent 33.33%);
            background-size: 100% 100%;
            border-radius: 4px;
        }
        .create-tile-thumb--wide::before {
            content: '';
            width: 88%;
            height: 52%;
            border-radius: 6px;
            background: #fff;
            border: 1px solid #ddd;
        }
        .create-tile-thumb--phone::before {
            content: '';
            width: 42%;
            height: 72%;
            border-radius: 10px;
            background: #1f2937;
            border: 3px solid #374151;
        }
        .create-tile-label { font-size: 12px; font-weight: 600; line-height: 1.3; }
        .create-tile.is-muted .create-tile-thumb { opacity: 0.65; }
    </style>
</head>
<body>
<nav class="app-menubar" id="appMenubar" aria-label="Application menu">
    <div class="menu-bar-inner" role="menubar" aria-label="Main">
        <div class="menu-root">
            <button type="button" class="menu-top" id="menuTopFile" aria-haspopup="true" aria-expanded="false" aria-controls="menuDropdownFile">File</button>
            <div class="menu-dropdown" id="menuDropdownFile" role="menu" hidden>
                <div class="menu-dropdown-head">
                    <div class="menu-dropdown-title">File</div>
                    <div class="menu-dropdown-sub">New, open, save &amp; export</div>
                </div>
                <div class="menu-sep-head" role="presentation"></div>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="new-document">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><line x1="12" y1="18" x2="12" y2="12"/><line x1="9" y1="15" x2="15" y2="15"/></svg></span>
                    <span class="menu-row-label">New…</span>
                    <kbd class="menu-kbd">Ctrl+N</kbd>
                </button>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="open-image">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg></span>
                    <span class="menu-row-label">Open…</span>
                    <kbd class="menu-kbd">Ctrl+O</kbd>
                </button>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="browse-image">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg></span>
                    <span class="menu-row-label">Browse…</span>
                    <kbd class="menu-kbd">Shift+Ctrl+O</kbd>
                </button>
                <button type="button" class="menu-row" role="menuitem" disabled title="Not available in this web app">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg></span>
                    <span class="menu-row-label">Open As…</span>
                    <kbd class="menu-kbd">Alt+Ctrl+O</kbd>
                </button>
                <div class="menu-submenu-parent" role="none">
                    <button type="button" class="menu-row" role="menuitem" aria-haspopup="true" tabindex="0">
                        <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></span>
                        <span class="menu-row-label">Open Recent</span>
                        <span class="menu-chevron" aria-hidden="true">›</span>
                    </button>
                    <div class="menu-flyout" role="menu">
                        <button type="button" class="menu-row" role="menuitem" disabled title="Recent files are not tracked in the browser">
                            <span class="menu-row-label">No recent files</span>
                        </button>
                    </div>
                </div>
                <div class="menu-sep" role="separator"></div>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="close-workspace">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg></span>
                    <span class="menu-row-label">Close</span>
                    <kbd class="menu-kbd">Ctrl+W</kbd>
                </button>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="save-crop">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg></span>
                    <span class="menu-row-label">Save</span>
                    <kbd class="menu-kbd">Ctrl+S</kbd>
                </button>
                <button type="button" class="menu-row" role="menuitem" disabled title="Use Save to export the current crop">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg></span>
                    <span class="menu-row-label">Save As…</span>
                    <kbd class="menu-kbd">Shift+Ctrl+S</kbd>
                </button>
                <button type="button" class="menu-row" role="menuitem" disabled title="Not available">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg></span>
                    <span class="menu-row-label">Save for Web…</span>
                    <kbd class="menu-kbd">Alt+Shift+Ctrl+S</kbd>
                </button>
                <button type="button" class="menu-row" role="menuitem" disabled title="Revert is not implemented">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg></span>
                    <span class="menu-row-label">Revert</span>
                </button>
                <div class="menu-sep" role="separator"></div>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="place-image">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg></span>
                    <span class="menu-row-label">Place…</span>
                </button>
                <div class="menu-sep" role="separator"></div>
                <div class="menu-submenu-parent" role="none">
                    <button type="button" class="menu-row" role="menuitem" aria-haspopup="true" tabindex="0">
                        <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg></span>
                        <span class="menu-row-label">Import</span>
                        <span class="menu-chevron" aria-hidden="true">›</span>
                    </button>
                    <div class="menu-flyout" role="menu">
                        <button type="button" class="menu-row" role="menuitem" disabled title="Not available">
                            <span class="menu-row-label">Import from Clipboard…</span>
                        </button>
                        <button type="button" class="menu-row" role="menuitem" data-menu-action="open-image">
                            <span class="menu-row-label">Place from File…</span>
                        </button>
                    </div>
                </div>
                <div class="menu-submenu-parent" role="none">
                    <button type="button" class="menu-row" role="menuitem" aria-haspopup="true" tabindex="0">
                        <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></span>
                        <span class="menu-row-label">Export</span>
                        <span class="menu-chevron" aria-hidden="true">›</span>
                    </button>
                    <div class="menu-flyout" role="menu">
                        <button type="button" class="menu-row" role="menuitem" data-menu-action="download-all">
                            <span class="menu-row-label">Download all slices (ZIP)</span>
                        </button>
                        <button type="button" class="menu-row" role="menuitem" data-menu-action="save-crop">
                            <span class="menu-row-label">Save crop as PNG</span>
                        </button>
                        <button type="button" class="menu-row" role="menuitem" data-menu-action="preview-slices">
                            <span class="menu-row-label">Preview slices</span>
                        </button>
                    </div>
                </div>
                <div class="menu-sep" role="separator"></div>
                <div class="menu-submenu-parent" role="none">
                    <button type="button" class="menu-row" role="menuitem" aria-haspopup="true" tabindex="0">
                        <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg></span>
                        <span class="menu-row-label">Workgroup</span>
                        <span class="menu-chevron" aria-hidden="true">›</span>
                    </button>
                    <div class="menu-flyout" role="menu">
                        <button type="button" class="menu-row" role="menuitem" disabled title="Not available">
                            <span class="menu-row-label">Browse Online…</span>
                        </button>
                    </div>
                </div>
                <div class="menu-sep" role="separator"></div>
                <div class="menu-submenu-parent" role="none">
                    <button type="button" class="menu-row" role="menuitem" aria-haspopup="true" tabindex="0">
                        <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg></span>
                        <span class="menu-row-label">Automate</span>
                        <span class="menu-chevron" aria-hidden="true">›</span>
                    </button>
                    <div class="menu-flyout" role="menu">
                        <button type="button" class="menu-row" role="menuitem" data-menu-action="slice">
                            <span class="menu-row-label">Slice image</span>
                        </button>
                    </div>
                </div>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="file-info">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg></span>
                    <span class="menu-row-label">File Info…</span>
                </button>
                <div class="menu-sep" role="separator"></div>
                <button type="button" class="menu-row" role="menuitem" disabled title="Not available in browser">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><line x1="7" y1="8" x2="17" y2="8"/></svg></span>
                    <span class="menu-row-label">Page Setup…</span>
                    <kbd class="menu-kbd">Shift+Ctrl+P</kbd>
                </button>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="print-preview">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg></span>
                    <span class="menu-row-label">Print with Preview…</span>
                    <kbd class="menu-kbd">Ctrl+P</kbd>
                </button>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="print-preview">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg></span>
                    <span class="menu-row-label">Print…</span>
                    <kbd class="menu-kbd">Alt+Ctrl+P</kbd>
                </button>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="print-preview">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg></span>
                    <span class="menu-row-label">Print One Copy</span>
                    <kbd class="menu-kbd">Alt+Shift+Ctrl+P</kbd>
                </button>
                <div class="menu-sep" role="separator"></div>
                <div class="menu-submenu-parent" role="none">
                    <button type="button" class="menu-row" role="menuitem" aria-haspopup="true" tabindex="0">
                        <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="3 11 22 2 13 21 11 13 3 11"/></svg></span>
                        <span class="menu-row-label">Jump To</span>
                        <span class="menu-chevron" aria-hidden="true">›</span>
                    </button>
                    <div class="menu-flyout" role="menu">
                        <button type="button" class="menu-row" role="menuitem" data-menu-action="jump-home">
                            <span class="menu-row-label">Home</span>
                        </button>
                        <button type="button" class="menu-row" role="menuitem" data-menu-action="jump-editor">
                            <span class="menu-row-label">Editor</span>
                        </button>
                    </div>
                </div>
                <div class="menu-sep" role="separator"></div>
                <button type="button" class="menu-row" role="menuitem" disabled title="Close this browser tab to exit">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg></span>
                    <span class="menu-row-label">Exit</span>
                    <kbd class="menu-kbd">Ctrl+Q</kbd>
                </button>
            </div>
        </div>
        <div class="menu-root">
            <button type="button" class="menu-top" id="menuTopEdit" aria-haspopup="true" aria-expanded="false" aria-controls="menuDropdownEdit">Edit</button>
            <div class="menu-dropdown" id="menuDropdownEdit" role="menu" hidden>
                <div class="menu-dropdown-head">
                    <div class="menu-dropdown-title">Edit</div>
                    <div class="menu-dropdown-sub">Undo, regions &amp; adjustments</div>
                </div>
                <div class="menu-sep-head" role="presentation"></div>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="undo">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-15-6.7L3 7"/></svg></span>
                    <span class="menu-row-label">Undo</span>
                    <kbd class="menu-kbd">Ctrl+Z</kbd>
                </button>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="undo-region">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5v0a5.5 5.5 0 0 1-5.5 5.5H11"/></svg></span>
                    <span class="menu-row-label">Undo region</span>
                    <kbd class="menu-kbd">Ctrl+Shift+Z</kbd>
                </button>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="clear-regions">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></span>
                    <span class="menu-row-label">Clear regions</span>
                    <kbd class="menu-kbd">Ctrl+Alt+X</kbd>
                </button>
                <div class="menu-sep" role="separator"></div>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="reset-edit">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 4v6h-6"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg></span>
                    <span class="menu-row-label">Reset edit</span>
                    <kbd class="menu-kbd">Ctrl+Alt+R</kbd>
                </button>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="merge-paint">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 2 7l10 5 10-5-10-5Z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg></span>
                    <span class="menu-row-label">Merge paint into base</span>
                    <kbd class="menu-kbd">Ctrl+Shift+M</kbd>
                </button>
            </div>
        </div>
        <div class="menu-root">
            <button type="button" class="menu-top" id="menuTopView" aria-haspopup="true" aria-expanded="false" aria-controls="menuDropdownView">View</button>
            <div class="menu-dropdown" id="menuDropdownView" role="menu" hidden>
                <div class="menu-dropdown-head">
                    <div class="menu-dropdown-title">View</div>
                    <div class="menu-dropdown-sub">Zoom &amp; side panels</div>
                </div>
                <div class="menu-sep-head" role="presentation"></div>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="zoom-in">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/><line x1="11" y1="8" x2="11" y2="14"/><line x1="8" y1="11" x2="14" y2="11"/></svg></span>
                    <span class="menu-row-label">Zoom in</span>
                    <kbd class="menu-kbd">Ctrl++</kbd>
                </button>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="zoom-out">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/><line x1="8" y1="11" x2="14" y2="11"/></svg></span>
                    <span class="menu-row-label">Zoom out</span>
                    <kbd class="menu-kbd">Ctrl+-</kbd>
                </button>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="zoom-reset">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h6v6"/><path d="M9 21H3v-6"/><path d="M21 3l-7 7"/><path d="M3 21l7-7"/></svg></span>
                    <span class="menu-row-label">Reset zoom</span>
                    <kbd class="menu-kbd">Ctrl+0</kbd>
                </button>
                <div class="menu-sep" role="separator"></div>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="panel-settings">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg></span>
                    <span class="menu-row-label">Settings panel</span>
                    <span class="menu-chevron" aria-hidden="true">›</span>
                </button>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="panel-crop">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2H3v3"/><path d="M18 2h3v3"/><path d="M6 22H3v-3"/><path d="M18 22h3v-3"/><rect x="7" y="7" width="10" height="10" rx="1"/></svg></span>
                    <span class="menu-row-label">Crop panel</span>
                    <span class="menu-chevron" aria-hidden="true">›</span>
                </button>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="panel-edit">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg></span>
                    <span class="menu-row-label">Edit panel</span>
                    <span class="menu-chevron" aria-hidden="true">›</span>
                </button>
                <button type="button" class="menu-row" role="menuitem" data-menu-action="panel-slicing">
                    <span class="menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/></svg></span>
                    <span class="menu-row-label">Custom slicing panel</span>
                    <span class="menu-chevron" aria-hidden="true">›</span>
                </button>
            </div>
        </div>
    </div>
</nav>
<div id="createDesignModal" class="create-modal hidden" role="dialog" aria-modal="true" aria-labelledby="createModalTitle">
    <div class="create-modal-backdrop" id="createModalBackdrop" aria-hidden="true"></div>
    <div class="create-modal-dialog">
        <div class="create-modal-top">
            <div class="create-modal-title-row">
                <h2 class="create-modal-title" id="createModalTitle">Create a design</h2>
                <button type="button" class="create-modal-close" id="createModalCloseBtn" aria-label="Close">&times;</button>
            </div>
            <label class="create-modal-search" for="createModalSearchInput">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                <input type="search" id="createModalSearchInput" class="create-modal-search-input" placeholder="What would you like to create?" autocomplete="off">
            </label>
        </div>
        <div class="create-modal-body">
            <nav class="create-modal-sidebar" id="createModalSidebar" aria-label="Design categories">
                <button type="button" class="create-nav-item is-active" data-scroll-to="createPaneForyou" data-create-tags="for you start home">
                    <span class="create-nav-icon create-nav-icon--spark" aria-hidden="true">&#10022;</span>
                    For you
                </button>
                <button type="button" class="create-nav-item" data-scroll-to="createPaneEmail" data-create-tags="email letter mail">
                    <span class="create-nav-icon create-nav-icon--mail" aria-hidden="true">&#9993;</span>
                    Emails
                </button>
                <button type="button" class="create-nav-item" data-scroll-to="createPaneSheet" data-create-tags="sheet table grid data">
                    <span class="create-nav-icon create-nav-icon--sheet" aria-hidden="true">&#9632;</span>
                    Sheets
                </button>
                <button type="button" class="create-nav-item" data-scroll-to="createPaneDoc" data-create-tags="doc document page">
                    <span class="create-nav-icon create-nav-icon--doc" aria-hidden="true">&#9636;</span>
                    Docs
                </button>
                <button type="button" class="create-nav-item" data-scroll-to="createPaneWhiteboard" data-create-tags="whiteboard sketch draw free">
                    <span class="create-nav-icon create-nav-icon--board" aria-hidden="true">&#9634;</span>
                    Whiteboards
                </button>
                <button type="button" class="create-nav-item" data-scroll-to="createPanePresentation" data-create-tags="presentation slide deck wide">
                    <span class="create-nav-icon create-nav-icon--pres" aria-hidden="true">&#9635;</span>
                    Presentations
                </button>
                <button type="button" class="create-nav-item" data-scroll-to="createPaneSocial" data-create-tags="social instagram story square">
                    <span class="create-nav-icon create-nav-icon--social" aria-hidden="true">&#9829;</span>
                    Social media
                </button>
                <button type="button" class="create-nav-item" data-scroll-to="createPaneVideo" data-create-tags="video reel clip">
                    <span class="create-nav-icon create-nav-icon--video" aria-hidden="true">&#9654;</span>
                    Videos
                </button>
                <button type="button" class="create-nav-item" data-scroll-to="createPanePrint" data-create-tags="print printable poster">
                    <span class="create-nav-icon create-nav-icon--print" aria-hidden="true">&#9113;</span>
                    Printables
                </button>
                <button type="button" class="create-nav-item" data-scroll-to="createPaneWeb" data-create-tags="web website banner">
                    <span class="create-nav-icon create-nav-icon--web" aria-hidden="true">&#9678;</span>
                    Websites
                </button>
                <button type="button" class="create-nav-item" data-scroll-to="createPaneCustom" data-create-tags="custom size dimensions layout width">
                    <span class="create-nav-icon create-nav-icon--size" aria-hidden="true">&#8862;</span>
                    Custom size
                </button>
            </nav>
            <div class="create-modal-main" id="createModalMain">
                <section class="create-sec" id="createPaneForyou" data-create-tags="frequently upload slice grid">
                    <h3>Frequently used</h3>
                    <div class="create-card-row">
                        <button type="button" class="create-tile" data-create-action="new-document" data-create-tags="blank new canvas document start">
                            <div class="create-tile-thumb create-tile-thumb--wide" aria-hidden="true"></div>
                            <div class="create-tile-label">Blank canvas</div>
                        </button>
                        <button type="button" class="create-tile" data-create-action="upload" data-create-tags="upload image photo blank">
                            <div class="create-tile-thumb create-tile-thumb--mail" aria-hidden="true"></div>
                            <div class="create-tile-label">Upload image</div>
                        </button>
                        <button type="button" class="create-tile" data-create-action="preset" data-create-preset="4" data-create-tags="grid four tiles slice">
                            <div class="create-tile-thumb create-tile-thumb--grid" aria-hidden="true"></div>
                            <div class="create-tile-label">4-tile grid</div>
                        </button>
                        <button type="button" class="create-tile" data-create-action="preset" data-create-preset="9" data-create-tags="nine instagram square">
                            <div class="create-tile-thumb create-tile-thumb--grid" aria-hidden="true"></div>
                            <div class="create-tile-label">9-tile grid</div>
                        </button>
                        <button type="button" class="create-tile" data-create-action="quick" data-create-quick="slice" data-create-tags="slice custom regions draw">
                            <div class="create-tile-thumb create-tile-thumb--wide" aria-hidden="true"></div>
                            <div class="create-tile-label">Custom regions</div>
                        </button>
                    </div>
                </section>
                <section class="create-sec" id="createPaneEmail" data-create-tags="email newsletter">
                    <h3>Emails</h3>
                    <div class="create-card-row">
                        <button type="button" class="create-tile" data-create-action="upload" data-create-tags="newsletter"><div class="create-tile-thumb create-tile-thumb--mail" aria-hidden="true"></div><div class="create-tile-label">Newsletter</div></button>
                        <button type="button" class="create-tile" data-create-action="preset" data-create-preset="16" data-create-tags="wide email header"><div class="create-tile-thumb create-tile-thumb--wide" aria-hidden="true"></div><div class="create-tile-label">16 tiles</div></button>
                    </div>
                </section>
                <section class="create-sec" id="createPaneSheet" data-create-tags="sheet spreadsheet">
                    <h3>Sheets</h3>
                    <div class="create-card-row">
                        <button type="button" class="create-tile" data-create-action="preset" data-create-preset="25" data-create-tags="cells grid"><div class="create-tile-thumb create-tile-thumb--grid" aria-hidden="true"></div><div class="create-tile-label">25 tiles</div></button>
                        <button type="button" class="create-tile" data-create-action="upload" data-create-tags="data"><div class="create-tile-thumb create-tile-thumb--wide" aria-hidden="true"></div><div class="create-tile-label">From image</div></button>
                    </div>
                </section>
                <section class="create-sec" id="createPaneDoc" data-create-tags="document">
                    <h3>Docs</h3>
                    <div class="create-card-row">
                        <button type="button" class="create-tile" data-create-action="upload" data-create-tags="page"><div class="create-tile-thumb create-tile-thumb--mail" aria-hidden="true"></div><div class="create-tile-label">Page slices</div></button>
                        <button type="button" class="create-tile" data-create-action="quick" data-create-quick="edit" data-create-tags="text edit"><div class="create-tile-thumb create-tile-thumb--wide" aria-hidden="true"></div><div class="create-tile-label">Edit &amp; text</div></button>
                    </div>
                </section>
                <section class="create-sec" id="createPaneWhiteboard" data-create-tags="whiteboard freeform">
                    <h3>Whiteboards</h3>
                    <div class="create-card-row">
                        <button type="button" class="create-tile" data-create-action="quick" data-create-quick="slice" data-create-tags="draw regions"><div class="create-tile-thumb create-tile-thumb--grid" aria-hidden="true"></div><div class="create-tile-label">Draw regions</div></button>
                        <button type="button" class="create-tile" data-create-action="upload" data-create-tags="import"><div class="create-tile-thumb create-tile-thumb--mail" aria-hidden="true"></div><div class="create-tile-label">Import image</div></button>
                    </div>
                </section>
                <section class="create-sec" id="createPanePresentation" data-create-tags="presentation slides">
                    <h3>Presentations</h3>
                    <div class="create-card-row">
                        <button type="button" class="create-tile" data-create-action="preset" data-create-preset="4" data-create-tags="slide 2x2"><div class="create-tile-thumb create-tile-thumb--wide" aria-hidden="true"></div><div class="create-tile-label">2 &times; 2 slides</div></button>
                        <button type="button" class="create-tile" data-create-action="preset" data-create-preset="100" data-create-tags="many thumbnails"><div class="create-tile-thumb create-tile-thumb--grid" aria-hidden="true"></div><div class="create-tile-label">Many tiles</div></button>
                    </div>
                </section>
                <section class="create-sec" id="createPaneSocial" data-create-tags="social instagram">
                    <h3>Popular for social</h3>
                    <div class="create-card-row">
                        <button type="button" class="create-tile" data-create-action="preset" data-create-preset="9" data-create-tags="instagram post"><div class="create-tile-thumb create-tile-thumb--phone" aria-hidden="true"></div><div class="create-tile-label">Square 9</div></button>
                        <button type="button" class="create-tile" data-create-action="preset" data-create-preset="4" data-create-tags="carousel"><div class="create-tile-thumb create-tile-thumb--phone" aria-hidden="true"></div><div class="create-tile-label">Carousel 4</div></button>
                        <button type="button" class="create-tile" data-create-action="upload" data-create-tags="photo"><div class="create-tile-thumb create-tile-thumb--mail" aria-hidden="true"></div><div class="create-tile-label">From photo</div></button>
                    </div>
                </section>
                <section class="create-sec" id="createPaneVideo" data-create-tags="video thumb storyboard">
                    <h3>Videos</h3>
                    <div class="create-card-row">
                        <button type="button" class="create-tile" data-create-action="preset" data-create-preset="16" data-create-tags="storyboard frames"><div class="create-tile-thumb create-tile-thumb--wide" aria-hidden="true"></div><div class="create-tile-label">Storyboard 16</div></button>
                        <button type="button" class="create-tile" data-create-action="upload" data-create-tags="thumbnail"><div class="create-tile-thumb create-tile-thumb--mail" aria-hidden="true"></div><div class="create-tile-label">Thumbnails</div></button>
                    </div>
                </section>
                <section class="create-sec" id="createPanePrint" data-create-tags="print poster">
                    <h3>Printables</h3>
                    <div class="create-card-row">
                        <button type="button" class="create-tile" data-create-action="preset" data-create-preset="9" data-create-tags="poster grid"><div class="create-tile-thumb create-tile-thumb--grid" aria-hidden="true"></div><div class="create-tile-label">Poster grid</div></button>
                        <button type="button" class="create-tile" data-create-action="upload" data-create-tags="print"><div class="create-tile-thumb create-tile-thumb--mail" aria-hidden="true"></div><div class="create-tile-label">Print split</div></button>
                    </div>
                </section>
                <section class="create-sec" id="createPaneWeb" data-create-tags="web banner">
                    <h3>Websites</h3>
                    <div class="create-card-row">
                        <button type="button" class="create-tile" data-create-action="preset" data-create-preset="25" data-create-tags="assets sprites"><div class="create-tile-thumb create-tile-thumb--grid" aria-hidden="true"></div><div class="create-tile-label">Asset grid</div></button>
                        <button type="button" class="create-tile" data-create-action="upload" data-create-tags="hero banner"><div class="create-tile-thumb create-tile-thumb--wide" aria-hidden="true"></div><div class="create-tile-label">Hero strip</div></button>
                    </div>
                </section>
                <section class="create-sec" id="createPaneCustom" data-create-tags="custom size layout settings">
                    <h3>Custom size</h3>
                    <div class="create-card-row">
                        <button type="button" class="create-tile" data-create-action="quick" data-create-quick="slicing-panel" data-create-tags="slicing options rows columns"><div class="create-tile-thumb create-tile-thumb--grid" aria-hidden="true"></div><div class="create-tile-label">Slicing options</div></button>
                        <button type="button" class="create-tile" data-create-action="quick" data-create-quick="zoom" data-create-tags="layout workspace"><div class="create-tile-thumb create-tile-thumb--wide" aria-hidden="true"></div><div class="create-tile-label">Workspace layout</div></button>
                        <button type="button" class="create-tile" data-create-action="quick" data-create-quick="settings" data-create-tags="settings panel split width"><div class="create-tile-thumb create-tile-thumb--mail" aria-hidden="true"></div><div class="create-tile-label">Panel width</div></button>
                    </div>
                </section>
            </div>
        </div>
    </div>
</div>
<div id="newDocumentModal" class="create-modal hidden" role="dialog" aria-modal="true" aria-labelledby="newDocumentModalTitle">
    <div class="create-modal-backdrop" id="newDocumentModalBackdrop" aria-hidden="true"></div>
    <div class="create-modal-dialog new-doc-dialog">
        <div class="create-modal-top">
            <div class="create-modal-title-row">
                <h2 class="create-modal-title" id="newDocumentModalTitle">New</h2>
                <button type="button" class="create-modal-close" id="newDocumentModalCloseBtn" aria-label="Close">&times;</button>
            </div>
            <p class="new-doc-muted" style="margin:0;">Create a blank canvas, then use <strong>Open image</strong> to place a photo (scaled to fit, centered).</p>
        </div>
        <div class="new-doc-body">
            <div class="new-doc-form-grid">
                <div class="field new-doc-span2">
                    <label for="newDocName">Name</label>
                    <input id="newDocName" type="text" maxlength="120" value="Untitled-1" autocomplete="off">
                </div>
                <div class="field">
                    <label for="newDocWidth">Width (px)</label>
                    <input id="newDocWidth" type="number" min="1" max="8192" value="1920">
                </div>
                <div class="field">
                    <label for="newDocHeight">Height (px)</label>
                    <input id="newDocHeight" type="number" min="1" max="8192" value="1080">
                </div>
                <div class="field new-doc-span2 new-doc-thumb-section" aria-labelledby="newDocThumbHeading">
                    <h3 class="new-doc-thumb-heading" id="newDocThumbHeading">Thumbnail designs</h3>
                    <p class="new-doc-muted" style="margin:0 0 10px;">Common social sizes for your blank canvas. You can still crop after you add an image.</p>
                    <div class="thumb-design-grid">
                        <button type="button" class="thumb-preset-btn thumb-preset--yt" data-new-doc-thumb="1" data-thumb-w="1280" data-thumb-h="720" title="YouTube video thumbnail (16:9)">
                            <span class="thumb-preset-badge">16:9</span>
                            <span class="thumb-preset-name">YouTube</span>
                            <span class="thumb-preset-meta">1280 × 720</span>
                        </button>
                        <button type="button" class="thumb-preset-btn thumb-preset--ig" data-new-doc-thumb="1" data-thumb-w="1080" data-thumb-h="1080" title="Instagram square">
                            <span class="thumb-preset-badge">1:1</span>
                            <span class="thumb-preset-name">Instagram</span>
                            <span class="thumb-preset-meta">1080 × 1080</span>
                        </button>
                        <button type="button" class="thumb-preset-btn thumb-preset--ig" data-new-doc-thumb="1" data-thumb-w="1080" data-thumb-h="1920" title="Instagram story / Reel">
                            <span class="thumb-preset-badge">9:16</span>
                            <span class="thumb-preset-name">Story / Reel</span>
                            <span class="thumb-preset-meta">1080 × 1920</span>
                        </button>
                        <button type="button" class="thumb-preset-btn thumb-preset--li" data-new-doc-thumb="1" data-thumb-w="1200" data-thumb-h="627" title="LinkedIn link preview">
                            <span class="thumb-preset-badge">~1.91:1</span>
                            <span class="thumb-preset-name">LinkedIn</span>
                            <span class="thumb-preset-meta">1200 × 627</span>
                        </button>
                        <div class="thumb-custom-card">
                            <span class="thumb-preset-name" style="margin:0;">Custom size</span>
                            <span class="thumb-preset-meta">Any width × height (px).</span>
                            <div class="thumb-custom-row">
                                <div class="field">
                                    <label for="newDocThumbCustomW">Width</label>
                                    <input id="newDocThumbCustomW" type="number" min="1" max="8192" value="1200" placeholder="W">
                                </div>
                                <div class="field">
                                    <label for="newDocThumbCustomH">Height</label>
                                    <input id="newDocThumbCustomH" type="number" min="1" max="8192" value="630" placeholder="H">
                                </div>
                                <button type="button" class="thumb-custom-apply" id="newDocThumbCustomApplyBtn">Apply to canvas</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="field new-doc-span2">
                    <span class="muted" style="font-size:12px;">Color mode</span>
                    <div style="padding:8px 10px;border:1px solid #e5e7eb;border-radius:8px;background:#f9fafb;font-size:13px;color:#374151;">RGB Color</div>
                </div>
                <div class="field new-doc-span2">
                    <span class="muted" style="font-size:12px;">Contents</span>
                    <div class="new-doc-contents">
                        <label><input type="radio" name="newDocContents" value="white" checked> White</label>
                        <label><input type="radio" name="newDocContents" value="transparent"> Transparent</label>
                        <label><input type="radio" name="newDocContents" value="custom"> Custom color</label>
                    </div>
                </div>
                <div class="field new-doc-span2 hidden" id="newDocColorRow">
                    <label for="newDocBgColor">Background color</label>
                    <input id="newDocBgColor" type="color" value="#ffffff">
                </div>
            </div>
            <div class="new-doc-actions">
                <button type="button" class="new-doc-btn-secondary" id="newDocumentCancelBtn">Cancel</button>
                <button type="button" class="new-doc-btn-primary" id="newDocumentCreateBtn">Create</button>
            </div>
        </div>
    </div>
</div>
<div class="app-shell">
<aside class="app-sidebar" aria-label="App navigation">
    <button type="button" class="sb-item sb-create" id="sbCreateBtn" title="Create a design" aria-label="Create a design">
        <span class="sb-plus" aria-hidden="true">+</span>
    </button>
    <button type="button" class="sb-item" data-nav="home" title="Home" aria-label="Home">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
    </button>
    <button type="button" class="sb-item" data-nav="editor" title="Editor" aria-label="Editor">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/></svg>
    </button>
    <button type="button" class="sb-item" data-nav="settings" title="Settings" aria-label="Settings">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
    </button>
    <div class="sb-spacer" aria-hidden="true"></div>
    <button type="button" class="sb-item" data-nav="download" title="Download ZIP" aria-label="Download all slices">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
    </button>
</aside>
<div class="app-main">
<div class="dash-home">
<section class="dash-hero" id="dashHero">
    <div class="dash-hero-inner">
        <h1 class="dash-headline">What will you slice today?</h1>
        <p class="dash-sub">Upload an image, crop and edit it, then export a grid or custom regions — all in your browser.</p>
        <div class="dash-search-row">
            <label class="dash-search" for="dashSearchInput">
                <svg class="dash-search-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                <input type="search" id="dashSearchInput" class="dash-search-input" placeholder="Search tips, slice counts, presets…" autocomplete="off" aria-label="Search">
            </label>
            <button type="button" class="dash-upload-btn" id="dashHeroUploadBtn">Upload</button>
        </div>
    </div>
</section>
<div class="dash-quick-wrap">
    <div class="dash-quick-inner">
    <div class="dash-quick-scroll">
        <button type="button" class="quick-orb quick-orb--u" data-quick="upload" title="Upload image">
            <span class="quick-orb-circle" aria-hidden="true">&#8681;</span>
            <span class="quick-orb-label">Upload</span>
        </button>
        <button type="button" class="quick-orb quick-orb--s" data-quick="slice" title="Slice tool">
            <span class="quick-orb-circle" aria-hidden="true">&#8862;</span>
            <span class="quick-orb-label">Slice</span>
        </button>
        <button type="button" class="quick-orb quick-orb--c" data-quick="crop" title="Crop">
            <span class="quick-orb-circle" aria-hidden="true">&#9986;</span>
            <span class="quick-orb-label">Crop</span>
        </button>
        <button type="button" class="quick-orb quick-orb--e" data-quick="edit" title="Edit">
            <span class="quick-orb-circle" aria-hidden="true">&#9998;</span>
            <span class="quick-orb-label">Edit</span>
        </button>
        <button type="button" class="quick-orb quick-orb--g" data-quick="slicing-panel" title="Custom slicing">
            <span class="quick-orb-circle" aria-hidden="true">&#9638;</span>
            <span class="quick-orb-label">Slicing</span>
        </button>
        <button type="button" class="quick-orb quick-orb--z" data-quick="zoom" title="Reset zoom">
            <span class="quick-orb-circle" aria-hidden="true">&#8635;</span>
            <span class="quick-orb-label">Reset zoom</span>
        </button>
        <button type="button" class="quick-orb quick-orb--d" data-quick="download" title="Download all">
            <span class="quick-orb-circle quick-orb-circle--txt" aria-hidden="true">ZIP</span>
            <span class="quick-orb-label">Download</span>
        </button>
    </div>
    </div>
</div>
<section class="dash-upload-row" aria-label="Upload image">
    <div class="dash-start-col">
        <div class="panel panel-upload dash-start-card">
            <div class="field">
                <label for="imageInput"><strong>Select image file</strong></label>
                <input id="imageInput" type="file" accept="image/jpeg,image/png,image/gif">
                <span class="muted">JPEG, PNG, or GIF — or use <strong>Upload</strong> above. <strong>New document</strong> opens a blank canvas; add an image when you are ready.</span>
                <div class="panel-upload-actions">
                    <button type="button" class="tool-btn" id="openNewDocumentModalBtn">New document…</button>
                </div>
            </div>
        </div>
    </div>
</section>
<div id="workspace" class="hidden">
    <div class="workspace-studio">
        <aside class="studio-tool-rail" id="psToolsBar" aria-label="Toolbox">
            <h3 class="studio-tool-rail-title">Tools</h3>
            <div class="studio-tool-primary" role="toolbar" aria-label="Canvas tools">
                <button type="button" id="cropToolBtn" class="ps-tool" data-ps-tool="crop" title="Crop Tool" aria-label="Crop Tool">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M8 4v5M4 8h5M16 20v-5M20 16h-5"/><path d="M10 10h8v8h-8z" opacity="0.35"/></svg>
                </button>
                <button type="button" id="sliceToolBtn" class="ps-tool ps-tool-active" data-ps-tool="slice" title="Slice Tool" aria-label="Slice Tool">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M5 19L19 5"/><path d="M8 5h11v11"/></svg>
                </button>
                <button type="button" id="eraseToolBtn" class="ps-tool" data-ps-tool="erase" title="Erase — paint white; slice boxes fully inside the erase area are removed" aria-label="Erase">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="6" y="8" width="12" height="8" rx="1" fill="#f3c2ce" stroke="#333" stroke-width="1.2"/><rect x="8" y="10" width="8" height="4" fill="#fff" opacity="0.7"/></svg>
                </button>
                <button type="button" id="textToolBtn" class="ps-tool" data-ps-tool="text" title="Add text — options in Edit" aria-label="Add text">
                    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5h8v2h-3v12H11V7H8V5z"/></svg>
                </button>
            </div>
            <div class="studio-tool-undo" role="group" aria-label="History">
                <button id="undoBtn" class="tiny-btn" type="button" disabled title="Undo last crop or slice output (Ctrl+Z)">Undo</button>
                <button id="undoRegionBtn" class="tiny-btn" type="button">Undo Region</button>
                <button id="clearRegionsBtn" class="tiny-btn" type="button">Clear Regions</button>
            </div>
            <div class="studio-tool-divider" aria-hidden="true"></div>
            <div class="ps-tools-grid" role="toolbar" aria-label="Additional tools (demo)">
                <button type="button" class="ps-tool ps-tool-flyout" data-ps-stub="marquee" title="Rectangular Marquee Tool" aria-label="Marquee Tool">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="5" y="6" width="12" height="10" stroke-dasharray="2.5 2"/></svg>
                </button>
                <button type="button" class="ps-tool" data-ps-stub="move" title="Move Tool" aria-label="Move Tool">
                    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 3v5M12 16v5M3 12h5M16 12h5"/><path d="M12 8l-3 4h6l-3-4z" fill="none" stroke="currentColor" stroke-width="1.5"/></svg>
                </button>
                <button type="button" class="ps-tool ps-tool-flyout" data-ps-stub="lasso" title="Lasso Tool" aria-label="Lasso Tool">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M7 5c-2 2-3 5-2 8 1 4 5 6 9 5 3-1 5-4 4-7"/></svg>
                </button>
                <button type="button" class="ps-tool" data-ps-stub="wand" title="Magic Wand Tool" aria-label="Magic Wand Tool">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M5 19l8-14 2 5 5 2-14 7z"/><path d="M15 4l1 2M17 3l1 2M18 6l2 1" stroke-linecap="round"/></svg>
                </button>
                <button type="button" class="ps-tool" data-ps-stub="healing" title="Healing Brush Tool" aria-label="Healing Brush Tool">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><rect x="7" y="8" width="10" height="8" rx="2"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/></svg>
                </button>
                <button type="button" class="ps-tool ps-tool-flyout" data-ps-stub="brush" title="Brush Tool" aria-label="Brush Tool">
                    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M4 20c2-1 8-8 10-12S17 4 17 4s1 2 1 4-7 10-12 12H4z" stroke="#111" stroke-width="0.5"/></svg>
                </button>
                <button type="button" class="ps-tool" data-ps-stub="clone" title="Clone Stamp Tool" aria-label="Clone Stamp Tool">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><rect x="6" y="7" width="9" height="9" rx="1"/><path d="M10 11h4M10 14h3"/></svg>
                </button>
                <button type="button" class="ps-tool" data-ps-stub="history" title="History Brush Tool" aria-label="History Brush Tool">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M6 18c2-4 6-8 10-10"/><path d="M5 19l3-1"/><path d="M14 6a6 6 0 1 0 5 8" stroke-dasharray="3 2"/></svg>
                </button>
                <button type="button" class="ps-tool ps-tool-flyout" data-ps-stub="gradient" title="Gradient Tool" aria-label="Gradient Tool">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><defs><linearGradient id="psToolbarGrad" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#000"/><stop offset="1" stop-color="#fff"/></linearGradient></defs><rect x="5" y="8" width="14" height="8" fill="url(#psToolbarGrad)" stroke="#333" stroke-width="1"/></svg>
                </button>
                <button type="button" class="ps-tool" data-ps-stub="blur" title="Blur Tool" aria-label="Blur Tool">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><circle cx="12" cy="12" r="5"/><path d="M5 12h2M17 12h2M12 5v2M12 17v2" opacity="0.5"/></svg>
                </button>
                <button type="button" class="ps-tool" data-ps-stub="dodge" title="Dodge Tool" aria-label="Dodge Tool">
                    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="12" cy="8" r="3" stroke="#111" stroke-width="0.8"/><path d="M12 11v9" stroke="#111" stroke-width="1.5" fill="none"/></svg>
                </button>
                <button type="button" class="ps-tool" data-ps-stub="path" title="Path Selection Tool" aria-label="Path Selection Tool">
                    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M6 6l4 4-4 4 3 3 4-4 4 4 3-3-4-4 4-4-3-3-4 4-4-4z"/></svg>
                </button>
                <button type="button" class="ps-tool ps-tool-flyout" data-ps-stub="pen" title="Pen Tool" aria-label="Pen Tool">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M5 19l6-14 2 6 6 2-14 6z"/></svg>
                </button>
                <button type="button" class="ps-tool ps-tool-flyout" data-ps-stub="shape" title="Rectangle Tool" aria-label="Shape Tool">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="6" y="7" width="12" height="10"/></svg>
                </button>
                <button type="button" class="ps-tool" data-ps-stub="notes" title="Notes Tool" aria-label="Notes Tool">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M8 5h10a2 2 0 0 1 2 2v8l-4 4H8a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z"/><path d="M10 10h6M10 14h4"/></svg>
                </button>
                <button type="button" class="ps-tool" data-ps-stub="eyedropper" title="Eyedropper Tool" aria-label="Eyedropper Tool">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M5 19l4-4 2 2-3 3H5v-1z"/><path d="M9 15l7-7a2 2 0 0 1 3 3l-7 7"/></svg>
                </button>
                <button type="button" class="ps-tool" data-ps-stub="hand" title="Hand Tool" aria-label="Hand Tool">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M11 17V9M11 17l-2-6M11 17l2-5M11 9l3-1 2 2v4M8 17h6"/></svg>
                </button>
                <button type="button" class="ps-tool" data-ps-stub="zoom" title="Zoom Tool" aria-label="Zoom Tool">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="10" cy="10" r="5"/><path d="M14 14l6 6"/></svg>
                </button>
            </div>
            <div class="ps-tool-mini-row" role="group" aria-label="Foreground and background">
                <button type="button" class="ps-tool-mini" id="psDefaultColorsBtn" title="Default Foreground and Background Colors" aria-label="Default colors">D</button>
                <button type="button" class="ps-tool-mini" id="psSwapColorsBtn" title="Switch Foreground and Background Colors" aria-label="Swap colors">⇄</button>
            </div>
            <div class="ps-swatch-stack" id="psSwatchStack" aria-hidden="true">
                <span class="ps-swatch ps-swatch-fg" id="psSwatchFg"></span>
                <span class="ps-swatch ps-swatch-bg" id="psSwatchBg"></span>
            </div>
            <div class="ps-bottom-tools" role="group" aria-label="Screen modes (demo)">
                <button type="button" class="ps-tool" data-ps-stub="quickmask" title="Quick Mask Mode" aria-label="Quick Mask Mode">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><rect x="5" y="5" width="14" height="14"/><circle cx="12" cy="12" r="4"/></svg>
                </button>
                <button type="button" class="ps-tool" data-ps-stub="screenmode" title="Screen Mode" aria-label="Screen Mode">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><rect x="4" y="5" width="16" height="11"/><path d="M4 18h16"/></svg>
                </button>
            </div>
        </aside>
        <nav class="ws-nav-rail" aria-label="Design sidebar">
            <button type="button" class="ws-nav-item is-active" data-studio-tab="elements" title="Elements">
                <span class="ws-nav-ico ws-nav-ico--elements" aria-hidden="true">
                    <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true">
                        <text x="5" y="12" font-size="7" font-family="system-ui,Segoe UI,sans-serif" font-weight="700" fill="currentColor">&#9829;</text>
                        <text x="10" y="12" font-size="7" font-family="system-ui,Segoe UI,sans-serif" fill="currentColor">&#9650;</text>
                        <text x="14.5" y="12" font-size="7" font-family="system-ui,Segoe UI,sans-serif" font-weight="700" fill="currentColor">&#9632;</text>
                        <text x="16.5" y="19" font-size="8" font-family="system-ui,Segoe UI,sans-serif" fill="currentColor">&#9834;</text>
                    </svg>
                </span>
                Elements
            </button>
            <button type="button" class="ws-nav-item" data-studio-tab="text" title="Text">
                <span class="ws-nav-ico" aria-hidden="true" style="font-weight:800;font-size:15px;letter-spacing:-0.02em;">T</span>
                Text
            </button>
            <button type="button" class="ws-nav-item" data-studio-tab="brand" title="Brand">
                <span class="ws-nav-brand-ico" aria-hidden="true">
                    <span class="ws-nav-crown-corner" aria-hidden="true">&#9813;</span>
                    <span class="ws-nav-brand-ico-inner">CO</span>
                </span>
                Brand
            </button>
            <button type="button" class="ws-nav-item" data-studio-tab="uploads" title="Uploads">
                <span class="ws-nav-ico" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V7M8 11l4-4 4 4"/><path d="M4 20h16"/></svg>
                </span>
                Uploads
            </button>
            <button type="button" class="ws-nav-item" data-studio-tab="tools" title="Tools">
                <span class="ws-nav-ico" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 3.5l2.2 2.2L8.2 14.2l-2.3 5.6 5.6-2.3L18.3 7.7l2.2 2.2"/><path d="M5 19l2.5-1"/></svg>
                </span>
                Tools
            </button>
            <button type="button" class="ws-nav-item" data-studio-tab="projects" title="Projects">
                <span class="ws-nav-ico" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6h16v12H4z"/><path d="M8 6V4h8v2"/></svg>
                </span>
                Projects
            </button>
            <button type="button" class="ws-nav-item" data-studio-tab="apps" title="Apps">
                <span class="ws-nav-ico" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3z"/><path d="M17.5 17.5H21V21h-3.5z"/><path d="M18.5 18.5h2M19.5 17.5v2"/></svg>
                </span>
                Apps
            </button>
            <hr class="ws-nav-divider" aria-hidden="true">
            <button type="button" class="ws-nav-item" data-studio-tab="magic" title="Magic Media">
                <span class="ws-nav-ico" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M11 10l-1 5 4-3-3-1 3-1-3-1z"/><path d="M15 7l.5 1M17 9.5l1 .5"/></svg>
                </span>
                Magic Media
            </button>
            <div class="ws-nav-spacer" aria-hidden="true"></div>
            <div class="ws-nav-footer">
                <button type="button" class="ws-nav-foot-item" id="wsNavNotesBtn" title="Notes (demo)">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M16 13H8M16 17H8M10 9H8"/></svg>
                    Notes
                </button>
                <button type="button" class="ws-nav-foot-item" id="wsNavTimerBtn" title="Timer (demo)">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l3 2M9 3h6M12 3v2"/></svg>
                    Timer
                </button>
            </div>
        </nav>
        <div class="workspace-layout">
        <div class="image-area">
            <div class="panel">
                <h3>Uploaded Image (Default 70%)</h3>
                <div class="tool-row">
                    <button id="zoomOutBtn" class="tiny-btn" type="button">-</button>
                    <button id="zoomInBtn" class="tiny-btn" type="button">+</button>
                    <button id="zoomResetBtn" class="tiny-btn" type="button">Reset Zoom</button>
                    <input id="zoomSlider" type="range" min="25" max="300" value="100" style="width:120px;">
                    <span class="muted">Zoom: <span id="zoomVal">100</span>%</span>
                    <span id="toolHint" class="muted">Drag on image to add custom slice regions.</span>
                </div>
                <div class="tool-row layout-element-row">
                    <label for="layoutElementSelect" class="muted">Select element to move</label>
                    <select id="layoutElementSelect" aria-label="Choose slice region or paint layer to reorder">
                        <option value="">— Select element —</option>
                    </select>
                    <button type="button" id="layoutElementMoveUpBtn" class="tiny-btn" disabled title="Move earlier in stack (drawn before / underneath when overlapping)">↑</button>
                    <button type="button" id="layoutElementMoveDownBtn" class="tiny-btn" disabled title="Move later in stack (drawn after / on top when overlapping)">↓</button>
                    <span class="muted" style="font-size:12px;">Reorder stack, or choose a <strong>text</strong> layer here to edit it in Edit — or use <strong>Add text</strong> and click the text on canvas to drag.</span>
                </div>
                <div class="preview-with-text-panel">
                    <div class="preview-wrap">
                        <canvas id="previewCanvas"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="settings-area">
            <div id="settingsPanel" class="panel section-panel is-closed">
                <div class="section-head">
                    <h3>Settings (Default 30%)</h3>
                    <label class="section-switch-label" for="toggleSettings">
                        <span class="section-switch">
                            <input id="toggleSettings" class="section-switch-input" type="checkbox" role="switch" aria-checked="false">
                            <span class="section-switch-track" aria-hidden="true"></span>
                        </span>
                        <span class="toggle-state">Closed</span>
                    </label>
                </div>
                <div id="settingsBody" class="section-body is-closed">
                    <div class="field">
                        <label>Image Area Width: <span id="layoutSplitVal">70</span>%</label>
                        <input id="layoutSplit" type="range" min="50" max="85" value="70">
                        <span class="muted">Customize how much space image vs settings use.</span>
                    </div>
                </div>
            </div>

            <div id="cropPanel" class="panel section-panel is-closed">
                <div class="section-head">
                    <h3>Crop</h3>
                    <label class="section-switch-label" for="toggleCrop">
                        <span class="section-switch">
                            <input id="toggleCrop" class="section-switch-input" type="checkbox" role="switch" aria-checked="false">
                            <span class="section-switch-track" aria-hidden="true"></span>
                        </span>
                        <span class="toggle-state">Closed</span>
                    </label>
                </div>
                <div id="cropBody" class="section-body is-closed">
                    <div class="row">
                        <div class="field"><label>X</label><input id="cropX" type="number" min="0" value="0"></div>
                        <div class="field"><label>Y</label><input id="cropY" type="number" min="0" value="0"></div>
                        <div class="field"><label>Width</label><input id="cropW" type="number" min="1" value="1"></div>
                        <div class="field"><label>Height</label><input id="cropH" type="number" min="1" value="1"></div>
                        <button id="cropMinBtn" type="button">Minimize Crop</button>
                        <button id="cropMaxBtn" type="button">Maximize Crop</button>
                        <div class="field">
                            <label>Crop Scale</label>
                            <input id="cropScaleSlider" type="range" min="50" max="200" value="100">
                        </div>
                        <button id="applyCropBtn" type="button">Apply Crop</button>
                        <button id="saveCropBtn" type="button">Save Crop</button>
                        <button id="undoCropPanelBtn" type="button" disabled title="Undo last crop or slice output">Undo</button>
                        <button id="resetCropBtn" type="button">Reset Crop</button>
                    </div>
                </div>
            </div>

            <div id="editPanel" class="panel section-panel is-closed">
                <div class="section-head">
                    <h3>Edit</h3>
                    <label class="section-switch-label" for="toggleEdit">
                        <span class="section-switch">
                            <input id="toggleEdit" class="section-switch-input" type="checkbox" role="switch" aria-checked="false">
                            <span class="section-switch-track" aria-hidden="true"></span>
                        </span>
                        <span class="toggle-state">Closed</span>
                    </label>
                </div>
                <div id="editBody" class="section-body is-closed">
                    <div class="row">
                        <div class="field">
                            <label>Brightness: <span id="brightnessVal">100</span>%</label>
                            <input id="brightness" type="range" min="20" max="200" value="100">
                        </div>
                        <div class="field">
                            <label>Contrast: <span id="contrastVal">100</span>%</label>
                            <input id="contrast" type="range" min="20" max="200" value="100">
                        </div>
                        <div class="field">
                            <label>Grayscale: <span id="grayscaleVal">0</span>%</label>
                            <input id="grayscale" type="range" min="0" max="100" value="0">
                        </div>
                        <button id="resetEditBtn" type="button">Reset Edit</button>
                    </div>
                    <div class="row" style="margin-top:10px; align-items:flex-start;">
                        <div class="field" style="min-width:200px; flex:1;">
                            <label for="overlayText">Text on image</label>
                            <input id="overlayText" type="text" maxlength="500" placeholder="Type here, then choose Add text and click the image" style="width:100%; max-width:100%; box-sizing:border-box;">
                        </div>
                        <div class="field">
                            <label>Size <span id="textSizeVal">24</span>px</label>
                            <input id="textSize" type="range" min="10" max="120" value="24">
                        </div>
                        <div class="field">
                            <label for="textColor">Color</label>
                            <input id="textColor" type="color" value="#1a1a1a">
                        </div>
                    </div>
                    <p class="muted"><strong>Layers</strong> (below) list the photo base, each erase/text edit, and slice layout regions. Hide a layer to preview without it; hidden slice regions are skipped in export. <strong>Merge paint into base</strong> bakes erase/text into the image. <strong>Add text</strong> / <strong>Erase</strong> work as before (Undo supported).</p>
                    <div style="margin-top:14px;">
                        <h4 style="margin:0 0 6px 0; font-size:14px;">Layers</h4>
                        <p class="muted" style="margin:0 0 8px 0;">Photo base plus paint layers (erase / text). Slice regions are layout guides. Toggle visibility or merge paint into the base image.</p>
                        <ul id="layerList" class="layer-list" aria-label="Layer stack"></ul>
                        <button type="button" id="flattenPaintLayersBtn" class="tiny-btn" style="margin-top:8px;">Merge visible paint layers into base image</button>
                    </div>
                </div>
            </div>

            <div id="slicingPanel" class="panel section-panel">
                <div class="section-head">
                    <h3>Custom Slicing</h3>
                    <label class="section-switch-label" for="toggleSlicing">
                        <span class="section-switch">
                            <input id="toggleSlicing" class="section-switch-input" type="checkbox" role="switch" aria-checked="true" checked>
                            <span class="section-switch-track" aria-hidden="true"></span>
                        </span>
                        <span class="toggle-state">Open</span>
                    </label>
                </div>
                <div id="slicingBody" class="section-body">
                    <div class="row">
                        <div class="field">
                            <label>Total slices</label>
                            <input id="sliceCount" type="number" min="1" value="4">
                            <input id="sliceSlider" type="range" min="1" max="400" value="4">
                            <div id="presetWrap" class="preset-wrap">
                                <button class="preset-btn" data-value="1" type="button">1</button>
                                <button class="preset-btn active" data-value="4" type="button">4</button>
                                <button class="preset-btn" data-value="9" type="button">9</button>
                                <button class="preset-btn" data-value="16" type="button">16</button>
                                <button class="preset-btn" data-value="25" type="button">25</button>
                                <button class="preset-btn" data-value="100" type="button">100</button>
                            </div>
                        </div>
                        <div class="field">
                            <label>
                                <input id="useCustomGrid" type="checkbox"> Use custom rows/columns
                            </label>
                        </div>
                        <div class="field">
                            <label>Rows</label>
                            <input id="rows" type="number" min="1" value="2" disabled>
                        </div>
                        <div class="field">
                            <label>Columns</label>
                            <input id="cols" type="number" min="1" value="2" disabled>
                        </div>
                        <div class="field">
                            <label>
                                <input id="autoSliceByTile" type="checkbox"> Auto-slice full image
                            </label>
                            <span class="muted">Pick row height or column width below, then set the matching pixel value (clear drawn regions first).</span>
                        </div>
                        <div class="field">
                            <span class="muted">Auto-slice direction</span>
                            <div style="display: flex; flex-direction: column; gap: 6px; margin-top: 4px;">
                                <label style="font-weight: normal;">
                                    <input type="radio" name="autoSliceAxis" value="height" checked> By <strong>row height</strong> (uses Slice Height — each strip is full image width)
                                </label>
                                <label style="font-weight: normal;">
                                    <input type="radio" name="autoSliceAxis" value="width"> By <strong>column width</strong> (uses Slice Width — each strip is full image height)
                                </label>
                            </div>
                        </div>
                        <div class="field">
                            <label>
                                <input id="useFixedSliceSize" type="checkbox"> Fixed size in Slice Tool
                            </label>
                        </div>
                        <div class="field">
                            <label>Slice Width (px)</label>
                            <input id="sliceBoxW" type="number" min="1" value="120">
                        </div>
                        <div class="field">
                            <label>Slice Height (px)</label>
                            <input id="sliceBoxH" type="number" min="1" value="120">
                        </div>
                        <button id="sliceBtn" type="button">Slice Image</button>
                        <button id="undoSlicePanelBtn" type="button" disabled title="Undo last crop or slice output">Undo</button>
                        <button id="downloadAllBtn" type="button">Download All Slices</button>
                    </div>
                    <p class="muted">Free-form selector: switch to Slice Tool and draw custom regions on image.</p>
                    <p id="sliceMeta" class="muted"></p>
                    <div class="slice-preview-block">
                        <div class="row" style="align-items: center;">
                            <button id="previewSliceBtn" type="button">Preview slices</button>
                            <button id="clearSlicePreviewBtn" type="button" class="tiny-btn">Clear preview</button>
                        </div>
                        <div class="row slice-preview-toolbar" style="align-items: center;">
                            <label class="muted" style="display: inline-flex; align-items: center; gap: 8px;">
                                Selection
                                <select id="previewBulkSelect" aria-label="Bulk selection for preview slices">
                                    <option value="">Bulk…</option>
                                    <option value="all">Select all</option>
                                    <option value="none">Select none</option>
                                    <option value="invert">Invert</option>
                                </select>
                            </label>
                            <button id="downloadPreviewSelectedBtn" type="button" disabled>Download selected</button>
                        </div>
                        <p id="slicePreviewMeta" class="muted"></p>
                        <div id="slicePreviewContainer" class="slice-preview-grid" aria-label="Slice preview thumbnails"></div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>

    <div class="panel">
        <h3>Sliced Images</h3>
        <div id="sliceContainer"></div>
    </div>
</div>
</div>
</div>
</div>

<section class="dash-elements-intro" aria-labelledby="dashElementsHeading">
    <div id="wsPanelElements" class="dash-elements-panel" role="region" aria-labelledby="dashElementsHeading">
        <div class="dash-elements-row">
            <div class="dash-elements-col-main">
                <h2 class="dash-elements-h" id="dashElementsHeading">Elements</h2>
                <div class="el-desc-wrap">
                    <label for="elementDescribeInput" class="hidden">Describe element</label>
                    <textarea id="elementDescribeInput" placeholder="Describe your ideal element" maxlength="500" rows="4"></textarea>
                    <div class="el-desc-toolbar">
                        <input type="file" id="elementReferenceInput" class="hidden" accept="image/jpeg,image/png,image/gif,image/webp" aria-hidden="true" tabindex="-1">
                        <button type="button" id="elementAttachBtn" title="Add reference image" aria-label="Add reference">+</button>
                        <button type="button" id="elementMicBtn" title="Voice input (demo)" aria-label="Microphone">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M12 14a3 3 0 0 0 3-3V5a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3z"/><path d="M19 10v1a7 7 0 0 1-14 0v-1M12 18v3"/></svg>
                        </button>
                    </div>
                </div>
                <div class="el-actions">
                    <button type="button" id="elementGenerateBtn" class="el-btn-generate">
                        <span aria-hidden="true">&#10024;</span> Generate <span class="el-chev" aria-hidden="true">&#9662;</span>
                    </button>
                    <button type="button" id="elementSearchBtn" class="el-btn-search">Search</button>
                </div>
            </div>
            <div class="dash-elements-col-tiles">
                <h3 class="el-browse-heading">Browse categories</h3>
                <p id="elementBrowseStatus" class="element-browse-status" role="status" aria-live="polite">Pick a category or describe what you need on the left.</p>
                <div id="elementCatGrid" class="el-cat-grid">
                    <button type="button" class="elem-cat-tile elem-cat--headers" data-elem-cat="Headers" aria-pressed="false">
                        <span class="elem-cat-ico" aria-hidden="true"><svg viewBox="0 0 32 32" fill="none"><rect x="6" y="7" width="10" height="8" rx="1.5" fill="#fff" opacity="0.95"/><path fill="#6b21b8" d="M8 10h2v3H8zm3.5 0h2v3h-2z"/><rect x="18" y="8" width="10" height="2" rx="0.5" fill="#fff" opacity="0.85"/><rect x="18" y="12" width="8" height="1.5" rx="0.5" fill="#fff" opacity="0.7"/><rect x="6" y="18" width="22" height="1.5" rx="0.5" fill="#fff" opacity="0.75"/><rect x="6" y="21" width="18" height="1.5" rx="0.5" fill="#fff" opacity="0.55"/></svg></span>
                        <span class="elem-cat-label">Headers</span>
                    </button>
                    <button type="button" class="elem-cat-tile elem-cat--footers" data-elem-cat="Footers" aria-pressed="false">
                        <span class="elem-cat-ico" aria-hidden="true"><svg viewBox="0 0 32 32" fill="none"><rect x="5" y="9" width="22" height="2.5" rx="1" fill="#fff" opacity="0.9"/><rect x="5" y="14" width="18" height="2" rx="1" fill="#fff" opacity="0.75"/><rect x="5" y="18" width="20" height="2" rx="1" fill="#fff" opacity="0.6"/><rect x="5" y="22" width="14" height="2" rx="1" fill="#fff" opacity="0.45"/></svg></span>
                        <span class="elem-cat-label">Footers</span>
                    </button>
                    <button type="button" class="elem-cat-tile elem-cat--ui-buttons" data-elem-cat="Buttons" aria-pressed="false">
                        <span class="elem-cat-ico" aria-hidden="true"><svg viewBox="0 0 32 32" fill="none"><rect x="6" y="11" width="16" height="9" rx="4.5" fill="#fff" opacity="0.9"/><path d="M20 15.5h5l-2.2 2.5L20 15.5z" fill="#0f766e"/></svg></span>
                        <span class="elem-cat-label">Buttons</span>
                    </button>
                    <button type="button" class="elem-cat-tile elem-cat--icon-blocks" data-elem-cat="Icon blocks" aria-pressed="false">
                        <span class="elem-cat-ico" aria-hidden="true"><svg viewBox="0 0 32 32" fill="none"><rect x="6" y="7" width="6" height="6" rx="1" fill="#fff" opacity="0.95"/><rect x="14" y="7" width="6" height="6" rx="1" fill="#fff" opacity="0.75"/><rect x="6" y="15" width="6" height="6" rx="1" fill="#fff" opacity="0.85"/><rect x="14" y="15" width="6" height="6" rx="1" fill="#fff" opacity="0.6"/></svg></span>
                        <span class="elem-cat-label">Icon blocks</span>
                    </button>
                    <button type="button" class="elem-cat-tile elem-cat--columns" data-elem-cat="Columns" aria-pressed="false">
                        <span class="elem-cat-ico" aria-hidden="true"><svg viewBox="0 0 32 32" fill="none"><rect x="8" y="6" width="6" height="20" rx="1" fill="#fff" opacity="0.9"/><rect x="18" y="6" width="6" height="20" rx="1" fill="#fff" opacity="0.75"/></svg></span>
                        <span class="elem-cat-label">Columns</span>
                    </button>
                    <button type="button" class="elem-cat-tile elem-cat--highlight" data-elem-cat="Highlight blocks" aria-pressed="false">
                        <span class="elem-cat-ico" aria-hidden="true"><svg viewBox="0 0 32 32" fill="none"><circle cx="11" cy="12" r="4" fill="#fff" opacity="0.95"/><path d="M11 9.5v1M11 12.5h.01" stroke="#1e40af" stroke-width="1.5" stroke-linecap="round"/><rect x="17" y="8" width="10" height="2" rx="0.5" fill="#fff" opacity="0.85"/><rect x="17" y="12" width="8" height="1.5" rx="0.5" fill="#fff" opacity="0.65"/><rect x="6" y="19" width="21" height="1.5" rx="0.5" fill="#fff" opacity="0.55"/></svg></span>
                        <span class="elem-cat-label">Highlight blocks</span>
                    </button>
                    <button type="button" class="elem-cat-tile elem-cat--graphics" data-elem-cat="Graphics" aria-pressed="false">
                        <span class="elem-cat-ico" aria-hidden="true"><svg viewBox="0 0 32 32" fill="none"><circle cx="16" cy="14" r="5" fill="#fbbf24"/><ellipse cx="16" cy="22" rx="10" ry="4" fill="#166534" opacity="0.85"/><path d="M10 12c2-3 5-4 6-6 1 2 3 3 4 5-2 1-4 1-6 1-1-2-3-3-4-4z" fill="#f59e0b"/></svg></span>
                        <span class="elem-cat-label">Graphics</span>
                    </button>
                    <button type="button" class="elem-cat-tile elem-cat--photos" data-elem-cat="Photos" aria-pressed="false">
                        <span class="elem-cat-ico" aria-hidden="true"><svg viewBox="0 0 32 32" fill="none"><rect x="5" y="8" width="22" height="16" rx="2" fill="#1e3a8a" opacity="0.35"/><circle cx="13" cy="14" r="3" fill="#fff" opacity="0.9"/><path d="M8 22l5-5 4 4 7-8v9H8v0z" fill="#fff" opacity="0.85"/></svg></span>
                        <span class="elem-cat-label">Photos</span>
                    </button>
                    <button type="button" class="elem-cat-tile elem-cat--videos" data-elem-cat="Videos" aria-pressed="false">
                        <span class="elem-cat-ico" aria-hidden="true"><svg viewBox="0 0 32 32" fill="none"><rect x="5" y="7" width="22" height="18" rx="3" fill="#fff" opacity="0.2"/><path d="M13 12l8 4-8 4v-8z" fill="#fff"/></svg></span>
                        <span class="elem-cat-label">Videos</span>
                    </button>
                </div>
                <div id="elementResultsPanel" class="element-results-panel" hidden>
                    <h4 id="elementResultsHeading" class="element-results-heading">Category ideas</h4>
                    <div id="elementResultsGrid" class="element-results-grid"></div>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="dash-home-lower">
    <section class="dash-section dash-features" aria-labelledby="dashNewHeading">
        <h2 class="dash-section-h" id="dashNewHeading">See what&rsquo;s new</h2>
        <div class="dash-cards">
            <article class="dash-card">
                <div class="dash-card-visual" aria-hidden="true"></div>
                <div class="dash-card-body">
                    <h3>Custom slice regions</h3>
                    <p>Draw free-form boxes on the preview, reorder them from the toolbar, and export only what you need.</p>
                </div>
            </article>
            <article class="dash-card">
                <div class="dash-card-visual dash-card-visual--2" aria-hidden="true"></div>
                <div class="dash-card-body">
                    <h3>Layers &amp; merge paint</h3>
                    <p>Toggle erase and text layers, then merge paint into the base image before slicing.</p>
                </div>
            </article>
            <article class="dash-card">
                <div class="dash-card-visual dash-card-visual--3" aria-hidden="true"></div>
                <div class="dash-card-body">
                    <h3>ZIP download</h3>
                    <p>Slice once and download every tile as a single ZIP — or pick tiles from preview.</p>
                </div>
            </article>
        </div>
    </section>
</div>
</div>

<script>
const imageInput = document.getElementById('imageInput');
const workspace = document.getElementById('workspace');
const previewCanvas = document.getElementById('previewCanvas');
const previewCtx = previewCanvas.getContext('2d');
const sliceContainer = document.getElementById('sliceContainer');
const downloadAllBtn = document.getElementById('downloadAllBtn');
const sliceMeta = document.getElementById('sliceMeta');
const previewSliceBtn = document.getElementById('previewSliceBtn');
const clearSlicePreviewBtn = document.getElementById('clearSlicePreviewBtn');
const slicePreviewContainer = document.getElementById('slicePreviewContainer');
const slicePreviewMeta = document.getElementById('slicePreviewMeta');
const previewBulkSelect = document.getElementById('previewBulkSelect');
const downloadPreviewSelectedBtn = document.getElementById('downloadPreviewSelectedBtn');
const psToolsBar = document.getElementById('psToolsBar');
const psSwatchStack = document.getElementById('psSwatchStack');
const psSwapColorsBtn = document.getElementById('psSwapColorsBtn');
const psDefaultColorsBtn = document.getElementById('psDefaultColorsBtn');
const undoRegionBtn = document.getElementById('undoRegionBtn');
const clearRegionsBtn = document.getElementById('clearRegionsBtn');
const layoutElementSelect = document.getElementById('layoutElementSelect');
const layoutElementMoveUpBtn = document.getElementById('layoutElementMoveUpBtn');
const layoutElementMoveDownBtn = document.getElementById('layoutElementMoveDownBtn');
const toolHint = document.getElementById('toolHint');
const zoomOutBtn = document.getElementById('zoomOutBtn');
const zoomInBtn = document.getElementById('zoomInBtn');
const zoomResetBtn = document.getElementById('zoomResetBtn');
const zoomSlider = document.getElementById('zoomSlider');
const zoomVal = document.getElementById('zoomVal');
const layoutSplit = document.getElementById('layoutSplit');
const layoutSplitVal = document.getElementById('layoutSplitVal');
const settingsPanel = document.getElementById('settingsPanel');
const cropPanel = document.getElementById('cropPanel');
const editPanel = document.getElementById('editPanel');
const slicingPanel = document.getElementById('slicingPanel');
const settingsBody = document.getElementById('settingsBody');
const cropBody = document.getElementById('cropBody');
const editBody = document.getElementById('editBody');
const slicingBody = document.getElementById('slicingBody');
const toggleSettings = document.getElementById('toggleSettings');
const toggleCrop = document.getElementById('toggleCrop');
const toggleEdit = document.getElementById('toggleEdit');
const toggleSlicing = document.getElementById('toggleSlicing');

const cropX = document.getElementById('cropX');
const cropY = document.getElementById('cropY');
const cropW = document.getElementById('cropW');
const cropH = document.getElementById('cropH');
const cropMinBtn = document.getElementById('cropMinBtn');
const cropMaxBtn = document.getElementById('cropMaxBtn');
const cropScaleSlider = document.getElementById('cropScaleSlider');
const applyCropBtn = document.getElementById('applyCropBtn');
const saveCropBtn = document.getElementById('saveCropBtn');
const resetCropBtn = document.getElementById('resetCropBtn');

const brightness = document.getElementById('brightness');
const contrast = document.getElementById('contrast');
const grayscale = document.getElementById('grayscale');
const brightnessVal = document.getElementById('brightnessVal');
const contrastVal = document.getElementById('contrastVal');
const grayscaleVal = document.getElementById('grayscaleVal');
const resetEditBtn = document.getElementById('resetEditBtn');
const overlayText = document.getElementById('overlayText');
const textSize = document.getElementById('textSize');
const textSizeVal = document.getElementById('textSizeVal');
const textColor = document.getElementById('textColor');
const textDesignPanelWrap = document.getElementById('textDesignPanelWrap');
const textFontSearch = document.getElementById('textFontSearch');
const tdpAddTextBoxBtn = document.getElementById('tdpAddTextBoxBtn');
const tdpMagicWriteBtn = document.getElementById('tdpMagicWriteBtn');
const tdpBrandEditLink = document.getElementById('tdpBrandEditLink');
const tdpBrandFontsBtn = document.getElementById('tdpBrandFontsBtn');

const sliceCountInput = document.getElementById('sliceCount');
const sliceSlider = document.getElementById('sliceSlider');
const presetWrap = document.getElementById('presetWrap');
const useCustomGrid = document.getElementById('useCustomGrid');
const rowsInput = document.getElementById('rows');
const colsInput = document.getElementById('cols');
const useFixedSliceSize = document.getElementById('useFixedSliceSize');
const sliceBoxW = document.getElementById('sliceBoxW');
const sliceBoxH = document.getElementById('sliceBoxH');
const autoSliceByTile = document.getElementById('autoSliceByTile');
const sliceBtn = document.getElementById('sliceBtn');
const undoBtn = document.getElementById('undoBtn');
const undoCropPanelBtn = document.getElementById('undoCropPanelBtn');
const undoSlicePanelBtn = document.getElementById('undoSlicePanelBtn');

let originalCanvas = document.createElement('canvas');
let currentCanvas = document.createElement('canvas');
let rasterBaseCanvas = document.createElement('canvas');
let overlayLayers = [];
let layerIdSeq = 0;
let sliceItems = [];
let pendingCreatePreset = null;
let pendingCreateQuick = null;
let toolMode = 'slice';
let studioExplorerTab = 'elements';
let newDocumentAwaitingImage = false;
let customRegions = [];
let isSelecting = false;
let dragStart = null;
let dragCurrent = null;
let previewActivePointerId = null;
let selectedTextLayerId = null;
let textLayerDragState = null;
let isSyncingTextFieldsFromLayer = false;
let layoutElementSelectProgrammatic = false;
let selectedCropRect = null;
let zoomLevel = 100;
const sectionState = {
    settings: false,
    crop: false,
    edit: false,
    slicing: true,
};

const MAX_UNDO_STACK = 15;
let undoStack = [];
let autoSliceTimer = null;
const AUTO_SLICE_DEBOUNCE_MS = 400;

function cloneCanvas(source) {
    const copy = document.createElement('canvas');
    copy.width = source.width;
    copy.height = source.height;
    copy.getContext('2d').drawImage(source, 0, 0);
    return copy;
}

function cloneOverlayLayers(arr) {
    return arr.map((L) => ({ ...L }));
}

function nextLayerId() {
    layerIdSeq += 1;
    return `L${layerIdSeq}`;
}

function rebuildCurrentCanvasFromLayers() {
    if (!rasterBaseCanvas.width || !rasterBaseCanvas.height) {
        currentCanvas.width = 0;
        currentCanvas.height = 0;
        return;
    }
    currentCanvas.width = rasterBaseCanvas.width;
    currentCanvas.height = rasterBaseCanvas.height;
    const ctx = currentCanvas.getContext('2d');
    ctx.drawImage(rasterBaseCanvas, 0, 0);
    overlayLayers.forEach((L) => {
        if (L.visible === false) return;
        if (L.type === 'fill') {
            ctx.fillStyle = L.color || '#ffffff';
            ctx.fillRect(L.x, L.y, L.w, L.h);
        } else if (L.type === 'text') {
            ctx.save();
            ctx.font = `${L.size}px Arial, Helvetica, sans-serif`;
            ctx.fillStyle = L.color || '#1a1a1a';
            ctx.textBaseline = 'top';
            ctx.textAlign = 'left';
            ctx.fillText(L.text, L.x, L.y);
            ctx.restore();
        }
    });
}

function flattenOverlayLayersToBase() {
    if (!rasterBaseCanvas.width || !rasterBaseCanvas.height) return;
    const bctx = rasterBaseCanvas.getContext('2d');
    overlayLayers.forEach((L) => {
        if (L.visible === false) return;
        if (L.type === 'fill') {
            bctx.fillStyle = L.color || '#ffffff';
            bctx.fillRect(L.x, L.y, L.w, L.h);
        } else if (L.type === 'text') {
            bctx.save();
            bctx.font = `${L.size}px Arial, Helvetica, sans-serif`;
            bctx.fillStyle = L.color || '#1a1a1a';
            bctx.textBaseline = 'top';
            bctx.textAlign = 'left';
            bctx.fillText(L.text, L.x, L.y);
            bctx.restore();
        }
    });
    overlayLayers = [];
    clearSelectedTextLayer();
    rebuildCurrentCanvasFromLayers();
}

function hasVisibleSliceRegions() {
    return customRegions.some((r) => r.visible !== false);
}

function renderLayerList() {
    const ul = document.getElementById('layerList');
    if (!ul) return;
    ul.innerHTML = '';
    const baseLi = document.createElement('li');
    baseLi.innerHTML = '<span class="muted">Photo base</span><span class="muted layer-spacer">background</span>';
    ul.appendChild(baseLi);

    for (let i = overlayLayers.length - 1; i >= 0; i--) {
        const L = overlayLayers[i];
        const li = document.createElement('li');
        const eye = document.createElement('input');
        eye.type = 'checkbox';
        eye.checked = L.visible !== false;
        eye.title = 'Show / hide this layer';
        eye.dataset.layerId = L.id;
        eye.dataset.layerAction = 'toggle-paint';
        const label = document.createElement('span');
        label.textContent = L.type === 'fill'
            ? `White paint (${L.w}×${L.h})`
            : `Text: ${L.text.length > 36 ? `${L.text.slice(0, 36)}…` : L.text}`;
        const del = document.createElement('button');
        del.type = 'button';
        del.className = 'tiny-btn';
        del.textContent = 'Remove';
        del.dataset.layerId = L.id;
        del.dataset.layerAction = 'delete-paint';
        li.appendChild(eye);
        li.appendChild(label);
        li.appendChild(del);
        ul.appendChild(li);
    }

    if (customRegions.length) {
        const hdr = document.createElement('li');
        hdr.className = 'layer-list-sub';
        hdr.textContent = 'Slice layout (export uses visible only)';
        ul.appendChild(hdr);
        customRegions.forEach((r, idx) => {
            const li = document.createElement('li');
            const eye = document.createElement('input');
            eye.type = 'checkbox';
            eye.checked = r.visible !== false;
            eye.title = 'Show guide / include in slice export';
            eye.dataset.sliceIndex = String(idx);
            eye.dataset.layerAction = 'toggle-slice';
            const label = document.createElement('span');
            label.textContent = `Region ${idx + 1} (${r.w}×${r.h})`;
            li.appendChild(eye);
            li.appendChild(label);
            ul.appendChild(li);
        });
    }
    refreshLayoutElementSelect();
}

function parseLayoutElementValue(v) {
    if (!v) return null;
    if (v.startsWith('slice:')) {
        const index = parseInt(v.slice(6), 10);
        if (!Number.isFinite(index)) return null;
        return { kind: 'slice', index };
    }
    if (v.startsWith('layer:')) {
        const id = v.slice(6);
        if (!id) return null;
        return { kind: 'layer', id };
    }
    return null;
}

function updateLayoutElementMoveButtons() {
    if (!layoutElementSelect || !layoutElementMoveUpBtn || !layoutElementMoveDownBtn) return;
    const parsed = parseLayoutElementValue(layoutElementSelect.value);
    if (!parsed) {
        layoutElementMoveUpBtn.disabled = true;
        layoutElementMoveDownBtn.disabled = true;
        return;
    }
    if (parsed.kind === 'slice') {
        const i = parsed.index;
        if (i < 0 || i >= customRegions.length) {
            layoutElementMoveUpBtn.disabled = true;
            layoutElementMoveDownBtn.disabled = true;
            return;
        }
        layoutElementMoveUpBtn.disabled = i <= 0;
        layoutElementMoveDownBtn.disabled = i >= customRegions.length - 1;
    } else {
        const i = overlayLayers.findIndex((l) => l.id === parsed.id);
        if (i === -1) {
            layoutElementMoveUpBtn.disabled = true;
            layoutElementMoveDownBtn.disabled = true;
            return;
        }
        layoutElementMoveUpBtn.disabled = i <= 0;
        layoutElementMoveDownBtn.disabled = i >= overlayLayers.length - 1;
    }
}

function refreshLayoutElementSelect() {
    if (!layoutElementSelect) return;
    const prev = layoutElementSelect.value;
    layoutElementSelect.innerHTML = '<option value="">— Select element —</option>';
    customRegions.forEach((r, i) => {
        const opt = document.createElement('option');
        opt.value = `slice:${i}`;
        opt.textContent = `Slice region ${i + 1} (${r.w}×${r.h})`;
        layoutElementSelect.appendChild(opt);
    });
    overlayLayers.forEach((L, i) => {
        const opt = document.createElement('option');
        opt.value = `layer:${L.id}`;
        const lab = L.type === 'fill'
            ? `Erase / paint ${i + 1} (${L.w}×${L.h})`
            : `Text ${i + 1}: ${L.text.length > 28 ? `${L.text.slice(0, 28)}…` : L.text}`;
        opt.textContent = lab;
        layoutElementSelect.appendChild(opt);
    });
    if (prev && [...layoutElementSelect.options].some((o) => o.value === prev)) {
        layoutElementSelect.value = prev;
    }
    updateLayoutElementMoveButtons();
    validateSelectedTextLayer();
}

function measureTextLayerBounds(L) {
    if (!L || L.type !== 'text') return null;
    const measureCtx = document.createElement('canvas').getContext('2d');
    measureCtx.font = `${L.size}px Arial, Helvetica, sans-serif`;
    const metrics = measureCtx.measureText(L.text || '');
    const textW = Math.max(1, metrics.width);
    const textH = Math.max(
        L.size,
        (metrics.actualBoundingBoxAscent || 0) + (metrics.actualBoundingBoxDescent || 0) || L.size * 1.2,
    );
    return { x: L.x, y: L.y, w: textW, h: textH };
}

function findTopTextLayerAtPoint(px, py) {
    for (let i = overlayLayers.length - 1; i >= 0; i -= 1) {
        const L = overlayLayers[i];
        if (L.visible === false || L.type !== 'text') continue;
        const b = measureTextLayerBounds(L);
        if (!b) continue;
        if (px >= b.x && px < b.x + b.w && py >= b.y && py < b.y + b.h) {
            return L;
        }
    }
    return null;
}

function validateSelectedTextLayer() {
    if (!selectedTextLayerId) return;
    const L = overlayLayers.find((l) => l.id === selectedTextLayerId && l.type === 'text');
    if (!L) {
        selectedTextLayerId = null;
    }
}

function clearSelectedTextLayer() {
    selectedTextLayerId = null;
    if (layoutElementSelect) {
        const parsed = parseLayoutElementValue(layoutElementSelect.value);
        if (parsed && parsed.kind === 'layer') {
            const L = overlayLayers.find((l) => l.id === parsed.id);
            if (!L || L.type === 'text') {
                layoutElementSelectProgrammatic = true;
                layoutElementSelect.value = '';
                layoutElementSelectProgrammatic = false;
            }
        }
    }
    updateLayoutElementMoveButtons();
}

function clampTextLayerPosition(L) {
    if (!L || L.type !== 'text' || !rasterBaseCanvas.width || !rasterBaseCanvas.height) return;
    const b = measureTextLayerBounds(L);
    if (!b) return;
    const cw = rasterBaseCanvas.width;
    const ch = rasterBaseCanvas.height;
    L.x = Math.max(0, Math.min(L.x, Math.max(0, cw - Math.min(b.w, cw))));
    L.y = Math.max(0, Math.min(L.y, Math.max(0, ch - Math.min(Math.ceil(b.h), ch))));
}

function selectTextLayerById(id) {
    const L = overlayLayers.find((l) => l.id === id && l.type === 'text');
    if (!L) {
        clearSelectedTextLayer();
        return;
    }
    selectedTextLayerId = id;
    isSyncingTextFieldsFromLayer = true;
    if (overlayText) overlayText.value = L.text;
    if (textSize) textSize.value = String(L.size);
    if (textSizeVal) textSizeVal.textContent = String(L.size);
    if (textColor) textColor.value = L.color || '#1a1a1a';
    isSyncingTextFieldsFromLayer = false;
    if (layoutElementSelect) {
        layoutElementSelectProgrammatic = true;
        layoutElementSelect.value = `layer:${id}`;
        layoutElementSelectProgrammatic = false;
    }
    updateLayoutElementMoveButtons();
}

function applyEditFieldsToSelectedTextLayer() {
    if (!selectedTextLayerId || isSyncingTextFieldsFromLayer) return;
    const L = overlayLayers.find((l) => l.id === selectedTextLayerId && l.type === 'text');
    if (!L) {
        clearSelectedTextLayer();
        return;
    }
    const raw = overlayText ? overlayText.value : '';
    L.text = raw;
    let size = parseInt(textSize && textSize.value, 10);
    if (!Number.isFinite(size)) size = L.size;
    L.size = Math.max(10, Math.min(120, size));
    if (textSize) textSize.value = String(L.size);
    if (textSizeVal) textSizeVal.textContent = String(L.size);
    L.color = (textColor && textColor.value) ? textColor.value : '#1a1a1a';
    clampTextLayerPosition(L);
    rebuildCurrentCanvasFromLayers();
    renderPreview();
    refreshLayoutMeta();
    renderLayerList();
}

function moveLayoutElement(delta) {
    if (!layoutElementSelect) return;
    const parsed = parseLayoutElementValue(layoutElementSelect.value);
    if (!parsed) return;
    if (parsed.kind === 'slice') {
        const i = parsed.index;
        const j = i + delta;
        if (j < 0 || j >= customRegions.length) return;
        pushCropUndoSnapshot();
        const tmp = customRegions[i];
        customRegions[i] = customRegions[j];
        customRegions[j] = tmp;
        layoutElementSelect.value = `slice:${j}`;
    } else {
        const i = overlayLayers.findIndex((l) => l.id === parsed.id);
        if (i === -1) return;
        const j = i + delta;
        if (j < 0 || j >= overlayLayers.length) return;
        pushCropUndoSnapshot();
        const tmp = overlayLayers[i];
        overlayLayers[i] = overlayLayers[j];
        overlayLayers[j] = tmp;
        layoutElementSelect.value = `layer:${parsed.id}`;
    }
    refreshLayoutMeta();
    scheduleAutoSlice();
    renderPreview();
    renderLayerList();
}

function updateUndoUi() {
    const has = undoStack.length > 0;
    undoBtn.disabled = !has;
    undoCropPanelBtn.disabled = !has;
    undoSlicePanelBtn.disabled = !has;
}

function pushCropUndoSnapshot() {
    undoStack.push({
        type: 'crop',
        rasterBaseCanvas: cloneCanvas(rasterBaseCanvas),
        overlayLayers: cloneOverlayLayers(overlayLayers),
        originalCanvas: cloneCanvas(originalCanvas),
        customRegions: customRegions.map((r) => ({ ...r })),
        selectedCropRect: selectedCropRect ? { ...selectedCropRect } : null,
        crop: {
            x: cropX.value,
            y: cropY.value,
            w: cropW.value,
            h: cropH.value,
        },
    });
    while (undoStack.length > MAX_UNDO_STACK) undoStack.shift();
    updateUndoUi();
}

function pushSliceUndoSnapshot() {
    undoStack.push({
        type: 'slice',
        slices: sliceItems.map((item) => ({ index: item.index, dataUrl: item.dataUrl })),
        sliceMetaText: sliceMeta.textContent,
    });
    while (undoStack.length > MAX_UNDO_STACK) undoStack.shift();
    updateUndoUi();
}

function applyCropUndoEntry(entry) {
    if (entry.rasterBaseCanvas && entry.rasterBaseCanvas.width) {
        rasterBaseCanvas = cloneCanvas(entry.rasterBaseCanvas);
        overlayLayers = cloneOverlayLayers(entry.overlayLayers || []);
        rebuildCurrentCanvasFromLayers();
    } else if (entry.currentCanvas && entry.currentCanvas.width) {
        currentCanvas = cloneCanvas(entry.currentCanvas);
        rasterBaseCanvas.width = currentCanvas.width;
        rasterBaseCanvas.height = currentCanvas.height;
        rasterBaseCanvas.getContext('2d').drawImage(currentCanvas, 0, 0);
        overlayLayers = [];
        rebuildCurrentCanvasFromLayers();
    }
    originalCanvas.width = entry.originalCanvas.width;
    originalCanvas.height = entry.originalCanvas.height;
    originalCanvas.getContext('2d').drawImage(entry.originalCanvas, 0, 0);
    customRegions = entry.customRegions.map((r) => ({ ...r }));
    selectedCropRect = entry.selectedCropRect ? { ...entry.selectedCropRect } : null;
    cropX.value = entry.crop.x;
    cropY.value = entry.crop.y;
    cropW.value = entry.crop.w;
    cropH.value = entry.crop.h;
    refreshLayoutMeta();
    renderLayerList();
}

function undoLast() {
    if (!undoStack.length) return;
    clearSlicePreview();
    const entry = undoStack.pop();
    if (entry.type === 'crop') {
        applyCropUndoEntry(entry);
    } else {
        if (!entry.slices.length) {
            clearSlices();
        } else {
            renderSlices(entry.slices.map((s) => ({ index: s.index, dataUrl: s.dataUrl })));
        }
        sliceMeta.textContent = entry.sliceMetaText;
        renderPreview();
    }
    updateUndoUi();
}

function setCanvasFromImage(img) {
    newDocumentAwaitingImage = false;
    originalCanvas.width = img.naturalWidth;
    originalCanvas.height = img.naturalHeight;
    originalCanvas.getContext('2d').drawImage(img, 0, 0);
    resetCrop();
}

function applyPendingCreateOptions() {
    if (pendingCreatePreset) {
        const v = pendingCreatePreset;
        pendingCreatePreset = null;
        openSectionPanel('slicing');
        const pb = document.querySelector(`#presetWrap .preset-btn[data-value="${v}"]`);
        if (pb) pb.click();
    }
    if (pendingCreateQuick) {
        const q = pendingCreateQuick;
        pendingCreateQuick = null;
        if (q === 'settings') {
            openSectionPanel('settings');
        } else if (q === 'slice') {
            openSectionPanel('slicing');
            setToolMode('slice');
        } else if (q === 'crop') {
            openSectionPanel('crop');
            setToolMode('crop');
        } else if (q === 'edit') {
            openSectionPanel('edit');
        } else if (q === 'slicing-panel') {
            openSectionPanel('slicing');
        } else if (q === 'zoom' && zoomResetBtn) {
            zoomResetBtn.click();
        } else if (window.runQuickAction) {
            window.runQuickAction(q);
        }
    }
}

function openBlankDesign(w, h, contentsMode, bgColorHex) {
    clearTimeout(autoSliceTimer);
    autoSliceTimer = null;
    undoStack = [];
    updateUndoUi();
    clearSlicePreview();
    clearSlices();
    setCanvasFromBlank(w, h, contentsMode, bgColorHex);
    newDocumentAwaitingImage = true;
    workspace.classList.remove('hidden');
    try { workspace.scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (e) {}
    if (toolHint) toolHint.textContent = 'Design opened. Upload an image, draw slice regions, or adjust settings in the panels.';
    if (sliceMeta) sliceMeta.textContent = 'New design — add an image or configure slicing.';
    applyPendingCreateOptions();
}

function setCanvasFromBlank(w, h, contentsMode, bgColorHex) {
    const ww = Math.max(1, Math.min(8192, Math.round(Number(w)) || 1920));
    const hh = Math.max(1, Math.min(8192, Math.round(Number(h)) || 1080));
    originalCanvas.width = ww;
    originalCanvas.height = hh;
    const octx = originalCanvas.getContext('2d');
    if (contentsMode === 'transparent') {
        octx.clearRect(0, 0, ww, hh);
    } else {
        const fill = (contentsMode === 'custom' && bgColorHex) ? bgColorHex : '#ffffff';
        octx.fillStyle = fill;
        octx.fillRect(0, 0, ww, hh);
    }
    resetCrop();
}

function placeImageCenteredOnDocument(img) {
    if (!rasterBaseCanvas.width || !rasterBaseCanvas.height) return;
    pushCropUndoSnapshot();
    const cw = rasterBaseCanvas.width;
    const ch = rasterBaseCanvas.height;
    const iw = img.naturalWidth;
    const ih = img.naturalHeight;
    const scale = Math.min(cw / iw, ch / ih);
    const nw = Math.max(1, Math.round(iw * scale));
    const nh = Math.max(1, Math.round(ih * scale));
    const dx = Math.floor((cw - nw) / 2);
    const dy = Math.floor((ch - nh) / 2);
    const bctx = rasterBaseCanvas.getContext('2d');
    bctx.drawImage(img, 0, 0, iw, ih, dx, dy, nw, nh);
    originalCanvas.width = cw;
    originalCanvas.height = ch;
    originalCanvas.getContext('2d').drawImage(rasterBaseCanvas, 0, 0);
    rebuildCurrentCanvasFromLayers();
    renderPreview();
    clearSlicePreview();
    refreshLayoutMeta();
    scheduleAutoSlice();
    renderLayerList();
    if (sliceMeta) sliceMeta.textContent = 'Image placed on canvas (centered, scaled to fit).';
    if (toolHint) toolHint.textContent = 'Image placed. Use Edit for adjustments, Crop to trim, or upload again to replace the whole document.';
}

function syncNewDocColorRowVisibility() {
    const row = document.getElementById('newDocColorRow');
    const rad = document.querySelector('input[name="newDocContents"]:checked');
    if (!row) return;
    row.classList.toggle('hidden', !rad || rad.value !== 'custom');
}

function closeNewDocumentModal() {
    const m = document.getElementById('newDocumentModal');
    if (!m) return;
    m.classList.add('hidden');
    document.body.style.overflow = '';
}

function openNewDocumentModal() {
    const m = document.getElementById('newDocumentModal');
    if (!m) return;
    if (window.closeCreateDesignModal) {
        const cm = document.getElementById('createDesignModal');
        if (cm && !cm.classList.contains('hidden')) window.closeCreateDesignModal();
    }
    if (window.closeAppMenus) window.closeAppMenus();
    m.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
    syncNewDocColorRowVisibility();
}

function createNewBlankDocumentFromModal() {
    const nameEl = document.getElementById('newDocName');
    const wEl = document.getElementById('newDocWidth');
    const hEl = document.getElementById('newDocHeight');
    const colorEl = document.getElementById('newDocBgColor');
    const contentRadio = document.querySelector('input[name="newDocContents"]:checked');
    const mode = contentRadio ? contentRadio.value : 'white';
    const w = parseInt(wEl && wEl.value, 10);
    const h = parseInt(hEl && hEl.value, 10);
    if (!Number.isFinite(w) || !Number.isFinite(h) || w < 1 || h < 1 || w > 8192 || h > 8192) {
        alert('Enter valid width and height in pixels (1–8192).');
        return;
    }
    pendingCreatePreset = null;
    pendingCreateQuick = null;
    closeNewDocumentModal();
    openBlankDesign(w, h, mode, (mode === 'custom' && colorEl && colorEl.value) ? colorEl.value : '#ffffff');
    if (toolHint) toolHint.textContent = 'Blank document ready. Use Open image to place a photo on the canvas (centered, scaled to fit).';
    if (sliceMeta) {
        const nm = nameEl && nameEl.value.trim();
        sliceMeta.textContent = nm ? `Document: ${nm}` : 'New blank document.';
    }
}

window.openNewDocumentModal = openNewDocumentModal;
window.closeNewDocumentModal = closeNewDocumentModal;

function resetCrop() {
    currentCanvas.width = originalCanvas.width;
    currentCanvas.height = originalCanvas.height;
    currentCanvas.getContext('2d').drawImage(originalCanvas, 0, 0);
    customRegions = [];
    overlayLayers = [];
    rasterBaseCanvas.width = currentCanvas.width;
    rasterBaseCanvas.height = currentCanvas.height;
    rasterBaseCanvas.getContext('2d').drawImage(currentCanvas, 0, 0);
    rebuildCurrentCanvasFromLayers();
    selectedCropRect = null;
    cropX.value = 0;
    cropY.value = 0;
    cropW.value = currentCanvas.width;
    cropH.value = currentCanvas.height;
    clearSlicePreview();
    renderPreview();
    refreshLayoutMeta();
    scheduleAutoSlice();
    renderLayerList();
}

function getFilterString() {
    if (!sectionState.edit) {
        return 'brightness(100%) contrast(100%) grayscale(0%)';
    }
    return `brightness(${brightness.value}%) contrast(${contrast.value}%) grayscale(${grayscale.value}%)`;
}

function applySectionToggle(key, enabled) {
    sectionState[key] = enabled;
    const mapping = {
        settings: { panel: settingsPanel, body: settingsBody },
        crop: { panel: cropPanel, body: cropBody },
        edit: { panel: editPanel, body: editBody },
        slicing: { panel: slicingPanel, body: slicingBody },
    };
    const target = mapping[key];
    if (!target) return;
    target.panel.classList.toggle('is-closed', !enabled);
    target.body.classList.toggle('is-closed', !enabled);
}

function syncToggleLabel(checkboxEl) {
    if (!checkboxEl) return;
    const label = checkboxEl.closest('.section-switch-label');
    const stateEl = label && label.querySelector('.toggle-state');
    if (stateEl) {
        stateEl.textContent = checkboxEl.checked ? 'Open' : 'Closed';
    }
    checkboxEl.setAttribute('aria-checked', checkboxEl.checked ? 'true' : 'false');
}

function isTextEditingTarget(el) {
    if (!el || !(el instanceof Element)) return false;
    if (el.closest('.menu-dropdown:not([hidden])')) return false;
    if (el.isContentEditable) return true;
    const tag = el.tagName;
    if (tag === 'TEXTAREA' || tag === 'SELECT') return true;
    if (tag === 'INPUT') {
        const type = (el.type || '').toLowerCase();
        if (type === 'button' || type === 'submit' || type === 'checkbox' || type === 'radio' || type === 'range' || type === 'file' || type === 'reset' || type === 'image' || type === 'color' || type === 'hidden') return false;
        return true;
    }
    return false;
}

function openSectionPanel(key) {
    const toggles = { settings: toggleSettings, crop: toggleCrop, edit: toggleEdit, slicing: toggleSlicing };
    const panels = { settings: settingsPanel, crop: cropPanel, edit: editPanel, slicing: slicingPanel };
    const cb = toggles[key];
    const panel = panels[key];
    if (!cb || !panel) return;
    if (!cb.checked) {
        cb.checked = true;
        cb.dispatchEvent(new Event('change', { bubbles: true }));
    }
    panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function runMenuAction(action) {
    const hidden = workspace.classList.contains('hidden');
    switch (action) {
        case 'browse-image':
        case 'place-image':
        case 'open-image':
            imageInput.click();
            break;
        case 'close-workspace':
            workspace.classList.add('hidden');
            break;
        case 'file-info': {
            if (!currentCanvas.width || !currentCanvas.height) {
                alert('No document is open. Use New or Open from the File menu first.');
                break;
            }
            const meta = sliceMeta && sliceMeta.textContent ? sliceMeta.textContent.trim() : '';
            const lines = [
                `Canvas: ${currentCanvas.width} × ${currentCanvas.height} px (RGB)`,
                meta ? `Note: ${meta}` : '',
            ].filter(Boolean);
            alert(lines.join('\n'));
            break;
        }
        case 'print-preview':
            if (hidden || !currentCanvas.width) {
                alert('Open a document first, then use Print.');
                break;
            }
            window.print();
            break;
        case 'jump-home':
            if (window.runNavAction) window.runNavAction('home');
            break;
        case 'jump-editor':
            if (window.runNavAction) window.runNavAction('editor');
            break;
        case 'new-document':
            openNewDocumentModal();
            break;
        case 'preview-slices':
            if (!hidden) previewSliceBtn.click();
            break;
        case 'save-crop':
            if (!hidden) saveCropBtn.click();
            break;
        case 'slice':
            if (!hidden) sliceImage();
            break;
        case 'download-all':
            downloadAll();
            break;
        case 'undo':
            if (!hidden && undoStack.length) undoLast();
            break;
        case 'undo-region':
            if (!hidden) undoRegionBtn.click();
            break;
        case 'clear-regions':
            if (!hidden) clearRegionsBtn.click();
            break;
        case 'reset-edit':
            if (!hidden) resetEditBtn.click();
            break;
        case 'merge-paint':
            if (!hidden && flattenPaintLayersBtn) flattenPaintLayersBtn.click();
            break;
        case 'zoom-in':
            if (!hidden) zoomInBtn.click();
            break;
        case 'zoom-out':
            if (!hidden) zoomOutBtn.click();
            break;
        case 'zoom-reset':
            if (!hidden) zoomResetBtn.click();
            break;
        case 'panel-settings':
            openSectionPanel('settings');
            break;
        case 'panel-crop':
            openSectionPanel('crop');
            break;
        case 'panel-edit':
            openSectionPanel('edit');
            break;
        case 'panel-slicing':
            openSectionPanel('slicing');
            break;
        default:
            break;
    }
}

function renderPreview() {
    if (!currentCanvas.width || !currentCanvas.height) return;
    previewCanvas.width = currentCanvas.width;
    previewCanvas.height = currentCanvas.height;
    previewCtx.clearRect(0, 0, previewCanvas.width, previewCanvas.height);
    previewCtx.filter = getFilterString();
    previewCtx.drawImage(currentCanvas, 0, 0);
    previewCtx.filter = 'none';

    if (!hasVisibleSliceRegions()) {
        if (shouldUseAutoSliceOverlay()) {
            if (getAutoSliceAxis() === 'height') {
                const sh = parseInt(sliceBoxH.value, 10);
                if (Number.isFinite(sh) && sh >= 1) drawHorizontalStripLines(sh);
            } else {
                const sw = parseInt(sliceBoxW.value, 10);
                if (Number.isFinite(sw) && sw >= 1) drawVerticalStripLines(sw);
            }
        } else {
            const { rows, cols } = getSliceLayout();
            drawGridOverlay(rows, cols);
        }
    }
    drawCustomRegionOverlay();
    drawSavedCropOverlay();
    drawSelectionRect();
    drawSelectedTextLayerHighlight();
    applyZoom();
}

function drawHorizontalStripLines(stepY) {
    if (stepY < 1) return;
    previewCtx.save();
    previewCtx.strokeStyle = 'rgba(255, 0, 0, 0.8)';
    previewCtx.lineWidth = 1;
    for (let y = stepY; y < previewCanvas.height; y += stepY) {
        const lineY = Math.floor(y) + 0.5;
        previewCtx.beginPath();
        previewCtx.moveTo(0, lineY);
        previewCtx.lineTo(previewCanvas.width, lineY);
        previewCtx.stroke();
    }
    previewCtx.restore();
}

function drawVerticalStripLines(stepX) {
    if (stepX < 1) return;
    previewCtx.save();
    previewCtx.strokeStyle = 'rgba(255, 0, 0, 0.8)';
    previewCtx.lineWidth = 1;
    for (let x = stepX; x < previewCanvas.width; x += stepX) {
        const lineX = Math.floor(x) + 0.5;
        previewCtx.beginPath();
        previewCtx.moveTo(lineX, 0);
        previewCtx.lineTo(lineX, previewCanvas.height);
        previewCtx.stroke();
    }
    previewCtx.restore();
}

function drawGridOverlay(rows, cols) {
    if (rows < 1 || cols < 1) return;
    previewCtx.save();
    previewCtx.strokeStyle = 'rgba(255, 0, 0, 0.8)';
    previewCtx.lineWidth = 1;
    for (let c = 1; c < cols; c++) {
        const x = Math.floor((c * previewCanvas.width) / cols) + 0.5;
        previewCtx.beginPath();
        previewCtx.moveTo(x, 0);
        previewCtx.lineTo(x, previewCanvas.height);
        previewCtx.stroke();
    }
    for (let r = 1; r < rows; r++) {
        const y = Math.floor((r * previewCanvas.height) / rows) + 0.5;
        previewCtx.beginPath();
        previewCtx.moveTo(0, y);
        previewCtx.lineTo(previewCanvas.width, y);
        previewCtx.stroke();
    }
    previewCtx.restore();
}

function drawCustomRegionOverlay() {
    if (!customRegions.length || !hasVisibleSliceRegions()) return;
    previewCtx.save();
    previewCtx.strokeStyle = 'rgba(0, 120, 255, 0.95)';
    previewCtx.fillStyle = 'rgba(0, 120, 255, 0.15)';
    previewCtx.lineWidth = 2;
    let visIndex = 0;
    customRegions.forEach((region, index) => {
        if (region.visible === false) return;
        visIndex += 1;
        previewCtx.fillRect(region.x, region.y, region.w, region.h);
        previewCtx.strokeRect(region.x, region.y, region.w, region.h);
        previewCtx.fillStyle = 'rgba(0, 0, 0, 0.7)';
        previewCtx.fillRect(region.x, region.y, 22, 16);
        previewCtx.fillStyle = '#fff';
        previewCtx.font = '11px Arial';
        previewCtx.fillText(String(visIndex), region.x + 6, region.y + 12);
        previewCtx.fillStyle = 'rgba(0, 120, 255, 0.15)';
    });
    previewCtx.restore();
}

function drawSavedCropOverlay() {
    if (!selectedCropRect || toolMode !== 'crop') return;
    previewCtx.save();
    previewCtx.strokeStyle = 'rgba(255, 160, 0, 1)';
    previewCtx.fillStyle = 'rgba(255, 160, 0, 0.18)';
    previewCtx.lineWidth = 2;
    previewCtx.fillRect(selectedCropRect.x, selectedCropRect.y, selectedCropRect.w, selectedCropRect.h);
    previewCtx.strokeRect(selectedCropRect.x, selectedCropRect.y, selectedCropRect.w, selectedCropRect.h);
    previewCtx.restore();
}

function drawSelectionRect() {
    if (!isSelecting || !dragStart || !dragCurrent) return;
    const rect = normalizeRect(dragStart.x, dragStart.y, dragCurrent.x, dragCurrent.y);
    previewCtx.save();
    const stroke = toolMode === 'slice'
        ? 'rgba(0, 120, 255, 1)'
        : toolMode === 'erase'
            ? 'rgba(180, 40, 180, 1)'
            : 'rgba(255, 160, 0, 1)';
    previewCtx.strokeStyle = stroke;
    previewCtx.setLineDash([6, 4]);
    previewCtx.lineWidth = 2;
    previewCtx.strokeRect(rect.x, rect.y, rect.w, rect.h);
    previewCtx.restore();
}

function drawSelectedTextLayerHighlight() {
    if (!selectedTextLayerId) return;
    const L = overlayLayers.find((l) => l.id === selectedTextLayerId && l.type === 'text' && l.visible !== false);
    if (!L) return;
    const b = measureTextLayerBounds(L);
    if (!b) return;
    previewCtx.save();
    previewCtx.strokeStyle = 'rgba(37, 99, 235, 0.95)';
    previewCtx.lineWidth = 2;
    previewCtx.setLineDash([5, 4]);
    previewCtx.strokeRect(b.x - 2, b.y - 2, b.w + 4, b.h + 4);
    previewCtx.restore();
}

function normalizeRect(x1, y1, x2, y2) {
    const x = Math.max(0, Math.min(x1, x2));
    const y = Math.max(0, Math.min(y1, y2));
    const maxX = Math.min(currentCanvas.width, Math.max(x1, x2));
    const maxY = Math.min(currentCanvas.height, Math.max(y1, y2));
    return {
        x,
        y,
        w: Math.max(1, maxX - x),
        h: Math.max(1, maxY - y),
    };
}

function findTopCustomRegionAtPoint(px, py) {
    let hit = null;
    for (let i = 0; i < customRegions.length; i++) {
        const r = customRegions[i];
        if (r.visible === false) continue;
        if (px >= r.x && px < r.x + r.w && py >= r.y && py < r.y + r.h) {
            hit = r;
        }
    }
    return hit;
}

function removeCustomRegionsFullyContainedIn(fx, fy, fw, fh) {
    const cr = fx + fw;
    const cb = fy + fh;
    for (let i = customRegions.length - 1; i >= 0; i--) {
        const r = customRegions[i];
        const rx2 = r.x + r.w;
        const ry2 = r.y + r.h;
        if (r.x >= fx && r.y >= fy && rx2 <= cr && ry2 <= cb) {
            customRegions.splice(i, 1);
        }
    }
}

function applyWhiteEraseFromRect(rect) {
    const x = Math.floor(rect.x);
    const y = Math.floor(rect.y);
    const w = Math.floor(rect.w);
    const h = Math.floor(rect.h);
    pushCropUndoSnapshot();
    overlayLayers.push({
        id: nextLayerId(),
        type: 'fill',
        visible: true,
        color: '#ffffff',
        x,
        y,
        w,
        h,
    });
    removeCustomRegionsFullyContainedIn(x, y, w, h);
    rebuildCurrentCanvasFromLayers();
    clearSlicePreview();
    refreshLayoutMeta();
    scheduleAutoSlice();
    renderLayerList();
}

function getOverlayTextSettings() {
    const raw = (overlayText && overlayText.value) ? overlayText.value : '';
    const text = raw.trim();
    let size = parseInt(textSize && textSize.value, 10);
    if (!Number.isFinite(size)) size = 24;
    size = Math.max(10, Math.min(120, size));
    const color = (textColor && textColor.value) ? textColor.value : '#1a1a1a';
    return { text, size, color };
}

function textToolDefaultHint() {
    return 'Click existing text to select it (blue outline), drag to move, or edit in Edit. Click empty canvas to place new text. Undo supported for moves.';
}

function setStudioTab(tab) {
    studioExplorerTab = tab;
    document.querySelectorAll('.ws-nav-rail [data-studio-tab]').forEach((btn) => {
        const v = btn.getAttribute('data-studio-tab');
        btn.classList.toggle('is-active', v === tab);
    });
    if (tab === 'elements') {
        const panel = document.getElementById('wsPanelElements');
        if (panel) {
            try { panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (e) {}
        }
    }
    if (tab !== 'text' && textFontSearch) {
        textFontSearch.value = '';
        document.querySelectorAll('.text-design-panel-wrap [data-tdp-preset]').forEach((btn) => {
            btn.style.display = '';
        });
    }
}

let selectedElementCategory = '';

const ELEMENT_CATEGORY_SAMPLES = {
    Headers: ['Hero header', 'Navigation bar', 'Title block', 'Announcement strip'],
    Footers: ['Contact footer', 'Social links footer', 'Minimal footer', 'Legal footer'],
    Buttons: ['Primary CTA', 'Secondary button', 'Icon button', 'Pill button group'],
    'Icon blocks': ['Feature icons row', 'Social icon set', 'Stats icons', 'Service icons grid'],
    Columns: ['Two-column layout', 'Three-column cards', 'Image + text columns', 'Pricing columns'],
    'Highlight blocks': ['Callout box', 'Quote highlight', 'Promo strip', 'Info alert block'],
    Graphics: ['Illustration spot', 'Shape divider', 'Badge cluster', 'Decorative blob'],
    Photos: ['Hero photo frame', 'Gallery grid', 'Portrait card', 'Background photo block'],
    Videos: ['Video thumbnail', 'Embed frame', 'Play button overlay', 'Video carousel tile'],
};

function updateElementBrowseStatus(visibleCount) {
    const status = document.getElementById('elementBrowseStatus');
    if (!status) return;
    if (selectedElementCategory) {
        status.textContent = `${selectedElementCategory} selected — pick an idea below or add details on the left.`;
        return;
    }
    const total = document.querySelectorAll('#elementCatGrid .elem-cat-tile').length;
    if (typeof visibleCount === 'number' && visibleCount === 0) {
        status.textContent = 'No categories match. Clear the description box to show all categories.';
    } else if (typeof visibleCount === 'number' && visibleCount < total) {
        status.textContent = `${visibleCount} of ${total} categories match your description.`;
    } else {
        status.textContent = 'Pick a category or describe what you need on the left.';
    }
}

function renderElementCategoryResults(category) {
    const panel = document.getElementById('elementResultsPanel');
    const grid = document.getElementById('elementResultsGrid');
    const heading = document.getElementById('elementResultsHeading');
    if (!panel || !grid) return;
    if (!category) {
        panel.hidden = true;
        grid.innerHTML = '';
        return;
    }
    const samples = ELEMENT_CATEGORY_SAMPLES[category] || ['Starter layout', 'Simple block', 'Custom element'];
    if (heading) heading.textContent = `${category} ideas`;
    grid.innerHTML = samples.map((label) => (
        `<button type="button" class="element-result-card" data-element-sample="${label.replace(/"/g, '&quot;')}">${label}</button>`
    )).join('');
    panel.hidden = false;
}

function clearElementCategorySelection() {
    selectedElementCategory = '';
    document.querySelectorAll('#elementCatGrid .elem-cat-tile').forEach((btn) => {
        btn.classList.remove('is-selected');
        btn.setAttribute('aria-pressed', 'false');
    });
    renderElementCategoryResults('');
}

function selectElementCategory(name) {
    if (!name) return;
    const prev = selectedElementCategory;
    const next = prev === name ? '' : name;
    selectedElementCategory = next;
    document.querySelectorAll('#elementCatGrid .elem-cat-tile').forEach((btn) => {
        const cat = btn.getAttribute('data-elem-cat') || '';
        const on = cat === selectedElementCategory;
        btn.classList.toggle('is-selected', on);
        btn.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    const ta = document.getElementById('elementDescribeInput');
    if (selectedElementCategory && ta) {
        const cur = ta.value.trim();
        if (!cur || (prev && cur.toLowerCase() === prev.toLowerCase())) {
            ta.value = selectedElementCategory;
        }
    } else if (!selectedElementCategory && ta && prev && ta.value.trim().toLowerCase() === prev.toLowerCase()) {
        ta.value = '';
    }
    const visible = filterElementCategories();
    renderElementCategoryResults(selectedElementCategory);
    updateElementBrowseStatus(visible);
    if (toolHint && workspace && !workspace.classList.contains('hidden') && selectedElementCategory) {
        toolHint.textContent = `${selectedElementCategory}: use crop, slice, and export tools on your image.`;
    }
    const panel = document.getElementById('elementResultsPanel');
    if (panel && selectedElementCategory) {
        try { panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (e) {}
    }
}

function filterElementCategories() {
    const ta = document.getElementById('elementDescribeInput');
    const q = (ta && ta.value) ? ta.value.trim().toLowerCase() : '';
    if (selectedElementCategory && q && !q.includes(selectedElementCategory.toLowerCase())) {
        clearElementCategorySelection();
    }
    let visible = 0;
    document.querySelectorAll('#elementCatGrid .elem-cat-tile').forEach((btn) => {
        const name = (btn.getAttribute('data-elem-cat') || '').toLowerCase();
        const blob = `${name} ${(btn.textContent || '').toLowerCase()}`;
        const isSelected = btn.getAttribute('data-elem-cat') === selectedElementCategory;
        const show = isSelected || !q || blob.includes(q);
        btn.hidden = !show;
        if (show) visible++;
    });
    return visible;
}

function elementTextStyleForCategory(cat) {
    const styles = {
        Headers: { size: 52, color: '#111827' },
        Footers: { size: 22, color: '#374151' },
        Buttons: { size: 30, color: '#1f6feb' },
        'Icon blocks': { size: 26, color: '#0f172a' },
        Columns: { size: 28, color: '#1e293b' },
        'Highlight blocks': { size: 32, color: '#7c3aed' },
        Graphics: { size: 28, color: '#c2410c' },
        Photos: { size: 24, color: '#1e3a8a' },
        Videos: { size: 26, color: '#a21caf' },
    };
    return styles[cat] || { size: 32, color: '#1a1a1a' };
}

function truncateElementLabel(text, maxLen) {
    const limit = maxLen || 80;
    const t = (text || '').trim();
    if (t.length <= limit) return t;
    return `${t.slice(0, limit - 1)}…`;
}

function ensureDesignOpenForElements() {
    if (workspace && workspace.classList.contains('hidden')) {
        openBlankDesign(1920, 1080, 'white', '#ffffff');
    }
}

function applyElementToCanvas(description) {
    const desc = (description || '').trim();
    if (!desc) {
        updateElementBrowseStatus(filterElementCategories());
        const status = document.getElementById('elementBrowseStatus');
        if (status) status.textContent = 'Describe an element first, or pick a category idea.';
        return false;
    }
    ensureDesignOpenForElements();
    if (!rasterBaseCanvas.width || !rasterBaseCanvas.height) return false;
    const style = elementTextStyleForCategory(selectedElementCategory);
    const label = truncateElementLabel(desc);
    clearSelectedTextLayer();
    if (overlayText) overlayText.value = label;
    if (textSize) {
        textSize.value = String(style.size);
        if (textSizeVal) textSizeVal.textContent = String(style.size);
    }
    if (textColor) textColor.value = style.color;
    if (typeof openSectionPanel === 'function') openSectionPanel('edit');
    if (toggleEdit) {
        toggleEdit.checked = true;
        applySectionToggle('edit', true);
        syncToggleLabel(toggleEdit);
    }
    const cx = Math.max(24, Math.floor(rasterBaseCanvas.width * 0.12));
    const cy = Math.max(24, Math.floor(rasterBaseCanvas.height * 0.1));
    applyTextAtCanvasPoint(cx, cy);
    setToolMode('text');
    renderPreview();
    if (workspace) {
        try { workspace.scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (e) {}
    }
    const status = document.getElementById('elementBrowseStatus');
    if (status) status.textContent = `Added “${label}” to the canvas — drag it in the preview or edit in Edit.`;
    if (toolHint) toolHint.textContent = `Element placed: ${label}. Click to select, drag to move, or edit in Edit.`;
    return true;
}

function autoSelectCategoryFromQuery(query) {
    const q = (query || '').trim().toLowerCase();
    if (!q) return;
    let best = '';
    document.querySelectorAll('#elementCatGrid .elem-cat-tile').forEach((btn) => {
        const name = (btn.getAttribute('data-elem-cat') || '').toLowerCase();
        if (name && q.includes(name)) best = btn.getAttribute('data-elem-cat');
    });
    if (!best || selectedElementCategory === best) return;
    selectedElementCategory = best;
    document.querySelectorAll('#elementCatGrid .elem-cat-tile').forEach((btn) => {
        const cat = btn.getAttribute('data-elem-cat') || '';
        const on = cat === best;
        btn.classList.toggle('is-selected', on);
        btn.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    renderElementCategoryResults(best);
}

function runElementGenerate() {
    const ta = document.getElementById('elementDescribeInput');
    const ideas = ['icons & shapes', 'photo frames', 'simple charts', 'dividers', 'badges', 'arrows', 'hero banner', 'call-to-action button', 'feature row'];
    const pick = ideas[Math.floor(Math.random() * ideas.length)];
    const prefix = selectedElementCategory ? `${selectedElementCategory}: ` : '';
    if (ta && !ta.value.trim()) {
        ta.value = `${prefix}${pick} for this layout`;
    } else if (ta && selectedElementCategory && !ta.value.toLowerCase().includes(selectedElementCategory.toLowerCase())) {
        ta.value = `${prefix}${ta.value.trim()}`;
    } else if (ta && !selectedElementCategory) {
        ta.value = `${ta.value.trim()} — ${pick}`;
    }
    autoSelectCategoryFromQuery(ta ? ta.value : '');
    const visible = filterElementCategories();
    updateElementBrowseStatus(visible);
    applyElementToCanvas(ta ? ta.value : '');
}

function runElementSearch() {
    const ta = document.getElementById('elementDescribeInput');
    const q = ta ? ta.value.trim() : '';
    autoSelectCategoryFromQuery(q);
    const visible = filterElementCategories();
    updateElementBrowseStatus(visible);
    const panel = document.getElementById('wsPanelElements');
    if (panel) {
        try { panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (e) {}
    }
    if (q.length >= 2 && visible === 0) {
        const status = document.getElementById('elementBrowseStatus');
        if (status) status.textContent = 'No categories match — try Generate to add your idea to the canvas anyway.';
    }
}

function attachElementReferenceFile(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function (evt) {
        const img = new Image();
        img.onload = function () {
            ensureDesignOpenForElements();
            if (newDocumentAwaitingImage || !originalCanvas.width) {
                placeImageCenteredOnDocument(img);
                newDocumentAwaitingImage = false;
            } else {
                placeImageCenteredOnDocument(img);
            }
            const status = document.getElementById('elementBrowseStatus');
            if (status) status.textContent = 'Reference image placed on the canvas.';
            if (toolHint) toolHint.textContent = 'Reference image added. Crop, slice, or add text elements as needed.';
            if (workspace) {
                try { workspace.scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (e) {}
            }
        };
        img.src = evt.target.result;
    };
    reader.readAsDataURL(file);
}

function initElementBrowse() {
    const catGrid = document.getElementById('elementCatGrid');
    if (catGrid) {
        catGrid.addEventListener('click', (e) => {
            const btn = e.target.closest('.elem-cat-tile');
            if (!btn || btn.hidden) return;
            e.preventDefault();
            selectElementCategory(btn.getAttribute('data-elem-cat') || '');
        });
    }
    const resultsGrid = document.getElementById('elementResultsGrid');
    if (resultsGrid) {
        resultsGrid.addEventListener('click', (e) => {
            const card = e.target.closest('[data-element-sample]');
            if (!card) return;
            const sample = card.getAttribute('data-element-sample') || '';
            const ta = document.getElementById('elementDescribeInput');
            if (ta && sample) {
                ta.value = selectedElementCategory ? `${selectedElementCategory}: ${sample}` : sample;
                ta.focus();
            }
            resultsGrid.querySelectorAll('.element-result-card').forEach((el) => {
                el.classList.toggle('is-picked', el === card);
            });
            updateElementBrowseStatus(filterElementCategories());
            applyElementToCanvas(ta ? ta.value : sample);
        });
    }
    const searchBtn = document.getElementById('elementSearchBtn');
    const generateBtn = document.getElementById('elementGenerateBtn');
    const attachBtn = document.getElementById('elementAttachBtn');
    const micBtn = document.getElementById('elementMicBtn');
    const describeInput = document.getElementById('elementDescribeInput');
    const referenceInput = document.getElementById('elementReferenceInput');
    if (searchBtn) searchBtn.addEventListener('click', runElementSearch);
    if (generateBtn) generateBtn.addEventListener('click', runElementGenerate);
    if (attachBtn && referenceInput) {
        attachBtn.addEventListener('click', () => referenceInput.click());
        referenceInput.addEventListener('change', (e) => {
            const file = e.target.files && e.target.files[0];
            attachElementReferenceFile(file);
            referenceInput.value = '';
        });
    } else if (attachBtn) {
        attachBtn.addEventListener('click', () => {
            if (imageInput) imageInput.click();
        });
    }
    if (micBtn && describeInput) {
        micBtn.addEventListener('click', () => {
            describeInput.focus();
            const status = document.getElementById('elementBrowseStatus');
            if (status) status.textContent = 'Type your element description, or use Generate to add it to the canvas.';
        });
    }
    if (describeInput) {
        describeInput.addEventListener('input', () => {
            const visible = filterElementCategories();
            updateElementBrowseStatus(visible);
        });
        describeInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                e.preventDefault();
                runElementGenerate();
            }
        });
    }
    updateElementBrowseStatus(document.querySelectorAll('#elementCatGrid .elem-cat-tile').length);
}

function filterTextPresetCards() {
    if (!textFontSearch) return;
    const q = textFontSearch.value.trim().toLowerCase();
    document.querySelectorAll('.text-design-panel-wrap [data-tdp-preset]').forEach((btn) => {
        const inner = (btn.textContent || '').toLowerCase();
        btn.style.display = !q || inner.includes(q) ? '' : 'none';
    });
}

function applyTextStylePreset(kind) {
    clearSelectedTextLayer();
    const presets = {
        box: { text: 'Your text', size: 28, color: '#1a1a1a' },
        heading: { text: 'Add a heading', size: 56, color: '#111827' },
        subheading: { text: 'Add a subheading', size: 34, color: '#1f2937' },
        body: { text: 'Add a little bit of body text', size: 18, color: '#374151' },
    };
    const p = presets[kind];
    if (!p || !overlayText || !textSize || !textColor) return;
    overlayText.value = p.text;
    const sz = Math.max(10, Math.min(120, p.size));
    textSize.value = String(sz);
    if (textSizeVal) textSizeVal.textContent = String(sz);
    textColor.value = p.color;
    setToolMode('text');
    toolHint.textContent = 'Click the image to place this text. Adjust wording, size, and color in Edit if needed.';
}

function focusEditTextFieldForEmptyTextClick() {
    if (!toggleEdit.checked) {
        toggleEdit.checked = true;
        applySectionToggle('edit', true);
        syncToggleLabel(toggleEdit);
    }
    if (editPanel && typeof editPanel.scrollIntoView === 'function') {
        try {
            editPanel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        } catch (err) {
            /* ignore */
        }
    }
    toolHint.textContent = 'Type in “Text on image” in the Edit section (opened for you), then click the preview to place it.';
    if (overlayText) {
        overlayText.focus();
    }
    renderPreview();
}

function applyTextAtCanvasPoint(px, py) {
    clearSelectedTextLayer();
    const { text, size, color } = getOverlayTextSettings();
    if (!text) {
        focusEditTextFieldForEmptyTextClick();
        return;
    }
    if (!rasterBaseCanvas.width || !rasterBaseCanvas.height) return;
    const measureCtx = document.createElement('canvas').getContext('2d');
    measureCtx.font = `${size}px Arial, Helvetica, sans-serif`;
    const metrics = measureCtx.measureText(text);
    const textW = Math.max(1, metrics.width);
    const textH = Math.max(size, (metrics.actualBoundingBoxAscent || 0) + (metrics.actualBoundingBoxDescent || 0) || size * 1.2);
    let x = Math.floor(px);
    let y = Math.floor(py);
    const cw = rasterBaseCanvas.width;
    const ch = rasterBaseCanvas.height;
    x = Math.max(0, Math.min(x, Math.max(0, cw - Math.min(textW, cw))));
    y = Math.max(0, Math.min(y, Math.max(0, ch - Math.min(Math.ceil(textH), ch))));
    pushCropUndoSnapshot();
    overlayLayers.push({
        id: nextLayerId(),
        type: 'text',
        visible: true,
        text,
        x,
        y,
        size,
        color,
    });
    rebuildCurrentCanvasFromLayers();
    clearSlicePreview();
    refreshLayoutMeta();
    scheduleAutoSlice();
    renderLayerList();
    if (toolMode === 'text') {
        toolHint.textContent = textToolDefaultHint();
    }
}

function getCanvasPointFromEvent(event) {
    const rect = previewCanvas.getBoundingClientRect();
    const scaleX = previewCanvas.width / rect.width;
    const scaleY = previewCanvas.height / rect.height;
    const x = (event.clientX - rect.left) * scaleX;
    const y = (event.clientY - rect.top) * scaleY;
    return {
        x: Math.max(0, Math.min(previewCanvas.width, x)),
        y: Math.max(0, Math.min(previewCanvas.height, y)),
    };
}

function applyZoom() {
    const scale = zoomLevel / 100;
    previewCanvas.style.width = `${Math.max(1, Math.round(previewCanvas.width * scale))}px`;
    previewCanvas.style.height = `${Math.max(1, Math.round(previewCanvas.height * scale))}px`;
    zoomVal.textContent = String(zoomLevel);
    zoomSlider.value = String(zoomLevel);
}

function setZoom(nextZoom) {
    zoomLevel = Math.max(25, Math.min(300, Math.round(nextZoom)));
    applyZoom();
}

const PS_STUB_HINTS = {
    marquee: 'Marquee and elliptical selections are not available here. Use Slice regions or Crop.',
    move: 'Move tool: pick a text layer under the preview, or use Add text — click text to drag, or use ↑↓ on a selected layer.',
    lasso: 'Lasso / magnetic selection is not available. Draw slice regions with the Slice tool instead.',
    wand: 'Magic Wand color selection is not available in this slicer.',
    healing: 'Healing Brush is not implemented — use Edit adjustments or erase strokes.',
    brush: 'Paint Brush is not implemented — use Erase (white) or text from the Type tool.',
    clone: 'Clone Stamp is not implemented in the browser slicer.',
    history: 'History Brush is not implemented.',
    gradient: 'Gradient fill is not implemented on the canvas.',
    blur: 'Blur / Sharpen / Smudge tools are not implemented.',
    dodge: 'Dodge / Burn / Sponge are not implemented.',
    path: 'Path / Direct Selection is not implemented.',
    pen: 'Pen / Freeform Pen is not implemented.',
    shape: 'Vector shape tools are not implemented. Use slice rectangles for layout.',
    notes: 'Notes tool is not implemented.',
    eyedropper: 'Eyedropper sampling is not wired to this canvas.',
    hand: 'Pan: scroll the preview area or use the zoom controls.',
    zoom: 'Zoom: use the + / − buttons or the zoom slider next to the preview.',
    quickmask: 'Quick Mask mode is not available.',
    screenmode: 'Screen mode toggles are visual only in this web app.',
};

function showPsStubHint(stubId) {
    const msg = PS_STUB_HINTS[stubId] || 'This tool is not implemented in Image Slicer.';
    if (toolHint) toolHint.textContent = msg;
}

function syncPsToolsFromToolMode() {
    if (!psToolsBar) return;
    psToolsBar.querySelectorAll('[data-ps-tool]').forEach((btn) => {
        const m = btn.getAttribute('data-ps-tool');
        btn.classList.toggle('ps-tool-active', m === toolMode);
    });
}

function setToolMode(mode) {
    if (mode === 'crop' && !sectionState.crop) {
        alert('Crop section is OFF. Turn it ON to use Crop Tool.');
        return;
    }
    if (mode === 'slice' && !sectionState.slicing) {
        alert('Custom Slicing section is OFF. Turn it ON to use Slice Tool.');
        return;
    }
    if ((mode === 'erase' || mode === 'text') && !sectionState.edit) {
        toggleEdit.checked = true;
        applySectionToggle('edit', true);
        syncToggleLabel(toggleEdit);
    }
    toolMode = mode;
    previewCanvas.style.cursor = mode === 'text' ? 'crosshair' : '';
    if (mode === 'slice') {
        toolHint.textContent = 'Drag on image to add custom free-form slice regions.';
    } else if (mode === 'erase') {
        toolHint.textContent = 'Drag or click: white fill removes pixels and clears any blue slice box fully inside the erased area (Undo supported).';
    } else if (mode === 'text') {
        toolHint.textContent = textToolDefaultHint();
    } else {
        toolHint.textContent = 'Drag on image to set crop box.';
    }
    renderPreview();
    if (mode === 'text') {
        setStudioTab('text');
    }
    syncPsToolsFromToolMode();
}

function onPreviewPointerDown(event) {
    if (!currentCanvas.width || !currentCanvas.height) return;
    if (toolMode === 'text') {
        if (!sectionState.edit) return;
        if (event.pointerType === 'mouse' && event.button !== 0) return;
        event.preventDefault();
        const pt = getCanvasPointFromEvent(event);
        const hitLayer = findTopTextLayerAtPoint(pt.x, pt.y);
        if (hitLayer) {
            selectTextLayerById(hitLayer.id);
            textLayerDragState = {
                pointerId: event.pointerId,
                layerId: hitLayer.id,
                grabDx: pt.x - hitLayer.x,
                grabDy: pt.y - hitLayer.y,
                startX: hitLayer.x,
                startY: hitLayer.y,
                pushedUndo: false,
            };
            try {
                previewCanvas.setPointerCapture(event.pointerId);
            } catch (err) {
                /* ignore */
            }
            if (toolHint) {
                toolHint.textContent = 'Drag to move this text, or edit wording/size/color in Edit.';
            }
            renderPreview();
            return;
        }
        applyTextAtCanvasPoint(pt.x, pt.y);
        return;
    }
    if ((toolMode === 'crop' && !sectionState.crop)
        || (toolMode === 'slice' && !sectionState.slicing)
        || (toolMode === 'erase' && !sectionState.edit)) return;
    if (event.pointerType === 'mouse' && event.button !== 0) return;
    if (previewActivePointerId !== null) return;

    event.preventDefault();
    previewActivePointerId = event.pointerId;
    try {
        previewCanvas.setPointerCapture(event.pointerId);
    } catch (err) {
        /* ignore */
    }

    isSelecting = true;
    dragStart = getCanvasPointFromEvent(event);
    dragCurrent = dragStart;
    renderPreview();
}

function onPreviewPointerMove(event) {
    if (textLayerDragState) {
        if (event.pointerId !== textLayerDragState.pointerId) return;
        const L = overlayLayers.find((l) => l.id === textLayerDragState.layerId && l.type === 'text');
        if (!L || L.visible === false) {
            textLayerDragState = null;
            return;
        }
        const pt = getCanvasPointFromEvent(event);
        const nx = Math.round(pt.x - textLayerDragState.grabDx);
        const ny = Math.round(pt.y - textLayerDragState.grabDy);
        if (!textLayerDragState.pushedUndo
            && (nx !== textLayerDragState.startX || ny !== textLayerDragState.startY)) {
            pushCropUndoSnapshot();
            textLayerDragState.pushedUndo = true;
        }
        L.x = nx;
        L.y = ny;
        clampTextLayerPosition(L);
        rebuildCurrentCanvasFromLayers();
        renderPreview();
        return;
    }
    if (!isSelecting) return;
    if (previewActivePointerId !== null && event.pointerId !== previewActivePointerId) return;
    dragCurrent = getCanvasPointFromEvent(event);
    renderPreview();
}

function onPreviewPointerUp(event) {
    if (textLayerDragState) {
        if (event.pointerId !== textLayerDragState.pointerId) return;
        try {
            if (typeof previewCanvas.hasPointerCapture === 'function' && previewCanvas.hasPointerCapture(event.pointerId)) {
                previewCanvas.releasePointerCapture(event.pointerId);
            }
        } catch (err) {
            /* ignore */
        }
        textLayerDragState = null;
        refreshLayoutMeta();
        scheduleAutoSlice();
        renderLayerList();
        renderPreview();
        return;
    }
    if (!isSelecting) return;
    if (previewActivePointerId !== null && event.pointerId !== previewActivePointerId) return;

    dragCurrent = getCanvasPointFromEvent(event);
    try {
        if (typeof previewCanvas.hasPointerCapture === 'function' && previewCanvas.hasPointerCapture(event.pointerId)) {
            previewCanvas.releasePointerCapture(event.pointerId);
        }
    } catch (err) {
        /* ignore */
    }
    previewActivePointerId = null;

    const upStartX = dragStart.x;
    const upStartY = dragStart.y;
    const upEndX = dragCurrent.x;
    const upEndY = dragCurrent.y;
    isSelecting = false;
    const rect = normalizeRect(upStartX, upStartY, upEndX, upEndY);
    dragStart = null;
    dragCurrent = null;

    if (rect.w < 3 || rect.h < 3) {
        if (toolMode === 'erase') {
            const regionHit = findTopCustomRegionAtPoint(upStartX, upStartY);
            if (regionHit) {
                applyWhiteEraseFromRect(regionHit);
                return;
            }
        }
        renderPreview();
        return;
    }

    if (toolMode === 'crop') {
        cropX.value = Math.floor(rect.x);
        cropY.value = Math.floor(rect.y);
        cropW.value = Math.floor(rect.w);
        cropH.value = Math.floor(rect.h);
        selectedCropRect = {
            x: Math.floor(rect.x),
            y: Math.floor(rect.y),
            w: Math.floor(rect.w),
            h: Math.floor(rect.h),
        };
    } else if (toolMode === 'erase') {
        applyWhiteEraseFromRect(rect);
        return;
    } else {
        let regionX = Math.floor(rect.x);
        let regionY = Math.floor(rect.y);
        let regionW = Math.floor(rect.w);
        let regionH = Math.floor(rect.h);

        if (useFixedSliceSize.checked) {
            regionW = Math.max(1, parseInt(sliceBoxW.value || 1, 10));
            regionH = Math.max(1, parseInt(sliceBoxH.value || 1, 10));
            regionW = Math.min(regionW, currentCanvas.width);
            regionH = Math.min(regionH, currentCanvas.height);
            regionX = Math.max(0, Math.min(regionX, currentCanvas.width - regionW));
            regionY = Math.max(0, Math.min(regionY, currentCanvas.height - regionH));
        }

        customRegions.push({
            x: regionX,
            y: regionY,
            w: regionW,
            h: regionH,
            visible: true,
        });
    }
    refreshLayoutMeta();
    renderLayerList();
}

function syncCropRectFromInputs() {
    if (!currentCanvas.width || !currentCanvas.height) return;

    const x = Math.max(0, parseInt(cropX.value || 0, 10));
    const y = Math.max(0, parseInt(cropY.value || 0, 10));
    const maxW = Math.max(1, currentCanvas.width - x);
    const maxH = Math.max(1, currentCanvas.height - y);
    const w = Math.max(1, Math.min(parseInt(cropW.value || 1, 10), maxW));
    const h = Math.max(1, Math.min(parseInt(cropH.value || 1, 10), maxH));

    selectedCropRect = { x, y, w, h };
    cropX.value = x;
    cropY.value = y;
    cropW.value = w;
    cropH.value = h;
    renderPreview();
}

function resizeCropSelection(scaleFactor) {
    if (!currentCanvas.width || !currentCanvas.height) return;
    if (!selectedCropRect) {
        syncCropRectFromInputs();
    }
    if (!selectedCropRect) return;

    const centerX = selectedCropRect.x + (selectedCropRect.w / 2);
    const centerY = selectedCropRect.y + (selectedCropRect.h / 2);

    let newW = Math.max(1, Math.round(selectedCropRect.w * scaleFactor));
    let newH = Math.max(1, Math.round(selectedCropRect.h * scaleFactor));
    newW = Math.min(newW, currentCanvas.width);
    newH = Math.min(newH, currentCanvas.height);

    let newX = Math.round(centerX - (newW / 2));
    let newY = Math.round(centerY - (newH / 2));
    newX = Math.max(0, Math.min(newX, currentCanvas.width - newW));
    newY = Math.max(0, Math.min(newY, currentCanvas.height - newH));

    selectedCropRect = { x: newX, y: newY, w: newW, h: newH };
    cropX.value = newX;
    cropY.value = newY;
    cropW.value = newW;
    cropH.value = newH;
    renderPreview();
}

function cropCurrentCanvasFromSelection(persistToOriginal = false) {
    if (!sectionState.crop) {
        alert('Crop section is OFF. Turn it ON first.');
        return false;
    }
    const x = Math.max(0, parseInt(cropX.value || selectedCropRect?.x || 0, 10));
    const y = Math.max(0, parseInt(cropY.value || selectedCropRect?.y || 0, 10));
    const w = Math.max(1, parseInt(cropW.value || selectedCropRect?.w || 1, 10));
    const h = Math.max(1, parseInt(cropH.value || selectedCropRect?.h || 1, 10));

    const maxW = currentCanvas.width - x;
    const maxH = currentCanvas.height - y;
    if (maxW <= 0 || maxH <= 0) {
        alert('Crop area starts outside image bounds.');
        return false;
    }

    const cropWidth = Math.min(w, maxW);
    const cropHeight = Math.min(h, maxH);
    flattenOverlayLayersToBase();
    pushCropUndoSnapshot();
    const nextCanvas = document.createElement('canvas');
    nextCanvas.width = cropWidth;
    nextCanvas.height = cropHeight;
    nextCanvas.getContext('2d').drawImage(currentCanvas, x, y, cropWidth, cropHeight, 0, 0, cropWidth, cropHeight);
    currentCanvas = nextCanvas;

    if (persistToOriginal) {
        originalCanvas.width = currentCanvas.width;
        originalCanvas.height = currentCanvas.height;
        originalCanvas.getContext('2d').drawImage(currentCanvas, 0, 0);
    }

    rasterBaseCanvas.width = currentCanvas.width;
    rasterBaseCanvas.height = currentCanvas.height;
    rasterBaseCanvas.getContext('2d').drawImage(currentCanvas, 0, 0);
    overlayLayers = [];
    rebuildCurrentCanvasFromLayers();

    selectedCropRect = null;
    customRegions = [];
    cropX.value = 0;
    cropY.value = 0;
    cropW.value = currentCanvas.width;
    cropH.value = currentCanvas.height;
    clearSlicePreview();
    refreshLayoutMeta();
    scheduleAutoSlice();
    renderLayerList();
    return true;
}

function applyCrop() {
    cropCurrentCanvasFromSelection(false);
}

function saveCroppedImage() {
    if (!currentCanvas.width || !currentCanvas.height) {
        alert('Please upload an image first.');
        return;
    }

    const ok = cropCurrentCanvasFromSelection(true);
    if (ok) {
        sliceMeta.textContent = 'Crop saved to image (no download).';
    }
}

function updateEditLabels() {
    brightnessVal.textContent = brightness.value;
    contrastVal.textContent = contrast.value;
    grayscaleVal.textContent = grayscale.value;
    if (textSizeVal && textSize) textSizeVal.textContent = textSize.value;
}

function getProcessedCanvas() {
    const out = document.createElement('canvas');
    out.width = currentCanvas.width;
    out.height = currentCanvas.height;
    const ctx = out.getContext('2d');
    ctx.filter = getFilterString();
    ctx.drawImage(currentCanvas, 0, 0);
    ctx.filter = 'none';
    return out;
}

function autoGrid(total) {
    let rows = Math.floor(Math.sqrt(total));
    while (rows > 1 && total % rows !== 0) rows--;
    return { rows, cols: Math.ceil(total / rows) };
}

function setPresetActive(targetValue) {
    const buttons = presetWrap.querySelectorAll('.preset-btn');
    buttons.forEach((btn) => {
        btn.classList.toggle('active', parseInt(btn.dataset.value, 10) === targetValue);
    });
}

function getAutoSliceAxis() {
    const el = document.querySelector('input[name="autoSliceAxis"]:checked');
    return el && el.value === 'width' ? 'width' : 'height';
}

function autoSliceInputReady() {
    if (!autoSliceByTile.checked || hasVisibleSliceRegions()) return false;
    if (getAutoSliceAxis() === 'height') {
        const sh = parseInt(sliceBoxH.value, 10);
        return Number.isFinite(sh) && sh >= 1;
    }
    const sw = parseInt(sliceBoxW.value, 10);
    return Number.isFinite(sw) && sw >= 1;
}

function shouldUseAutoSliceOverlay() {
    return autoSliceInputReady();
}

function updateAutoSliceInputEnabledState() {
    const axisRadios = document.querySelectorAll('input[name="autoSliceAxis"]');
    if (!sectionState.slicing) {
        sliceBoxW.disabled = false;
        sliceBoxH.disabled = false;
        axisRadios.forEach((r) => { r.disabled = true; });
        return;
    }
    if (!autoSliceByTile.checked) {
        sliceBoxW.disabled = false;
        sliceBoxH.disabled = false;
        axisRadios.forEach((r) => { r.disabled = true; });
        return;
    }
    axisRadios.forEach((r) => { r.disabled = false; });
    if (getAutoSliceAxis() === 'height') {
        sliceBoxW.disabled = true;
        sliceBoxH.disabled = false;
    } else {
        sliceBoxW.disabled = false;
        sliceBoxH.disabled = true;
    }
}

function refreshLayoutMeta() {
    if (!sectionState.slicing) {
        sliceMeta.textContent = 'Custom Slicing is OFF.';
        renderPreview();
        return;
    }
    if (customRegions.length && hasVisibleSliceRegions()) {
        const n = customRegions.length;
        const nh = customRegions.filter((r) => r.visible === false).length;
        if (autoSliceByTile.checked) {
            sliceMeta.textContent = nh
                ? `Custom selector: ${n - nh} visible region(s), ${nh} hidden. Clear regions to use auto-slice.`
                : `Custom selector: ${n} region(s). Clear regions to use auto-slice.`;
        } else {
            sliceMeta.textContent = nh
                ? `Custom selector: ${n - nh} visible free-form region(s) (${nh} hidden).`
                : `Custom selector: ${n} free-form region(s) ready for slicing.`;
        }
        renderPreview();
        return;
    }
    if (autoSliceByTile.checked) {
        const axis = getAutoSliceAxis();
        if (axis === 'height') {
            const sh = parseInt(sliceBoxH.value, 10);
            if (!Number.isFinite(sh) || sh < 1) {
                sliceMeta.textContent = 'Auto-slice (by height): set Slice Height (px), ≥ 1.';
            } else if (currentCanvas.width && currentCanvas.height) {
                const n = Math.ceil(currentCanvas.height / sh);
                sliceMeta.textContent = `Auto-slice: ${n} horizontal strip(s), each ${currentCanvas.width}×${sh}px (last row may be shorter).`;
            } else {
                sliceMeta.textContent = `Auto-slice by row height: ${sh}px per strip (upload an image).`;
            }
        } else {
            const sw = parseInt(sliceBoxW.value, 10);
            if (!Number.isFinite(sw) || sw < 1) {
                sliceMeta.textContent = 'Auto-slice (by width): set Slice Width (px), ≥ 1.';
            } else if (currentCanvas.width && currentCanvas.height) {
                const n = Math.ceil(currentCanvas.width / sw);
                sliceMeta.textContent = `Auto-slice: ${n} vertical strip(s), each ${sw}×${currentCanvas.height}px (last column may be narrower).`;
            } else {
                sliceMeta.textContent = `Auto-slice by column width: ${sw}px per strip (upload an image).`;
            }
        }
        renderPreview();
        return;
    }
    const { total, rows, cols } = getSliceLayout();
    const cropInfo = selectedCropRect ? ` | Crop selected: ${selectedCropRect.w} x ${selectedCropRect.h}` : '';
    const fixedInfo = useFixedSliceSize.checked
        ? ` | Fixed slice size: ${Math.max(1, parseInt(sliceBoxW.value || 1, 10))}×${Math.max(1, parseInt(sliceBoxH.value || 1, 10))}`
        : '';
    sliceMeta.textContent = `Grid preview: ${rows} x ${cols} (${total} slices)${cropInfo}${fixedInfo}`;
    renderPreview();
}

function syncSelectorState() {
    const custom = useCustomGrid.checked;
    sliceSlider.disabled = custom;
    presetWrap.querySelectorAll('.preset-btn').forEach((btn) => {
        btn.disabled = custom;
    });
}

function getSliceLayout() {
    const total = Math.max(1, parseInt(sliceCountInput.value || 1, 10));
    if (useCustomGrid.checked) {
        const rows = Math.max(1, parseInt(rowsInput.value || 1, 10));
        const cols = Math.max(1, parseInt(colsInput.value || 1, 10));
        return { total: rows * cols, rows, cols };
    }
    const grid = autoGrid(total);
    return { total, rows: grid.rows, cols: grid.cols };
}

function updatePreviewDownloadSelectedState() {
    const boxes = slicePreviewContainer.querySelectorAll('.preview-slice-cb');
    const checked = slicePreviewContainer.querySelectorAll('.preview-slice-cb:checked').length;
    downloadPreviewSelectedBtn.disabled = boxes.length === 0 || checked === 0;
}

function clearSlicePreview() {
    slicePreviewContainer.innerHTML = '';
    slicePreviewMeta.textContent = '';
    if (previewBulkSelect) previewBulkSelect.value = '';
    downloadPreviewSelectedBtn.disabled = true;
}

function syncDownloadAllUiState() {
    downloadAllBtn.disabled = false;
    const menuRow = document.querySelector('#appMenubar [data-menu-action="download-all"]');
    if (menuRow) menuRow.disabled = false;
}

function clearSlices() {
    sliceContainer.innerHTML = '';
    sliceItems = [];
    syncDownloadAllUiState();
}

function computeSliceTiles() {
    if (!sectionState.slicing) {
        return { ok: false, message: 'Turn Custom Slicing ON to preview or slice.' };
    }
    if (!currentCanvas.width || !currentCanvas.height) {
        return { ok: false, message: 'Upload an image first.' };
    }
    const processed = getProcessedCanvas();
    const visibleRegions = customRegions.filter((r) => r.visible !== false);
    if (visibleRegions.length) {
        const result = [];
        visibleRegions.forEach((region, i) => {
            const x = Math.max(0, Math.min(region.x, processed.width - 1));
            const y = Math.max(0, Math.min(region.y, processed.height - 1));
            const w = Math.max(1, Math.min(region.w, processed.width - x));
            const h = Math.max(1, Math.min(region.h, processed.height - y));
            const tile = document.createElement('canvas');
            tile.width = w;
            tile.height = h;
            tile.getContext('2d').drawImage(processed, x, y, w, h, 0, 0, w, h);
            result.push({
                index: i + 1,
                dataUrl: tile.toDataURL('image/png'),
            });
        });
        return { ok: true, slices: result, mode: 'custom', rows: null, cols: null };
    }
    if (autoSliceByTile.checked) {
        const iw = processed.width;
        const ih = processed.height;
        const result = [];
        let index = 0;
        if (getAutoSliceAxis() === 'height') {
            const sh = parseInt(sliceBoxH.value, 10);
            if (!Number.isFinite(sh) || sh < 1) {
                return { ok: false, message: 'Set Slice Height (pixels, at least 1) for auto-slice by row height.' };
            }
            const rows = Math.ceil(ih / sh);
            for (let r = 0; r < rows; r++) {
                const y = r * sh;
                const h = Math.min(sh, ih - y);
                if (h < 1) continue;
                const tile = document.createElement('canvas');
                tile.width = iw;
                tile.height = h;
                tile.getContext('2d').drawImage(processed, 0, y, iw, h, 0, 0, iw, h);
                index += 1;
                result.push({ index, dataUrl: tile.toDataURL('image/png') });
            }
            return { ok: true, slices: result, mode: 'stripHeight', rowHeight: sh, stripCount: result.length };
        }
        const sw = parseInt(sliceBoxW.value, 10);
        if (!Number.isFinite(sw) || sw < 1) {
            return { ok: false, message: 'Set Slice Width (pixels, at least 1) for auto-slice by column width.' };
        }
        const cols = Math.ceil(iw / sw);
        for (let c = 0; c < cols; c++) {
            const x = c * sw;
            const w = Math.min(sw, iw - x);
            if (w < 1) continue;
            const tile = document.createElement('canvas');
            tile.width = w;
            tile.height = ih;
            tile.getContext('2d').drawImage(processed, x, 0, w, ih, 0, 0, w, ih);
            index += 1;
            result.push({ index, dataUrl: tile.toDataURL('image/png') });
        }
        return { ok: true, slices: result, mode: 'stripWidth', colWidth: sw, stripCount: result.length };
    }
    const { total, rows, cols } = getSliceLayout();
    if (processed.width < cols || processed.height < rows) {
        return { ok: false, message: 'Image is too small for this grid. Use fewer rows/columns or slices.' };
    }
    const result = [];
    for (let i = 0; i < total; i++) {
        const r = Math.floor(i / cols);
        const c = i % cols;
        const x1 = Math.floor((c * processed.width) / cols);
        const x2 = Math.floor(((c + 1) * processed.width) / cols);
        const y1 = Math.floor((r * processed.height) / rows);
        const y2 = Math.floor(((r + 1) * processed.height) / rows);
        const w = Math.max(1, x2 - x1);
        const h = Math.max(1, y2 - y1);
        const tile = document.createElement('canvas');
        tile.width = w;
        tile.height = h;
        tile.getContext('2d').drawImage(processed, x1, y1, w, h, 0, 0, w, h);
        result.push({
            index: i + 1,
            dataUrl: tile.toDataURL('image/png'),
        });
    }
    return { ok: true, slices: result, mode: 'grid', rows, cols };
}

function runSlicePreview() {
    const computed = computeSliceTiles();
    if (!computed.ok) {
        clearSlicePreview();
        slicePreviewMeta.textContent = computed.message;
        return;
    }
    slicePreviewContainer.innerHTML = '';
    computed.slices.forEach((item) => {
        const card = document.createElement('div');
        card.className = 'slice-preview-card';
        card.dataset.index = String(item.index);
        card.innerHTML = `
            <label class="slice-preview-pick">
                <input type="checkbox" class="preview-slice-cb" checked>
                <span>#${item.index}</span>
            </label>
            <img src="${item.dataUrl}" alt="Preview ${item.index}">
        `;
        slicePreviewContainer.appendChild(card);
    });
    updatePreviewDownloadSelectedState();
    let layoutNote = 'custom regions';
    if (computed.mode === 'grid') {
        layoutNote = `${computed.rows} × ${computed.cols} grid`;
    } else if (computed.mode === 'stripHeight') {
        layoutNote = `${computed.stripCount} full-width row(s), ${computed.rowHeight}px tall`;
    } else if (computed.mode === 'stripWidth') {
        layoutNote = `${computed.stripCount} full-height column(s), ${computed.colWidth}px wide`;
    }
    slicePreviewMeta.textContent = `Preview: ${computed.slices.length} tile(s) (${layoutNote}). Tick slices to include, then Download selected for a ZIP. Main list still uses Slice Image.`;
}

function renderSlices(slices) {
    clearSlices();
    for (const item of slices) {
        const card = document.createElement('div');
        card.className = 'slice-card';
        card.innerHTML = `
            <img src="${item.dataUrl}" alt="Slice ${item.index}">
            <div>Slice ${item.index}</div>
            <a href="${item.dataUrl}" download="slice_${item.index}.png">Download</a>
        `;
        sliceContainer.appendChild(card);
    }
    sliceItems = slices;
    syncDownloadAllUiState();
}

function scheduleAutoSlice() {
    if (!autoSliceByTile.checked || hasVisibleSliceRegions()) return;
    if (!autoSliceInputReady()) {
        clearTimeout(autoSliceTimer);
        autoSliceTimer = null;
        return;
    }
    clearTimeout(autoSliceTimer);
    autoSliceTimer = setTimeout(() => {
        autoSliceTimer = null;
        sliceImage({ silent: true });
    }, AUTO_SLICE_DEBOUNCE_MS);
}

function sliceImage(opts = {}) {
    const silent = !!opts.silent;
    if (!sectionState.slicing) {
        if (silent) {
            sliceMeta.textContent = 'Turn Custom Slicing ON to slice.';
        } else {
            alert('Custom Slicing section is OFF. Turn it ON to slice.');
        }
        return;
    }
    if (!currentCanvas.width || !currentCanvas.height) {
        if (!silent) {
            alert('Please upload an image first.');
        }
        return;
    }

    const computed = computeSliceTiles();
    if (!computed.ok) {
        if (silent) {
            sliceMeta.textContent = computed.message;
        } else {
            alert(computed.message);
        }
        return;
    }
    if (computed.mode === 'custom') {
        sliceMeta.textContent = `Generated ${computed.slices.length} custom slice(s) from free-form selector.`;
    } else if (computed.mode === 'stripHeight') {
        sliceMeta.textContent = `Generated ${computed.slices.length} horizontal strip(s) (~${computed.rowHeight}px tall, full width).`;
    } else if (computed.mode === 'stripWidth') {
        sliceMeta.textContent = `Generated ${computed.slices.length} vertical strip(s) (~${computed.colWidth}px wide, full height).`;
    } else {
        sliceMeta.textContent = `Generated ${computed.slices.length} slices (${computed.rows} x ${computed.cols}).`;
    }
    clearSlicePreview();
    pushSliceUndoSnapshot();
    renderSlices(computed.slices);
}

function downloadAll() {
    if (!sliceItems.length) {
        const msg = 'No slices to download yet. Run Slice image first (with Custom Slicing on), then try again.';
        if (sliceMeta && !workspace.classList.contains('hidden')) sliceMeta.textContent = msg;
        else alert(msg);
        return;
    }
    downloadAllBtn.disabled = true;
    const menuRow = document.querySelector('#appMenubar [data-menu-action="download-all"]');
    if (menuRow) menuRow.disabled = true;
    const oldText = downloadAllBtn.textContent;
    downloadAllBtn.textContent = 'Preparing ZIP...';

    const folderName = `sliced_images_${Date.now()}`;
    const payload = {
        folder_name: folderName,
        slices: sliceItems.map((item) => ({
            name: `slice_${item.index}.png`,
            data: item.dataUrl.split(',')[1],
        })),
    };

    fetch('download_zip.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
    }).then((response) => {
        if (!response.ok) {
            return response.text().then((txt) => {
                throw new Error(txt || 'ZIP creation failed.');
            });
        }
        return response.blob();
    }).then((blob) => {
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `${folderName}.zip`;
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(link.href), 2000);
    }).catch((err) => {
        alert(`Could not create ZIP file. ${err.message || 'Try again.'}`);
    }).finally(() => {
        downloadAllBtn.textContent = oldText;
        syncDownloadAllUiState();
    });
}

function downloadPreviewSelected() {
    const selected = [];
    slicePreviewContainer.querySelectorAll('.slice-preview-card').forEach((card) => {
        const cb = card.querySelector('.preview-slice-cb');
        if (!cb || !cb.checked) return;
        const img = card.querySelector('img');
        if (!img || !img.src || !img.src.startsWith('data:')) return;
        const idx = parseInt(card.dataset.index, 10) || selected.length + 1;
        selected.push({ index: idx, dataUrl: img.src });
    });
    if (!selected.length) {
        alert('Select at least one preview slice (use checkboxes).');
        return;
    }
    downloadPreviewSelectedBtn.disabled = true;
    const oldText = downloadPreviewSelectedBtn.textContent;
    downloadPreviewSelectedBtn.textContent = 'Preparing ZIP…';

    const folderName = `preview_slices_${Date.now()}`;
    const payload = {
        folder_name: folderName,
        slices: selected.map((item) => ({
            name: `preview_slice_${item.index}.png`,
            data: item.dataUrl.split(',')[1],
        })),
    };

    fetch('download_zip.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
    }).then((response) => {
        if (!response.ok) {
            return response.text().then((txt) => {
                throw new Error(txt || 'ZIP creation failed.');
            });
        }
        return response.blob();
    }).then((blob) => {
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `${folderName}.zip`;
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(link.href), 2000);
    }).catch((err) => {
        alert(`Could not create ZIP file. ${err.message || 'Try again.'}`);
    }).finally(() => {
        downloadPreviewSelectedBtn.disabled = false;
        downloadPreviewSelectedBtn.textContent = oldText;
        updatePreviewDownloadSelectedState();
    });
}

imageInput.addEventListener('change', (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function (evt) {
        const img = new Image();
        img.onload = function () {
            const placeOnBlank = newDocumentAwaitingImage && rasterBaseCanvas.width && rasterBaseCanvas.height;
            clearTimeout(autoSliceTimer);
            autoSliceTimer = null;
            undoStack = [];
            updateUndoUi();
            clearSlicePreview();
            clearSlices();
            if (placeOnBlank) {
                placeImageCenteredOnDocument(img);
                newDocumentAwaitingImage = false;
            } else {
                setCanvasFromImage(img);
            }
            workspace.classList.remove('hidden');
            scheduleAutoSlice();
            applyPendingCreateOptions();
        };
        img.src = evt.target.result;
    };
    reader.readAsDataURL(file);
});

[brightness, contrast, grayscale].forEach((input) => {
    input.addEventListener('input', () => {
        updateEditLabels();
        renderPreview();
    });
});
textSize.addEventListener('input', () => {
    textSizeVal.textContent = textSize.value;
    if (!isSyncingTextFieldsFromLayer) {
        applyEditFieldsToSelectedTextLayer();
    }
});
if (overlayText) {
    overlayText.addEventListener('input', () => {
        if (!isSyncingTextFieldsFromLayer) {
            applyEditFieldsToSelectedTextLayer();
        }
    });
}
if (textColor) {
    textColor.addEventListener('input', () => {
        if (!isSyncingTextFieldsFromLayer) {
            applyEditFieldsToSelectedTextLayer();
        }
    });
}

useCustomGrid.addEventListener('change', () => {
    rowsInput.disabled = !useCustomGrid.checked;
    colsInput.disabled = !useCustomGrid.checked;
    syncSelectorState();
    refreshLayoutMeta();
});

sliceCountInput.addEventListener('input', () => {
    const count = Math.max(1, parseInt(sliceCountInput.value || 1, 10));
    if (count <= parseInt(sliceSlider.max, 10)) {
        sliceSlider.value = count;
    }
    setPresetActive(count);
    refreshLayoutMeta();
});

sliceSlider.addEventListener('input', () => {
    const count = Math.max(1, parseInt(sliceSlider.value || 1, 10));
    sliceCountInput.value = count;
    setPresetActive(count);
    refreshLayoutMeta();
});

presetWrap.addEventListener('click', (event) => {
    const btn = event.target.closest('.preset-btn');
    if (!btn || btn.disabled) return;
    const value = Math.max(1, parseInt(btn.dataset.value || 1, 10));
    sliceCountInput.value = value;
    sliceSlider.value = Math.min(value, parseInt(sliceSlider.max, 10));
    setPresetActive(value);
    refreshLayoutMeta();
});

function onRowsColsInput() {
    refreshLayoutMeta();
}
[rowsInput, colsInput].forEach((input) => {
    input.addEventListener('input', onRowsColsInput);
});
function onSliceTileSizeInput() {
    refreshLayoutMeta();
    scheduleAutoSlice();
}
[sliceBoxW, sliceBoxH].forEach((input) => {
    input.addEventListener('input', onSliceTileSizeInput);
});
document.querySelectorAll('input[name="autoSliceAxis"]').forEach((radio) => {
    radio.addEventListener('change', () => {
        updateAutoSliceInputEnabledState();
        refreshLayoutMeta();
        scheduleAutoSlice();
    });
});
autoSliceByTile.addEventListener('change', () => {
    updateAutoSliceInputEnabledState();
    refreshLayoutMeta();
    if (autoSliceByTile.checked) {
        scheduleAutoSlice();
    } else {
        clearTimeout(autoSliceTimer);
        autoSliceTimer = null;
    }
});
useFixedSliceSize.addEventListener('input', refreshLayoutMeta);

if (psToolsBar) {
    psToolsBar.addEventListener('click', (e) => {
        const act = e.target.closest('[data-ps-tool]');
        if (act) {
            const m = act.getAttribute('data-ps-tool');
            if (m === 'crop') setToolMode('crop');
            else if (m === 'slice') setToolMode('slice');
            else if (m === 'erase') setToolMode('erase');
            else if (m === 'text') setToolMode('text');
            return;
        }
        const st = e.target.closest('[data-ps-stub]');
        if (st) showPsStubHint(st.getAttribute('data-ps-stub'));
    });
}
if (psSwapColorsBtn && psSwatchStack) {
    psSwapColorsBtn.addEventListener('click', () => {
        psSwatchStack.classList.toggle('ps-swapped');
    });
}
if (psDefaultColorsBtn && psSwatchStack) {
    psDefaultColorsBtn.addEventListener('click', () => {
        psSwatchStack.classList.remove('ps-swapped');
    });
}
if (tdpAddTextBoxBtn) {
    tdpAddTextBoxBtn.addEventListener('click', () => applyTextStylePreset('box'));
}
if (tdpMagicWriteBtn) {
    tdpMagicWriteBtn.addEventListener('click', () => {
        const cur = (overlayText && overlayText.value) ? overlayText.value.trim() : '';
        const v = window.prompt('Enter text for the image:', cur || 'Your message');
        if (v === null) return;
        if (overlayText) overlayText.value = v.slice(0, 500);
        applyEditFieldsToSelectedTextLayer();
        setToolMode('text');
        toolHint.textContent = 'Click the image to place this text. Adjust size and color in Edit if needed.';
    });
}
if (tdpBrandEditLink) {
    tdpBrandEditLink.addEventListener('click', (e) => {
        e.preventDefault();
        if (typeof openSectionPanel === 'function') openSectionPanel('edit');
    });
}
if (tdpBrandFontsBtn) {
    tdpBrandFontsBtn.addEventListener('click', () => {
        if (typeof openSectionPanel === 'function') openSectionPanel('edit');
        if (overlayText) overlayText.focus();
    });
}
if (textFontSearch) {
    textFontSearch.addEventListener('input', filterTextPresetCards);
}
document.querySelectorAll('.text-design-panel-wrap [data-tdp-preset]').forEach((btn) => {
    btn.addEventListener('click', () => {
        const kind = btn.getAttribute('data-tdp-preset');
        if (kind) applyTextStylePreset(kind);
    });
});
document.querySelectorAll('.ws-nav-rail [data-studio-tab]').forEach((btn) => {
    btn.addEventListener('click', () => {
        const tab = btn.getAttribute('data-studio-tab');
        if (tab) setStudioTab(tab);
    });
});
initElementBrowse();
const wsNavNotesBtn = document.getElementById('wsNavNotesBtn');
const wsNavTimerBtn = document.getElementById('wsNavTimerBtn');
if (wsNavNotesBtn && toolHint) {
    wsNavNotesBtn.addEventListener('click', () => {
        toolHint.textContent = 'Notes (demo): jot ideas in your own notes app; this control is visual only.';
    });
}
if (wsNavTimerBtn && toolHint) {
    wsNavTimerBtn.addEventListener('click', () => {
        toolHint.textContent = 'Timer (demo): use your phone or OS clock for timed sessions.';
    });
}
undoBtn.addEventListener('click', undoLast);
undoCropPanelBtn.addEventListener('click', undoLast);
undoSlicePanelBtn.addEventListener('click', undoLast);
document.addEventListener('keydown', (e) => {
    const t = e.target;
    if (e.key === 'Escape') {
        const newDocModal = document.getElementById('newDocumentModal');
        if (newDocModal && !newDocModal.classList.contains('hidden')) {
            if (window.closeNewDocumentModal) window.closeNewDocumentModal();
            return;
        }
        const createModal = document.getElementById('createDesignModal');
        if (createModal && !createModal.classList.contains('hidden')) {
            if (window.closeCreateDesignModal) window.closeCreateDesignModal();
            return;
        }
        const menuOpen = document.querySelector('#appMenubar .menu-top[aria-expanded="true"]');
        if (menuOpen && window.closeAppMenus) {
            window.closeAppMenus();
            return;
        }
    }
    const mod = e.ctrlKey || e.metaKey;
    if (mod && e.shiftKey && (e.key === 'z' || e.key === 'Z')) {
        if (isTextEditingTarget(t)) return;
        if (workspace.classList.contains('hidden')) return;
        e.preventDefault();
        undoRegionBtn.click();
        return;
    }
    if (mod && (e.key === 'z' || e.key === 'Z') && !e.shiftKey) {
        if (isTextEditingTarget(t)) return;
        if (workspace.classList.contains('hidden') || !undoStack.length) return;
        e.preventDefault();
        undoLast();
        return;
    }
    if (!mod) return;
    if (mod && (e.key === 'o' || e.key === 'O') && !e.shiftKey && !e.altKey) {
        if (isTextEditingTarget(t)) return;
        e.preventDefault();
        imageInput.click();
        return;
    }
    if (mod && (e.key === 'n' || e.key === 'N') && !e.shiftKey && !e.altKey) {
        if (isTextEditingTarget(t)) return;
        e.preventDefault();
        openNewDocumentModal();
        return;
    }
    if (mod && (e.key === 'w' || e.key === 'W') && !e.shiftKey && !e.altKey) {
        if (isTextEditingTarget(t)) return;
        if (!workspace.classList.contains('hidden')) {
            e.preventDefault();
            runMenuAction('close-workspace');
        }
        return;
    }
    if (mod && e.shiftKey && (e.key === 'o' || e.key === 'O') && !e.altKey) {
        if (isTextEditingTarget(t)) return;
        e.preventDefault();
        runMenuAction('browse-image');
        return;
    }
    if (mod && (e.key === 'p' || e.key === 'P') && !e.shiftKey && !e.altKey) {
        if (isTextEditingTarget(t)) return;
        if (!workspace.classList.contains('hidden') && currentCanvas.width) {
            e.preventDefault();
            runMenuAction('print-preview');
        }
        return;
    }
    if (mod && (e.key === 's' || e.key === 'S') && !e.shiftKey && !e.altKey) {
        if (isTextEditingTarget(t)) return;
        if (workspace.classList.contains('hidden')) return;
        e.preventDefault();
        saveCropBtn.click();
        return;
    }
    if (mod && e.shiftKey && e.key === 'Enter') {
        if (isTextEditingTarget(t)) return;
        e.preventDefault();
        if (!workspace.classList.contains('hidden')) sliceImage();
        return;
    }
    if (mod && e.shiftKey && (e.key === 'd' || e.key === 'D')) {
        if (isTextEditingTarget(t)) return;
        e.preventDefault();
        downloadAll();
        return;
    }
    if (mod && e.shiftKey && (e.key === 'p' || e.key === 'P')) {
        if (isTextEditingTarget(t)) return;
        e.preventDefault();
        if (!workspace.classList.contains('hidden')) previewSliceBtn.click();
        return;
    }
    if (mod && e.shiftKey && (e.key === 'm' || e.key === 'M')) {
        if (isTextEditingTarget(t)) return;
        if (workspace.classList.contains('hidden')) return;
        e.preventDefault();
        if (flattenPaintLayersBtn) flattenPaintLayersBtn.click();
        return;
    }
    if (mod && e.altKey && (e.key === 'x' || e.key === 'X') && !e.shiftKey) {
        if (isTextEditingTarget(t)) return;
        if (workspace.classList.contains('hidden')) return;
        e.preventDefault();
        clearRegionsBtn.click();
        return;
    }
    if (mod && e.altKey && (e.key === 'r' || e.key === 'R') && !e.shiftKey) {
        if (isTextEditingTarget(t)) return;
        if (workspace.classList.contains('hidden')) return;
        e.preventDefault();
        resetEditBtn.click();
        return;
    }
    if (mod && !e.shiftKey && !e.altKey && (e.key === '0' || e.code === 'Digit0' || e.code === 'Numpad0')) {
        if (isTextEditingTarget(t)) return;
        if (workspace.classList.contains('hidden')) return;
        e.preventDefault();
        zoomResetBtn.click();
        return;
    }
    if (mod && !e.altKey && (e.key === '=' || e.key === '+' || e.code === 'Equal' || e.code === 'NumpadAdd')) {
        if (isTextEditingTarget(t)) return;
        if (workspace.classList.contains('hidden')) return;
        e.preventDefault();
        zoomInBtn.click();
        return;
    }
    if (mod && !e.altKey && (e.key === '-' || e.key === '_' || e.code === 'Minus' || e.code === 'NumpadSubtract')) {
        if (isTextEditingTarget(t)) return;
        if (workspace.classList.contains('hidden')) return;
        e.preventDefault();
        zoomOutBtn.click();
    }
});
undoRegionBtn.addEventListener('click', () => {
    if (customRegions.length) {
        customRegions.pop();
        refreshLayoutMeta();
        scheduleAutoSlice();
        renderLayerList();
    }
});
clearRegionsBtn.addEventListener('click', () => {
    customRegions = [];
    refreshLayoutMeta();
    scheduleAutoSlice();
    renderLayerList();
});
if (layoutElementSelect && layoutElementMoveUpBtn && layoutElementMoveDownBtn) {
    layoutElementSelect.addEventListener('change', () => {
        if (layoutElementSelectProgrammatic) {
            updateLayoutElementMoveButtons();
            return;
        }
        const parsed = parseLayoutElementValue(layoutElementSelect.value);
        if (parsed && parsed.kind === 'layer') {
            const L = overlayLayers.find((l) => l.id === parsed.id);
            if (L && L.type === 'text') {
                selectTextLayerById(parsed.id);
                if (toolHint) {
                    toolHint.textContent = 'Selected text layer — edit in Edit or switch to Add text and drag on canvas to move.';
                }
            } else {
                clearSelectedTextLayer();
            }
        } else {
            clearSelectedTextLayer();
        }
        updateLayoutElementMoveButtons();
    });
    layoutElementMoveUpBtn.addEventListener('click', () => moveLayoutElement(-1));
    layoutElementMoveDownBtn.addEventListener('click', () => moveLayoutElement(1));
}

const layerListEl = document.getElementById('layerList');
const flattenPaintLayersBtn = document.getElementById('flattenPaintLayersBtn');
if (layerListEl) {
    layerListEl.addEventListener('change', (e) => {
        const t = e.target;
        if (!(t instanceof HTMLInputElement) || t.type !== 'checkbox') return;
        if (t.dataset.layerAction === 'toggle-paint') {
            const L = overlayLayers.find((l) => l.id === t.dataset.layerId);
            if (L) {
                L.visible = t.checked;
                rebuildCurrentCanvasFromLayers();
                renderPreview();
            }
        } else if (t.dataset.layerAction === 'toggle-slice') {
            const idx = parseInt(t.dataset.sliceIndex, 10);
            if (Number.isFinite(idx) && customRegions[idx]) {
                customRegions[idx].visible = t.checked;
                renderPreview();
                refreshLayoutMeta();
                scheduleAutoSlice();
                renderLayerList();
            }
        }
    });
    layerListEl.addEventListener('click', (e) => {
        const btn = e.target.closest('button');
        if (!btn || btn.dataset.layerAction !== 'delete-paint') return;
        const id = btn.dataset.layerId;
        const ix = overlayLayers.findIndex((l) => l.id === id);
        if (ix === -1) return;
        pushCropUndoSnapshot();
        overlayLayers.splice(ix, 1);
        rebuildCurrentCanvasFromLayers();
        renderPreview();
        renderLayerList();
        clearSlicePreview();
        refreshLayoutMeta();
        scheduleAutoSlice();
    });
}
if (flattenPaintLayersBtn) {
    flattenPaintLayersBtn.addEventListener('click', () => {
        if (!overlayLayers.length) return;
        pushCropUndoSnapshot();
        flattenOverlayLayersToBase();
        renderLayerList();
        clearSlicePreview();
        refreshLayoutMeta();
        scheduleAutoSlice();
    });
}

previewCanvas.addEventListener('pointerdown', onPreviewPointerDown);
previewCanvas.addEventListener('pointermove', onPreviewPointerMove);
previewCanvas.addEventListener('pointerup', onPreviewPointerUp);
previewCanvas.addEventListener('pointercancel', onPreviewPointerUp);
cropMinBtn.addEventListener('click', () => resizeCropSelection(0.9));
cropMaxBtn.addEventListener('click', () => resizeCropSelection(1.1));
cropScaleSlider.addEventListener('input', () => {
    const scalePercent = Math.max(50, Math.min(200, parseInt(cropScaleSlider.value || 100, 10)));
    resizeCropSelection(scalePercent / 100);
    cropScaleSlider.value = '100';
});
[cropX, cropY, cropW, cropH].forEach((input) => {
    input.addEventListener('input', syncCropRectFromInputs);
});
zoomOutBtn.addEventListener('click', () => setZoom(zoomLevel - 10));
zoomInBtn.addEventListener('click', () => setZoom(zoomLevel + 10));
zoomResetBtn.addEventListener('click', () => setZoom(100));
zoomSlider.addEventListener('input', () => setZoom(parseInt(zoomSlider.value || 100, 10)));

applyCropBtn.addEventListener('click', applyCrop);
saveCropBtn.addEventListener('click', saveCroppedImage);
resetCropBtn.addEventListener('click', resetCrop);
resetEditBtn.addEventListener('click', () => {
    brightness.value = 100;
    contrast.value = 100;
    grayscale.value = 0;
    updateEditLabels();
    renderPreview();
});
sliceBtn.addEventListener('click', () => sliceImage());
previewSliceBtn.addEventListener('click', runSlicePreview);
clearSlicePreviewBtn.addEventListener('click', clearSlicePreview);
slicePreviewContainer.addEventListener('change', (e) => {
    if (e.target && e.target.classList && e.target.classList.contains('preview-slice-cb')) {
        updatePreviewDownloadSelectedState();
    }
});
previewBulkSelect.addEventListener('change', () => {
    const mode = previewBulkSelect.value;
    if (!mode) return;
    slicePreviewContainer.querySelectorAll('.preview-slice-cb').forEach((cb) => {
        if (mode === 'all') cb.checked = true;
        else if (mode === 'none') cb.checked = false;
        else if (mode === 'invert') cb.checked = !cb.checked;
    });
    previewBulkSelect.value = '';
    updatePreviewDownloadSelectedState();
});
downloadPreviewSelectedBtn.addEventListener('click', downloadPreviewSelected);
downloadAllBtn.addEventListener('click', downloadAll);
layoutSplit.addEventListener('input', () => {
    if (!sectionState.settings) return;
    const pct = Math.max(50, Math.min(85, parseInt(layoutSplit.value || 70, 10)));
    layoutSplitVal.textContent = pct;
    workspace.style.setProperty('--image-panel-width', `${pct}%`);
});
toggleSettings.addEventListener('change', () => {
    applySectionToggle('settings', toggleSettings.checked);
    syncToggleLabel(toggleSettings);
});
toggleCrop.addEventListener('change', () => {
    applySectionToggle('crop', toggleCrop.checked);
    syncToggleLabel(toggleCrop);
    if (!toggleCrop.checked && toolMode === 'crop') {
        if (sectionState.slicing) {
            setToolMode('slice');
        } else {
            toolMode = 'crop';
            toolHint.textContent = 'Open Crop or Custom Slicing to use drawing tools.';
            renderPreview();
            syncPsToolsFromToolMode();
        }
    }
});
toggleEdit.addEventListener('change', () => {
    applySectionToggle('edit', toggleEdit.checked);
    syncToggleLabel(toggleEdit);
    if (!toggleEdit.checked && (toolMode === 'erase' || toolMode === 'text')) {
        if (sectionState.slicing) {
            setToolMode('slice');
        } else if (sectionState.crop) {
            setToolMode('crop');
        } else {
            toolMode = 'slice';
            previewCanvas.style.cursor = '';
            toolHint.textContent = 'Open Crop, Edit, or Custom Slicing to use tools.';
            renderPreview();
            syncPsToolsFromToolMode();
        }
    }
    renderPreview();
});
toggleSlicing.addEventListener('change', () => {
    applySectionToggle('slicing', toggleSlicing.checked);
    syncToggleLabel(toggleSlicing);
    if (!toggleSlicing.checked && toolMode === 'slice') {
        if (sectionState.crop) {
            setToolMode('crop');
        } else {
            toolMode = 'slice';
            previewCanvas.style.cursor = '';
            toolHint.textContent = 'Open Crop or Custom Slicing to use drawing tools.';
            renderPreview();
            syncPsToolsFromToolMode();
        }
    }
    updateAutoSliceInputEnabledState();
    refreshLayoutMeta();
    scheduleAutoSlice();
});

updateEditLabels();
syncSelectorState();
updateAutoSliceInputEnabledState();
refreshLayoutMeta();
workspace.style.setProperty('--image-panel-width', `${layoutSplit.value}%`);
applySectionToggle('settings', toggleSettings.checked);
applySectionToggle('crop', toggleCrop.checked);
applySectionToggle('edit', toggleEdit.checked);
applySectionToggle('slicing', toggleSlicing.checked);
syncToggleLabel(toggleSettings);
syncToggleLabel(toggleCrop);
syncToggleLabel(toggleEdit);
syncToggleLabel(toggleSlicing);
(function initAppMenubar() {
    const bar = document.getElementById('appMenubar');
    if (!bar) return;
    const topButtons = bar.querySelectorAll('.menu-top');

    function closeAppMenus() {
        topButtons.forEach((btn) => {
            btn.setAttribute('aria-expanded', 'false');
            const id = btn.getAttribute('aria-controls');
            const panel = id && document.getElementById(id);
            if (panel) panel.hidden = true;
        });
    }
    window.closeAppMenus = closeAppMenus;

    function openDropdown(topBtn) {
        closeAppMenus();
        const id = topBtn.getAttribute('aria-controls');
        const panel = id && document.getElementById(id);
        if (!panel) return;
        if (topBtn.id === 'menuTopFile') syncDownloadAllUiState();
        topBtn.setAttribute('aria-expanded', 'true');
        panel.hidden = false;
    }

    function toggleDropdown(topBtn) {
        const open = topBtn.getAttribute('aria-expanded') === 'true';
        if (open) closeAppMenus();
        else openDropdown(topBtn);
    }

    topButtons.forEach((btn) => {
        btn.addEventListener('click', (ev) => {
            ev.stopPropagation();
            toggleDropdown(btn);
        });
    });

    bar.querySelectorAll('[data-menu-action]').forEach((row) => {
        row.addEventListener('click', () => {
            runMenuAction(row.getAttribute('data-menu-action'));
            closeAppMenus();
        });
    });

    document.addEventListener('pointerdown', (ev) => {
        if (!bar.contains(ev.target)) closeAppMenus();
    }, true);
})();
(function initDashShell() {
    const triggerUpload = () => {
        if (imageInput) imageInput.click();
    };
    const dashHeroBtn = document.getElementById('dashHeroUploadBtn');
    const sbCreate = document.getElementById('sbCreateBtn');
    if (dashHeroBtn) dashHeroBtn.addEventListener('click', triggerUpload);
    if (sbCreate) sbCreate.addEventListener('click', () => { if (window.openCreateDesignModal) window.openCreateDesignModal(); });

    function runQuickAction(key) {
        if (key === 'upload') {
            triggerUpload();
            return;
        }
        if (key === 'download') {
            downloadAll();
            return;
        }
        if (key === 'zoom') {
            if (!workspace.classList.contains('hidden')) zoomResetBtn.click();
            else triggerUpload();
            return;
        }
        if (workspace.classList.contains('hidden')) {
            triggerUpload();
            return;
        }
        if (key === 'slice') {
            openSectionPanel('slicing');
            setToolMode('slice');
        } else if (key === 'crop') {
            openSectionPanel('crop');
            setToolMode('crop');
        } else if (key === 'edit') {
            openSectionPanel('edit');
        } else if (key === 'slicing-panel') {
            openSectionPanel('slicing');
        } else if (key === 'settings') {
            openSectionPanel('settings');
        }
    }
    window.runQuickAction = runQuickAction;

    function runNavAction(nav) {
        const hero = document.getElementById('dashHero');
        if (nav === 'home') {
            if (hero) hero.scrollIntoView({ behavior: 'smooth', block: 'start' });
            return;
        }
        if (nav === 'editor') {
            if (!workspace.classList.contains('hidden')) {
                workspace.scrollIntoView({ behavior: 'smooth', block: 'start' });
            } else {
                triggerUpload();
            }
            return;
        }
        if (nav === 'settings') {
            openSectionPanel('settings');
            if (settingsPanel) settingsPanel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            return;
        }
        if (nav === 'download') {
            downloadAll();
        }
    }
    window.runNavAction = runNavAction;

    document.querySelectorAll('[data-quick]').forEach((btn) => {
        btn.addEventListener('click', () => runQuickAction(btn.getAttribute('data-quick')));
    });
    document.querySelectorAll('.app-sidebar [data-nav]').forEach((btn) => {
        btn.addEventListener('click', () => runNavAction(btn.getAttribute('data-nav')));
    });

    const dashSearchInput = document.getElementById('dashSearchInput');
    if (dashSearchInput) {
        dashSearchInput.addEventListener('input', () => {
            const q = (dashSearchInput.value || '').trim().toLowerCase();
            document.querySelectorAll('.dash-card').forEach((card) => {
                const t = (card.textContent || '').toLowerCase();
                card.style.display = !q || t.includes(q) ? '' : 'none';
            });
        });
    }
})();
(function initCreateDesignModal() {
    const modal = document.getElementById('createDesignModal');
    const main = document.getElementById('createModalMain');
    const backdrop = document.getElementById('createModalBackdrop');
    const closeBtn = document.getElementById('createModalCloseBtn');
    const search = document.getElementById('createModalSearchInput');
    if (!modal || !backdrop || !closeBtn) return;

    function filterCreateModal(q) {
        const qq = (q || '').trim().toLowerCase();
        document.querySelectorAll('.create-nav-item').forEach((nav) => {
            const tags = `${nav.dataset.createTags || ''} ${nav.textContent || ''}`;
            nav.style.display = !qq || tags.toLowerCase().includes(qq) ? '' : 'none';
        });
        document.querySelectorAll('.create-sec').forEach((sec) => {
            const tags = `${sec.dataset.createTags || ''} ${sec.textContent || ''}`;
            sec.style.display = !qq || tags.toLowerCase().includes(qq) ? '' : 'none';
        });
    }

    function closeCreateDesignModal() {
        modal.classList.add('hidden');
        document.body.style.overflow = '';
        if (search) search.value = '';
        filterCreateModal('');
    }

    function openCreateDesignModal() {
        if (window.closeNewDocumentModal) {
            const nd = document.getElementById('newDocumentModal');
            if (nd && !nd.classList.contains('hidden')) window.closeNewDocumentModal();
        }
        modal.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
        if (window.closeAppMenus) window.closeAppMenus();
        filterCreateModal(search ? search.value : '');
        closeBtn.focus();
    }

    window.openCreateDesignModal = openCreateDesignModal;
    window.closeCreateDesignModal = closeCreateDesignModal;

    backdrop.addEventListener('click', closeCreateDesignModal);
    closeBtn.addEventListener('click', closeCreateDesignModal);

    document.querySelectorAll('.create-nav-item[data-scroll-to]').forEach((btn) => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.create-nav-item').forEach((b) => b.classList.remove('is-active'));
            btn.classList.add('is-active');
            const id = btn.getAttribute('data-scroll-to');
            const el = id && document.getElementById(id);
            if (el && main) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    });

    function applyCreateTile(tile) {
        const action = tile.getAttribute('data-create-action');
        closeCreateDesignModal();
        if (action === 'new-document') {
            if (window.openNewDocumentModal) window.openNewDocumentModal();
            else openBlankDesign(1920, 1080, 'white', '#ffffff');
            return;
        }
        if (action === 'upload') {
            if (imageInput) imageInput.click();
            return;
        }
        if (action === 'preset') {
            const v = tile.getAttribute('data-create-preset');
            if (!v) return;
            if (workspace.classList.contains('hidden')) {
                pendingCreatePreset = v;
                openBlankDesign(1920, 1080, 'white', '#ffffff');
                return;
            }
            openSectionPanel('slicing');
            const pb = document.querySelector(`#presetWrap .preset-btn[data-value="${v}"]`);
            if (pb) pb.click();
            try { workspace.scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (e) {}
            return;
        }
        if (action === 'quick') {
            const q = tile.getAttribute('data-create-quick');
            if (!q) return;
            if (q === 'settings') {
                if (workspace.classList.contains('hidden')) {
                    pendingCreateQuick = 'settings';
                    openBlankDesign(1920, 1080, 'white', '#ffffff');
                } else {
                    openSectionPanel('settings');
                    try { workspace.scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (e) {}
                }
                return;
            }
            if (workspace.classList.contains('hidden')) {
                pendingCreateQuick = q;
                openBlankDesign(1920, 1080, 'white', '#ffffff');
                return;
            }
            if (window.runQuickAction) window.runQuickAction(q);
            try { workspace.scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (e) {}
        }
    }

    const createModalMain = document.getElementById('createModalMain');
    if (createModalMain) {
        createModalMain.addEventListener('click', (e) => {
            const tile = e.target.closest('.create-tile[data-create-action]');
            if (!tile || tile.offsetParent === null) return;
            applyCreateTile(tile);
        });
    }

    if (search) {
        search.addEventListener('input', () => filterCreateModal(search.value));
    }
})();
(function initNewDocumentModal() {
    const modal = document.getElementById('newDocumentModal');
    const backdrop = document.getElementById('newDocumentModalBackdrop');
    const closeBtn = document.getElementById('newDocumentModalCloseBtn');
    const cancelBtn = document.getElementById('newDocumentCancelBtn');
    const createBtn = document.getElementById('newDocumentCreateBtn');
    const openBtn = document.getElementById('openNewDocumentModalBtn');
    if (!modal || !backdrop || !closeBtn || !createBtn) return;

    backdrop.addEventListener('click', closeNewDocumentModal);
    closeBtn.addEventListener('click', closeNewDocumentModal);
    if (cancelBtn) cancelBtn.addEventListener('click', closeNewDocumentModal);
    createBtn.addEventListener('click', createNewBlankDocumentFromModal);

    document.querySelectorAll('input[name="newDocContents"]').forEach((r) => {
        r.addEventListener('change', syncNewDocColorRowVisibility);
    });

    if (openBtn) openBtn.addEventListener('click', openNewDocumentModal);

    const ndW = document.getElementById('newDocWidth');
    const ndH = document.getElementById('newDocHeight');
    const ndThumbCW = document.getElementById('newDocThumbCustomW');
    const ndThumbCH = document.getElementById('newDocThumbCustomH');
    const ndThumbApply = document.getElementById('newDocThumbCustomApplyBtn');

    modal.addEventListener('click', (e) => {
        const preset = e.target.closest('.thumb-preset-btn[data-thumb-w][data-new-doc-thumb]');
        if (!preset || !modal.contains(preset)) return;
        const tw = preset.getAttribute('data-thumb-w');
        const th = preset.getAttribute('data-thumb-h');
        if (tw && th && ndW && ndH) {
            ndW.value = tw;
            ndH.value = th;
        }
    });

    if (ndThumbApply && ndW && ndH && ndThumbCW && ndThumbCH) {
        ndThumbApply.addEventListener('click', () => {
            const tw = Math.max(1, Math.min(8192, Math.round(Number(ndThumbCW.value))));
            const th = Math.max(1, Math.min(8192, Math.round(Number(ndThumbCH.value))));
            if (!Number.isFinite(tw) || !Number.isFinite(th)) {
                alert('Enter valid width and height (1–8192 px).');
                return;
            }
            ndW.value = String(tw);
            ndH.value = String(th);
        });
    }
})();
setToolMode('slice');
setZoom(100);
syncDownloadAllUiState();
renderLayerList();
</script>
</body>
</html>
