<?php
require_once 'config.php';

$message = '';
$error = '';

if ($_POST['action'] ?? '' === 'setup_tables') {
    try {
        // Read the SQL file
        $sql = file_get_contents('setup_tables.sql');
        
        // Extract game content tables section
        $gameTablesStart = strpos($sql, '-- Game Content Tables');
        $gameTablesEnd = strpos($sql, '-- Badges & Rewards System Tables', $gameTablesStart);
        
        if ($gameTablesStart !== false && $gameTablesEnd !== false) {
            $gameTablesSQL = substr($sql, $gameTablesStart, $gameTablesEnd - $gameTablesStart);
            
            // Split by semicolon and execute each statement
            $statements = array_filter(array_map('trim', explode(';', $gameTablesSQL)));
            
            $successCount = 0;
            foreach ($statements as $statement) {
                if (!empty($statement) && !preg_match('/^--/', $statement)) {
                    try {
                        $pdo->exec($statement);
                        $successCount++;
                    } catch (PDOException $e) {
                        $error .= "Error: " . $e->getMessage() . "<br>";
                    }
                }
            }
            
            if ($successCount > 0) {
                $message = "Successfully executed $successCount SQL statements. Game content tables are now ready!";
            }
        } else {
            $error = "Could not find game content tables in setup_tables.sql";
        }
        
    } catch (Exception $e) {
        $error = "Error: " . $e->getMessage();
    }
}

if ($_POST['action'] ?? '' === 'setup_badges') {
    try {
        // Read the SQL file
        $sql = file_get_contents('setup_tables.sql');
        
        // Extract badges system tables section
        $badgesStart = strpos($sql, '-- Badges & Rewards System Tables');
        
        if ($badgesStart !== false) {
            $badgesSQL = substr($sql, $badgesStart);
            
            // Split by semicolon and execute each statement
            $statements = array_filter(array_map('trim', explode(';', $badgesSQL)));
            
            $successCount = 0;
            foreach ($statements as $statement) {
                if (!empty($statement) && !preg_match('/^--/', $statement)) {
                    try {
                        $pdo->exec($statement);
                        $successCount++;
                    } catch (PDOException $e) {
                        $error .= "Error: " . $e->getMessage() . "<br>";
                    }
                }
            }
            
            if ($successCount > 0) {
                $message = "Successfully executed $successCount SQL statements. Badges system is now ready!";
            }
        } else {
            $error = "Could not find badges system tables in setup_tables.sql";
        }
        
    } catch (Exception $e) {
        $error = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Setup - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        .setup-container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .setup-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .setup-section {
            margin-bottom: 2rem;
            padding: 1.5rem;
            border: 2px solid #e1e5e9;
            border-radius: 10px;
        }
        
        .setup-section h3 {
            color: var(--primary-color);
            margin-bottom: 1rem;
        }
        
        .btn-setup {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            width: 100%;
        }
        
        .btn-setup:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
        
        .message {
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1rem;
        }
        
        .message-success {
            background: rgba(40, 167, 69, 0.1);
            color: #28a745;
            border: 1px solid rgba(40, 167, 69, 0.2);
        }
        
        .message-error {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
            border: 1px solid rgba(220, 53, 69, 0.2);
        }
    </style>
</head>
<body>
    <div class="animated-bg"></div>
    
    <div class="setup-container">
        <div class="setup-header">
            <h1><i class="fas fa-database"></i> Database Setup</h1>
            <p>Set up the required database tables for the learning platform</p>
        </div>

        <?php if ($message): ?>
            <div class="message message-success"><?php echo $message; ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="message message-error"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="setup-section">
            <h3><i class="fas fa-gamepad"></i> Game Content Tables</h3>
            <p>Create tables for managing quiz questions, memory pairs, word puzzles, and math problems.</p>
            <form method="POST">
                <input type="hidden" name="action" value="setup_tables">
                <button type="submit" class="btn-setup">
                    <i class="fas fa-play"></i> Setup Game Content Tables
                </button>
            </form>
        </div>

        <div class="setup-section">
            <h3><i class="fas fa-trophy"></i> Badges & Rewards System</h3>
            <p>Create tables for the badges, rewards, and user progress tracking system.</p>
            <form method="POST">
                <input type="hidden" name="action" value="setup_badges">
                <button type="submit" class="btn-setup">
                    <i class="fas fa-play"></i> Setup Badges System
                </button>
            </form>
        </div>

        <div class="setup-section">
            <h3><i class="fas fa-check-circle"></i> Complete Setup</h3>
            <p>Run both setups to have a fully functional learning platform.</p>
            <div style="display: flex; gap: 1rem;">
                <a href="index.php" class="btn-setup" style="text-decoration: none; text-align: center;">
                    <i class="fas fa-home"></i> Go to Home
                </a>
                <a href="admin.php" class="btn-setup" style="text-decoration: none; text-align: center; background: linear-gradient(135deg, #28a745 0%, #20c997 100%);">
                    <i class="fas fa-cogs"></i> Admin Panel
                </a>
            </div>
        </div>
    </div>
</body>
</html>