<?php
require_once 'config.php';

$game_type = $_GET['type'] ?? '';
$game_id = intval($_GET['id'] ?? 1);

// Validate game type
if ($game_type !== 'math_challenge') {
    header('Location: game.php?type=math_challenge');
    exit;
}

$game_data = null;
$game_title = "Math Challenge";

try {
    // Get math problems for the game
    $math_problems = $pdo->query("SELECT * FROM math_problems ORDER BY RAND() LIMIT 20")->fetchAll();
    
    if (!empty($math_problems)) {
        $game_data = [
            'id' => $game_id,
            'title' => 'Math Challenge',
            'description' => 'Solve mathematical problems and equations',
            'problems' => array_slice($math_problems, 0, 15),
            'time_limit' => 300, // 5 minutes
            'points_per_problem' => 10
        ];
    }
} catch (PDOException $e) {
    // Handle error
}

if (!$game_data) {
    header('Location: game.php?type=math_challenge');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $game_data['title']; ?> - Apna School</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .math-container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
        }
        
        .math-header {
            text-align: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid rgba(102, 126, 234, 0.1);
        }
        
        .math-title {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .math-timer {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            display: inline-block;
            font-weight: 600;
            margin-bottom: 1rem;
        }
        
        .math-progress {
            background: rgba(102, 126, 234, 0.1);
            height: 8px;
            border-radius: 50px;
            overflow: hidden;
            margin-bottom: 2rem;
        }
        
        .math-progress-fill {
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50px;
            transition: width 0.3s ease;
        }
        
        .math-problem {
            background: rgba(102, 126, 234, 0.05);
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            text-align: center;
        }
        
        .problem-text {
            font-family: 'Courier New', monospace;
            font-size: 2rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 1.5rem;
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            border: 2px solid #e1e5e9;
        }
        
        .math-input {
            width: 100%;
            max-width: 300px;
            padding: 1rem;
            font-size: 1.5rem;
            border: 2px solid #e1e5e9;
            border-radius: 10px;
            text-align: center;
            font-weight: 600;
            margin-bottom: 1rem;
            transition: all 0.3s ease;
        }
        
        .math-input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .math-input.correct {
            border-color: #28a745;
            background: rgba(40, 167, 69, 0.1);
        }
        
        .math-input.incorrect {
            border-color: #dc3545;
            background: rgba(220, 53, 69, 0.1);
        }
        
        .math-navigation {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 2rem;
            padding-top: 1rem;
            border-top: 2px solid rgba(102, 126, 234, 0.1);
        }
        
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 50px;
            font-weight: 600;
            text-decoration: none;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.6);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(40, 167, 69, 0.4);
        }
        
        .btn-success:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(40, 167, 69, 0.6);
        }
        
        .btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none !important;
        }
        
        .math-stats {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding: 1rem;
            background: rgba(102, 126, 234, 0.05);
            border-radius: 15px;
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-number {
            font-size: 1.5rem;
            font-weight: 700;
            color: #667eea;
        }
        
        .stat-label {
            color: #666;
            font-size: 0.9rem;
        }
        
        .back-link {
            position: fixed;
            top: 20px;
            left: 20px;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            padding: 10px 20px;
            border-radius: 25px;
            text-decoration: none;
            color: #333;
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            z-index: 1000;
        }
        
        .back-link:hover {
            background: white;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            color: #333;
            text-decoration: none;
        }
        
        .math-results {
            text-align: center;
            padding: 2rem;
            background: rgba(102, 126, 234, 0.05);
            border-radius: 15px;
            margin-top: 2rem;
        }
        
        .score-display {
            font-size: 3rem;
            font-weight: 700;
            color: #667eea;
            margin-bottom: 1rem;
        }
        
        .feedback {
            margin-top: 1rem;
            padding: 1rem;
            border-radius: 10px;
            font-weight: 600;
        }
        
        .feedback.correct {
            background: rgba(40, 167, 69, 0.1);
            color: #28a745;
            border: 1px solid #28a745;
        }
        
        .feedback.incorrect {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
            border: 1px solid #dc3545;
        }
    </style>
</head>
<body>
    <a href="game.php?type=math_challenge" class="back-link">
        <i class="fas fa-arrow-left"></i> Back to Games
    </a>

    <div class="math-container">
        <div class="math-header">
            <h1 class="math-title">
                <i class="fas fa-calculator"></i>
                <?php echo $game_data['title']; ?>
            </h1>
            <div class="math-timer" id="timer">
                <i class="fas fa-clock"></i>
                <span id="time-display">5:00</span>
            </div>
            <div class="math-progress">
                <div class="math-progress-fill" id="progress-bar" style="width: 0%"></div>
            </div>
        </div>

        <div class="math-stats">
            <div class="stat-item">
                <div class="stat-number" id="correct">0</div>
                <div class="stat-label">Correct</div>
            </div>
            <div class="stat-item">
                <div class="stat-number" id="current-problem">1</div>
                <div class="stat-label">Problem</div>
            </div>
            <div class="stat-item">
                <div class="stat-number" id="total-problems"><?php echo count($game_data['problems']); ?></div>
                <div class="stat-label">Total</div>
            </div>
        </div>

        <div id="math-problem" class="math-problem">
            <!-- Math problem will be loaded here -->
        </div>

        <div class="math-navigation">
            <button class="btn btn-primary" id="prev-btn" onclick="previousProblem()" disabled>
                <i class="fas fa-arrow-left"></i> Previous
            </button>
            <span id="problem-counter">Problem 1 of <?php echo count($game_data['problems']); ?></span>
            <button class="btn btn-success" id="next-btn" onclick="nextProblem()" disabled>
                Next <i class="fas fa-arrow-right"></i>
            </button>
        </div>

        <div id="math-results" class="math-results" style="display: none;">
            <!-- Results will be shown here -->
        </div>
    </div>

    <script>
        // Game data
        const gameData = <?php echo json_encode($game_data); ?>;
        let currentProblem = 0;
        let userAnswers = [];
        let correctAnswers = 0;
        let timeLeft = <?php echo $game_data['time_limit']; ?>;
        let timerInterval;
        let gameCompleted = false;

        // Initialize game
        function initGame() {
            displayProblem();
            startTimer();
            updateProgress();
        }

        // Display current problem
        function displayProblem() {
            const problem = gameData.problems[currentProblem];
            const problemDiv = document.getElementById('math-problem');
            
            problemDiv.innerHTML = `
                <div class="problem-text">${problem.problem}</div>
                <input type="number" class="math-input" id="math-input" placeholder="Enter your answer" step="0.01" onkeypress="handleKeyPress(event)">
                <div id="feedback"></div>
            `;

            // Restore previous answer if exists
            if (userAnswers[currentProblem] !== undefined) {
                document.getElementById('math-input').value = userAnswers[currentProblem];
            }

            // Focus on input
            document.getElementById('math-input').focus();
            updateNavigation();
        }

        // Handle key press
        function handleKeyPress(event) {
            if (event.key === 'Enter') {
                checkAnswer();
            }
        }

        // Check answer
        function checkAnswer() {
            const input = document.getElementById('math-input');
            const userAnswer = parseFloat(input.value);
            const correctAnswer = parseFloat(gameData.problems[currentProblem].answer);
            const feedback = document.getElementById('feedback');
            
            if (isNaN(userAnswer)) return;
            
            // Store answer
            userAnswers[currentProblem] = userAnswer;
            
            if (Math.abs(userAnswer - correctAnswer) < 0.01) { // Allow small floating point differences
                input.classList.add('correct');
                feedback.innerHTML = '<div class="feedback correct"><i class="fas fa-check"></i> Correct!</div>';
                if (!userAnswers[currentProblem + 1]) { // Only count if not already answered
                    correctAnswers++;
                }
            } else {
                input.classList.add('incorrect');
                feedback.innerHTML = `<div class="feedback incorrect"><i class="fas fa-times"></i> Incorrect. The answer is: ${correctAnswer}</div>`;
            }
            
            // Enable next button
            document.getElementById('next-btn').disabled = false;
            updateStats();
        }

        // Next problem
        function nextProblem() {
            if (currentProblem < gameData.problems.length - 1) {
                currentProblem++;
                displayProblem();
                updateProgress();
            } else {
                finishGame();
            }
        }

        // Previous problem
        function previousProblem() {
            if (currentProblem > 0) {
                currentProblem--;
                displayProblem();
                updateProgress();
            }
        }

        // Update navigation
        function updateNavigation() {
            document.getElementById('prev-btn').disabled = currentProblem === 0;
            document.getElementById('problem-counter').textContent = 
                `Problem ${currentProblem + 1} of ${gameData.problems.length}`;
            
            // Enable next button if user has answered this problem
            const hasAnswered = userAnswers[currentProblem] !== undefined;
            document.getElementById('next-btn').disabled = !hasAnswered;
            
            if (currentProblem === gameData.problems.length - 1) {
                document.getElementById('next-btn').innerHTML = 
                    '<i class="fas fa-check"></i> Finish Game';
            } else {
                document.getElementById('next-btn').innerHTML = 
                    'Next <i class="fas fa-arrow-right"></i>';
            }
        }

        // Update statistics
        function updateStats() {
            document.getElementById('correct').textContent = correctAnswers;
            document.getElementById('current-problem').textContent = currentProblem + 1;
        }

        // Update progress
        function updateProgress() {
            const progress = ((currentProblem + 1) / gameData.problems.length) * 100;
            document.getElementById('progress-bar').style.width = progress + '%';
        }

        // Start timer
        function startTimer() {
            timerInterval = setInterval(() => {
                timeLeft--;
                updateTimerDisplay();
                
                if (timeLeft <= 0) {
                    finishGame();
                }
            }, 1000);
        }

        // Update timer display
        function updateTimerDisplay() {
            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;
            document.getElementById('time-display').textContent = 
                `${minutes}:${seconds.toString().padStart(2, '0')}`;
        }

        // Finish game
        function finishGame() {
            gameCompleted = true;
            clearInterval(timerInterval);
            
            const score = Math.round((correctAnswers / gameData.problems.length) * 100);
            const timeUsed = <?php echo $game_data['time_limit']; ?> - timeLeft;
            
            document.getElementById('math-problem').style.display = 'none';
            document.getElementById('math-navigation').style.display = 'none';
            document.getElementById('math-results').style.display = 'block';
            document.getElementById('math-results').innerHTML = `
                <div class="score-display">${score}%</div>
                <h3>Game Completed!</h3>
                <p>You solved ${correctAnswers} out of ${gameData.problems.length} problems correctly.</p>
                <p>Time used: ${Math.floor(timeUsed / 60)}:${(timeUsed % 60).toString().padStart(2, '0')}</p>
                <div style="margin-top: 2rem;">
                    <a href="game.php?type=math_challenge" class="btn btn-primary">
                        <i class="fas fa-redo"></i> Try Again
                    </a>
                    <a href="front_page.php" class="btn btn-success">
                        <i class="fas fa-home"></i> Back to Home
                    </a>
                </div>
            `;
        }

        // Initialize game when page loads
        document.addEventListener('DOMContentLoaded', initGame);
    </script>
</body>
</html>
