-- Animated Teaching Platform Database
CREATE DATABASE IF NOT EXISTS animated_teaching;
USE animated_teaching;

-- Users table
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE,
    email VARCHAR(100) UNIQUE,
    roll_number VARCHAR(20) UNIQUE,
    password VARCHAR(255),
    full_name VARCHAR(100) NOT NULL,
    avatar VARCHAR(255) DEFAULT 'default_avatar.png',
    user_role ENUM('student', 'user', 'admin') DEFAULT 'student',
    total_points INT DEFAULT 0,
    level INT DEFAULT 1,
    is_active BOOLEAN DEFAULT TRUE,
    email_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL
);

-- Courses table
CREATE TABLE courses (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    instructor_id INT,
    difficulty_level ENUM('beginner', 'intermediate', 'advanced') DEFAULT 'beginner',
    total_lessons INT DEFAULT 0,
    course_image VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (instructor_id) REFERENCES users(id)
);

-- Lessons table
CREATE TABLE lessons (
    id INT PRIMARY KEY AUTO_INCREMENT,
    course_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    content TEXT,
    lesson_type ENUM('video', 'text', 'interactive', 'quiz') DEFAULT 'text',
    order_index INT NOT NULL,
    points_reward INT DEFAULT 10,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

-- Quizzes table
CREATE TABLE quizzes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    lesson_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    time_limit INT DEFAULT 300, -- in seconds
    total_questions INT DEFAULT 0,
    points_reward INT DEFAULT 50,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE
);

-- Quiz questions table
CREATE TABLE quiz_questions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    quiz_id INT NOT NULL,
    question_text TEXT NOT NULL,
    question_type ENUM('multiple_choice', 'true_false', 'fill_blank') DEFAULT 'multiple_choice',
    points INT DEFAULT 10,
    order_index INT NOT NULL,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
);

-- Quiz answers table
CREATE TABLE quiz_answers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    question_id INT NOT NULL,
    answer_text TEXT NOT NULL,
    is_correct BOOLEAN DEFAULT FALSE,
    order_index INT NOT NULL,
    FOREIGN KEY (question_id) REFERENCES quiz_questions(id) ON DELETE CASCADE
);

-- User quiz attempts
CREATE TABLE user_quiz_attempts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    quiz_id INT NOT NULL,
    score INT DEFAULT 0,
    total_questions INT DEFAULT 0,
    time_taken INT DEFAULT 0, -- in seconds
    completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id)
);

-- Badges table
CREATE TABLE badges (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(255) NOT NULL,
    points_required INT DEFAULT 0,
    category ENUM('achievement', 'milestone', 'special') DEFAULT 'achievement',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User badges
CREATE TABLE user_badges (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    badge_id INT NOT NULL,
    earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (badge_id) REFERENCES badges(id),
    UNIQUE KEY unique_user_badge (user_id, badge_id)
);

-- User progress
CREATE TABLE user_progress (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    lesson_id INT NOT NULL,
    completed BOOLEAN DEFAULT FALSE,
    points_earned INT DEFAULT 0,
    completed_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (lesson_id) REFERENCES lessons(id),
    UNIQUE KEY unique_user_lesson (user_id, lesson_id)
);

-- Leaderboard view
CREATE VIEW leaderboard AS
SELECT 
    u.id,
    u.username,
    u.full_name,
    u.avatar,
    u.total_points,
    u.level,
    COUNT(ub.badge_id) as badge_count,
    ROW_NUMBER() OVER (ORDER BY u.total_points DESC) as rank
FROM users u
LEFT JOIN user_badges ub ON u.id = ub.user_id
GROUP BY u.id, u.username, u.full_name, u.avatar, u.total_points, u.level
ORDER BY u.total_points DESC;

-- Game Leaderboard view (shows top players for each game type)
CREATE VIEW game_leaderboard AS
SELECT 
    u.id,
    u.username,
    u.full_name,
    u.avatar,
    ugp.game_type,
    ugp.game_id,
    ugp.total_points as game_points,
    ugp.current_level as game_level,
    ugp.games_played,
    ugp.games_won,
    ugp.best_score,
    ROW_NUMBER() OVER (PARTITION BY ugp.game_type ORDER BY ugp.total_points DESC) as game_rank
FROM users u
JOIN user_game_progress ugp ON u.id = ugp.user_id
ORDER BY ugp.game_type, ugp.total_points DESC;

-- User Game Statistics view
CREATE VIEW user_game_stats AS
SELECT 
    u.id,
    u.username,
    u.full_name,
    u.total_points,
    u.level,
    COUNT(DISTINCT ugp.game_type) as games_played_types,
    SUM(ugp.games_played) as total_games_played,
    SUM(ugp.games_won) as total_games_won,
    SUM(ugp.total_points) as total_game_points,
    ROUND(AVG(ugp.games_won / NULLIF(ugp.games_played, 0)) * 100, 2) as win_percentage
FROM users u
LEFT JOIN user_game_progress ugp ON u.id = ugp.user_id
GROUP BY u.id, u.username, u.full_name, u.total_points, u.level;

-- Insert sample badges
INSERT INTO badges (name, description, icon, points_required, category) VALUES
('First Steps', 'Complete your first lesson', '<i class="fas fa-bullseye"></i>', 10, 'milestone'),
('Quiz Master', 'Score 100% on any quiz', '<i class="fas fa-brain"></i>', 50, 'achievement'),
('Speed Demon', 'Complete a quiz in under 2 minutes', '<i class="fas fa-bolt"></i>', 75, 'achievement'),
('Perfect Score', 'Get 10 perfect quiz scores in a row', '<i class="fas fa-percentage"></i>', 200, 'achievement'),
('Knowledge Seeker', 'Complete 50 lessons', '<i class="fas fa-book"></i>', 500, 'milestone'),
('Quiz Champion', 'Complete 20 quizzes', '<i class="fas fa-trophy"></i>', 300, 'achievement'),
('Early Bird', 'Complete a lesson before 8 AM', '<i class="fas fa-sun"></i>', 25, 'special'),
('Night Owl', 'Complete a lesson after 10 PM', '<i class="fas fa-moon"></i>', 25, 'special'),
('Streak Master', 'Study for 7 days in a row', '<i class="fas fa-fire"></i>', 150, 'achievement'),
('Point Collector', 'Earn 1000 total points', '<i class="fas fa-gem"></i>', 1000, 'milestone'),
-- Game-specific badges
('Interactive Quiz Novice', 'Complete your first interactive quiz', '<i class="fas fa-question-circle"></i>', 20, 'milestone'),
('Memory Master', 'Complete 10 memory challenges', '<i class="fas fa-brain"></i>', 100, 'achievement'),
('Word Wizard', 'Solve 25 word puzzles', '<i class="fas fa-spell-check"></i>', 200, 'achievement'),
('Math Genius', 'Complete 15 math challenges', '<i class="fas fa-calculator"></i>', 150, 'achievement'),
('Game Collector', 'Play all four game types', '<i class="fas fa-gamepad"></i>', 50, 'milestone'),
('Speed Solver', 'Complete any game in record time', '<i class="fas fa-stopwatch"></i>', 75, 'achievement'),
('Perfect Player', 'Get perfect scores in all game types', '<i class="fas fa-star"></i>', 500, 'achievement'),
('Level Up', 'Reach level 5 in any game', '<i class="fas fa-level-up-alt"></i>', 100, 'milestone');

-- Insert sample course
INSERT INTO courses (title, description, instructor_id, difficulty_level, course_image) VALUES
('Interactive PHP Programming', 'Learn PHP through animated tutorials and interactive exercises', 1, 'beginner', 'php_course.jpg'),
('Web Development Fundamentals', 'Master HTML, CSS, and JavaScript with gamified learning', 1, 'beginner', 'webdev_course.jpg'),
('Advanced PHP Techniques', 'Deep dive into advanced PHP concepts and best practices', 1, 'advanced', 'advanced_php.jpg');

-- Insert sample lessons
INSERT INTO lessons (course_id, title, content, lesson_type, order_index, points_reward) VALUES
(1, 'Introduction to PHP', 'Learn the basics of PHP programming language', 'interactive', 1, 20),
(1, 'Variables and Data Types', 'Understanding PHP variables and different data types', 'interactive', 2, 25),
(1, 'Control Structures', 'If statements, loops, and conditional logic', 'interactive', 3, 30),
(1, 'Functions in PHP', 'Creating and using functions in PHP', 'interactive', 4, 35),
(1, 'Arrays and Loops', 'Working with arrays and different types of loops', 'interactive', 5, 40);

-- Insert sample quiz
INSERT INTO quizzes (lesson_id, title, description, time_limit, total_questions, points_reward) VALUES
(1, 'PHP Basics Quiz', 'Test your knowledge of PHP fundamentals', 300, 5, 50),
(2, 'Variables Quiz', 'Quiz on PHP variables and data types', 240, 4, 40),
(3, 'Control Structures Quiz', 'Test your understanding of PHP control structures', 300, 6, 60);

-- Gamified Learning Games Tables

-- Interactive Quiz Games table
CREATE TABLE interactive_quiz_games (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    difficulty_level ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
    total_questions INT DEFAULT 10,
    time_limit INT DEFAULT 300, -- in seconds
    points_per_question INT DEFAULT 10,
    level_requirement INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Memory Challenge Games table
CREATE TABLE memory_challenge_games (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    difficulty_level ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
    total_pairs INT DEFAULT 8,
    time_limit INT DEFAULT 180, -- in seconds
    points_per_pair INT DEFAULT 5,
    level_requirement INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Word Puzzle Games table
CREATE TABLE word_puzzle_games (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    difficulty_level ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
    total_words INT DEFAULT 10,
    time_limit INT DEFAULT 240, -- in seconds
    points_per_word INT DEFAULT 8,
    level_requirement INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Math Challenge Games table
CREATE TABLE math_challenge_games (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    difficulty_level ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
    total_problems INT DEFAULT 15,
    time_limit INT DEFAULT 300, -- in seconds
    points_per_problem INT DEFAULT 7,
    level_requirement INT DEFAULT 1,
    math_type ENUM('addition', 'subtraction', 'multiplication', 'division', 'mixed') DEFAULT 'mixed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User Game Progress table (for all game types)
CREATE TABLE user_game_progress (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    game_type ENUM('interactive_quiz', 'memory_challenge', 'word_puzzle', 'math_challenge') NOT NULL,
    game_id INT NOT NULL,
    current_level INT DEFAULT 1,
    total_points INT DEFAULT 0,
    games_played INT DEFAULT 0,
    games_won INT DEFAULT 0,
    best_score INT DEFAULT 0,
    best_time INT DEFAULT 0, -- in seconds
    last_played TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    UNIQUE KEY unique_user_game (user_id, game_type, game_id)
);

-- User Game Attempts table (detailed attempt history)
CREATE TABLE user_game_attempts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    game_type ENUM('interactive_quiz', 'memory_challenge', 'word_puzzle', 'math_challenge') NOT NULL,
    game_id INT NOT NULL,
    score INT DEFAULT 0,
    time_taken INT DEFAULT 0, -- in seconds
    level_played INT DEFAULT 1,
    completed BOOLEAN DEFAULT FALSE,
    attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Game-specific data tables

-- Interactive Quiz Questions
CREATE TABLE interactive_quiz_questions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    game_id INT NOT NULL,
    question_text TEXT NOT NULL,
    question_type ENUM('multiple_choice', 'true_false', 'fill_blank') DEFAULT 'multiple_choice',
    points INT DEFAULT 10,
    order_index INT NOT NULL,
    FOREIGN KEY (game_id) REFERENCES interactive_quiz_games(id) ON DELETE CASCADE
);

-- Interactive Quiz Answers
CREATE TABLE interactive_quiz_answers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    question_id INT NOT NULL,
    answer_text TEXT NOT NULL,
    is_correct BOOLEAN DEFAULT FALSE,
    order_index INT NOT NULL,
    FOREIGN KEY (question_id) REFERENCES interactive_quiz_questions(id) ON DELETE CASCADE
);

-- Memory Challenge Pairs
CREATE TABLE memory_challenge_pairs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    game_id INT NOT NULL,
    card1_text VARCHAR(255) NOT NULL,
    card2_text VARCHAR(255) NOT NULL,
    card1_image VARCHAR(255),
    card2_image VARCHAR(255),
    points INT DEFAULT 5,
    order_index INT NOT NULL,
    FOREIGN KEY (game_id) REFERENCES memory_challenge_games(id) ON DELETE CASCADE
);

-- Word Puzzle Words
CREATE TABLE word_puzzle_words (
    id INT PRIMARY KEY AUTO_INCREMENT,
    game_id INT NOT NULL,
    word VARCHAR(100) NOT NULL,
    definition TEXT,
    hint TEXT,
    difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
    points INT DEFAULT 8,
    order_index INT NOT NULL,
    FOREIGN KEY (game_id) REFERENCES word_puzzle_games(id) ON DELETE CASCADE
);

-- Math Challenge Problems
CREATE TABLE math_challenge_problems (
    id INT PRIMARY KEY AUTO_INCREMENT,
    game_id INT NOT NULL,
    problem_text TEXT NOT NULL,
    correct_answer DECIMAL(10,2) NOT NULL,
    operation_type ENUM('addition', 'subtraction', 'multiplication', 'division') NOT NULL,
    difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
    points INT DEFAULT 7,
    order_index INT NOT NULL,
    FOREIGN KEY (game_id) REFERENCES math_challenge_games(id) ON DELETE CASCADE
);

-- Insert sample Interactive Quiz Games
INSERT INTO interactive_quiz_games (title, description, difficulty_level, total_questions, time_limit, points_per_question, level_requirement) VALUES
('General Knowledge Quiz', 'Test your general knowledge with fun questions', 'easy', 10, 300, 10, 1),
('Science Quiz', 'Explore the world of science through questions', 'medium', 15, 450, 15, 2),
('History Challenge', 'Dive deep into historical facts and events', 'hard', 20, 600, 20, 3);

-- Insert sample Memory Challenge Games
INSERT INTO memory_challenge_games (title, description, difficulty_level, total_pairs, time_limit, points_per_pair, level_requirement) VALUES
('Animal Pairs', 'Match animals with their names', 'easy', 8, 180, 5, 1),
('Country Capitals', 'Match countries with their capitals', 'medium', 12, 240, 8, 2),
('Famous Quotes', 'Match quotes with their authors', 'hard', 16, 300, 12, 3);

-- Insert sample Word Puzzle Games
INSERT INTO word_puzzle_games (title, description, difficulty_level, total_words, time_limit, points_per_word, level_requirement) VALUES
('Basic Vocabulary', 'Solve word puzzles with common words', 'easy', 10, 240, 8, 1),
('Advanced Vocabulary', 'Challenge yourself with complex words', 'medium', 15, 360, 12, 2),
('Technical Terms', 'Master technical and scientific terminology', 'hard', 20, 480, 16, 3);

-- Insert sample Math Challenge Games
INSERT INTO math_challenge_games (title, description, difficulty_level, total_problems, time_limit, points_per_problem, level_requirement, math_type) VALUES
('Basic Arithmetic', 'Practice addition and subtraction', 'easy', 15, 300, 7, 1, 'mixed'),
('Multiplication Master', 'Master multiplication tables', 'medium', 20, 400, 10, 2, 'multiplication'),
('Division Challenge', 'Solve complex division problems', 'hard', 25, 500, 15, 3, 'division');

-- Insert sample Interactive Quiz Questions
INSERT INTO interactive_quiz_questions (game_id, question_text, question_type, points, order_index) VALUES
(1, 'What is the capital of France?', 'multiple_choice', 10, 1),
(1, 'The sun is a star.', 'true_false', 10, 2),
(1, 'What is 2 + 2?', 'fill_blank', 10, 3);

-- Insert sample Interactive Quiz Answers
INSERT INTO interactive_quiz_answers (question_id, answer_text, is_correct, order_index) VALUES
(1, 'Paris', TRUE, 1),
(1, 'London', FALSE, 2),
(1, 'Berlin', FALSE, 3),
(1, 'Madrid', FALSE, 4),
(2, 'True', TRUE, 1),
(2, 'False', FALSE, 2),
(3, '4', TRUE, 1);

-- Insert sample Memory Challenge Pairs
INSERT INTO memory_challenge_pairs (game_id, card1_text, card2_text, points, order_index) VALUES
(1, 'Lion', 'King of the jungle', 5, 1),
(1, 'Eagle', 'Flies high in the sky', 5, 2),
(1, 'Dolphin', 'Intelligent sea mammal', 5, 3),
(1, 'Elephant', 'Largest land animal', 5, 4);

-- Insert sample Word Puzzle Words
INSERT INTO word_puzzle_words (game_id, word, definition, hint, points, order_index) VALUES
(1, 'BRILLIANT', 'Exceptionally clever or talented', 'Very smart', 8, 1),
(1, 'MYSTERIOUS', 'Difficult to understand or explain', 'Secretive', 8, 2),
(1, 'ADVENTURE', 'An exciting or unusual experience', 'Journey', 8, 3),
(1, 'KNOWLEDGE', 'Information and skills acquired through experience', 'Learning', 8, 4);

-- Insert sample Math Challenge Problems
INSERT INTO math_challenge_problems (game_id, problem_text, correct_answer, operation_type, points, order_index) VALUES
(1, 'What is 15 + 27?', 42.00, 'addition', 7, 1),
(1, 'What is 50 - 23?', 27.00, 'subtraction', 7, 2),
(1, 'What is 8 × 7?', 56.00, 'multiplication', 7, 3),
(1, 'What is 84 ÷ 12?', 7.00, 'division', 7, 4);

-- Insert sample users with different roles
INSERT INTO users (username, email, roll_number, password, full_name, user_role, total_points, level, is_active, email_verified) VALUES
('admin', 'admin@apnaschool.com', NULL, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'admin', 0, 1, TRUE, TRUE),
(NULL, NULL, 'STU001', NULL, 'John Student', 'student', 150, 2, TRUE, TRUE),
('sarah_user', 'sarah@user.com', NULL, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Sarah User', 'user', 200, 3, TRUE, TRUE),
(NULL, NULL, 'STU002', NULL, 'Mike Student', 'student', 75, 1, TRUE, TRUE);