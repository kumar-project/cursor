<?php
// Simple server test
header('Content-Type: application/json');

$response = [
    'status' => 'success',
    'message' => 'Server is working!',
    'timestamp' => date('Y-m-d H:i:s'),
    'php_version' => phpversion(),
    'server' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
    'method' => $_SERVER['REQUEST_METHOD'] ?? 'Unknown',
    'url' => $_SERVER['REQUEST_URI'] ?? 'Unknown'
];

echo json_encode($response, JSON_PRETTY_PRINT);
?>
