<?php
require_once 'config.php';

$game_type = $_GET['type'] ?? '';
$game_id = intval($_GET['id'] ?? 1);

// Validate game type
$valid_games = ['interactive_quiz', 'memory_challenge', 'word_puzzle', 'math_challenge'];
if (!in_array($game_type, $valid_games)) {
    $game_type = 'interactive_quiz';
}

$game_data = null;
$game_title = "Game";

// Get timer setting from admin settings
$timer_setting = 10; // Default 10 seconds
try {
    $stmt = $pdo->prepare("SELECT setting_value FROM game_settings WHERE setting_name = 'question_timer'");
    $stmt->execute();
    $result = $stmt->fetch();
    if ($result) {
        $timer_setting = (int)$result['setting_value'];
    }
} catch (Exception $e) {
    // Use default if setting not found
    $timer_setting = 10;
}

try {
    if ($game_type === 'interactive_quiz') {
        // Get all quiz questions and shuffle them
        $all_questions = $pdo->query("SELECT * FROM quiz_questions")->fetchAll();
        
        if (!empty($all_questions)) {
            // Shuffle the questions array to ensure no repetition
            shuffle($all_questions);
            
            // Take only the first 20 questions (or all if less than 20)
            $quiz_questions = array_slice($all_questions, 0, 20);
            
            $game_data = [
                'id' => $game_id,
                'title' => 'Interactive Quiz',
                'description' => 'Test your knowledge with a variety of questions',
                'questions' => $quiz_questions,
                'time_limit' => 300, // 5 minutes total
                'points_per_question' => 10,
                'question_timer' => $timer_setting
            ];
        }
    }
} catch (PDOException $e) {
    // Handle error
}

if (!$game_data) {
    header('Location: game.php?type=' . $game_type);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $game_data['title']; ?> - Apna School</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .quiz-container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
        }
        
        .quiz-header {
            text-align: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid rgba(102, 126, 234, 0.1);
        }
        
        .quiz-title {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        
        
        .quiz-timer {
            background: linear-gradient(135deg, #ffc107 0%, #ff9f43 100%);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            display: inline-block;
            font-weight: 600;
            margin-bottom: 1rem;
            float: right;
        }
        
        .quiz-timer.warning {
            background: linear-gradient(135deg, #ffc107 0%, #ff9f43 100%);
            animation: pulse 1s infinite;
        }
        
        .quiz-timer.danger {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            animation: pulse 0.5s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        .quiz-progress {
            background: rgba(102, 126, 234, 0.1);
            height: 8px;
            border-radius: 50px;
            overflow: hidden;
            margin-bottom: 2rem;
        }
        
        .quiz-progress-fill {
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50px;
            transition: width 0.3s ease;
        }
        
        .question-container {
            margin-bottom: 2rem;
        }
        
        .question-text {
            font-size: 1.3rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            color: #333;
            line-height: 1.6;
        }
        
        .answer-options {
            display: grid;
            gap: 1rem;
        }
        
        .answer-option {
            display: flex;
            align-items: center;
            padding: 1rem 1.5rem;
            background: white;
            border: 2px solid #e1e5e9;
            border-radius: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .answer-option:hover {
            border-color: #667eea;
            background: rgba(102, 126, 234, 0.05);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.15);
        }
        
        .answer-option.selected {
            border-color: #667eea;
            background: rgba(102, 126, 234, 0.1);
            color: #667eea;
            font-weight: 600;
        }
        
        .answer-option.correct {
            border-color: #28a745;
            background: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }
        
        .answer-option.incorrect {
            border-color: #dc3545;
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }

        .answer-option.disabled {
            opacity: 0.5;
            cursor: not-allowed;
            pointer-events: none;
            background: #f8f9fa;
            color: #6c757d;
            border-color: #dee2e6;
        }
        
        .option-letter {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            margin-right: 1rem;
            flex-shrink: 0;
        }
        
        .option-text {
            flex: 1;
            font-weight: 500;
        }
        
        .quiz-navigation {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 2rem;
            padding-top: 1rem;
            border-top: 2px solid rgba(102, 126, 234, 0.1);
        }
        
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 50px;
            font-weight: 600;
            text-decoration: none;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.6);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(40, 167, 69, 0.4);
        }
        
        .btn-success:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(40, 167, 69, 0.6);
        }
        
        .btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none !important;
        }
        
        .quiz-results {
            text-align: center;
            padding: 3rem 2rem;
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
            border-radius: 20px;
            margin-top: 2rem;
            border: 2px solid rgba(102, 126, 234, 0.2);
        }
        
        .results-header {
            margin-bottom: 2rem;
        }
        
        .results-header i {
            font-size: 3rem;
            color: #ffc107;
            margin-bottom: 1rem;
            display: block;
        }
        
        .results-header h2 {
            font-size: 2.5rem;
            font-weight: 700;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin: 0;
        }
        
        .score-display {
            margin: 2rem 0;
        }
        
        .score-circle {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
            position: relative;
            overflow: hidden;
        }
        
        .score-circle::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(45deg, transparent, rgba(255,255,255,0.1), transparent);
            animation: shine 3s infinite;
        }
        
        @keyframes shine {
            0% { transform: translateX(-100%) translateY(-100%) rotate(45deg); }
            50% { transform: translateX(100%) translateY(100%) rotate(45deg); }
            100% { transform: translateX(-100%) translateY(-100%) rotate(45deg); }
        }
        
        .score-number {
            font-size: 4rem;
            font-weight: 800;
            color: white;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
            z-index: 1;
            position: relative;
        }
        
        .score-display p {
            font-size: 1.2rem;
            color: #666;
            margin: 0;
            font-weight: 500;
        }
        
        .results-actions {
            margin-top: 2rem;
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .results-actions .btn {
            padding: 12px 24px;
            border-radius: 25px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }
        
        .results-actions .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .results-actions .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }
        
        .results-actions .btn-secondary {
            background: white;
            color: #667eea;
            border: 2px solid #667eea;
        }
        
        .results-actions .btn-secondary:hover {
            background: #667eea;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
        }
        
        .back-link {
            position: fixed;
            top: 20px;
            left: 20px;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            padding: 10px 20px;
            border-radius: 25px;
            text-decoration: none;
            color: #333;
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            z-index: 1000;
        }
        
        .back-link:hover {
            background: white;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            color: #333;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <a href="game.php?type=<?php echo $game_type; ?>" class="back-link">
        <i class="fas fa-arrow-left"></i> Back to Games
    </a>

    <div class="quiz-container">
        <div class="quiz-header">
            <h1 class="quiz-title">
                <i class="fas fa-question-circle"></i>
                <?php echo $game_data['title']; ?>
            </h1>
            <div class="quiz-timer" id="quiz-timer">
                <i class="fas fa-stopwatch"></i>
                <span id="timer-display">10</span>
            </div>
            <div class="quiz-progress">
                <div class="quiz-progress-fill" id="progress-bar" style="width: 0%"></div>
            </div>
        </div>

        <div id="quiz-content">
            <!-- Quiz content will be loaded here -->
        </div>

        <div class="quiz-navigation" id="quiz-navigation" style="display: none;">
            <button class="btn btn-primary" id="prev-btn" onclick="previousQuestion()" disabled>
                <i class="fas fa-arrow-left"></i> Previous
            </button>
            <span id="question-counter">Question 1 of <?php echo count($game_data['questions']); ?></span>
            <button class="btn btn-success" id="next-btn" onclick="nextQuestion()" disabled>
                Next <i class="fas fa-arrow-right"></i>
            </button>
        </div>
    </div>

    <script>
        // Quiz data
        const quizData = <?php echo json_encode($game_data); ?>;
        let currentQuestion = 0;
        let userAnswers = [];
        let quizCompleted = false;
        let questionTimeLeft = quizData.question_timer || 10;
        let questionTimerInterval;
        let answersDisabled = false;
        let usedQuestions = new Set(); // Track used questions to prevent repetition

        // Initialize quiz
        function initQuiz() {
            // Validate that we don't have duplicate questions
            validateUniqueQuestions();
            displayQuestion();
            startQuestionTimer();
            updateProgress();
        }

        // Validate that all questions are unique
        function validateUniqueQuestions() {
            const questionIds = new Set();
            const questionTexts = new Set();
            
            quizData.questions.forEach((question, index) => {
                // Check for duplicate IDs
                if (question.id && questionIds.has(question.id)) {
                    console.warn(`Duplicate question ID found: ${question.id}`);
                } else if (question.id) {
                    questionIds.add(question.id);
                }
                
                // Check for duplicate question text
                if (questionTexts.has(question.question)) {
                    console.warn(`Duplicate question text found at index ${index}: ${question.question}`);
                } else {
                    questionTexts.add(question.question);
                }
            });
            
            console.log(`Quiz loaded with ${quizData.questions.length} unique questions`);
        }

        // Display current question
        function displayQuestion() {
            const question = quizData.questions[currentQuestion];
            const content = document.getElementById('quiz-content');
            
            // Track this question as used to prevent repetition
            usedQuestions.add(question.id || currentQuestion);
            
            // Reset question timer and disabled state
            questionTimeLeft = quizData.question_timer || 10;
            answersDisabled = false;
            
            content.innerHTML = `
                <div class="question-container">
                    <div class="question-text">${question.question}</div>
                    <div class="answer-options">
                        <div class="answer-option" onclick="selectAnswer('A')" data-option="A">
                            <div class="option-letter">A</div>
                            <div class="option-text">${question.option_a}</div>
                        </div>
                        <div class="answer-option" onclick="selectAnswer('B')" data-option="B">
                            <div class="option-letter">B</div>
                            <div class="option-text">${question.option_b}</div>
                        </div>
                        <div class="answer-option" onclick="selectAnswer('C')" data-option="C">
                            <div class="option-letter">C</div>
                            <div class="option-text">${question.option_c}</div>
                        </div>
                        <div class="answer-option" onclick="selectAnswer('D')" data-option="D">
                            <div class="option-letter">D</div>
                            <div class="option-text">${question.option_d}</div>
                        </div>
                    </div>
                </div>
            `;

            // Restore previous answer if exists
            if (userAnswers[currentQuestion]) {
                selectAnswer(userAnswers[currentQuestion], true);
            }

            updateNavigation();
            startQuestionTimer();
        }

        // Select an answer
        function selectAnswer(option, restore = false) {
            if (quizCompleted || answersDisabled) return;

            // Clear previous selections
            document.querySelectorAll('.answer-option').forEach(el => {
                el.classList.remove('selected', 'correct', 'incorrect');
            });

            // Select current option
            const selectedOption = document.querySelector(`[data-option="${option}"]`);
            selectedOption.classList.add('selected');

            // Store answer
            userAnswers[currentQuestion] = option;

            // Stop question timer
            clearInterval(questionTimerInterval);

            // Show correct answer
            showCorrectAnswer();

            // Auto-advance after 2 seconds
            setTimeout(() => {
                if (currentQuestion < quizData.questions.length - 1) {
                    nextQuestion();
                } else {
                    finishQuiz();
                }
            }, 2000);
        }

        // Show correct answer
        function showCorrectAnswer() {
            const question = quizData.questions[currentQuestion];
            const correctOption = document.querySelector(`[data-option="${question.correct_answer}"]`);
            const selectedOption = document.querySelector(`[data-option="${userAnswers[currentQuestion]}"]`);
            
            // Mark correct answer
            correctOption.classList.add('correct');
            
            // Mark selected answer as incorrect if wrong
            if (userAnswers[currentQuestion] !== question.correct_answer) {
                selectedOption.classList.add('incorrect');
            }
        }


        // Next question
        function nextQuestion() {
            if (currentQuestion < quizData.questions.length - 1) {
                currentQuestion++;
                displayQuestion();
                updateProgress();
            } else {
                finishQuiz();
            }
        }

        // Previous question
        function previousQuestion() {
            if (currentQuestion > 0) {
                currentQuestion--;
                displayQuestion();
                updateProgress();
            }
        }

        // Update navigation buttons
        function updateNavigation() {
            document.getElementById('prev-btn').disabled = currentQuestion === 0;
            document.getElementById('question-counter').textContent = 
                `Question ${currentQuestion + 1} of ${quizData.questions.length}`;
            
            // Always enable next button since we auto-advance
            document.getElementById('next-btn').disabled = false;
            
            if (currentQuestion === quizData.questions.length - 1) {
                document.getElementById('next-btn').innerHTML = 
                    '<i class="fas fa-check"></i> Finish Quiz';
            } else {
                document.getElementById('next-btn').innerHTML = 
                    'Next <i class="fas fa-arrow-right"></i>';
            }
        }

        // Start question timer
        function startQuestionTimer() {
            clearInterval(questionTimerInterval);
            questionTimeLeft = quizData.question_timer || 10;
            updateTimerDisplay();
            
            questionTimerInterval = setInterval(() => {
                questionTimeLeft--;
                updateTimerDisplay();
                
                if (questionTimeLeft <= 0) {
                    clearInterval(questionTimerInterval);
                    // Disable all answer options
                    disableAnswers();
                    // Auto-advance to next question when time runs out
                    setTimeout(() => {
                        if (currentQuestion < quizData.questions.length - 1) {
                            nextQuestion();
                        } else {
                            finishQuiz();
                        }
                    }, 2000); // Wait 2 seconds to show disabled state
                }
            }, 1000);
        }

        // Update timer display
        function updateTimerDisplay() {
            const timerElement = document.getElementById('quiz-timer');
            const timeDisplay = document.getElementById('timer-display');
            
            timeDisplay.textContent = questionTimeLeft;
            
            // Add warning classes based on time left
            timerElement.classList.remove('warning', 'danger');
            if (questionTimeLeft <= 3) {
                timerElement.classList.add('danger');
            } else if (questionTimeLeft <= 5) {
                timerElement.classList.add('warning');
            }
        }

        // Disable all answer options
        function disableAnswers() {
            answersDisabled = true;
            document.querySelectorAll('.answer-option').forEach(option => {
                option.classList.add('disabled');
                // Remove onclick to prevent clicking
                option.onclick = null;
            });
        }

        // Update progress bar
        function updateProgress() {
            const progress = ((currentQuestion + 1) / quizData.questions.length) * 100;
            document.getElementById('progress-bar').style.width = progress + '%';
        }


        // Finish quiz
        function finishQuiz() {
            quizCompleted = true;
            clearInterval(questionTimerInterval);
            
            // Calculate score
            let correctAnswers = 0;
            quizData.questions.forEach((question, index) => {
                if (userAnswers[index] === question.correct_answer) {
                    correctAnswers++;
                }
            });

            const score = Math.round((correctAnswers / quizData.questions.length) * 100);
            
            // Display results
            document.getElementById('quiz-content').innerHTML = `
                <div class="quiz-results">
                    <div class="results-header">
                        <i class="fas fa-trophy"></i>
                        <h2>Quiz Completed!</h2>
                    </div>
                    <div class="score-display">
                        <div class="score-circle">
                            <span class="score-number">${score}%</span>
                        </div>
                        <p>You got ${correctAnswers} out of ${quizData.questions.length} questions correct!</p>
                    </div>
                    <div class="results-actions">
                        <button onclick="location.reload()" class="btn btn-primary">
                            <i class="fas fa-redo"></i> Try Again
                        </button>
                        <button onclick="window.location.href='game.php?type=<?php echo $game_type; ?>'" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Back to Games
                        </button>
                    </div>
                </div>
            `;
            
            document.getElementById('quiz-navigation').style.display = 'none';
        }

        // Initialize quiz when page loads
        document.addEventListener('DOMContentLoaded', initQuiz);
    </script>
</body>
</html>
