<?php
require_once 'config.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'fix_encoding') {
    try {
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $fixed_count = 0;
        $total_checked = 0;
        
        // Fix quiz questions
        $stmt = $pdo->query('SELECT id, question, option_a, option_b, option_c, option_d, category FROM quiz_questions');
        $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $total_checked += count($questions);
        
        foreach ($questions as $question) {
            $needs_fix = false;
            $fixed_data = [];
            
            $fields_to_check = ['question', 'option_a', 'option_b', 'option_c', 'option_d', 'category'];
            
            foreach ($fields_to_check as $field) {
                $value = $question[$field];
                
                // Check for encoding issues
                if (preg_match('/[^\x20-\x7E\xC0-\xFF]/u', $value) || strpos($value, '?') !== false) {
                    $fixed_value = mb_convert_encoding($value, 'UTF-8', 'auto');
                    
                    if (preg_match('/[^\x20-\x7E\xC0-\xFF]/u', $fixed_value)) {
                        $fixed_value = mb_convert_encoding($value, 'UTF-8', 'Windows-1252');
                    }
                    
                    if (preg_match('/[^\x20-\x7E\xC0-\xFF]/u', $fixed_value)) {
                        $fixed_value = mb_convert_encoding($value, 'UTF-8', 'ISO-8859-1');
                    }
                    
                    $fixed_data[$field] = $fixed_value;
                    $needs_fix = true;
                } else {
                    $fixed_data[$field] = $value;
                }
            }
            
            if ($needs_fix) {
                $update_stmt = $pdo->prepare("UPDATE quiz_questions SET question = ?, option_a = ?, option_b = ?, option_c = ?, option_d = ?, category = ? WHERE id = ?");
                $update_stmt->execute([
                    $fixed_data['question'],
                    $fixed_data['option_a'],
                    $fixed_data['option_b'],
                    $fixed_data['option_c'],
                    $fixed_data['option_d'],
                    $fixed_data['category'],
                    $question['id']
                ]);
                
                $fixed_count++;
            }
        }
        
        // Fix other tables
        $tables_to_fix = ['memory_pairs', 'word_puzzles', 'math_problems'];
        
        foreach ($tables_to_fix as $table) {
            $stmt = $pdo->query("SELECT * FROM $table");
            $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $total_checked += count($records);
            
            foreach ($records as $record) {
                $needs_fix = false;
                $fixed_data = [];
                
                foreach ($record as $field => $value) {
                    if (is_string($value) && (preg_match('/[^\x20-\x7E\xC0-\xFF]/u', $value) || strpos($value, '?') !== false)) {
                        $fixed_value = mb_convert_encoding($value, 'UTF-8', 'auto');
                        
                        if (preg_match('/[^\x20-\x7E\xC0-\xFF]/u', $fixed_value)) {
                            $fixed_value = mb_convert_encoding($value, 'UTF-8', 'Windows-1252');
                        }
                        
                        if (preg_match('/[^\x20-\x7E\xC0-\xFF]/u', $fixed_value)) {
                            $fixed_value = mb_convert_encoding($value, 'UTF-8', 'ISO-8859-1');
                        }
                        
                        $fixed_data[$field] = $fixed_value;
                        $needs_fix = true;
                    } else {
                        $fixed_data[$field] = $value;
                    }
                }
                
                if ($needs_fix) {
                    $fields = array_keys($fixed_data);
                    $placeholders = str_repeat('?,', count($fields) - 1) . '?';
                    $values = array_values($fixed_data);
                    
                    $update_sql = "UPDATE $table SET " . implode(' = ?, ', $fields) . " = ? WHERE id = ?";
                    $update_stmt = $pdo->prepare($update_sql);
                    $update_stmt->execute(array_merge($values, [$record['id']]));
                    
                    $fixed_count++;
                }
            }
        }
        
        $message = "Successfully fixed encoding issues in $fixed_count records out of $total_checked total records checked.";
        
    } catch (Exception $e) {
        $error = 'Error fixing encoding: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fix Encoding Issues - Apna School</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 30px;
        }
        
        .alert {
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            text-decoration: none;
            display: inline-block;
            margin: 10px 5px;
        }
        
        .btn:hover {
            opacity: 0.9;
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a52 100%);
        }
        
        .info-box {
            background-color: #e7f3ff;
            border: 1px solid #b3d9ff;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
        
        .warning-box {
            background-color: #fff3cd;
            border: 1px solid #ffeaa7;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔧 Fix Encoding Issues</h1>
        
        <?php if ($message): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <div class="info-box">
            <h3>What this tool does:</h3>
            <ul>
                <li>✅ Detects corrupted text with encoding issues</li>
                <li>✅ Converts text from various encodings to UTF-8</li>
                <li>✅ Fixes quiz questions, memory pairs, word puzzles, and math problems</li>
                <li>✅ Preserves all data while fixing display issues</li>
            </ul>
        </div>
        
        <div class="warning-box">
            <h3>⚠️ Important:</h3>
            <p>This will fix the corrupted text you're seeing in the admin panel. The process is safe and will not delete any data - it only fixes the character encoding.</p>
        </div>
        
        <form method="POST" style="text-align: center;">
            <input type="hidden" name="action" value="fix_encoding">
            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to fix the encoding issues? This will update the database.')">
                🔧 Fix Encoding Issues
            </button>
        </form>
        
        <div style="text-align: center; margin-top: 30px;">
            <a href="admin.php" class="btn">← Back to Admin Panel</a>
            <a href="index.php" class="btn">🏠 Go to Home</a>
        </div>
    </div>
</body>
</html>
