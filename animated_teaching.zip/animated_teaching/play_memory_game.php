<?php
require_once 'config.php';

$game_type = $_GET['type'] ?? '';
$game_id = intval($_GET['id'] ?? 1);

// Validate game type
if ($game_type !== 'memory_challenge') {
    header('Location: game.php?type=memory_challenge');
    exit;
}

$game_data = null;
$game_title = "Memory Challenge";

try {
    // Get memory pairs for the game
    $memory_pairs = $pdo->query("SELECT * FROM memory_pairs ORDER BY RAND() LIMIT 12")->fetchAll();
    
    if (!empty($memory_pairs)) {
        $game_data = [
            'id' => $game_id,
            'title' => 'Memory Challenge',
            'description' => 'Test your memory by matching pairs of items',
            'pairs' => array_slice($memory_pairs, 0, 8),
            'time_limit' => 120, // 2 minutes
            'points_per_pair' => 10
        ];
    }
} catch (PDOException $e) {
    // Handle error
}

if (!$game_data) {
    header('Location: game.php?type=memory_challenge');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $game_data['title']; ?> - Apna School</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .memory-container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
        }
        
        .memory-header {
            text-align: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid rgba(102, 126, 234, 0.1);
        }
        
        .memory-title {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .memory-timer {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            display: inline-block;
            font-weight: 600;
            margin-bottom: 1rem;
        }
        
        .memory-progress {
            background: rgba(102, 126, 234, 0.1);
            height: 8px;
            border-radius: 50px;
            overflow: hidden;
            margin-bottom: 2rem;
        }
        
        .memory-progress-fill {
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50px;
            transition: width 0.3s ease;
        }
        
        .memory-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        .memory-card {
            aspect-ratio: 1;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2rem;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .memory-card:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }
        
        .memory-card.flipped {
            background: white;
            color: #333;
            border: 2px solid #667eea;
        }
        
        .memory-card.matched {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            transform: scale(0.95);
        }
        
        .memory-card.wrong {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            color: white;
            animation: shake 0.5s ease-in-out;
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }
        
        .memory-stats {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding: 1rem;
            background: rgba(102, 126, 234, 0.05);
            border-radius: 15px;
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-number {
            font-size: 1.5rem;
            font-weight: 700;
            color: #667eea;
        }
        
        .stat-label {
            color: #666;
            font-size: 0.9rem;
        }
        
        .back-link {
            position: fixed;
            top: 20px;
            left: 20px;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            padding: 10px 20px;
            border-radius: 25px;
            text-decoration: none;
            color: #333;
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            z-index: 1000;
        }
        
        .back-link:hover {
            background: white;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            color: #333;
            text-decoration: none;
        }
        
        .memory-results {
            text-align: center;
            padding: 2rem;
            background: rgba(102, 126, 234, 0.05);
            border-radius: 15px;
            margin-top: 2rem;
        }
        
        .score-display {
            font-size: 3rem;
            font-weight: 700;
            color: #667eea;
            margin-bottom: 1rem;
        }
        
        @media (max-width: 768px) {
            .memory-grid {
                grid-template-columns: repeat(3, 1fr);
            }
            
            .memory-card {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <a href="game.php?type=memory_challenge" class="back-link">
        <i class="fas fa-arrow-left"></i> Back to Games
    </a>

    <div class="memory-container">
        <div class="memory-header">
            <h1 class="memory-title">
                <i class="fas fa-brain"></i>
                <?php echo $game_data['title']; ?>
            </h1>
            <div class="memory-timer" id="timer">
                <i class="fas fa-clock"></i>
                <span id="time-display">2:00</span>
            </div>
            <div class="memory-progress">
                <div class="memory-progress-fill" id="progress-bar" style="width: 0%"></div>
            </div>
        </div>

        <div class="memory-stats">
            <div class="stat-item">
                <div class="stat-number" id="matches">0</div>
                <div class="stat-label">Matches</div>
            </div>
            <div class="stat-item">
                <div class="stat-number" id="moves">0</div>
                <div class="stat-label">Moves</div>
            </div>
            <div class="stat-item">
                <div class="stat-number" id="pairs-left"><?php echo count($game_data['pairs']); ?></div>
                <div class="stat-label">Pairs Left</div>
            </div>
        </div>

        <div id="memory-grid" class="memory-grid">
            <!-- Memory cards will be loaded here -->
        </div>

        <div id="memory-results" class="memory-results" style="display: none;">
            <!-- Results will be shown here -->
        </div>
    </div>

    <script>
        // Game data
        const gameData = <?php echo json_encode($game_data); ?>;
        let timeLeft = <?php echo $game_data['time_limit']; ?>;
        let timerInterval;
        let gameCompleted = false;
        let flippedCards = [];
        let matchedPairs = 0;
        let totalMoves = 0;
        let cards = [];

        // Initialize game
        function initGame() {
            createCards();
            displayCards();
            startTimer();
            updateStats();
        }

        // Create cards from pairs
        function createCards() {
            cards = [];
            gameData.pairs.forEach((pair, index) => {
                // Create two cards for each pair
                cards.push({
                    id: index * 2,
                    content: pair.pair_value,
                    pairId: index,
                    matched: false
                });
                cards.push({
                    id: index * 2 + 1,
                    content: pair.pair_value,
                    pairId: index,
                    matched: false
                });
            });
            
            // Shuffle cards
            cards = cards.sort(() => Math.random() - 0.5);
        }

        // Display cards
        function displayCards() {
            const grid = document.getElementById('memory-grid');
            grid.innerHTML = '';
            
            cards.forEach(card => {
                const cardElement = document.createElement('div');
                cardElement.className = 'memory-card';
                cardElement.dataset.cardId = card.id;
                cardElement.dataset.pairId = card.pairId;
                cardElement.innerHTML = '<i class="fas fa-question"></i>';
                cardElement.onclick = () => flipCard(card.id);
                grid.appendChild(cardElement);
            });
        }

        // Flip card
        function flipCard(cardId) {
            if (gameCompleted || flippedCards.length >= 2) return;
            
            const card = cards.find(c => c.id === cardId);
            const cardElement = document.querySelector(`[data-card-id="${cardId}"]`);
            
            if (card.matched || flippedCards.includes(cardId)) return;
            
            // Flip card
            cardElement.classList.add('flipped');
            cardElement.innerHTML = card.content;
            flippedCards.push(cardId);
            
            if (flippedCards.length === 2) {
                totalMoves++;
                updateStats();
                
                setTimeout(() => {
                    checkMatch();
                }, 1000);
            }
        }

        // Check if flipped cards match
        function checkMatch() {
            const [card1Id, card2Id] = flippedCards;
            const card1 = cards.find(c => c.id === card1Id);
            const card2 = cards.find(c => c.id === card2Id);
            
            const card1Element = document.querySelector(`[data-card-id="${card1Id}"]`);
            const card2Element = document.querySelector(`[data-card-id="${card2Id}"]`);
            
            if (card1.pairId === card2.pairId) {
                // Match found
                card1.matched = true;
                card2.matched = true;
                card1Element.classList.add('matched');
                card2Element.classList.add('matched');
                matchedPairs++;
                
                if (matchedPairs === gameData.pairs.length) {
                    finishGame();
                }
            } else {
                // No match
                card1Element.classList.add('wrong');
                card2Element.classList.add('wrong');
                
                setTimeout(() => {
                    card1Element.classList.remove('flipped', 'wrong');
                    card2Element.classList.remove('flipped', 'wrong');
                    card1Element.innerHTML = '<i class="fas fa-question"></i>';
                    card2Element.innerHTML = '<i class="fas fa-question"></i>';
                }, 1000);
            }
            
            flippedCards = [];
            updateStats();
        }

        // Update statistics
        function updateStats() {
            document.getElementById('matches').textContent = matchedPairs;
            document.getElementById('moves').textContent = totalMoves;
            document.getElementById('pairs-left').textContent = gameData.pairs.length - matchedPairs;
            
            // Update progress
            const progress = (matchedPairs / gameData.pairs.length) * 100;
            document.getElementById('progress-bar').style.width = progress + '%';
        }

        // Start timer
        function startTimer() {
            timerInterval = setInterval(() => {
                timeLeft--;
                updateTimerDisplay();
                
                if (timeLeft <= 0) {
                    finishGame();
                }
            }, 1000);
        }

        // Update timer display
        function updateTimerDisplay() {
            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;
            document.getElementById('time-display').textContent = 
                `${minutes}:${seconds.toString().padStart(2, '0')}`;
        }

        // Finish game
        function finishGame() {
            gameCompleted = true;
            clearInterval(timerInterval);
            
            const score = Math.round((matchedPairs / gameData.pairs.length) * 100);
            const timeUsed = <?php echo $game_data['time_limit']; ?> - timeLeft;
            
            document.getElementById('memory-grid').style.display = 'none';
            document.getElementById('memory-results').style.display = 'block';
            document.getElementById('memory-results').innerHTML = `
                <div class="score-display">${score}%</div>
                <h3>Game Completed!</h3>
                <p>You matched ${matchedPairs} out of ${gameData.pairs.length} pairs in ${totalMoves} moves.</p>
                <p>Time used: ${Math.floor(timeUsed / 60)}:${(timeUsed % 60).toString().padStart(2, '0')}</p>
                <div style="margin-top: 2rem;">
                    <a href="game.php?type=memory_challenge" class="btn btn-primary" style="background: #667eea; color: white; padding: 12px 30px; border-radius: 50px; text-decoration: none; margin: 0 1rem;">
                        <i class="fas fa-redo"></i> Try Again
                    </a>
                    <a href="front_page.php" class="btn btn-success" style="background: #28a745; color: white; padding: 12px 30px; border-radius: 50px; text-decoration: none; margin: 0 1rem;">
                        <i class="fas fa-home"></i> Back to Home
                    </a>
                </div>
            `;
        }

        // Initialize game when page loads
        document.addEventListener('DOMContentLoaded', initGame);
    </script>
</body>
</html>
