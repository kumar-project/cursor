<?php
require_once 'config.php';

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$error = '';
$success = '';
$current_tab = $_GET['tab'] ?? 'courses';

// CRITICAL: Create missing tables FIRST before any other operations
try {
    // Force create custom_data_types table
    $pdo->exec("DROP TABLE IF EXISTS custom_data_types");
    $pdo->exec("CREATE TABLE custom_data_types (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(100) UNIQUE NOT NULL,
        display_name VARCHAR(200) NOT NULL,
        table_name VARCHAR(100) NOT NULL,
        description TEXT,
        fields JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");
    
    // Force create game_settings table
    $pdo->exec("DROP TABLE IF EXISTS game_settings");
    $pdo->exec("CREATE TABLE game_settings (
        id INT PRIMARY KEY AUTO_INCREMENT,
        setting_name VARCHAR(100) UNIQUE NOT NULL,
        setting_value VARCHAR(255) NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");
    
    // Insert default settings
    $default_settings = [
        ['quiz_timer', '10'],
        ['game_timer', '60'],
        ['auto_advance', '1'],
        ['show_timer', '1']
    ];
    
    foreach ($default_settings as $setting) {
        $stmt = $pdo->prepare("INSERT INTO game_settings (setting_name, setting_value) VALUES (?, ?)");
        $stmt->execute($setting);
    }
    
    // Log success
    error_log("Database tables created successfully");
    
} catch (PDOException $e) {
    // Log the error and show user-friendly message
    error_log("CRITICAL DATABASE ERROR: " . $e->getMessage());
    die("<h1>Database Setup Error</h1><p>Failed to create required database tables. Please check your database connection and permissions.</p><p>Error: " . htmlspecialchars($e->getMessage()) . "</p>");
}

// Get custom data types
$custom_data_types = [];
try {
    $stmt = $pdo->query("SELECT * FROM custom_data_types ORDER BY display_name");
    $custom_data_types = $stmt->fetchAll(PDO::FETCH_ASSOC);
    error_log("Loaded " . count($custom_data_types) . " custom data types from database");
} catch (PDOException $e) {
    // Table might not exist yet, that's okay
    error_log("Error loading custom data types: " . $e->getMessage());
}

// Helper function to import CSV/TXT files
function importCSVFile($file_path, $data_type, $pdo) {
    $imported_count = 0;
    
    // Try to detect file encoding and convert to UTF-8
    $content = file_get_contents($file_path);
    $encoding = mb_detect_encoding($content, ['UTF-8', 'ISO-8859-1', 'Windows-1252'], true);
    
    if ($encoding && $encoding !== 'UTF-8') {
        $content = mb_convert_encoding($content, 'UTF-8', $encoding);
        file_put_contents($file_path, $content);
    }
    
    $handle = fopen($file_path, 'r');
    
    if (!$handle) {
        throw new Exception('Could not open file for reading');
    }
    
    // Skip header row
    $header = fgetcsv($handle);
    
    while (($data = fgetcsv($handle)) !== FALSE) {
        try {
            switch ($data_type) {
                case 'quiz':
                    if (count($data) >= 8) {
                        $stmt = $pdo->prepare("INSERT INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_answer, category, difficulty, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$data[0], $data[1], $data[2], $data[3], $data[4], $data[5], $data[6], $data[7], $data[8] ?? 10]);
                        $imported_count++;
                    }
                    break;
                case 'memory':
                    if (count($data) >= 4) {
                        $stmt = $pdo->prepare("INSERT INTO memory_pairs (pair_value, display_text, category, difficulty) VALUES (?, ?, ?, ?)");
                        $stmt->execute([$data[0], $data[1], $data[2], $data[3]]);
                        $imported_count++;
                    }
                    break;
                case 'word':
                    if (count($data) >= 5) {
                        $stmt = $pdo->prepare("INSERT INTO word_puzzles (word, hint, category, difficulty, points) VALUES (?, ?, ?, ?, ?)");
                        $stmt->execute([$data[0], $data[1], $data[2], $data[3], $data[4]]);
                        $imported_count++;
                    }
                    break;
                case 'math':
                    if (count($data) >= 5) {
                        $stmt = $pdo->prepare("INSERT INTO math_problems (problem, answer, operation, difficulty, points) VALUES (?, ?, ?, ?, ?)");
                        $stmt->execute([$data[0], $data[1], $data[2], $data[3], $data[4]]);
                        $imported_count++;
                    }
                    break;
                default:
                    // Handle custom data types
                    if (strpos($data_type, 'custom_') === 0) {
                        $custom_type = str_replace('custom_', '', $data_type);
                        $stmt = $pdo->prepare("SELECT * FROM custom_data_types WHERE name = ?");
                        $stmt->execute([$custom_type]);
                        $custom_type_info = $stmt->fetch(PDO::FETCH_ASSOC);
                        
                        if ($custom_type_info) {
                            $fields = json_decode($custom_type_info['fields'], true);
                            $table_name = $custom_type_info['table_name'];
                            
                            if (count($data) >= count($fields)) {
                                $field_names = [];
                                $placeholders = [];
                                $values = [];
                                
                                foreach ($fields as $field) {
                                    $field_name = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $field['name']));
                                    $field_names[] = "`$field_name`";
                                    $placeholders[] = '?';
                                    $values[] = $data[array_search($field, $fields)];
                                }
                                
                                $sql = "INSERT INTO `$table_name` (" . implode(', ', $field_names) . ") VALUES (" . implode(', ', $placeholders) . ")";
                                $stmt = $pdo->prepare($sql);
                                $stmt->execute($values);
                                $imported_count++;
                            }
                        }
                    }
                    break;
            }
        } catch (PDOException $e) {
            // Skip invalid rows but continue processing
            continue;
        }
    }
    
    fclose($handle);
    return $imported_count;
}

// Helper function to import Excel files
function importExcelFile($file_path, $data_type, $pdo) {
    // Simple Excel import using CSV conversion
    $imported_count = 0;
    
    // Try to detect file encoding and convert to UTF-8
    $content = file_get_contents($file_path);
    $encoding = mb_detect_encoding($content, ['UTF-8', 'ISO-8859-1', 'Windows-1252'], true);
    
    if ($encoding && $encoding !== 'UTF-8') {
        $content = mb_convert_encoding($content, 'UTF-8', $encoding);
        file_put_contents($file_path, $content);
    }
    
    // Try to read the file as if it were CSV (works for simple Excel files)
    $handle = fopen($file_path, 'r');
    
    if (!$handle) {
        throw new Exception('Could not open Excel file.');
    }
    
    // Skip header row
    $header = fgetcsv($handle);
    
    while (($data = fgetcsv($handle)) !== FALSE) {
        try {
            switch ($data_type) {
                case 'quiz':
                    if (count($data) >= 8) {
                        $stmt = $pdo->prepare("INSERT INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_answer, category, difficulty, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$data[0], $data[1], $data[2], $data[3], $data[4], $data[5], $data[6], $data[7], $data[8] ?? 10]);
                        $imported_count++;
                    }
                    break;
                case 'memory':
                    if (count($data) >= 4) {
                        $stmt = $pdo->prepare("INSERT INTO memory_pairs (pair_value, display_text, category, difficulty) VALUES (?, ?, ?, ?)");
                        $stmt->execute([$data[0], $data[1], $data[2], $data[3]]);
                        $imported_count++;
                    }
                    break;
                case 'word':
                    if (count($data) >= 5) {
                        $stmt = $pdo->prepare("INSERT INTO word_puzzles (word, hint, category, difficulty, points) VALUES (?, ?, ?, ?, ?)");
                        $stmt->execute([$data[0], $data[1], $data[2], $data[3], $data[4]]);
                        $imported_count++;
                    }
                    break;
                case 'math':
                    if (count($data) >= 5) {
                        $stmt = $pdo->prepare("INSERT INTO math_problems (problem, answer, operation, difficulty, points) VALUES (?, ?, ?, ?, ?)");
                        $stmt->execute([$data[0], $data[1], $data[2], $data[3], $data[4]]);
                        $imported_count++;
                    }
                    break;
                default:
                    // Handle custom data types
                    if (strpos($data_type, 'custom_') === 0) {
                        $custom_type = str_replace('custom_', '', $data_type);
                        $stmt = $pdo->prepare("SELECT * FROM custom_data_types WHERE name = ?");
                        $stmt->execute([$custom_type]);
                        $custom_type_info = $stmt->fetch(PDO::FETCH_ASSOC);
                        
                        if ($custom_type_info) {
                            $fields = json_decode($custom_type_info['fields'], true);
                            $table_name = $custom_type_info['table_name'];
                            
                            if (count($data) >= count($fields)) {
                                $field_names = [];
                                $placeholders = [];
                                $values = [];
                                
                                foreach ($fields as $field) {
                                    $field_name = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $field['name']));
                                    $field_names[] = "`$field_name`";
                                    $placeholders[] = '?';
                                    $values[] = $data[array_search($field, $fields)];
                                }
                                
                                $sql = "INSERT INTO `$table_name` (" . implode(', ', $field_names) . ") VALUES (" . implode(', ', $placeholders) . ")";
                                $stmt = $pdo->prepare($sql);
                                $stmt->execute($values);
                                $imported_count++;
                            }
                        }
                    }
                    break;
            }
        } catch (PDOException $e) {
            // Skip invalid rows but continue processing
            continue;
        }
    }
    
    fclose($handle);
    return $imported_count;
}

// Helper function to export data
function exportData($export_type, $file_format, $pdo) {
    $filename = $export_type . '_data_' . date('Y-m-d_H-i-s') . '.' . $file_format;
    
    switch ($export_type) {
        case 'quiz':
            $stmt = $pdo->query("SELECT * FROM quiz_questions");
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $headers = ['ID', 'Question', 'Option A', 'Option B', 'Option C', 'Option D', 'Correct Answer', 'Category', 'Difficulty', 'Points', 'Created At'];
            break;
        case 'memory':
            $stmt = $pdo->query("SELECT * FROM memory_pairs");
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $headers = ['ID', 'Pair Value', 'Display Text', 'Category', 'Difficulty', 'Created At'];
            break;
        case 'word':
            $stmt = $pdo->query("SELECT * FROM word_puzzles");
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $headers = ['ID', 'Word', 'Hint', 'Category', 'Difficulty', 'Points', 'Created At'];
            break;
        case 'math':
            $stmt = $pdo->query("SELECT * FROM math_problems");
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $headers = ['ID', 'Problem', 'Answer', 'Operation', 'Difficulty', 'Points', 'Created At'];
            break;
        default:
            // Handle custom data types
            if (strpos($export_type, 'custom_') === 0) {
                $custom_type = str_replace('custom_', '', $export_type);
                $stmt = $pdo->prepare("SELECT * FROM custom_data_types WHERE name = ?");
                $stmt->execute([$custom_type]);
                $custom_type_info = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($custom_type_info) {
                    $table_name = $custom_type_info['table_name'];
                    $fields = json_decode($custom_type_info['fields'], true);
                    
                    $stmt = $pdo->query("SELECT * FROM `$table_name`");
                    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    $headers = ['ID'];
                    foreach ($fields as $field) {
                        $headers[] = $field['name'];
                    }
                    $headers[] = 'Created At';
                } else {
                    throw new Exception('Custom data type not found');
                }
            } else {
                throw new Exception('Invalid export type');
            }
            break;
    }
    
    if ($file_format === 'csv') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        fputcsv($output, $headers);
        
        foreach ($data as $row) {
            fputcsv($output, $row);
        }
        
        fclose($output);
    } elseif ($file_format === 'txt') {
        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        echo implode("\t", $headers) . "\n";
        foreach ($data as $row) {
            echo implode("\t", $row) . "\n";
        }
    } else {
        throw new Exception('Unsupported file format');
    }
}

// Check if this is an AJAX request
$is_ajax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

// Only process form submissions if it's actually a POST request with an action
$has_post_action = isset($_POST['action']) && !empty($_POST['action']);

// Handle form submissions only if there's a POST request with action
if ($has_post_action && $_POST['action'] === 'add_course') {
    $title = sanitize_input($_POST['title'] ?? '');
    $description = sanitize_input($_POST['description'] ?? '');
    $difficulty_level = sanitize_input($_POST['difficulty_level'] ?? 'beginner');
    $total_lessons = intval($_POST['total_lessons'] ?? 0);
    $course_image = sanitize_input($_POST['course_image'] ?? 'default-course.jpg');
    
    // Handle file upload
    if (isset($_FILES['course_image_upload']) && $_FILES['course_image_upload']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'assets/images/courses/';
        $upload_file = $upload_dir . basename($_FILES['course_image_upload']['name']);
        
        // Create directory if it doesn't exist
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        // Check if file is an image
        $image_info = getimagesize($_FILES['course_image_upload']['tmp_name']);
        if ($image_info !== false) {
            // Move uploaded file
            if (move_uploaded_file($_FILES['course_image_upload']['tmp_name'], $upload_file)) {
                $course_image = basename($_FILES['course_image_upload']['name']);
                $success = 'Course image uploaded successfully!';
            } else {
                $error = 'Failed to upload course image';
            }
        } else {
            $error = 'Please upload a valid image file';
        }
    }
    
    if (empty($title) || empty($description)) {
        $error = 'Please fill in all required fields';
    } elseif ($total_lessons < 0) {
        $error = 'Total lessons must be a positive number';
    } elseif (empty($error)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO courses (title, description, difficulty_level, total_lessons, course_image) VALUES (?, ?, ?, ?, ?)");
            if ($stmt->execute([$title, $description, $difficulty_level, $total_lessons, $course_image])) {
                $success = 'Course added successfully!';
            } else {
                $error = 'Failed to add course';
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
    
    // Return JSON response for AJAX requests
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => $success ? true : false, 'message' => $success ?: $error]);
        exit;
    }
}

if ($has_post_action && $_POST['action'] === 'add_quiz') {
    $question = sanitize_input($_POST['question'] ?? '');
    $option_a = sanitize_input($_POST['option_a'] ?? '');
    $option_b = sanitize_input($_POST['option_b'] ?? '');
    $option_c = sanitize_input($_POST['option_c'] ?? '');
    $option_d = sanitize_input($_POST['option_d'] ?? '');
    $correct_answer = sanitize_input($_POST['correct_answer'] ?? '');
    $category = sanitize_input($_POST['category'] ?? '');
    $difficulty = sanitize_input($_POST['difficulty'] ?? 'easy');
    $points = intval($_POST['points'] ?? 10);
    
    if (empty($question) || empty($option_a) || empty($option_b) || empty($option_c) || empty($option_d) || empty($correct_answer)) {
        $error = 'Please fill in all required fields';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_answer, category, difficulty, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if ($stmt->execute([$question, $option_a, $option_b, $option_c, $option_d, $correct_answer, $category, $difficulty, $points])) {
                $success = 'Quiz question added successfully!';
            } else {
                $error = 'Failed to add quiz question';
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

if ($has_post_action && $_POST['action'] === 'add_memory') {
    $pair_value = sanitize_input($_POST['pair_value'] ?? '');
    $display_text = sanitize_input($_POST['display_text'] ?? '');
    $category = sanitize_input($_POST['category'] ?? '');
    $difficulty = sanitize_input($_POST['difficulty'] ?? 'easy');
    
    if (empty($pair_value) || empty($display_text)) {
        $error = 'Please fill in all required fields';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO memory_pairs (pair_value, display_text, category, difficulty) VALUES (?, ?, ?, ?)");
            if ($stmt->execute([$pair_value, $display_text, $category, $difficulty])) {
                $success = 'Memory pair added successfully!';
            } else {
                $error = 'Failed to add memory pair';
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
    
    // Return JSON response for AJAX requests
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => $success ? true : false, 'message' => $success ?: $error]);
        exit;
    }
}

if ($has_post_action && $_POST['action'] === 'add_word') {
    $word = sanitize_input($_POST['word'] ?? '');
    $hint = sanitize_input($_POST['hint'] ?? '');
    $category = sanitize_input($_POST['category'] ?? '');
    $difficulty = sanitize_input($_POST['difficulty'] ?? 'easy');
    $points = intval($_POST['points'] ?? 15);
    
    if (empty($word) || empty($hint)) {
        $error = 'Please fill in all required fields';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO word_puzzles (word, hint, category, difficulty, points) VALUES (?, ?, ?, ?, ?)");
            if ($stmt->execute([$word, $hint, $category, $difficulty, $points])) {
                $success = 'Word puzzle added successfully!';
            } else {
                $error = 'Failed to add word puzzle';
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
    
    // Return JSON response for AJAX requests
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => $success ? true : false, 'message' => $success ?: $error]);
        exit;
    }
}

if ($has_post_action && $_POST['action'] === 'add_math') {
    $problem = sanitize_input($_POST['problem'] ?? '');
    $answer = floatval($_POST['answer'] ?? 0);
    $operation = sanitize_input($_POST['operation'] ?? 'mixed');
    $difficulty = sanitize_input($_POST['difficulty'] ?? 'easy');
    $points = intval($_POST['points'] ?? 10);
    
    if (empty($problem) || $answer == 0) {
        $error = 'Please fill in all required fields';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO math_problems (problem, answer, operation, difficulty, points) VALUES (?, ?, ?, ?, ?)");
            if ($stmt->execute([$problem, $answer, $operation, $difficulty, $points])) {
                $success = 'Math problem added successfully!';
            } else {
                $error = 'Failed to add math problem';
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
    
    // Return JSON response for AJAX requests
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => $success ? true : false, 'message' => $success ?: $error]);
        exit;
    }
}

// Handle file import/export operations
if ($has_post_action && $_POST['action'] === 'import_file') {
    $file_type = sanitize_input($_POST['file_type'] ?? '');
    $data_type = sanitize_input($_POST['data_type'] ?? '');
    
    if (empty($file_type) || empty($data_type)) {
        $error = 'Please select file type and data type';
    } elseif (!isset($_FILES['import_file']) || $_FILES['import_file']['error'] !== UPLOAD_ERR_OK) {
        $error = 'Please select a valid file to upload';
    } else {
        try {
            $uploaded_file = $_FILES['import_file'];
            $file_extension = strtolower(pathinfo($uploaded_file['name'], PATHINFO_EXTENSION));
            
            // Validate file extension
            $allowed_extensions = ['csv', 'txt', 'xlsx', 'xls'];
            if (!in_array($file_extension, $allowed_extensions)) {
                throw new Exception('Invalid file type. Please upload CSV, TXT, or Excel files only.');
            }
            
            // Validate file size (max 5MB)
            if ($uploaded_file['size'] > 5 * 1024 * 1024) {
                throw new Exception('File size too large. Maximum size is 5MB.');
            }
            
            // Process the file based on type
            $imported_count = 0;
            $temp_file = $uploaded_file['tmp_name'];
            
            if ($file_extension === 'csv' || $file_extension === 'txt') {
                $imported_count = importCSVFile($temp_file, $data_type, $pdo);
            } elseif ($file_extension === 'xlsx' || $file_extension === 'xls') {
                try {
                    $imported_count = importExcelFile($temp_file, $data_type, $pdo);
                } catch (Exception $e) {
                    // If Excel import fails, suggest CSV conversion
                    throw new Exception('Excel import failed: ' . $e->getMessage() . ' Please save your Excel file as CSV format and try again.');
                }
            }
            
            $success = "Successfully imported {$imported_count} {$data_type} records from file!";
            
        } catch (Exception $e) {
            $error = 'Import error: ' . $e->getMessage();
        }
    }
    
    // Return JSON response for AJAX requests
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => $success ? true : false, 'message' => $success ?: $error]);
        exit;
    }
}

// Handle export operations
if ($has_post_action && $_POST['action'] === 'export_data') {
    $export_type = sanitize_input($_POST['export_type'] ?? '');
    $file_format = sanitize_input($_POST['file_format'] ?? '');
    
    if (empty($export_type) || empty($file_format)) {
        $error = 'Please select export type and file format';
    } else {
        try {
            exportData($export_type, $file_format, $pdo);
            exit; // Exit after download
        } catch (Exception $e) {
            $error = 'Export error: ' . $e->getMessage();
        }
    }
}

// Handle custom data type creation
if ($has_post_action && $_POST['action'] === 'create_custom_datatype') {
    // Debug: Log the received data
    error_log("Custom data type creation request received");
    error_log("POST data: " . print_r($_POST, true));
    
    $name = sanitize_input($_POST['name'] ?? '');
    $display_name = sanitize_input($_POST['display_name'] ?? '');
    $description = sanitize_input($_POST['description'] ?? '');
    $fields = $_POST['fields'] ?? [];
    
    // Debug: Log processed data
    error_log("Processed data - Name: $name, Display: $display_name, Fields count: " . count($fields));
    
    if (empty($name) || empty($display_name) || empty($fields)) {
        $error = 'Please fill in all required fields for custom data type';
    } else {
        try {
            // Validate field structure
            $validated_fields = [];
            $valid_types = ['VARCHAR(255)', 'TEXT', 'INT', 'DECIMAL(10,2)', 'BOOLEAN', 'DATE', 'DATETIME'];
            
            foreach ($fields as $field) {
                error_log("Processing field: " . print_r($field, true));
                if (!empty($field['name']) && !empty($field['type'])) {
                    $field_type = sanitize_input($field['type']);
                    
                    // Ensure field type is valid
                    if (!in_array($field_type, $valid_types)) {
                        $field_type = 'VARCHAR(255)'; // Default to VARCHAR if invalid
                    }
                    
                    $validated_fields[] = [
                        'name' => sanitize_input($field['name']),
                        'type' => $field_type,
                        'required' => isset($field['required']) ? true : false,
                        'default' => sanitize_input($field['default'] ?? '')
                    ];
                    error_log("Added validated field: " . print_r(end($validated_fields), true));
                } else {
                    error_log("Skipping invalid field: " . print_r($field, true));
                }
            }
            
            if (empty($validated_fields)) {
                throw new Exception('At least one field is required');
            }
            
            $table_name = 'custom_' . strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $name));
            
            // Create custom data type record
            $stmt = $pdo->prepare("INSERT INTO custom_data_types (name, display_name, table_name, description, fields) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $display_name, $table_name, $description, json_encode($validated_fields)]);
            
            // Create the actual table
            $create_table_sql = "CREATE TABLE IF NOT EXISTS `$table_name` (
                id INT PRIMARY KEY AUTO_INCREMENT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP";
            
            foreach ($validated_fields as $field) {
                $field_name = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $field['name']));
                $field_type = $field['type'];
                $field_required = $field['required'] ? 'NOT NULL' : '';
                $field_default = !empty($field['default']) ? "DEFAULT '{$field['default']}'" : '';
                
                $create_table_sql .= ",\n                `$field_name` $field_type $field_required $field_default";
            }
            
            $create_table_sql .= "\n            )";
            
            // Log the SQL for debugging
            error_log("Creating custom table with SQL: " . $create_table_sql);
            
            try {
                $result = $pdo->exec($create_table_sql);
                if ($result === false) {
                    $error_info = $pdo->errorInfo();
                    throw new Exception('Failed to create custom data type table. SQL Error: ' . $error_info[2]);
                }
            } catch (PDOException $e) {
                throw new Exception('Failed to create custom data type table. PDO Error: ' . $e->getMessage() . ' SQL: ' . $create_table_sql);
            }
            
            $success = "Custom data type '$display_name' created successfully!";
            
        } catch (Exception $e) {
            $error = 'Error creating custom data type: ' . $e->getMessage();
            error_log("Custom data type creation error: " . $e->getMessage());
        }
    }
    
    // Return JSON response for AJAX requests
    if ($is_ajax) {
        // Debug: Log the response being sent
        $response = ['success' => $success ? true : false, 'message' => $success ?: $error];
        error_log("Sending JSON response: " . json_encode($response));
        
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }
}

// Handle import operations
if ($has_post_action && $_POST['action'] === 'import_data') {
    $import_type = sanitize_input($_POST['import_type'] ?? '');
    
    if (empty($import_type)) {
        $error = 'Please select an import type';
    } else {
        try {
            // Check database connection
            if (!$pdo) {
                throw new Exception('Database connection failed');
            }
            // First, ensure tables exist
            $create_tables_sql = "
                CREATE TABLE IF NOT EXISTS quiz_questions (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    question TEXT NOT NULL,
                    option_a VARCHAR(255) NOT NULL,
                    option_b VARCHAR(255) NOT NULL,
                    option_c VARCHAR(255) NOT NULL,
                    option_d VARCHAR(255) NOT NULL,
                    correct_answer ENUM('A', 'B', 'C', 'D') NOT NULL,
                    points INT DEFAULT 10,
                    difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
                    category VARCHAR(100),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                );
                
                CREATE TABLE IF NOT EXISTS memory_pairs (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    pair_value VARCHAR(255) NOT NULL,
                    display_text VARCHAR(255) NOT NULL,
                    category VARCHAR(100),
                    difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                );
                
                CREATE TABLE IF NOT EXISTS word_puzzles (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    word VARCHAR(255) NOT NULL,
                    hint TEXT NOT NULL,
                    category VARCHAR(100),
                    difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
                    points INT DEFAULT 15,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                );
                
                CREATE TABLE IF NOT EXISTS math_problems (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    problem TEXT NOT NULL,
                    answer DECIMAL(10,2) NOT NULL,
                    operation ENUM('addition', 'subtraction', 'multiplication', 'division', 'mixed') DEFAULT 'mixed',
                    difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
                    points INT DEFAULT 10,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                );
                
                CREATE TABLE IF NOT EXISTS custom_data_types (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    name VARCHAR(100) NOT NULL UNIQUE,
                    display_name VARCHAR(100) NOT NULL,
                    table_name VARCHAR(100) NOT NULL UNIQUE,
                    description TEXT,
                    fields JSON NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                );
            ";
            
            $pdo->exec($create_tables_sql);
            
            if ($import_type === 'quiz') {
            // Import quiz questions from setup_tables.sql
            $quizData = [
                ['What is the capital of France?', 'London', 'Berlin', 'Paris', 'Madrid', 'C', 'Geography', 'easy', 10],
                ['Which planet is known as the Red Planet?', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'B', 'Science', 'easy', 10],
                ['What is 15 + 27?', '40', '42', '41', '43', 'B', 'Math', 'easy', 10],
                ['Who painted the Mona Lisa?', 'Van Gogh', 'Picasso', 'Da Vinci', 'Michelangelo', 'C', 'Art', 'medium', 15],
                ['What is the largest ocean on Earth?', 'Atlantic', 'Indian', 'Pacific', 'Arctic', 'C', 'Geography', 'easy', 10]
            ];
            
            $stmt = $pdo->prepare("INSERT INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_answer, category, difficulty, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            foreach ($quizData as $data) {
                if (!$stmt->execute($data)) {
                    throw new Exception('Failed to insert quiz question: ' . implode(', ', $data));
                }
            }
            $success = 'Quiz questions imported successfully!';
            
        } elseif ($import_type === 'memory') {
            // Import memory pairs
            $memoryData = [
                ['<i class="fas fa-bullseye"></i>', 'Target', 'Icon', 'easy'],
                ['<i class="fas fa-gamepad"></i>', 'Game Controller', 'Icon', 'easy'],
                ['<i class="fas fa-palette"></i>', 'Artist Palette', 'Icon', 'easy'],
                ['<i class="fas fa-tent"></i>', 'Circus Tent', 'Icon', 'easy'],
                ['<i class="fas fa-theater-masks"></i>', 'Theater Masks', 'Icon', 'medium'],
                ['<i class="fas fa-guitar"></i>', 'Guitar', 'Icon', 'medium'],
                ['<i class="fas fa-music"></i>', 'Trumpet', 'Icon', 'medium'],
                ['<i class="fas fa-star"></i>', 'Star', 'Icon', 'easy']
            ];
            
            $stmt = $pdo->prepare("INSERT INTO memory_pairs (pair_value, display_text, category, difficulty) VALUES (?, ?, ?, ?)");
            foreach ($memoryData as $data) {
                if (!$stmt->execute($data)) {
                    throw new Exception('Failed to insert memory pair: ' . implode(', ', $data));
                }
            }
            $success = 'Memory pairs imported successfully!';
            
        } elseif ($import_type === 'word') {
            // Import word puzzles
            $wordData = [
                ['EDUCATION', 'The process of learning', 'General', 'easy', 15],
                ['KNOWLEDGE', 'Information and understanding', 'General', 'medium', 20],
                ['TEACHER', 'Someone who educates', 'General', 'easy', 15],
                ['STUDENT', 'Someone who learns', 'General', 'easy', 15],
                ['SCHOOL', 'A place of learning', 'General', 'easy', 15],
                ['COMPUTER', 'Electronic device for processing data', 'Technology', 'easy', 15],
                ['SCIENCE', 'Systematic study of the natural world', 'General', 'medium', 20],
                ['MATHEMATICS', 'Study of numbers and shapes', 'General', 'hard', 25]
            ];
            
            $stmt = $pdo->prepare("INSERT INTO word_puzzles (word, hint, category, difficulty, points) VALUES (?, ?, ?, ?, ?)");
            foreach ($wordData as $data) {
                if (!$stmt->execute($data)) {
                    throw new Exception('Failed to insert word puzzle: ' . implode(', ', $data));
                }
            }
            $success = 'Word puzzles imported successfully!';
            
        } elseif ($import_type === 'math') {
            // Import math problems
            $mathData = [
                ['12 + 8 = ?', 20, 'addition', 'easy', 10],
                ['25 - 7 = ?', 18, 'subtraction', 'easy', 10],
                ['6 × 4 = ?', 24, 'multiplication', 'easy', 10],
                ['36 ÷ 6 = ?', 6, 'division', 'easy', 10],
                ['15 + 23 = ?', 38, 'addition', 'easy', 10],
                ['45 - 18 = ?', 27, 'subtraction', 'medium', 15],
                ['7 × 8 = ?', 56, 'multiplication', 'medium', 15],
                ['72 ÷ 9 = ?', 8, 'division', 'medium', 15]
            ];
            
            $stmt = $pdo->prepare("INSERT INTO math_problems (problem, answer, operation, difficulty, points) VALUES (?, ?, ?, ?, ?)");
            foreach ($mathData as $data) {
                if (!$stmt->execute($data)) {
                    throw new Exception('Failed to insert math problem: ' . implode(', ', $data));
                }
            }
            $success = 'Math problems imported successfully!';
            
        } elseif ($import_type === 'all') {
            // Import all data
            $quizData = [
                ['What is the capital of France?', 'London', 'Berlin', 'Paris', 'Madrid', 'C', 'Geography', 'easy', 10],
                ['Which planet is known as the Red Planet?', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'B', 'Science', 'easy', 10],
                ['What is 15 + 27?', '40', '42', '41', '43', 'B', 'Math', 'easy', 10],
                ['Who painted the Mona Lisa?', 'Van Gogh', 'Picasso', 'Da Vinci', 'Michelangelo', 'C', 'Art', 'medium', 15],
                ['What is the largest ocean on Earth?', 'Atlantic', 'Indian', 'Pacific', 'Arctic', 'C', 'Geography', 'easy', 10]
            ];
            
            $memoryData = [
                ['<i class="fas fa-bullseye"></i>', 'Target', 'Icon', 'easy'],
                ['<i class="fas fa-gamepad"></i>', 'Game Controller', 'Icon', 'easy'],
                ['<i class="fas fa-palette"></i>', 'Artist Palette', 'Icon', 'easy'],
                ['<i class="fas fa-tent"></i>', 'Circus Tent', 'Icon', 'easy'],
                ['<i class="fas fa-theater-masks"></i>', 'Theater Masks', 'Icon', 'medium'],
                ['<i class="fas fa-guitar"></i>', 'Guitar', 'Icon', 'medium'],
                ['<i class="fas fa-music"></i>', 'Trumpet', 'Icon', 'medium'],
                ['<i class="fas fa-star"></i>', 'Star', 'Icon', 'easy']
            ];
            
            $wordData = [
                ['EDUCATION', 'The process of learning', 'General', 'easy', 15],
                ['KNOWLEDGE', 'Information and understanding', 'General', 'medium', 20],
                ['TEACHER', 'Someone who educates', 'General', 'easy', 15],
                ['STUDENT', 'Someone who learns', 'General', 'easy', 15],
                ['SCHOOL', 'A place of learning', 'General', 'easy', 15],
                ['COMPUTER', 'Electronic device for processing data', 'Technology', 'easy', 15],
                ['SCIENCE', 'Systematic study of the natural world', 'General', 'medium', 20],
                ['MATHEMATICS', 'Study of numbers and shapes', 'General', 'hard', 25]
            ];
            
            $mathData = [
                ['12 + 8 = ?', 20, 'addition', 'easy', 10],
                ['25 - 7 = ?', 18, 'subtraction', 'easy', 10],
                ['6 × 4 = ?', 24, 'multiplication', 'easy', 10],
                ['36 ÷ 6 = ?', 6, 'division', 'easy', 10],
                ['15 + 23 = ?', 38, 'addition', 'easy', 10],
                ['45 - 18 = ?', 27, 'subtraction', 'medium', 15],
                ['7 × 8 = ?', 56, 'multiplication', 'medium', 15],
                ['72 ÷ 9 = ?', 8, 'division', 'medium', 15]
            ];
            
            // Import quiz questions
            $stmt = $pdo->prepare("INSERT INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_answer, category, difficulty, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            foreach ($quizData as $data) {
                if (!$stmt->execute($data)) {
                    throw new Exception('Failed to insert quiz question: ' . implode(', ', $data));
                }
            }
            
            // Import memory pairs
            $stmt = $pdo->prepare("INSERT INTO memory_pairs (pair_value, display_text, category, difficulty) VALUES (?, ?, ?, ?)");
            foreach ($memoryData as $data) {
                if (!$stmt->execute($data)) {
                    throw new Exception('Failed to insert memory pair: ' . implode(', ', $data));
                }
            }
            
            // Import word puzzles
            $stmt = $pdo->prepare("INSERT INTO word_puzzles (word, hint, category, difficulty, points) VALUES (?, ?, ?, ?, ?)");
            foreach ($wordData as $data) {
                if (!$stmt->execute($data)) {
                    throw new Exception('Failed to insert word puzzle: ' . implode(', ', $data));
                }
            }
            
            // Import math problems
            $stmt = $pdo->prepare("INSERT INTO math_problems (problem, answer, operation, difficulty, points) VALUES (?, ?, ?, ?, ?)");
            foreach ($mathData as $data) {
                if (!$stmt->execute($data)) {
                    throw new Exception('Failed to insert math problem: ' . implode(', ', $data));
                }
            }
            
            $success = 'All game content imported successfully!';
        }
        
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        } catch (Exception $e) {
            $error = 'Import error: ' . $e->getMessage();
        }
        
        // Return JSON response for AJAX requests
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => $success ? true : false, 'message' => $success ?: $error]);
            exit;
        }
    }
}

// Handle settings update
if ($has_post_action && $_POST['action'] === 'update_settings') {
    $quiz_timer = intval($_POST['quiz_timer'] ?? 10);
    $game_timer = intval($_POST['game_timer'] ?? 60);
    $auto_advance = intval($_POST['auto_advance'] ?? 1);
    $show_timer = intval($_POST['show_timer'] ?? 1);
    
    // Validate timer values
    if ($quiz_timer < 5 || $quiz_timer > 60) {
        $error = 'Quiz timer must be between 5 and 60 seconds';
    } elseif ($game_timer < 30 || $game_timer > 300) {
        $error = 'Game timer must be between 30 and 300 seconds';
    } else {
        try {
            // Create settings table if it doesn't exist
            $pdo->exec("CREATE TABLE IF NOT EXISTS game_settings (
                id INT PRIMARY KEY AUTO_INCREMENT,
                setting_name VARCHAR(100) UNIQUE NOT NULL,
                setting_value VARCHAR(255) NOT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )");
            
            // Update or insert settings
            $settings = [
                'quiz_timer' => $quiz_timer,
                'game_timer' => $game_timer,
                'auto_advance' => $auto_advance,
                'show_timer' => $show_timer
            ];
            
            foreach ($settings as $name => $value) {
                $stmt = $pdo->prepare("INSERT INTO game_settings (setting_name, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
                $stmt->execute([$name, $value, $value]);
            }
            
            $success = 'Settings updated successfully!';
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
    
    // Return JSON response for AJAX requests
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => $success ? true : false, 'message' => $success ?: $error]);
        exit;
    }
}

// Handle delete operations
if ($has_post_action && $_POST['action'] === 'delete_quiz') {
    $id = intval($_POST['id'] ?? 0);
    try {
        $stmt = $pdo->prepare("DELETE FROM quiz_questions WHERE id = ?");
        if ($stmt->execute([$id])) {
            $success = 'Quiz question deleted successfully!';
        }
    } catch (PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
    
    // Return JSON response for AJAX requests
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => $success ? true : false, 'message' => $success ?: $error]);
        exit;
    }
}

if ($has_post_action && $_POST['action'] === 'delete_memory') {
    $id = intval($_POST['id'] ?? 0);
    try {
        $stmt = $pdo->prepare("DELETE FROM memory_pairs WHERE id = ?");
        if ($stmt->execute([$id])) {
            $success = 'Memory pair deleted successfully!';
        }
    } catch (PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
    
    // Return JSON response for AJAX requests
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => $success ? true : false, 'message' => $success ?: $error]);
        exit;
    }
}

if ($has_post_action && $_POST['action'] === 'delete_word') {
    $id = intval($_POST['id'] ?? 0);
    try {
        $stmt = $pdo->prepare("DELETE FROM word_puzzles WHERE id = ?");
        if ($stmt->execute([$id])) {
            $success = 'Word puzzle deleted successfully!';
        }
    } catch (PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
    
    // Return JSON response for AJAX requests
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => $success ? true : false, 'message' => $success ?: $error]);
        exit;
    }
}

if ($has_post_action && $_POST['action'] === 'delete_math') {
    $id = intval($_POST['id'] ?? 0);
    try {
        $stmt = $pdo->prepare("DELETE FROM math_problems WHERE id = ?");
        if ($stmt->execute([$id])) {
            $success = 'Math problem deleted successfully!';
        }
    } catch (PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
    
    // Return JSON response for AJAX requests
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => $success ? true : false, 'message' => $success ?: $error]);
        exit;
    }
}

if ($has_post_action && $_POST['action'] === 'delete_course') {
    $id = intval($_POST['id'] ?? 0);
    try {
        $stmt = $pdo->prepare("DELETE FROM courses WHERE id = ?");
        if ($stmt->execute([$id])) {
            $success = 'Course deleted successfully!';
        }
    } catch (PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
    
    // Return JSON response for AJAX requests
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => $success ? true : false, 'message' => $success ?: $error]);
        exit;
    }
}

// Check if tables exist, if not redirect to setup
$tables_exist = true;
try {
    $pdo->query("SELECT 1 FROM quiz_questions LIMIT 1");
} catch (PDOException $e) {
    $tables_exist = false;
}

if (!$tables_exist) {
    header('Location: setup_database.php');
    exit;
}

// Get existing data for display
try {
    $quiz_questions = $pdo->query("SELECT * FROM quiz_questions ORDER BY id DESC")->fetchAll();
} catch (PDOException $e) {
    $quiz_questions = [];
}

try {
    $memory_pairs = $pdo->query("SELECT * FROM memory_pairs ORDER BY id DESC")->fetchAll();
} catch (PDOException $e) {
    $memory_pairs = [];
}

try {
    $word_puzzles = $pdo->query("SELECT * FROM word_puzzles ORDER BY id DESC")->fetchAll();
} catch (PDOException $e) {
    $word_puzzles = [];
}

try {
    $math_problems = $pdo->query("SELECT * FROM math_problems ORDER BY id DESC")->fetchAll();
} catch (PDOException $e) {
    $math_problems = [];
}

try {
    $courses = $pdo->query("SELECT * FROM courses ORDER BY id DESC")->fetchAll();
} catch (PDOException $e) {
    $courses = [];
}

// Load current settings
$current_settings = [
    'quiz_timer' => 10,
    'game_timer' => 60,
    'auto_advance' => 1,
    'show_timer' => 1
];

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS game_settings (
        id INT PRIMARY KEY AUTO_INCREMENT,
        setting_name VARCHAR(100) UNIQUE NOT NULL,
        setting_value VARCHAR(255) NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");
    
    $stmt = $pdo->query("SELECT setting_name, setting_value FROM game_settings");
    $settings_data = $stmt->fetchAll();
    
    foreach ($settings_data as $setting) {
        $current_settings[$setting['setting_name']] = $setting['setting_value'];
    }
} catch (PDOException $e) {
    // Use default settings if table doesn't exist
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        .admin-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }

        .admin-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem;
            border-radius: 15px;
            margin-bottom: 2rem;
            text-align: center;
        }

        .admin-header h1 {
            margin: 0;
            font-size: 2.5rem;
        }

        .admin-header p {
            margin: 0.5rem 0 0 0;
            opacity: 0.9;
        }

        .admin-nav {
            display: flex;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
            overflow: hidden;
        }

        .admin-nav a {
            flex: 1;
            padding: 1rem 2rem;
            text-decoration: none;
            color: #666;
            font-weight: 600;
            transition: all 0.3s ease;
            border-bottom: 3px solid transparent;
        }

        .admin-nav a:hover,
        .admin-nav a.active {
            color: var(--primary-color);
            background: rgba(102, 126, 234, 0.05);
            border-bottom-color: var(--primary-color);
        }

        .admin-content {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            padding: 2rem;
        }

        .form-section {
            margin-bottom: 3rem;
        }

        .form-section h3 {
            color: var(--dark-color);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: var(--dark-color);
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e1e5e9;
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s ease;
            background: white;
            font-family: inherit;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-group.full-width {
            grid-column: 1 / -1;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }

        .data-table th,
        .data-table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #e1e5e9;
        }

        .data-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: var(--dark-color);
        }

        .data-table tr:hover {
            background: rgba(102, 126, 234, 0.05);
        }

        .btn-group {
            display: flex;
            gap: 0.5rem;
        }

        .btn-small {
            padding: 0.5rem 1rem;
            font-size: 0.9rem;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-danger {
            background: #dc3545;
            color: white;
        }

        .btn-danger:hover {
            background: #c82333;
        }

        .difficulty-badge {
            padding: 0.25rem 0.5rem;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .difficulty-easy {
            background: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }

        .difficulty-medium {
            background: rgba(255, 193, 7, 0.1);
            color: #ffc107;
        }

        .difficulty-hard {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--primary-color);
            text-decoration: none;
            margin-bottom: 2rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .back-link:hover {
            color: var(--dark-color);
        }

        .home-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            text-decoration: none;
            padding: 0.75rem 1.5rem;
            border-radius: 25px;
            font-weight: 600;
            transition: all 0.3s ease;
            border: 2px solid rgba(255, 255, 255, 0.3);
        }

        .home-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            border-color: rgba(255, 255, 255, 0.5);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        /* Import Section Styles */
        .import-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .import-card {
            background: #f8f9fa;
            border: 2px solid #e9ecef;
            border-radius: 15px;
            padding: 2rem;
            text-align: center;
            transition: all 0.3s ease;
        }

        .import-card:hover {
            border-color: var(--primary-color);
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.1);
        }

        .import-icon {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            font-size: 2rem;
            color: white;
        }

        .import-card h4 {
            margin-bottom: 1rem;
            color: var(--dark-color);
            font-size: 1.3rem;
        }

        .import-card p {
            color: #666;
            margin-bottom: 1.5rem;
            line-height: 1.6;
        }

        .import-form {
            margin: 0;
        }

        .import-all-section {
            margin: 3rem 0;
        }

        .import-all-card {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            border-radius: 20px;
            padding: 2rem;
            display: flex;
            align-items: center;
            gap: 2rem;
            box-shadow: 0 10px 30px rgba(40, 167, 69, 0.2);
        }

        .import-all-icon {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            color: white;
            flex-shrink: 0;
        }

        .import-all-content {
            flex: 1;
        }

        .import-all-content h4 {
            margin: 0 0 0.5rem 0;
            font-size: 1.5rem;
        }

        .import-all-content p {
            margin: 0 0 1.5rem 0;
            opacity: 0.9;
        }

        .btn-success {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: 2px solid rgba(255, 255, 255, 0.3);
        }

        .btn-success:hover {
            background: rgba(255, 255, 255, 0.3);
            border-color: rgba(255, 255, 255, 0.5);
            transform: translateY(-2px);
        }

        .import-info {
            background: #e3f2fd;
            border: 1px solid #bbdefb;
            border-radius: 15px;
            padding: 2rem;
            margin-top: 2rem;
        }

        .import-info h4 {
            color: #1976d2;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .import-info ul {
            margin: 0;
            padding-left: 1.5rem;
            color: #666;
        }

        .import-info li {
            margin-bottom: 0.5rem;
            line-height: 1.6;
        }

        @media (max-width: 768px) {
            .admin-container {
                padding: 1rem;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .admin-nav {
                flex-direction: column;
            }

            .data-table {
                font-size: 0.9rem;
            }

            .data-table th,
            .data-table td {
                padding: 0.5rem;
            }

            .admin-header div {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }

            .home-btn {
                padding: 0.5rem 1rem;
                font-size: 0.9rem;
            }

            .import-grid {
                grid-template-columns: 1fr;
            }

            .import-all-card {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
            }

            .import-all-icon {
                width: 80px;
                height: 80px;
                font-size: 2rem;
            }
        }

        /* Message Styles */
        .message {
            padding: 1rem 1.5rem;
            margin: 1rem 0;
            border-radius: 8px;
            font-weight: 500;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .message-success {
            background: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }

        .message-error {
            background: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }

        .message-warning {
            background: #fff3cd;
            color: #856404;
            border-left: 4px solid #ffc107;
        }

        /* Import/Export Styles */
        .import-export-section {
            margin-bottom: 3rem;
        }

        .import-export-section h4 {
            color: var(--primary-color);
            margin-bottom: 1.5rem;
            font-size: 1.3rem;
        }

        .import-export-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .import-export-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s ease;
        }

        .import-export-card:hover {
            transform: translateY(-5px);
        }

        .import-export-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            font-size: 2rem;
            color: white;
        }

        .import-export-card h5 {
            color: var(--primary-color);
            margin-bottom: 1rem;
            font-size: 1.2rem;
        }

        .import-export-card p {
            color: #666;
            margin-bottom: 1.5rem;
            line-height: 1.6;
        }

        .import-export-form {
            text-align: left;
        }

        .import-export-form .form-group {
            margin-bottom: 1rem;
        }

        .import-export-form label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #333;
        }

        .import-export-form select,
        .import-export-form input[type="file"] {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        .import-export-form select:focus,
        .import-export-form input[type="file"]:focus {
            outline: none;
            border-color: var(--primary-color);
        }

        .import-export-form small {
            display: block;
            margin-top: 0.25rem;
            color: #666;
            font-size: 0.85rem;
        }

        .import-export-info {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 2rem;
            margin-top: 2rem;
        }

        .import-export-info h4 {
            color: var(--primary-color);
            margin-bottom: 1.5rem;
        }

        .format-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
        }

        .format-info-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .format-info-card h5 {
            color: var(--primary-color);
            margin-bottom: 1rem;
        }

        .format-examples h6 {
            color: #333;
            margin: 1rem 0 0.5rem 0;
            font-size: 0.9rem;
        }

        .format-examples code {
            background: #f1f3f4;
            padding: 0.5rem;
            border-radius: 4px;
            font-size: 0.85rem;
            display: block;
            margin-bottom: 0.5rem;
            word-break: break-all;
        }

        .format-info-card ul {
            list-style: none;
            padding: 0;
        }

        .format-info-card li {
            padding: 0.5rem 0;
            border-bottom: 1px solid #eee;
        }

        .format-info-card li:last-child {
            border-bottom: none;
        }

        /* Select with Add Button */
        .select-with-add {
            display: flex;
            gap: 0.5rem;
            align-items: center;
        }

        .select-with-add select {
            flex: 1;
        }

        .btn-add-custom {
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 8px;
            padding: 0.75rem;
            cursor: pointer;
            transition: background-color 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 44px;
            height: 44px;
        }

        .btn-add-custom:hover {
            background: #5a67d8;
        }

        /* Modal Styles */
        .modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }

        .modal-content {
            background: white;
            border-radius: 15px;
            max-width: 600px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1.5rem;
            border-bottom: 1px solid #e1e5e9;
        }

        .modal-header h3 {
            margin: 0;
            color: var(--primary-color);
        }

        .modal-close {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #666;
            padding: 0.5rem;
            border-radius: 50%;
            transition: background-color 0.3s ease;
        }

        .modal-close:hover {
            background: #f1f3f4;
        }

        .modal-body {
            padding: 1.5rem;
        }

        .modal-body .form-group {
            margin-bottom: 1.5rem;
        }

        .modal-body label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #333;
        }

        .modal-body input,
        .modal-body textarea,
        .modal-body select {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        .modal-body input:focus,
        .modal-body textarea:focus,
        .modal-body select:focus {
            outline: none;
            border-color: var(--primary-color);
        }

        .modal-body textarea {
            resize: vertical;
            min-height: 80px;
        }

        .modal-body small {
            display: block;
            margin-top: 0.25rem;
            color: #666;
            font-size: 0.85rem;
        }

        /* Field Rows */
        .field-row {
            display: grid;
            grid-template-columns: 2fr 2fr 1fr 2fr auto;
            gap: 0.5rem;
            align-items: center;
            margin-bottom: 0.5rem;
            padding: 0.5rem;
            background: #f8f9fa;
            border-radius: 8px;
        }

        .field-row input,
        .field-row select {
            margin: 0;
        }

        .checkbox-label {
            display: flex;
            align-items: center;
            gap: 0.25rem;
            font-size: 0.9rem;
            margin: 0;
        }

        .checkbox-label input[type="checkbox"] {
            width: auto;
            margin: 0;
        }

        .btn-remove-field {
            background: #dc3545;
            color: white;
            border: none;
            border-radius: 6px;
            padding: 0.5rem;
            cursor: pointer;
            transition: background-color 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 36px;
            height: 36px;
        }

        .btn-remove-field:hover {
            background: #c82333;
        }

        .modal-actions {
            display: flex;
            gap: 1rem;
            justify-content: flex-end;
            padding-top: 1rem;
            border-top: 1px solid #e1e5e9;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .import-export-grid {
                grid-template-columns: 1fr;
            }
            
            .format-info-grid {
                grid-template-columns: 1fr;
            }
            
            .import-export-card {
                padding: 1.5rem;
            }

            .field-row {
                grid-template-columns: 1fr;
                gap: 0.5rem;
            }

            .modal-content {
                width: 95%;
                margin: 1rem;
            }

            .modal-actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="animated-bg"></div>
    
    <div class="admin-container">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
            <div style="display: flex; gap: 1rem; align-items: center;">
                <a href="index.php" class="back-link">
                    <i class="fas fa-arrow-left"></i> Back to Home
                </a>
                <a href="front_page.php" class="btn btn-primary" style="background: #667eea; color: white; padding: 8px 16px; border-radius: 5px; text-decoration: none;">
                    <i class="fas fa-eye"></i> View Front Page
                </a>
                <a href="setup_demo_data.php" class="btn btn-success" style="background: #28a745; color: white; padding: 8px 16px; border-radius: 5px; text-decoration: none;">
                    <i class="fas fa-database"></i> Add Demo Data
                </a>
            </div>
            <a href="fix_encoding_web.php" class="btn btn-warning" style="background: #ffc107; color: #000; padding: 8px 16px; border-radius: 5px; text-decoration: none;">
                <i class="fas fa-tools"></i> Fix Encoding Issues
            </a>
        </div>

        <div class="admin-header">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                <h1 style="margin: 0;"><i class="fas fa-cogs"></i> Admin Panel</h1>
                <div style="display: flex; gap: 1rem; align-items: center;">
                    <a href="front_page.php" class="home-btn" style="background: rgba(255,255,255,0.2); color: white; padding: 8px 16px; border-radius: 5px; text-decoration: none;">
                        <i class="fas fa-eye"></i> Front Page
                    </a>
                    <a href="index.php" class="home-btn">
                        <i class="fas fa-home"></i> Home
                    </a>
                </div>
            </div>
            <p style="margin: 0;">Manage game content and questions</p>
        </div>

        <?php if ($error): ?>
            <div class="message message-error"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="message message-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <div class="admin-nav">
            <a href="?tab=courses" class="<?php echo $current_tab === 'courses' ? 'active' : ''; ?>">
                <i class="fas fa-graduation-cap"></i> Courses
            </a>
            <a href="?tab=quiz" class="<?php echo $current_tab === 'quiz' ? 'active' : ''; ?>">
                <i class="fas fa-question-circle"></i> Quiz Questions
            </a>
            <a href="?tab=memory" class="<?php echo $current_tab === 'memory' ? 'active' : ''; ?>">
                <i class="fas fa-brain"></i> Memory Pairs
            </a>
            <a href="?tab=word" class="<?php echo $current_tab === 'word' ? 'active' : ''; ?>">
                <i class="fas fa-puzzle-piece"></i> Word Puzzles
            </a>
            <a href="?tab=math" class="<?php echo $current_tab === 'math' ? 'active' : ''; ?>">
                <i class="fas fa-calculator"></i> Math Problems
            </a>
            <a href="?tab=settings" class="<?php echo $current_tab === 'settings' ? 'active' : ''; ?>">
                <i class="fas fa-cog"></i> Settings
            </a>
            <a href="?tab=import" class="<?php echo $current_tab === 'import' ? 'active' : ''; ?>">
                <i class="fas fa-download"></i> Import Data
            </a>
            <a href="?tab=import_export" class="<?php echo $current_tab === 'import_export' ? 'active' : ''; ?>">
                <i class="fas fa-file-import"></i> Import/Export Files
            </a>
        </div>

        <div class="admin-content">
            <?php if ($current_tab === 'courses'): ?>
                <!-- Courses Tab -->
                <div class="form-section">
                    <h3><i class="fas fa-plus"></i> Add New Course</h3>
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="add_course">
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="title">Course Title *</label>
                                <input type="text" id="title" name="title" required placeholder="Enter course title">
                            </div>
                            <div class="form-group">
                                <label for="difficulty_level">Difficulty Level</label>
                                <select id="difficulty_level" name="difficulty_level">
                                    <option value="beginner">Beginner</option>
                                    <option value="intermediate">Intermediate</option>
                                    <option value="advanced">Advanced</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="total_lessons">Total Lessons</label>
                                <input type="number" id="total_lessons" name="total_lessons" min="0" placeholder="Number of lessons" value="0">
                            </div>
                            <div class="form-group">
                                <label for="course_image">Course Image</label>
                                <div style="display: flex; gap: 10px; align-items: center;">
                                    <input type="file" id="course_image_upload" name="course_image_upload" accept="image/*" style="flex: 1;">
                                    <span style="color: #666;">OR</span>
                                    <select id="course_image" name="course_image" style="flex: 1;">
                                        <option value="default-course.jpg">Default Course Image</option>
                                        <option value="JWU_March_Applications_AI.jpg">AI Applications Image</option>
                                    </select>
                                </div>
                                <small style="color: #666; display: block; margin-top: 5px;">
                                    Upload a new image or select from existing ones
                                </small>
                                <div id="image-preview" style="margin-top: 10px; display: none;">
                                    <img id="preview-img" src="" alt="Preview" style="max-width: 200px; max-height: 150px; border: 1px solid #ddd; border-radius: 5px;">
                                </div>
                            </div>
                        </div>

                        <div class="form-group full-width">
                            <label for="description">Course Description *</label>
                            <textarea id="description" name="description" rows="4" required placeholder="Describe what students will learn in this course"></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Add Course
                        </button>
                    </form>
                </div>

                <div class="form-section">
                    <h3><i class="fas fa-list"></i> Existing Courses</h3>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Difficulty</th>
                                <th>Lessons</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($courses as $course): ?>
                            <tr>
                                <td style="font-weight: bold;"><?php echo htmlspecialchars($course['title']); ?></td>
                                <td><?php echo htmlspecialchars(substr($course['description'], 0, 50)) . '...'; ?></td>
                                <td><span class="difficulty-badge difficulty-<?php echo $course['difficulty_level']; ?>"><?php echo ucfirst($course['difficulty_level']); ?></span></td>
                                <td><?php echo $course['total_lessons']; ?></td>
                                <td>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="delete_course">
                                        <input type="hidden" name="id" value="<?php echo $course['id']; ?>">
                                        <button type="submit" class="btn-small btn-danger" onclick="return confirm('Are you sure?')">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

            <?php elseif ($current_tab === 'quiz'): ?>
                <!-- Quiz Questions Tab -->
                <div class="form-section">
                    <h3><i class="fas fa-plus"></i> Add New Quiz Question</h3>
                    <form method="POST">
                        <input type="hidden" name="action" value="add_quiz">
                        
                        <div class="form-group full-width">
                            <label for="question">Question *</label>
                            <textarea id="question" name="question" rows="3" required placeholder="Enter the question"></textarea>
                        </div>

                        <div class="form-grid">
                            <div class="form-group">
                                <label for="option_a">Option A *</label>
                                <input type="text" id="option_a" name="option_a" required>
                            </div>
                            <div class="form-group">
                                <label for="option_b">Option B *</label>
                                <input type="text" id="option_b" name="option_b" required>
                            </div>
                            <div class="form-group">
                                <label for="option_c">Option C *</label>
                                <input type="text" id="option_c" name="option_c" required>
                            </div>
                            <div class="form-group">
                                <label for="option_d">Option D *</label>
                                <input type="text" id="option_d" name="option_d" required>
                            </div>
                        </div>

                        <div class="form-grid">
                            <div class="form-group">
                                <label for="correct_answer">Correct Answer *</label>
                                <select id="correct_answer" name="correct_answer" required>
                                    <option value="">Select Answer</option>
                                    <option value="A">A</option>
                                    <option value="B">B</option>
                                    <option value="C">C</option>
                                    <option value="D">D</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="category">Category</label>
                                <input type="text" id="category" name="category" placeholder="e.g., Geography, Science">
                            </div>
                            <div class="form-group">
                                <label for="difficulty">Difficulty</label>
                                <select id="difficulty" name="difficulty">
                                    <option value="easy">Easy</option>
                                    <option value="medium">Medium</option>
                                    <option value="hard">Hard</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="points">Points</label>
                                <input type="number" id="points" name="points" value="10" min="1">
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Add Question
                        </button>
                    </form>
                </div>

                <div class="form-section">
                    <h3><i class="fas fa-list"></i> Existing Quiz Questions</h3>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Question</th>
                                <th>Category</th>
                                <th>Difficulty</th>
                                <th>Points</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($quiz_questions as $question): ?>
                            <tr>
                                <td><?php echo htmlspecialchars(substr($question['question'], 0, 50)) . '...'; ?></td>
                                <td><?php echo htmlspecialchars($question['category']); ?></td>
                                <td><span class="difficulty-badge difficulty-<?php echo $question['difficulty']; ?>"><?php echo ucfirst($question['difficulty']); ?></span></td>
                                <td><?php echo $question['points']; ?></td>
                                <td>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="delete_quiz">
                                        <input type="hidden" name="id" value="<?php echo $question['id']; ?>">
                                        <button type="submit" class="btn-small btn-danger" onclick="return confirm('Are you sure?')">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

            <?php elseif ($current_tab === 'memory'): ?>
                <!-- Memory Pairs Tab -->
                <div class="form-section">
                    <h3><i class="fas fa-plus"></i> Add New Memory Pair</h3>
                    <form method="POST">
                        <input type="hidden" name="action" value="add_memory">
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="pair_value">Pair Value (Emoji/Symbol) *</label>
                                <input type="text" id="pair_value" name="pair_value" required placeholder="e.g., <i class='fas fa-bullseye'></i>">
                            </div>
                            <div class="form-group">
                                <label for="display_text">Display Text *</label>
                                <input type="text" id="display_text" name="display_text" required placeholder="e.g., Target">
                            </div>
                            <div class="form-group">
                                <label for="category">Category</label>
                                <input type="text" id="category" name="category" placeholder="e.g., Emoji, Animals">
                            </div>
                            <div class="form-group">
                                <label for="difficulty">Difficulty</label>
                                <select id="difficulty" name="difficulty">
                                    <option value="easy">Easy</option>
                                    <option value="medium">Medium</option>
                                    <option value="hard">Hard</option>
                                </select>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Add Pair
                        </button>
                    </form>
                </div>

                <div class="form-section">
                    <h3><i class="fas fa-list"></i> Existing Memory Pairs</h3>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Pair Value</th>
                                <th>Display Text</th>
                                <th>Category</th>
                                <th>Difficulty</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($memory_pairs as $pair): ?>
                            <tr>
                                <td style="font-size: 1.5rem;"><?php echo htmlspecialchars($pair['pair_value']); ?></td>
                                <td><?php echo htmlspecialchars($pair['display_text']); ?></td>
                                <td><?php echo htmlspecialchars($pair['category']); ?></td>
                                <td><span class="difficulty-badge difficulty-<?php echo $pair['difficulty']; ?>"><?php echo ucfirst($pair['difficulty']); ?></span></td>
                                <td>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="delete_memory">
                                        <input type="hidden" name="id" value="<?php echo $pair['id']; ?>">
                                        <button type="submit" class="btn-small btn-danger" onclick="return confirm('Are you sure?')">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

            <?php elseif ($current_tab === 'word'): ?>
                <!-- Word Puzzles Tab -->
                <div class="form-section">
                    <h3><i class="fas fa-plus"></i> Add New Word Puzzle</h3>
                    <form method="POST">
                        <input type="hidden" name="action" value="add_word">
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="word">Word *</label>
                                <input type="text" id="word" name="word" required placeholder="e.g., EDUCATION" style="text-transform: uppercase;">
                            </div>
                            <div class="form-group">
                                <label for="category">Category</label>
                                <input type="text" id="category" name="category" placeholder="e.g., General, Technology">
                            </div>
                            <div class="form-group">
                                <label for="difficulty">Difficulty</label>
                                <select id="difficulty" name="difficulty">
                                    <option value="easy">Easy</option>
                                    <option value="medium">Medium</option>
                                    <option value="hard">Hard</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="points">Points</label>
                                <input type="number" id="points" name="points" value="15" min="1">
                            </div>
                        </div>

                        <div class="form-group full-width">
                            <label for="hint">Hint *</label>
                            <textarea id="hint" name="hint" rows="2" required placeholder="Enter a helpful hint for the word"></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Add Word Puzzle
                        </button>
                    </form>
                </div>

                <div class="form-section">
                    <h3><i class="fas fa-list"></i> Existing Word Puzzles</h3>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Word</th>
                                <th>Hint</th>
                                <th>Category</th>
                                <th>Difficulty</th>
                                <th>Points</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($word_puzzles as $puzzle): ?>
                            <tr>
                                <td style="font-weight: bold;"><?php echo htmlspecialchars($puzzle['word']); ?></td>
                                <td><?php echo htmlspecialchars(substr($puzzle['hint'], 0, 30)) . '...'; ?></td>
                                <td><?php echo htmlspecialchars($puzzle['category']); ?></td>
                                <td><span class="difficulty-badge difficulty-<?php echo $puzzle['difficulty']; ?>"><?php echo ucfirst($puzzle['difficulty']); ?></span></td>
                                <td><?php echo $puzzle['points']; ?></td>
                                <td>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="delete_word">
                                        <input type="hidden" name="id" value="<?php echo $puzzle['id']; ?>">
                                        <button type="submit" class="btn-small btn-danger" onclick="return confirm('Are you sure?')">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

            <?php elseif ($current_tab === 'math'): ?>
                <!-- Math Problems Tab -->
                <div class="form-section">
                    <h3><i class="fas fa-plus"></i> Add New Math Problem</h3>
                    <form method="POST">
                        <input type="hidden" name="action" value="add_math">
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="problem">Problem *</label>
                                <input type="text" id="problem" name="problem" required placeholder="e.g., 12 + 8 = ?">
                            </div>
                            <div class="form-group">
                                <label for="answer">Answer *</label>
                                <input type="number" id="answer" name="answer" step="0.01" required placeholder="e.g., 20">
                            </div>
                            <div class="form-group">
                                <label for="operation">Operation</label>
                                <select id="operation" name="operation">
                                    <option value="mixed">Mixed</option>
                                    <option value="addition">Addition</option>
                                    <option value="subtraction">Subtraction</option>
                                    <option value="multiplication">Multiplication</option>
                                    <option value="division">Division</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="difficulty">Difficulty</label>
                                <select id="difficulty" name="difficulty">
                                    <option value="easy">Easy</option>
                                    <option value="medium">Medium</option>
                                    <option value="hard">Hard</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="points">Points</label>
                                <input type="number" id="points" name="points" value="10" min="1">
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Add Math Problem
                        </button>
                    </form>
                </div>

                <div class="form-section">
                    <h3><i class="fas fa-list"></i> Existing Math Problems</h3>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Problem</th>
                                <th>Answer</th>
                                <th>Operation</th>
                                <th>Difficulty</th>
                                <th>Points</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($math_problems as $problem): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($problem['problem']); ?></td>
                                <td style="font-weight: bold;"><?php echo $problem['answer']; ?></td>
                                <td><?php echo ucfirst($problem['operation']); ?></td>
                                <td><span class="difficulty-badge difficulty-<?php echo $problem['difficulty']; ?>"><?php echo ucfirst($problem['difficulty']); ?></span></td>
                                <td><?php echo $problem['points']; ?></td>
                                <td>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="delete_math">
                                        <input type="hidden" name="id" value="<?php echo $problem['id']; ?>">
                                        <button type="submit" class="btn-small btn-danger" onclick="return confirm('Are you sure?')">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

            <?php elseif ($current_tab === 'settings'): ?>
                <!-- Settings Tab -->
                <div class="form-section">
                    <h3><i class="fas fa-cog"></i> Game Settings</h3>
                    <p style="color: #666; margin-bottom: 2rem;">Configure game settings including timers and difficulty levels.</p>
                    
                    <form method="POST" id="settingsForm">
                        <input type="hidden" name="action" value="update_settings">
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="quiz_timer">Quiz Question Timer (seconds)</label>
                                <input type="number" id="quiz_timer" name="quiz_timer" value="<?php echo $current_settings['quiz_timer']; ?>" min="5" max="60" required>
                                <small style="color: #666;">Time allowed per quiz question (5-60 seconds)</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="game_timer">Total Game Timer (seconds)</label>
                                <input type="number" id="game_timer" name="game_timer" value="<?php echo $current_settings['game_timer']; ?>" min="30" max="300" required>
                                <small style="color: #666;">Total time for entire game (30-300 seconds)</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="auto_advance">Auto-advance Questions</label>
                                <select id="auto_advance" name="auto_advance">
                                    <option value="1" <?php echo $current_settings['auto_advance'] == 1 ? 'selected' : ''; ?>>Yes - Auto advance after timer</option>
                                    <option value="0" <?php echo $current_settings['auto_advance'] == 0 ? 'selected' : ''; ?>>No - Wait for user selection</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="show_timer">Show Timer in Quiz</label>
                                <select id="show_timer" name="show_timer">
                                    <option value="1" <?php echo $current_settings['show_timer'] == 1 ? 'selected' : ''; ?>>Yes - Show countdown timer</option>
                                    <option value="0" <?php echo $current_settings['show_timer'] == 0 ? 'selected' : ''; ?>>No - Hide timer</option>
                                </select>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Settings
                        </button>
                    </form>
                </div>
                
                <div class="form-section">
                    <h3><i class="fas fa-info-circle"></i> Current Settings</h3>
                    <div style="background: #f8f9fa; padding: 1.5rem; border-radius: 10px; border-left: 4px solid var(--primary-color);">
                        <p><strong>Quiz Question Timer:</strong> <span id="currentQuizTimer"><?php echo $current_settings['quiz_timer']; ?></span> seconds</p>
                        <p><strong>Total Game Timer:</strong> <span id="currentGameTimer"><?php echo $current_settings['game_timer']; ?></span> seconds</p>
                        <p><strong>Auto-advance:</strong> <span id="currentAutoAdvance"><?php echo $current_settings['auto_advance'] == 1 ? 'Enabled' : 'Disabled'; ?></span></p>
                        <p><strong>Show Timer:</strong> <span id="currentShowTimer"><?php echo $current_settings['show_timer'] == 1 ? 'Enabled' : 'Disabled'; ?></span></p>
                    </div>
                </div>

            <?php elseif ($current_tab === 'import'): ?>
                <!-- Import Data Tab -->
                <div class="form-section">
                    <h3><i class="fas fa-download"></i> Import Sample Game Content</h3>
                    <p style="color: #666; margin-bottom: 2rem;">Import pre-made game content to quickly populate your database with sample questions, memory pairs, word puzzles, and math problems.</p>
                    
                    <div class="import-grid">
                        <div class="import-card">
                            <div class="import-icon">
                                <i class="fas fa-question-circle"></i>
                            </div>
                            <h4>Quiz Questions</h4>
                            <p>Import 5 sample quiz questions covering Geography, Science, Math, and Art topics.</p>
                            <form method="POST" class="import-form" action="admin.php">
                                <input type="hidden" name="action" value="import_data">
                                <input type="hidden" name="import_type" value="quiz">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-download"></i> Import Quiz Questions
                                </button>
                            </form>
                        </div>

                        <div class="import-card">
                            <div class="import-icon">
                                <i class="fas fa-brain"></i>
                            </div>
                            <h4>Memory Pairs</h4>
                            <p>Import 8 memory pairs with FontAwesome icons for matching games.</p>
                            <form method="POST" class="import-form" action="admin.php">
                                <input type="hidden" name="action" value="import_data">
                                <input type="hidden" name="import_type" value="memory">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-download"></i> Import Memory Pairs
                                </button>
                            </form>
                        </div>

                        <div class="import-card">
                            <div class="import-icon">
                                <i class="fas fa-puzzle-piece"></i>
                            </div>
                            <h4>Word Puzzles</h4>
                            <p>Import 8 word puzzles with hints covering educational and technology terms.</p>
                            <form method="POST" class="import-form" action="admin.php">
                                <input type="hidden" name="action" value="import_data">
                                <input type="hidden" name="import_type" value="word">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-download"></i> Import Word Puzzles
                                </button>
                            </form>
                        </div>

                        <div class="import-card">
                            <div class="import-icon">
                                <i class="fas fa-calculator"></i>
                            </div>
                            <h4>Math Problems</h4>
                            <p>Import 8 math problems covering addition, subtraction, multiplication, and division.</p>
                            <form method="POST" class="import-form" action="admin.php">
                                <input type="hidden" name="action" value="import_data">
                                <input type="hidden" name="import_type" value="math">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-download"></i> Import Math Problems
                                </button>
                            </form>
                        </div>
                    </div>

                    <div class="import-all-section">
                        <div class="import-all-card">
                            <div class="import-all-icon">
                                <i class="fas fa-rocket"></i>
                            </div>
                            <div class="import-all-content">
                                <h4>Import All Content</h4>
                                <p>Import all sample game content at once - perfect for getting started quickly!</p>
                                <form method="POST" class="import-form" action="admin.php">
                                    <input type="hidden" name="action" value="import_data">
                                    <input type="hidden" name="import_type" value="all">
                                    <button type="submit" class="btn btn-success btn-large">
                                        <i class="fas fa-rocket"></i> Import All Content
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="import-info">
                        <h4><i class="fas fa-info-circle"></i> Import Information</h4>
                        <ul>
                            <li>All imported content will be added to your existing database</li>
                            <li>No existing data will be overwritten</li>
                            <li>You can delete imported content individually from each tab</li>
                            <li>Imported content includes various difficulty levels</li>
                        </ul>
                    </div>
                </div>

            <?php elseif ($current_tab === 'import_export'): ?>
                <!-- Import/Export Files Tab -->
                <div class="form-section">
                    <h3><i class="fas fa-file-import"></i> Import/Export Files</h3>
                    <p style="color: #666; margin-bottom: 2rem;">Import data from Excel, CSV, or TXT files, or export your existing data to these formats.</p>
                    
                    <!-- Import Section -->
                    <div class="import-export-section">
                        <h4><i class="fas fa-upload"></i> Import from File</h4>
                        <div class="import-export-grid">
                            <div class="import-export-card">
                                <div class="import-export-icon">
                                    <i class="fas fa-file-csv"></i>
                                </div>
                                <h5>CSV/TXT Import</h5>
                                <p>Import data from CSV or TXT files with proper column formatting.</p>
                                <form method="POST" enctype="multipart/form-data" class="import-export-form" action="admin.php">
                                    <input type="hidden" name="action" value="import_file">
                                    <input type="hidden" name="file_type" value="csv">
                                    
                                    <div class="form-group">
                                        <label for="import_data_type">Data Type:</label>
                                        <div class="select-with-add">
                                            <select name="data_type" id="import_data_type" required>
                                                <option value="">Select Data Type</option>
                                                <option value="quiz">Quiz Questions</option>
                                                <option value="memory">Memory Pairs</option>
                                                <option value="word">Word Puzzles</option>
                                                <option value="math">Math Problems</option>
                                                <?php foreach ($custom_data_types as $custom_type): ?>
                                                    <option value="custom_<?php echo $custom_type['name']; ?>"><?php echo htmlspecialchars($custom_type['display_name']); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <button type="button" class="btn-add-custom" onclick="openCustomDataTypeModal()" title="Add Custom Data Type">
                                                <i class="fas fa-plus"></i>
                                            </button>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="import_file">Select File:</label>
                                        <input type="file" name="import_file" id="import_file" accept=".csv,.txt" required>
                                        <small>Supported formats: CSV, TXT (Max 5MB)</small>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-upload"></i> Import File
                                    </button>
                                </form>
                            </div>
                            
                            <div class="import-export-card">
                                <div class="import-export-icon">
                                    <i class="fas fa-file-excel"></i>
                                </div>
                                <h5>Excel Import</h5>
                                <p>Import data from Excel files (.xlsx, .xls). Note: For best results, save your Excel file as CSV format first.</p>
                                <form method="POST" enctype="multipart/form-data" class="import-export-form" action="admin.php">
                                    <input type="hidden" name="action" value="import_file">
                                    <input type="hidden" name="file_type" value="excel">
                                    
                                    <div class="form-group">
                                        <label for="import_data_type_excel">Data Type:</label>
                                        <div class="select-with-add">
                                            <select name="data_type" id="import_data_type_excel" required>
                                                <option value="">Select Data Type</option>
                                                <option value="quiz">Quiz Questions</option>
                                                <option value="memory">Memory Pairs</option>
                                                <option value="word">Word Puzzles</option>
                                                <option value="math">Math Problems</option>
                                                <?php foreach ($custom_data_types as $custom_type): ?>
                                                    <option value="custom_<?php echo $custom_type['name']; ?>"><?php echo htmlspecialchars($custom_type['display_name']); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <button type="button" class="btn-add-custom" onclick="openCustomDataTypeModal()" title="Add Custom Data Type">
                                                <i class="fas fa-plus"></i>
                                            </button>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="import_file_excel">Select File:</label>
                                        <input type="file" name="import_file" id="import_file_excel" accept=".xlsx,.xls" required>
                                        <small>Supported formats: XLSX, XLS (Max 5MB)</small>
                                        <small style="color: #666; display: block; margin-top: 0.25rem;">
                                            <strong>Tip:</strong> For best results, save your Excel file as CSV format first (File → Save As → CSV)
                                        </small>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-upload"></i> Import Excel
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Export Section -->
                    <div class="import-export-section">
                        <h4><i class="fas fa-download"></i> Export to File</h4>
                        <div class="import-export-grid">
                            <div class="import-export-card">
                                <div class="import-export-icon">
                                    <i class="fas fa-file-csv"></i>
                                </div>
                                <h5>CSV Export</h5>
                                <p>Export your data to CSV format for easy sharing and backup.</p>
                                <form method="POST" class="import-export-form" action="admin.php">
                                    <input type="hidden" name="action" value="export_data">
                                    <input type="hidden" name="file_format" value="csv">
                                    
                                    <div class="form-group">
                                        <label for="export_data_type_csv">Data Type:</label>
                                        <div class="select-with-add">
                                            <select name="export_type" id="export_data_type_csv" required>
                                                <option value="">Select Data Type</option>
                                                <option value="quiz">Quiz Questions</option>
                                                <option value="memory">Memory Pairs</option>
                                                <option value="word">Word Puzzles</option>
                                                <option value="math">Math Problems</option>
                                                <?php foreach ($custom_data_types as $custom_type): ?>
                                                    <option value="custom_<?php echo $custom_type['name']; ?>"><?php echo htmlspecialchars($custom_type['display_name']); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <button type="button" class="btn-add-custom" onclick="openCustomDataTypeModal()" title="Add Custom Data Type">
                                                <i class="fas fa-plus"></i>
                                            </button>
                                        </div>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-success">
                                        <i class="fas fa-download"></i> Export CSV
                                    </button>
                                </form>
                            </div>
                            
                            <div class="import-export-card">
                                <div class="import-export-icon">
                                    <i class="fas fa-file-alt"></i>
                                </div>
                                <h5>TXT Export</h5>
                                <p>Export your data to tab-separated TXT format.</p>
                                <form method="POST" class="import-export-form" action="admin.php">
                                    <input type="hidden" name="action" value="export_data">
                                    <input type="hidden" name="file_format" value="txt">
                                    
                                    <div class="form-group">
                                        <label for="export_data_type_txt">Data Type:</label>
                                        <div class="select-with-add">
                                            <select name="export_type" id="export_data_type_txt" required>
                                                <option value="">Select Data Type</option>
                                                <option value="quiz">Quiz Questions</option>
                                                <option value="memory">Memory Pairs</option>
                                                <option value="word">Word Puzzles</option>
                                                <option value="math">Math Problems</option>
                                                <?php foreach ($custom_data_types as $custom_type): ?>
                                                    <option value="custom_<?php echo $custom_type['name']; ?>"><?php echo htmlspecialchars($custom_type['display_name']); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <button type="button" class="btn-add-custom" onclick="openCustomDataTypeModal()" title="Add Custom Data Type">
                                                <i class="fas fa-plus"></i>
                                            </button>
                                        </div>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-success">
                                        <i class="fas fa-download"></i> Export TXT
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- File Format Information -->
                    <div class="import-export-info">
                        <h4><i class="fas fa-info-circle"></i> File Format Information</h4>
                        <div class="format-info-grid">
                            <div class="format-info-card">
                                <h5>CSV/TXT Import Format</h5>
                                <div class="format-examples">
                                    <h6>Quiz Questions:</h6>
                                    <code>Question,Option A,Option B,Option C,Option D,Correct Answer,Category,Difficulty,Points</code>
                                    
                                    <h6>Memory Pairs:</h6>
                                    <code>Pair Value,Display Text,Category,Difficulty</code>
                                    
                                    <h6>Word Puzzles:</h6>
                                    <code>Word,Hint,Category,Difficulty,Points</code>
                                    
                                    <h6>Math Problems:</h6>
                                    <code>Problem,Answer,Operation,Difficulty,Points</code>
                                </div>
                            </div>
                            
                            <div class="format-info-card">
                                <h5>Import Tips</h5>
                                <ul>
                                    <li>✅ CSV/TXT files work best for imports</li>
                                    <li>✅ Excel files (.xlsx, .xls) are supported but CSV is recommended</li>
                                    <li>✅ Save Excel files as CSV for best compatibility</li>
                                    <li>✅ First row should contain column headers</li>
                                    <li>✅ Maximum file size: 5MB</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Tab functionality to avoid CSP issues
        document.addEventListener('DOMContentLoaded', function() {
            const tabLinks = document.querySelectorAll('.tab-link');
            const tabContents = document.querySelectorAll('.tab-content');
            
            // Image preview functionality
            const imageUpload = document.getElementById('course_image_upload');
            const imageSelect = document.getElementById('course_image');
            const imagePreview = document.getElementById('image-preview');
            const previewImg = document.getElementById('preview-img');
            
            if (imageUpload) {
                imageUpload.addEventListener('change', function(e) {
                    const file = e.target.files[0];
                    if (file) {
                        const reader = new FileReader();
                        reader.onload = function(e) {
                            previewImg.src = e.target.result;
                            imagePreview.style.display = 'block';
                        };
                        reader.readAsDataURL(file);
                    }
                });
            }
            
            if (imageSelect) {
                imageSelect.addEventListener('change', function(e) {
                    const selectedImage = e.target.value;
                    if (selectedImage) {
                        previewImg.src = 'assets/images/' + selectedImage;
                        imagePreview.style.display = 'block';
                    }
                });
            }
            
            tabLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    // Remove active class from all tabs
                    tabLinks.forEach(l => l.classList.remove('active'));
                    tabContents.forEach(c => c.classList.remove('active'));
                    
                    // Add active class to clicked tab
                    this.classList.add('active');
                    
                    // Show corresponding content
                    const targetTab = this.getAttribute('href').substring(1);
                    const targetContent = document.getElementById(targetTab);
                    if (targetContent) {
                        targetContent.classList.add('active');
                    }
                });
            });
            
            // Initialize first tab as active
            if (tabLinks.length > 0 && tabContents.length > 0) {
                tabLinks[0].classList.add('active');
                tabContents[0].classList.add('active');
            }
        });
        
        // Auto-uppercase word input
        document.getElementById('word')?.addEventListener('input', function() {
            this.value = this.value.toUpperCase();
        });

        // Auto-remove success messages
        setTimeout(() => {
            const successMessage = document.querySelector('.message-success');
            if (successMessage) {
                successMessage.remove();
            }
        }, 5000);

        // AJAX form submission for all forms
        document.addEventListener('DOMContentLoaded', function() {
            // Check if browser is offline and warn user
            if (!navigator.onLine) {
                showMessage('⚠️ Browser is in offline mode. Some features may not work properly. Please go online for full functionality.', 'warning');
            }
            
            // Listen for online/offline events
            window.addEventListener('online', function() {
                showMessage('✅ Connection restored! You can now use all features.', 'success');
            });
            
            window.addEventListener('offline', function() {
                showMessage('⚠️ Connection lost. Some features may not work properly.', 'warning');
            });
            
            // Handle all form submissions with AJAX
            const forms = document.querySelectorAll('form');
            forms.forEach(form => {
                form.addEventListener('submit', function(e) {
                    // For import forms, allow fallback to regular submission if AJAX fails
                    const isImportForm = this.querySelector('input[name="action"][value="import_file"]');
                    
                    e.preventDefault();
                    
                    const formData = new FormData(this);
                    const submitBtn = this.querySelector('button[type="submit"]');
                    const originalText = submitBtn.innerHTML;
                    
                    // Show loading state
                    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
                    submitBtn.disabled = true;
                    
                    // Send AJAX request
                    const url = window.location.origin + window.location.pathname;
                    const controller = new AbortController();
                    const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout
                    
                    fetch(url, {
                        method: 'POST',
                        body: formData,
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        signal: controller.signal
                    })
                    .then(response => response.json())
                    .then(data => {
                        // Show message
                        if (data.success) {
                            showMessage(data.message, 'success');
                            // Reset form if it's an add form (but not import forms)
                            if (this.querySelector('input[name*="add_"]') && !isImportForm) {
                                this.reset();
                            }
                            // Reload the page to show updated data
                            setTimeout(() => {
                                window.location.reload();
                            }, 1000);
                        } else {
                            showMessage(data.message, 'error');
                        }
                    })
                    .catch(error => {
                        console.error('Network error:', error);
                        if (error.name === 'AbortError') {
                            showMessage('Request timed out. Please try again.', 'error');
                        } else if (error.name === 'TypeError' && (error.message.includes('fetch') || error.message.includes('Failed to fetch'))) {
                            // Check if browser is in offline mode
                            if (!navigator.onLine) {
                                showMessage('Browser is in offline mode. Please go online and try again.', 'error');
                            } else {
                            showMessage('Network error: Falling back to regular form submission...', 'warning');
                            // For import forms, try regular form submission as fallback
                            if (isImportForm) {
                                    showMessage('AJAX failed, trying regular form submission...', 'warning');
                                // Remove the event listener temporarily and submit normally
                                this.removeEventListener('submit', arguments.callee);
                                    setTimeout(() => {
                                this.submit();
                                    }, 1000);
                                return;
                            } else {
                                showMessage('Network error: Please check your server connection and try again.', 'error');
                                }
                            }
                        } else {
                            showMessage('An error occurred. Please try again.', 'error');
                        }
                    })
                    .finally(() => {
                        clearTimeout(timeoutId);
                        // Reset button state
                        submitBtn.innerHTML = originalText;
                        submitBtn.disabled = false;
                    });
                });
            });
        });

        // Function to show messages
        function showMessage(message, type) {
            // Remove existing messages
            const existingMessages = document.querySelectorAll('.message');
            existingMessages.forEach(msg => msg.remove());
            
            // Create new message
            const messageDiv = document.createElement('div');
            messageDiv.className = `message message-${type}`;
            messageDiv.textContent = message;
            
            // Insert after admin header
            const adminHeader = document.querySelector('.admin-header');
            if (adminHeader) {
            adminHeader.insertAdjacentElement('afterend', messageDiv);
            } else {
                // Fallback: insert at top of body
                document.body.insertBefore(messageDiv, document.body.firstChild);
            }
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                if (messageDiv.parentElement) {
                messageDiv.remove();
                }
            }, 5000);
        }
    </script>

    <!-- Custom Data Type Modal -->
    <div id="customDataTypeModal" class="modal" style="display: none;">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-plus"></i> Create Custom Data Type</h3>
                <button type="button" class="modal-close" onclick="closeCustomDataTypeModal()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <form id="customDataTypeForm" method="POST" action="admin.php">
                    <input type="hidden" name="action" value="create_custom_datatype">
                    
                    <div class="form-group">
                        <label for="custom_name">Name (Internal):</label>
                        <input type="text" name="name" id="custom_name" required placeholder="e.g., vocabulary">
                        <small>Internal name (lowercase, no spaces)</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="custom_display_name">Display Name:</label>
                        <input type="text" name="display_name" id="custom_display_name" required placeholder="e.g., Vocabulary Words">
                        <small>Name shown in dropdowns</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="custom_description">Description:</label>
                        <textarea name="description" id="custom_description" placeholder="Describe what this data type is for"></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label>Fields:</label>
                        <div id="fields-container">
                            <div class="field-row">
                                <input type="text" name="fields[0][name]" placeholder="Field Name" required>
                                <select name="fields[0][type]" required>
                                    <option value="">Select Type</option>
                                    <option value="VARCHAR(255)">Text (Short)</option>
                                    <option value="TEXT">Text (Long)</option>
                                    <option value="INT">Number</option>
                                    <option value="DECIMAL(10,2)">Decimal</option>
                                    <option value="DATE">Date</option>
                                    <option value="ENUM('easy','medium','hard')">Difficulty</option>
                                </select>
                                <label class="checkbox-label">
                                    <input type="checkbox" name="fields[0][required]"> Required
                                </label>
                                <input type="text" name="fields[0][default]" placeholder="Default Value">
                                <button type="button" class="btn-remove-field" onclick="removeField(this)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                        <button type="button" class="btn btn-secondary" onclick="addField()">
                            <i class="fas fa-plus"></i> Add Field
                        </button>
                    </div>
                    
                    <div class="modal-actions">
                        <button type="button" class="btn btn-secondary" onclick="closeCustomDataTypeModal()">Cancel</button>
                        <button type="submit" class="btn btn-primary">Create Data Type</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        let fieldIndex = 1;

        function openCustomDataTypeModal() {
            document.getElementById('customDataTypeModal').style.display = 'flex';
        }

        function closeCustomDataTypeModal() {
            document.getElementById('customDataTypeModal').style.display = 'none';
            document.getElementById('customDataTypeForm').reset();
            // Reset fields to just one
            const container = document.getElementById('fields-container');
            container.innerHTML = `
                <div class="field-row">
                    <input type="text" name="fields[0][name]" placeholder="Field Name" required>
                    <select name="fields[0][type]" required>
                        <option value="">Select Type</option>
                        <option value="VARCHAR(255)">Text (Short)</option>
                        <option value="TEXT">Text (Long)</option>
                        <option value="INT">Number</option>
                        <option value="DECIMAL(10,2)">Decimal</option>
                        <option value="DATE">Date</option>
                        <option value="ENUM('easy','medium','hard')">Difficulty</option>
                    </select>
                    <label class="checkbox-label">
                        <input type="checkbox" name="fields[0][required]"> Required
                    </label>
                    <input type="text" name="fields[0][default]" placeholder="Default Value">
                    <button type="button" class="btn-remove-field" onclick="removeField(this)">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
            fieldIndex = 1;
            console.log('Modal closed, fieldIndex reset to:', fieldIndex);
        }

        function addField() {
            const container = document.getElementById('fields-container');
            const fieldRow = document.createElement('div');
            fieldRow.className = 'field-row';
            fieldRow.innerHTML = `
                <input type="text" name="fields[${fieldIndex}][name]" placeholder="Field Name" required>
                <select name="fields[${fieldIndex}][type]" required>
                    <option value="">Select Type</option>
                    <option value="VARCHAR(255)">Text (Short)</option>
                    <option value="TEXT">Text (Long)</option>
                    <option value="INT">Number</option>
                    <option value="DECIMAL(10,2)">Decimal</option>
                    <option value="DATE">Date</option>
                    <option value="ENUM('easy','medium','hard')">Difficulty</option>
                </select>
                <label class="checkbox-label">
                    <input type="checkbox" name="fields[${fieldIndex}][required]"> Required
                </label>
                <input type="text" name="fields[${fieldIndex}][default]" placeholder="Default Value">
                <button type="button" class="btn-remove-field" onclick="removeField(this)">
                    <i class="fas fa-trash"></i>
                </button>
            `;
            container.appendChild(fieldRow);
            fieldIndex++;
            console.log('Added field with index:', fieldIndex - 1, 'Next index will be:', fieldIndex);
        }
        
        // Function to add custom data type to all dropdowns
        function addCustomDataTypeToDropdowns(name, displayName) {
            console.log('Adding custom data type to dropdowns:', name, displayName);
            
            // Find all select elements that contain custom data types
            const selects = document.querySelectorAll('select[name="data_type"], select[name="export_type"]');
            
            selects.forEach(select => {
                // Check if this select already has the custom data type
                const existingOption = select.querySelector(`option[value="custom_${name}"]`);
                if (!existingOption) {
                    // Create new option element
                    const option = document.createElement('option');
                    option.value = `custom_${name}`;
                    option.textContent = displayName;
                    
                    // Add it before the closing select tag (after the standard options)
                    select.appendChild(option);
                    console.log('Added option to select:', select.id, option.value, option.textContent);
                }
            });
        }
        
        // Function to refresh custom data types from server
        function refreshCustomDataTypes() {
            console.log('Refreshing custom data types from server...');
            
            // Fetch the current page to get updated custom data types
            fetch(window.location.href, {
                method: 'GET',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.text())
            .then(html => {
                // Create a temporary div to parse the HTML
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = html;
                
                // Find the custom data types in the new HTML
                const newSelects = tempDiv.querySelectorAll('select[name="data_type"], select[name="export_type"]');
                const currentSelects = document.querySelectorAll('select[name="data_type"], select[name="export_type"]');
                
                // Update each current select with the new options
                currentSelects.forEach((currentSelect, index) => {
                    if (newSelects[index]) {
                        const newCustomOptions = newSelects[index].querySelectorAll('option[value^="custom_"]');
                        
                        // Remove existing custom options
                        const existingCustomOptions = currentSelect.querySelectorAll('option[value^="custom_"]');
                        existingCustomOptions.forEach(option => option.remove());
                        
                        // Add new custom options
                        newCustomOptions.forEach(option => {
                            const newOption = option.cloneNode(true);
                            currentSelect.appendChild(newOption);
                        });
                        
                        console.log('Updated select:', currentSelect.id, 'with', newCustomOptions.length, 'custom options');
                    }
                });
            })
            .catch(error => {
                console.error('Error refreshing custom data types:', error);
            });
        }
        
        // Debug function to check custom data types
        function debugCustomDataTypes() {
            console.log('=== Custom Data Types Debug ===');
            const selects = document.querySelectorAll('select[name="data_type"], select[name="export_type"]');
            console.log('Found', selects.length, 'select elements');
            
            selects.forEach((select, index) => {
                console.log(`Select ${index + 1} (${select.id}):`);
                const customOptions = select.querySelectorAll('option[value^="custom_"]');
                console.log('  Custom options:', customOptions.length);
                customOptions.forEach(option => {
                    console.log(`    - ${option.value}: ${option.textContent}`);
                });
            });
        }
        
        // Make debug function available globally
        window.debugCustomDataTypes = debugCustomDataTypes;
        window.refreshCustomDataTypes = refreshCustomDataTypes;
        
        // Add debug button to the page (only in development)
        if (window.location.hostname === 'localhost') {
            const debugButton = document.createElement('button');
            debugButton.innerHTML = 'Debug Custom Data Types';
            debugButton.style.cssText = 'position: fixed; top: 10px; right: 10px; z-index: 10000; background: #007bff; color: white; border: none; padding: 10px; border-radius: 5px; cursor: pointer;';
            debugButton.onclick = function() {
                debugCustomDataTypes();
                refreshCustomDataTypes();
            };
            document.body.appendChild(debugButton);
        }
        
        // Function to show messages to user
        function showMessage(message, type) {
            // Remove existing messages
            const existingMessages = document.querySelectorAll('.message');
            existingMessages.forEach(msg => msg.remove());
            
            // Create new message
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${type}`;
            messageDiv.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 20px;
                border-radius: 5px;
                color: white;
                font-weight: bold;
                z-index: 10000;
                max-width: 400px;
            `;
            
            if (type === 'success') {
                messageDiv.style.backgroundColor = '#28a745';
            } else if (type === 'error') {
                messageDiv.style.backgroundColor = '#dc3545';
            } else if (type === 'warning') {
                messageDiv.style.backgroundColor = '#ffc107';
                messageDiv.style.color = '#212529';
            } else {
                messageDiv.style.backgroundColor = '#007bff';
            }
            
            messageDiv.textContent = message;
            document.body.appendChild(messageDiv);
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                if (messageDiv.parentNode) {
                    messageDiv.parentNode.removeChild(messageDiv);
                }
            }, 5000);
        }
        
        // Debug function to log form data before submission
        function debugFormData() {
            const form = document.getElementById('customDataTypeForm');
            const formData = new FormData(form);
            console.log('Form data before submission:');
            for (let [key, value] of formData.entries()) {
                console.log(key + ': ' + value);
            }
            
            // Also check if all required fields are filled
            const name = form.querySelector('input[name="name"]').value;
            const displayName = form.querySelector('input[name="display_name"]').value;
            const fields = form.querySelectorAll('input[name*="[name]"]');
            
            console.log('Name:', name);
            console.log('Display Name:', displayName);
            console.log('Fields count:', fields.length);
            
            fields.forEach((field, index) => {
                const fieldName = field.value;
                const fieldType = field.parentElement.querySelector('select[name*="[type]"]').value;
                console.log(`Field ${index}: name="${fieldName}", type="${fieldType}"`);
            });
        }

        function removeField(button) {
            const container = document.getElementById('fields-container');
            if (container.children.length > 1) {
                button.parentElement.remove();
            }
        }

        // Handle custom data type form submission
        document.getElementById('customDataTypeForm').addEventListener('submit', function(e) {
            // Allow fallback to regular form submission if AJAX fails
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            
            e.preventDefault();
            
            // Debug: Log form data before submission
            debugFormData();
            
            // Client-side validation
            const name = this.querySelector('input[name="name"]').value.trim();
            const displayName = this.querySelector('input[name="display_name"]').value.trim();
            const fields = this.querySelectorAll('input[name*="[name]"]');
            
            if (!name || !displayName) {
                showMessage('Please fill in the name and display name fields', 'error');
                return;
            }
            
            let validFields = 0;
            fields.forEach(field => {
                const fieldName = field.value.trim();
                const fieldType = field.parentElement.querySelector('select[name*="[type]"]').value;
                if (fieldName && fieldType) {
                    validFields++;
                }
            });
            
            if (validFields === 0) {
                showMessage('Please add at least one field with both name and type', 'error');
                return;
            }
            
            const formData = new FormData(this);
            
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating...';
            submitBtn.disabled = true;
            
            const url = window.location.origin + window.location.pathname;
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout
            
            fetch(url, {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: controller.signal
            })
            .then(response => {
                console.log('Response status:', response.status);
                console.log('Response headers:', response.headers);
                return response.text().then(text => {
                    console.log('Response text:', text);
                    try {
                        return JSON.parse(text);
                    } catch (e) {
                        console.error('JSON parse error:', e);
                        console.error('Response text:', text);
                        throw new Error('Invalid JSON response: ' + text.substring(0, 200));
                    }
                });
            })
            .then(data => {
                console.log('Parsed data:', data);
                if (data.success) {
                    showMessage(data.message, 'success');
                    closeCustomDataTypeModal();
                    
                    // Refresh custom data types from server
                    refreshCustomDataTypes();
                    
                    // Optional: Still reload after a delay to ensure everything is synced
                    setTimeout(() => {
                        window.location.reload();
                    }, 3000);
                } else {
                    showMessage(data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Network error:', error);
                if (error.name === 'AbortError') {
                    showMessage('Request timed out. Please try again.', 'error');
                } else if (error.name === 'TypeError' && error.message.includes('fetch')) {
                    showMessage('Network error: Falling back to regular form submission...', 'warning');
                    // Remove the event listener temporarily and submit normally
                    this.removeEventListener('submit', arguments.callee);
                    this.submit();
                    return;
                } else {
                    showMessage('An error occurred. Please try again.', 'error');
                }
            })
            .finally(() => {
                clearTimeout(timeoutId);
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            });
        });
    </script>
</body>
</html>