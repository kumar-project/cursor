<?php
require_once 'config.php';

echo "<h2>Fixing All Encoding Issues...</h2>";

try {
    // Set proper charset for the connection
    $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
    
    // Fix quiz questions
    echo "<h3>Fixing Quiz Questions...</h3>";
    $pdo->exec("DELETE FROM quiz_questions");
    
    $quiz_questions = [
        ['What is the capital of France?', 'London', 'Paris', 'Berlin', 'Madrid', 'B', 'Geography', 'easy', 10],
        ['Which planet is known as the Red Planet?', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'B', 'Science', 'easy', 10],
        ['What is 15 + 27?', '40', '42', '41', '43', 'B', 'Math', 'easy', 10],
        ['What is the speed of light in vacuum?', '300,000 km/s', '299,792,458 m/s', '186,000 miles/s', 'All of the above', 'D', 'Science', 'hard', 20],
        ['What is the smallest country in the world?', 'Monaco', 'Vatican City', 'San Marino', 'Liechtenstein', 'B', 'Geography', 'hard', 20],
        ['Who wrote "Romeo and Juliet"?', 'Charles Dickens', 'William Shakespeare', 'Mark Twain', 'Jane Austen', 'B', 'Literature', 'medium', 15],
        ['What is the chemical symbol for gold?', 'Go', 'Gd', 'Au', 'Ag', 'C', 'Science', 'medium', 15],
        ['Which ocean is the largest?', 'Atlantic', 'Indian', 'Pacific', 'Arctic', 'C', 'Geography', 'easy', 10]
    ];
    
    $stmt = $pdo->prepare("INSERT INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_answer, category, difficulty, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    foreach ($quiz_questions as $q) {
        $stmt->execute($q);
    }
    echo "✓ Fixed " . count($quiz_questions) . " quiz questions<br>";
    
    // Fix memory pairs
    echo "<h3>Fixing Memory Pairs...</h3>";
    $pdo->exec("DELETE FROM memory_pairs");
    
    $memory_pairs = [
        ['Apple', 'Red fruit', 'Fruits', 'easy'],
        ['Dog', 'Loyal pet', 'Animals', 'easy'],
        ['Sun', 'Bright star', 'Space', 'easy'],
        ['Book', 'Reading material', 'Education', 'easy'],
        ['Water', 'H2O', 'Science', 'medium'],
        ['Computer', 'Electronic device', 'Technology', 'medium'],
        ['Mountain', 'High landform', 'Geography', 'medium'],
        ['Music', 'Sound art', 'Arts', 'medium']
    ];
    
    $stmt = $pdo->prepare("INSERT INTO memory_pairs (pair_value, display_text, category, difficulty) VALUES (?, ?, ?, ?)");
    foreach ($memory_pairs as $mp) {
        $stmt->execute($mp);
    }
    echo "✓ Fixed " . count($memory_pairs) . " memory pairs<br>";
    
    // Fix word puzzles
    echo "<h3>Fixing Word Puzzles...</h3>";
    $pdo->exec("DELETE FROM word_puzzles");
    
    $word_puzzles = [
        ['PYTHON', 'A programming language named after a snake', 'Technology', 'medium', 15],
        ['ELEPHANT', 'The largest land animal', 'Animals', 'easy', 10],
        ['MOUNTAIN', 'A large landform that rises above surrounding land', 'Geography', 'easy', 10],
        ['BUTTERFLY', 'A colorful flying insect', 'Animals', 'easy', 10],
        ['COMPUTER', 'An electronic device for processing data', 'Technology', 'easy', 10],
        ['RAINBOW', 'A colorful arc in the sky after rain', 'Nature', 'easy', 10]
    ];
    
    $stmt = $pdo->prepare("INSERT INTO word_puzzles (word, hint, category, difficulty, points) VALUES (?, ?, ?, ?, ?)");
    foreach ($word_puzzles as $wp) {
        $stmt->execute($wp);
    }
    echo "✓ Fixed " . count($word_puzzles) . " word puzzles<br>";
    
    // Fix math problems
    echo "<h3>Fixing Math Problems...</h3>";
    $pdo->exec("DELETE FROM math_problems");
    
    $math_problems = [
        ['What is 25 + 17?', 42, 'addition', 'easy', 10],
        ['What is 100 - 35?', 65, 'subtraction', 'easy', 10],
        ['What is 8 × 7?', 56, 'multiplication', 'medium', 15],
        ['What is 144 ÷ 12?', 12, 'division', 'medium', 15],
        ['What is 15 + 25 - 10?', 30, 'mixed', 'medium', 15],
        ['What is 5 × 6 + 10?', 40, 'mixed', 'hard', 20],
        ['What is 100 ÷ 4 × 3?', 75, 'mixed', 'hard', 20],
        ['What is 20 + 30 - 15 + 5?', 40, 'mixed', 'hard', 20]
    ];
    
    $stmt = $pdo->prepare("INSERT INTO math_problems (problem, answer, operation, difficulty, points) VALUES (?, ?, ?, ?, ?)");
    foreach ($math_problems as $mp) {
        $stmt->execute($mp);
    }
    echo "✓ Fixed " . count($math_problems) . " math problems<br>";
    
    echo "<h3>✅ All Encoding Issues Fixed!</h3>";
    echo "All corrupted data has been replaced with clean, properly encoded content.<br>";
    echo "All tables now contain properly formatted data that will display correctly.<br>";
    echo "<a href='admin.php'>← Back to Admin Panel</a>";
    
} catch (Exception $e) {
    echo "<h3>❌ Error:</h3>";
    echo "Error fixing encoding: " . $e->getMessage();
    echo "<br><a href='admin.php'>← Back to Admin Panel</a>";
}
?>
