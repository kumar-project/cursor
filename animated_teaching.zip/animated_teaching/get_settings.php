<?php
require_once 'config.php';

header('Content-Type: application/json');

try {
    // Create settings table if it doesn't exist
    $pdo->exec("CREATE TABLE IF NOT EXISTS game_settings (
        id INT PRIMARY KEY AUTO_INCREMENT,
        setting_name VARCHAR(100) UNIQUE NOT NULL,
        setting_value VARCHAR(255) NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");
    
    // Default settings
    $default_settings = [
        'quiz_timer' => 10,
        'game_timer' => 60,
        'auto_advance' => 1,
        'show_timer' => 1
    ];
    
    // Load current settings
    $stmt = $pdo->query("SELECT setting_name, setting_value FROM game_settings");
    $settings_data = $stmt->fetchAll();
    
    $settings = $default_settings;
    foreach ($settings_data as $setting) {
        $settings[$setting['setting_name']] = intval($setting['setting_value']);
    }
    
    echo json_encode($settings);
    
} catch (PDOException $e) {
    echo json_encode([
        'quiz_timer' => 10,
        'game_timer' => 60,
        'auto_advance' => 1,
        'show_timer' => 1
    ]);
}
?>
