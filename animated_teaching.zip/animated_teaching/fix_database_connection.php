<?php
// Database connection fix for WAMP environment
// This script will help diagnose and fix database connection issues

echo "<h2>Database Connection Diagnostic Tool</h2>";

// Check PHP extensions
echo "<h3>PHP Extensions Check:</h3>";
echo "PDO Available: " . (extension_loaded('pdo') ? "✅ Yes" : "❌ No") . "<br>";
echo "PDO MySQL Available: " . (extension_loaded('pdo_mysql') ? "✅ Yes" : "❌ No") . "<br>";
echo "MySQLi Available: " . (extension_loaded('mysqli') ? "✅ Yes" : "❌ No") . "<br>";

// Test MySQLi connection
echo "<h3>MySQLi Connection Test:</h3>";
try {
    $mysqli = new mysqli('localhost', 'root', '');
    if ($mysqli->connect_error) {
        echo "❌ MySQLi connection failed: " . $mysqli->connect_error . "<br>";
    } else {
        echo "✅ MySQLi connection successful!<br>";
        
        // Check if database exists
        $result = $mysqli->query("SHOW DATABASES LIKE 'animated_teaching'");
        if ($result->num_rows > 0) {
            echo "✅ Database 'animated_teaching' exists<br>";
        } else {
            echo "❌ Database 'animated_teaching' does not exist<br>";
            echo "Creating database...<br>";
            if ($mysqli->query("CREATE DATABASE animated_teaching")) {
                echo "✅ Database created successfully!<br>";
            } else {
                echo "❌ Failed to create database: " . $mysqli->error . "<br>";
            }
        }
        
        $mysqli->close();
    }
} catch (Exception $e) {
    echo "❌ MySQLi connection error: " . $e->getMessage() . "<br>";
}

// Test PDO connection
echo "<h3>PDO Connection Test:</h3>";
try {
    $pdo = new PDO('mysql:host=localhost;dbname=animated_teaching;charset=utf8mb4', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "✅ PDO connection successful!<br>";
    
    // Check if users table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'users'");
    if ($stmt->rowCount() > 0) {
        echo "✅ Users table exists<br>";
    } else {
        echo "❌ Users table does not exist<br>";
    }
    
} catch (PDOException $e) {
    echo "❌ PDO connection failed: " . $e->getMessage() . "<br>";
}

echo "<h3>Solutions:</h3>";
echo "<ol>";
echo "<li><strong>Enable PDO MySQL Extension:</strong><br>";
echo "   - Open WAMP Control Panel<br>";
echo "   - Click on PHP → PHP Extensions<br>";
echo "   - Make sure 'pdo_mysql' is checked<br>";
echo "   - Restart WAMP services</li><br>";

echo "<li><strong>Alternative: Use MySQLi instead of PDO</strong><br>";
echo "   - The system can be modified to use MySQLi instead of PDO<br>";
echo "   - This requires updating the config.php file</li><br>";

echo "<li><strong>Manual Database Setup:</strong><br>";
echo "   - Open phpMyAdmin (http://localhost/phpmyadmin)<br>";
echo "   - Create database 'animated_teaching'<br>";
echo "   - Import the complete_database_schema.sql file</li>";
echo "</ol>";

echo "<h3>Quick Fix Options:</h3>";
echo "<a href='create_database_mysqli.php' style='background: #007cba; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px; display: inline-block;'>Create Database with MySQLi</a>";
echo "<a href='setup_database.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px; display: inline-block;'>Setup Database Tables</a>";
echo "<a href='register.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px; display: inline-block;'>Back to Registration</a>";
?>
