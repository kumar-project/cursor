<?php
require_once 'config.php';

// Get custom data types
$custom_data_types = [];
try {
    $stmt = $pdo->query("SELECT * FROM custom_data_types ORDER BY display_name");
    $custom_data_types = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<h2>Custom Data Types in Database</h2>";
    echo "<p>Found " . count($custom_data_types) . " custom data types:</p>";
    
    if (empty($custom_data_types)) {
        echo "<p style='color: orange;'>No custom data types found in database.</p>";
    } else {
        echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
        echo "<tr><th>ID</th><th>Name</th><th>Display Name</th><th>Table Name</th><th>Description</th><th>Created</th></tr>";
        foreach ($custom_data_types as $type) {
            echo "<tr>";
            echo "<td>" . $type['id'] . "</td>";
            echo "<td>" . htmlspecialchars($type['name']) . "</td>";
            echo "<td>" . htmlspecialchars($type['display_name']) . "</td>";
            echo "<td>" . htmlspecialchars($type['table_name']) . "</td>";
            echo "<td>" . htmlspecialchars($type['description']) . "</td>";
            echo "<td>" . $type['created_at'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
} catch (PDOException $e) {
    echo "<p style='color: red;'>Error loading custom data types: " . $e->getMessage() . "</p>";
}

echo "<h2>Test Dropdown Generation</h2>";
echo "<p>This is how the dropdown would look:</p>";

echo "<select name='test_data_type' id='test_data_type'>";
echo "<option value=''>Select Data Type</option>";
echo "<option value='quiz'>Quiz Questions</option>";
echo "<option value='memory'>Memory Pairs</option>";
echo "<option value='word'>Word Puzzles</option>";
echo "<option value='math'>Math Problems</option>";
foreach ($custom_data_types as $custom_type) {
    echo "<option value='custom_" . $custom_type['name'] . "'>" . htmlspecialchars($custom_type['display_name']) . "</option>";
}
echo "</select>";

echo "<h2>Raw Custom Data Types Array</h2>";
echo "<pre>";
print_r($custom_data_types);
echo "</pre>";
?>
