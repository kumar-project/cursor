<?php
require_once 'config.php';

echo "<h2>Fixing Quiz Import Issue</h2>";

try {
    // First, let's check what tables exist
    echo "<h3>Step 1: Checking existing tables</h3>";
    $stmt = $pdo->query("SHOW TABLES LIKE 'quiz_questions'");
    if ($stmt->rowCount() > 0) {
        echo "✓ quiz_questions table exists<br>";
        
        // Check the structure
        $stmt = $pdo->query("DESCRIBE quiz_questions");
        $columns = $stmt->fetchAll();
        echo "Current table structure:<br>";
        foreach ($columns as $column) {
            echo "- " . $column['Field'] . " (" . $column['Type'] . ")<br>";
        }
    } else {
        echo "✗ quiz_questions table does not exist<br>";
    }
    
    echo "<h3>Step 2: Creating the correct table structure</h3>";
    
    // Drop the existing table if it has the wrong structure
    $pdo->exec("DROP TABLE IF EXISTS quiz_questions");
    echo "✓ Dropped existing table<br>";
    
    // Create the correct table structure for the game system
    $create_table_sql = "
        CREATE TABLE quiz_questions (
            id INT PRIMARY KEY AUTO_INCREMENT,
            question TEXT NOT NULL,
            option_a VARCHAR(255) NOT NULL,
            option_b VARCHAR(255) NOT NULL,
            option_c VARCHAR(255) NOT NULL,
            option_d VARCHAR(255) NOT NULL,
            correct_answer ENUM('A', 'B', 'C', 'D') NOT NULL,
            points INT DEFAULT 10,
            difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
            category VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
    ";
    
    $pdo->exec($create_table_sql);
    echo "✓ Created new quiz_questions table with correct structure<br>";
    
    echo "<h3>Step 3: Importing sample quiz questions</h3>";
    
    // Sample quiz data
    $quizData = [
        ['What is the capital of France?', 'London', 'Berlin', 'Paris', 'Madrid', 'C', 'Geography', 'easy', 10],
        ['Which planet is known as the Red Planet?', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'B', 'Science', 'easy', 10],
        ['What is 15 + 27?', '40', '42', '41', '43', 'B', 'Math', 'easy', 10],
        ['Who painted the Mona Lisa?', 'Van Gogh', 'Picasso', 'Da Vinci', 'Michelangelo', 'C', 'Art', 'medium', 15],
        ['What is the largest ocean on Earth?', 'Atlantic', 'Indian', 'Pacific', 'Arctic', 'C', 'Geography', 'easy', 10],
        ['What is the chemical symbol for gold?', 'Go', 'Gd', 'Au', 'Ag', 'C', 'Science', 'medium', 15],
        ['Which country has the most population?', 'India', 'China', 'USA', 'Brazil', 'B', 'Geography', 'medium', 15],
        ['What is 8 × 7?', '54', '56', '58', '60', 'B', 'Math', 'easy', 10]
    ];
    
    $stmt = $pdo->prepare("INSERT INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_answer, category, difficulty, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    $imported = 0;
    foreach ($quizData as $data) {
        if ($stmt->execute($data)) {
            $imported++;
        }
    }
    
    echo "✓ Successfully imported $imported quiz questions!<br>";
    
    echo "<h3>Step 4: Verifying the import</h3>";
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM quiz_questions");
    $result = $stmt->fetch();
    echo "✓ Total quiz questions in database: " . $result['count'] . "<br>";
    
    echo "<h3>🎉 Quiz Import Fixed Successfully!</h3>";
    echo "<p>Your quiz import should now work properly. You can:</p>";
    echo "<ul>";
    echo "<li><a href='admin.php?tab=quiz'>Go to Admin Panel - Quiz Questions</a></li>";
    echo "<li><a href='admin.php?tab=import'>Go to Admin Panel - Import Data</a></li>";
    echo "<li><a href='index.php'>Go to Home Page to test the quiz</a></li>";
    echo "</ul>";
    
} catch (PDOException $e) {
    echo "✗ Database error: " . $e->getMessage() . "<br>";
    echo "Error code: " . $e->getCode() . "<br>";
} catch (Exception $e) {
    echo "✗ General error: " . $e->getMessage() . "<br>";
}
?>
