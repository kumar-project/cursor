<?php
// Test page for import/export functionality
require_once 'config.php';

echo "<h1>Import/Export Test Page</h1>";
echo "<p>This page tests the import/export functionality.</p>";

// Test database connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "<p style='color: green;'>✅ Database connection successful!</p>";
} catch (PDOException $e) {
    echo "<p style='color: red;'>❌ Database connection failed: " . $e->getMessage() . "</p>";
    exit;
}

// Test table existence
$tables = ['quiz_questions', 'memory_pairs', 'word_puzzles', 'math_problems'];
foreach ($tables as $table) {
    try {
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM $table");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<p style='color: green;'>✅ Table '$table' exists with {$result['count']} records</p>";
    } catch (PDOException $e) {
        echo "<p style='color: red;'>❌ Table '$table' does not exist or has errors</p>";
    }
}

echo "<hr>";
echo "<h2>Sample Files Created:</h2>";
echo "<ul>";
echo "<li><a href='sample_quiz_questions.csv' target='_blank'>sample_quiz_questions.csv</a></li>";
echo "<li><a href='sample_memory_pairs.csv' target='_blank'>sample_memory_pairs.csv</a></li>";
echo "<li><a href='sample_word_puzzles.csv' target='_blank'>sample_word_puzzles.csv</a></li>";
echo "<li><a href='sample_math_problems.csv' target='_blank'>sample_math_problems.csv</a></li>";
echo "</ul>";

echo "<hr>";
echo "<h2>Next Steps:</h2>";
echo "<ol>";
echo "<li>Go to <a href='admin.php?tab=import_export'>Admin Panel → Import/Export Files</a></li>";
echo "<li>Try importing the sample CSV files</li>";
echo "<li>Try exporting data to CSV/TXT formats</li>";
echo "<li>Check the database to verify imports worked</li>";
echo "</ol>";

echo "<hr>";
echo "<p><strong>Note:</strong> Excel import requires PhpSpreadsheet library. For now, convert Excel files to CSV format.</p>";
?>
