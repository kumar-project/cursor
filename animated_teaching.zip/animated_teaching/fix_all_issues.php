<!DOCTYPE html>
<html>
<head>
    <title>Fix All Issues</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
        .container { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: green; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .error { color: red; background: #f8d7da; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .warning { color: orange; background: #fff3cd; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .btn { background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 10px 5px; }
    </style>
</head>
<body>
<div class='container'>
<h2><i class="fas fa-tools"></i> Fix All Issues</h2>

<?php
require_once 'config.php';

echo "<h3>1. Database Connection Test</h3>";
try {
    $pdo->query("SELECT 1");
    echo "<div class='success'>✅ Database connection successful</div>";
} catch (PDOException $e) {
    echo "<div class='error'>❌ Database connection failed: " . $e->getMessage() . "</div>";
    echo "<div class='warning'>Please check your WAMP/MySQL is running and database credentials are correct.</div>";
    exit;
}

echo "<h3>2. Creating Missing Tables</h3>";

// Create courses table if it doesn't exist
try {
    $sql = "CREATE TABLE IF NOT EXISTS courses (
        id INT PRIMARY KEY AUTO_INCREMENT,
        title VARCHAR(200) NOT NULL,
        description TEXT,
        instructor_id INT,
        difficulty_level ENUM('beginner', 'intermediate', 'advanced') DEFAULT 'beginner',
        total_lessons INT DEFAULT 0,
        course_image VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    $pdo->exec($sql);
    echo "<div class='success'>✅ Courses table created/verified</div>";
} catch (PDOException $e) {
    echo "<div class='error'>❌ Error creating courses table: " . $e->getMessage() . "</div>";
}

// Create game tables
$game_tables = [
    'quiz_questions' => "CREATE TABLE IF NOT EXISTS quiz_questions (
        id INT PRIMARY KEY AUTO_INCREMENT,
        question TEXT NOT NULL,
        option_a VARCHAR(255) NOT NULL,
        option_b VARCHAR(255) NOT NULL,
        option_c VARCHAR(255) NOT NULL,
        option_d VARCHAR(255) NOT NULL,
        correct_answer ENUM('A', 'B', 'C', 'D') NOT NULL,
        points INT DEFAULT 10,
        difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
        category VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    
    'memory_pairs' => "CREATE TABLE IF NOT EXISTS memory_pairs (
        id INT PRIMARY KEY AUTO_INCREMENT,
        pair_value VARCHAR(255) NOT NULL,
        display_text VARCHAR(255) NOT NULL,
        category VARCHAR(100),
        difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    
    'word_puzzles' => "CREATE TABLE IF NOT EXISTS word_puzzles (
        id INT PRIMARY KEY AUTO_INCREMENT,
        word VARCHAR(255) NOT NULL,
        hint TEXT NOT NULL,
        category VARCHAR(100),
        difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
        points INT DEFAULT 15,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    
    'math_problems' => "CREATE TABLE IF NOT EXISTS math_problems (
        id INT PRIMARY KEY AUTO_INCREMENT,
        problem TEXT NOT NULL,
        answer DECIMAL(10,2) NOT NULL,
        operation ENUM('addition', 'subtraction', 'multiplication', 'division', 'mixed') DEFAULT 'mixed',
        difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
        points INT DEFAULT 10,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )"
];

foreach ($game_tables as $table_name => $sql) {
    try {
        $pdo->exec($sql);
        echo "<div class='success'>✅ $table_name table created/verified</div>";
    } catch (PDOException $e) {
        echo "<div class='error'>❌ Error creating $table_name table: " . $e->getMessage() . "</div>";
    }
}

echo "<h3>3. Adding Sample Data</h3>";

// Add sample courses if none exist
try {
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM courses");
    $result = $stmt->fetch();
    
    if ($result['count'] == 0) {
        $sample_courses = [
            [
                'title' => 'Interactive PHP Programming',
                'description' => 'Learn PHP through animated tutorials and interactive exercises',
                'difficulty_level' => 'beginner',
                'total_lessons' => 12,
                'course_image' => 'php-course.jpg'
            ],
            [
                'title' => 'Web Development Fundamentals',
                'description' => 'Master HTML, CSS, and JavaScript with gamified learning',
                'difficulty_level' => 'beginner',
                'total_lessons' => 15,
                'course_image' => 'webdev-course.jpg'
            ],
            [
                'title' => 'Database Design',
                'description' => 'Learn how to design efficient and scalable database systems',
                'difficulty_level' => 'intermediate',
                'total_lessons' => 10,
                'course_image' => 'database-course.jpg'
            ]
        ];
        
        $stmt = $pdo->prepare("INSERT INTO courses (title, description, difficulty_level, total_lessons, course_image) VALUES (?, ?, ?, ?, ?)");
        
        foreach ($sample_courses as $course) {
            $stmt->execute([
                $course['title'],
                $course['description'],
                $course['difficulty_level'],
                $course['total_lessons'],
                $course['course_image']
            ]);
        }
        
        echo "<div class='success'>✅ Sample courses added</div>";
    } else {
        echo "<div class='info'>ℹ️ Courses already exist (" . $result['count'] . " courses)</div>";
    }
} catch (PDOException $e) {
    echo "<div class='error'>❌ Error adding sample courses: " . $e->getMessage() . "</div>";
}

// Add sample game data
$sample_data = [
    "INSERT IGNORE INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_answer, category, difficulty) VALUES
    ('What is the capital of France?', 'London', 'Berlin', 'Paris', 'Madrid', 'C', 'Geography', 'easy'),
    ('Which planet is known as the Red Planet?', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'B', 'Science', 'easy'),
    ('What is 15 + 27?', '40', '42', '41', '43', 'B', 'Math', 'easy')",
    
    "INSERT IGNORE INTO memory_pairs (pair_value, display_text, category, difficulty) VALUES
    ('<i class=\"fas fa-bullseye\"></i>', 'Target', 'Icon', 'easy'),
    ('<i class=\"fas fa-gamepad\"></i>', 'Game Controller', 'Icon', 'easy'),
    ('<i class=\"fas fa-palette\"></i>', 'Artist Palette', 'Icon', 'easy'),
    ('<i class=\"fas fa-tent\"></i>', 'Circus Tent', 'Icon', 'easy')",
    
    "INSERT IGNORE INTO word_puzzles (word, hint, category, difficulty) VALUES
    ('EDUCATION', 'The process of learning', 'General', 'easy'),
    ('KNOWLEDGE', 'Information and understanding', 'General', 'medium'),
    ('TEACHER', 'Someone who educates', 'General', 'easy')",
    
    "INSERT IGNORE INTO math_problems (problem, answer, operation, difficulty) VALUES
    ('12 + 8 = ?', 20, 'addition', 'easy'),
    ('25 - 7 = ?', 18, 'subtraction', 'easy'),
    ('6 × 4 = ?', 24, 'multiplication', 'easy'),
    ('36 ÷ 6 = ?', 6, 'division', 'easy')"
];

foreach ($sample_data as $sql) {
    try {
        $pdo->exec($sql);
    } catch (PDOException $e) {
        echo "<div class='warning'>⚠️ Error adding sample data: " . $e->getMessage() . "</div>";
    }
}

echo "<div class='success'>✅ Sample game data added</div>";

echo "<h3>4. Final Verification</h3>";

// Check all tables
$tables = ['courses', 'quiz_questions', 'memory_pairs', 'word_puzzles', 'math_problems'];
foreach ($tables as $table) {
    try {
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM $table");
        $result = $stmt->fetch();
        echo "<div class='success'>✅ $table: " . $result['count'] . " records</div>";
    } catch (PDOException $e) {
        echo "<div class='error'>❌ $table: " . $e->getMessage() . "</div>";
    }
}

echo "<h3>5. Application Status</h3>";
echo "<div class='success'>";
echo "✅ Database tables created/verified<br>";
echo "✅ Sample data added<br>";
echo "✅ Application should now work properly<br>";
echo "</div>";

echo "<h3>6. Next Steps</h3>";
echo "<div class='info'>";
echo "1. <strong>Test the main application:</strong> <a href='index.php' class='btn'>Go to Main App</a><br>";
echo "2. <strong>Test the admin panel:</strong> <a href='admin.php' class='btn'>Go to Admin Panel</a><br>";
echo "3. <strong>Add more courses:</strong> Use the 'Add Course' section on the main page<br>";
echo "4. <strong>Add game content:</strong> Use the admin panel to add quiz questions, memory pairs, etc.<br>";
echo "</div>";

echo "<h3>7. Troubleshooting</h3>";
echo "<div class='info'>";
echo "If you still experience issues:<br>";
echo "• Check browser console (F12) for JavaScript errors<br>";
echo "• Ensure WAMP/MySQL is running<br>";
echo "• Clear browser cache and refresh the page<br>";
echo "• Check that all files are in the correct directory<br>";
echo "</div>";

?>

</div>
</body>
</html>
