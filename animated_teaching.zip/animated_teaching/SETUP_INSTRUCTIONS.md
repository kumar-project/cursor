# Database Setup Instructions

## Issue Fixed
The error "Column not found: 1054 Unknown column 'created_at'" has been resolved by:

1. **Updated admin.php** to use `ORDER BY id DESC` instead of `ORDER BY created_at DESC`
2. **Added error handling** to gracefully handle missing tables
3. **Created setup_database.php** for easy database table creation

## How to Fix

### Option 1: Use the Setup Page (Recommended)
1. Visit: `http://localhost/apna%20school/setup_database.php`
2. Click "Setup Game Content Tables" to create the required tables
3. Click "Setup Badges System" to create the badges system tables
4. Visit `admin.php` - it will now work properly

### Option 2: Manual Database Setup
1. Open phpMyAdmin or your MySQL client
2. Select the `animated_teaching` database
3. Run the SQL commands from `setup_tables.sql` starting from "-- Game Content Tables"

### Option 3: Command Line (if PDO drivers are available)
```bash
php setup_admin_tables.php
php setup_badges.php
```

## What Was Fixed

### 1. Admin.php Changes
- Changed `ORDER BY created_at DESC` to `ORDER BY id DESC`
- Added table existence check
- Added error handling for missing tables
- Automatic redirect to setup page if tables don't exist

### 2. New Files Created
- `setup_database.php` - Web-based setup interface
- `setup_admin_tables.php` - Command-line setup for game tables
- `setup_badges.php` - Command-line setup for badges system

### 3. Error Prevention
- Graceful handling of missing database tables
- Clear error messages and setup instructions
- Automatic redirection to setup page

## Next Steps
1. Visit the setup page to create the required tables
2. The admin panel will work properly after setup
3. You can start adding quiz questions, memory pairs, word puzzles, and math problems
4. The badges system will track user progress and award badges automatically

## Features Available After Setup
- ✅ Admin panel for managing game content
- ✅ Badges & rewards system
- ✅ Progress tracking
- ✅ Leaderboard
- ✅ Real-time notifications
- ✅ AJAX-powered interface