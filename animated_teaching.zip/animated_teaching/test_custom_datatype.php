<?php
require_once 'config.php';

echo "<h2>Testing Custom Data Type Creation...</h2>";

try {
    // Test creating a simple custom data type
    $name = 'test_type';
    $display_name = 'Test Type';
    $description = 'A test custom data type';
    $table_name = 'custom_test_type';
    
    // Create the custom data type record
    $stmt = $pdo->prepare("INSERT INTO custom_data_types (name, display_name, table_name, description, fields) VALUES (?, ?, ?, ?, ?)");
    $fields_json = json_encode([
        ['name' => 'title', 'type' => 'VARCHAR(255)', 'required' => true, 'default' => ''],
        ['name' => 'description', 'type' => 'TEXT', 'required' => false, 'default' => '']
    ]);
    
    $stmt->execute([$name, $display_name, $table_name, $description, $fields_json]);
    echo "✓ Custom data type record created<br>";
    
    // Create the actual table
    $create_table_sql = "CREATE TABLE IF NOT EXISTS `$table_name` (
        id INT PRIMARY KEY AUTO_INCREMENT,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";
    
    $pdo->exec($create_table_sql);
    echo "✓ Custom table created successfully<br>";
    
    // Test inserting data
    $stmt = $pdo->prepare("INSERT INTO `$table_name` (title, description) VALUES (?, ?)");
    $stmt->execute(['Test Title', 'Test Description']);
    echo "✓ Test data inserted successfully<br>";
    
    // Clean up
    $pdo->exec("DROP TABLE IF EXISTS `$table_name`");
    $stmt = $pdo->prepare("DELETE FROM custom_data_types WHERE name = ?");
    $stmt->execute([$name]);
    echo "✓ Test data cleaned up<br>";
    
    echo "<h3>✅ Custom Data Type Creation Test Passed!</h3>";
    echo "The custom data type functionality is working correctly.<br>";
    echo "<a href='admin.php'>← Back to Admin Panel</a>";
    
} catch (Exception $e) {
    echo "<h3>❌ Test Failed:</h3>";
    echo "Error: " . $e->getMessage();
    echo "<br><a href='admin.php'>← Back to Admin Panel</a>";
}
?>