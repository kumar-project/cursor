<?php
// Check what's in the database
$host = 'localhost';
$dbname = 'animated_teaching';
$username = 'root';
$password = '';

echo "<h2>🔍 Database Check</h2>";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<p>✅ Connected to database successfully</p>";
    
    // Check table structure
    echo "<h3>📋 Table Structure:</h3>";
    $stmt = $pdo->query("DESCRIBE users");
    $columns = $stmt->fetchAll();
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    foreach ($columns as $column) {
        echo "<tr>";
        echo "<td>" . $column['Field'] . "</td>";
        echo "<td>" . $column['Type'] . "</td>";
        echo "<td>" . $column['Null'] . "</td>";
        echo "<td>" . $column['Key'] . "</td>";
        echo "<td>" . ($column['Default'] ?? 'NULL') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Check existing users
    echo "<h3>👥 Current Users:</h3>";
    $stmt = $pdo->query("SELECT id, username, email, roll_number, full_name, user_role, is_active FROM users ORDER BY id");
    $users = $stmt->fetchAll();
    
    if (empty($users)) {
        echo "<p>❌ No users found in database</p>";
        echo "<p><strong>This is why login fails!</strong></p>";
    } else {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>ID</th><th>Username</th><th>Email</th><th>Roll Number</th><th>Full Name</th><th>Role</th><th>Active</th></tr>";
        foreach ($users as $user) {
            echo "<tr>";
            echo "<td>" . $user['id'] . "</td>";
            echo "<td>" . ($user['username'] ?? 'NULL') . "</td>";
            echo "<td>" . ($user['email'] ?? 'NULL') . "</td>";
            echo "<td>" . ($user['roll_number'] ?? 'NULL') . "</td>";
            echo "<td>" . $user['full_name'] . "</td>";
            echo "<td>" . $user['user_role'] . "</td>";
            echo "<td>" . ($user['is_active'] ? 'Yes' : 'No') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    // Check if STU001 exists
    echo "<h3>🎯 Looking for STU001:</h3>";
    $stmt = $pdo->prepare("SELECT * FROM users WHERE roll_number = 'STU001'");
    $stmt->execute();
    $stu001 = $stmt->fetch();
    
    if ($stu001) {
        echo "<p>✅ STU001 found in database!</p>";
        echo "<p><strong>Details:</strong></p>";
        echo "<ul>";
        echo "<li>ID: " . $stu001['id'] . "</li>";
        echo "<li>Full Name: " . $stu001['full_name'] . "</li>";
        echo "<li>Role: " . $stu001['user_role'] . "</li>";
        echo "<li>Active: " . ($stu001['is_active'] ? 'Yes' : 'No') . "</li>";
        echo "<li>Password: " . ($stu001['password'] ? 'Set' : 'NULL') . "</li>";
        echo "</ul>";
    } else {
        echo "<p>❌ STU001 NOT found in database!</p>";
        echo "<p><strong>This is why login fails!</strong></p>";
    }
    
    echo "<h3>🔧 Quick Actions:</h3>";
    echo "<p><a href='quick_fix.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Run Quick Fix</a></p>";
    echo "<p><a href='login.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Go to Login</a></p>";
    
} catch (PDOException $e) {
    echo "<h2>❌ Database Connection Error:</h2>";
    echo "<p><strong>Error:</strong> " . $e->getMessage() . "</p>";
    echo "<p><strong>Possible solutions:</strong></p>";
    echo "<ul>";
    echo "<li>Make sure WAMP/XAMPP is running</li>";
    echo "<li>Start MySQL service</li>";
    echo "<li>Check if 'animated_teaching' database exists</li>";
    echo "<li>Verify database credentials</li>";
    echo "</ul>";
}
?>
