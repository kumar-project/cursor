<?php
require_once 'config.php';

$error = '';
$success = '';
$current_tab = $_GET['tab'] ?? 'courses';

// Handle course submission
if ($_POST['action'] ?? '' === 'add_course') {
    $title = sanitize_input($_POST['title'] ?? '');
    $description = sanitize_input($_POST['description'] ?? '');
    $difficulty_level = sanitize_input($_POST['difficulty_level'] ?? 'beginner');
    $total_lessons = intval($_POST['total_lessons'] ?? 0);
    $course_image = sanitize_input($_POST['course_image'] ?? 'default-course.jpg');
    
    $response = ['success' => false, 'message' => '', 'course' => null];
    
    if (empty($title)) {
        $response['message'] = 'Course title is required.';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO courses (title, description, difficulty_level, total_lessons, course_image) VALUES (?, ?, ?, ?, ?)");
            if ($stmt->execute([$title, $description, $difficulty_level, $total_lessons, $course_image])) {
                $response['success'] = true;
                $response['message'] = 'Course added successfully!';
                $response['course'] = [
                    'id' => $pdo->lastInsertId(),
                    'title' => $title,
                    'description' => $description,
                    'difficulty_level' => $difficulty_level,
                    'total_lessons' => $total_lessons,
                    'course_image' => $course_image
                ];
            } else {
                $response['message'] = 'Failed to add course.';
            }
        } catch (PDOException $e) {
            $response['message'] = 'Database error: ' . $e->getMessage();
        }
    }
    
    if ($_POST['ajax'] ?? false) {
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    } else {
        if ($response['success']) {
            $success = $response['message'];
        } else {
            $error = $response['message'];
        }
    }
}

// Get courses
try {
    $courses_stmt = $pdo->query("SELECT * FROM courses ORDER BY created_at DESC");
    $courses = $courses_stmt->fetchAll();
} catch (PDOException $e) {
    $courses = [];
    $error = "Error fetching courses: " . $e->getMessage();
}

// Get lessons
try {
    $lessons_stmt = $pdo->query("
        SELECT l.*, c.title as course_title 
        FROM lessons l 
        LEFT JOIN courses c ON l.course_id = c.id 
        ORDER BY l.created_at DESC
    ");
    $lessons = $lessons_stmt->fetchAll();
} catch (PDOException $e) {
    $lessons = [];
}

// Get quizzes
try {
    $quizzes_stmt = $pdo->query("
        SELECT q.*, l.title as lesson_title, c.title as course_title 
        FROM quizzes q 
        LEFT JOIN lessons l ON q.lesson_id = l.id 
        LEFT JOIN courses c ON l.course_id = c.id 
        ORDER BY q.created_at DESC
    ");
    $quizzes = $quizzes_stmt->fetchAll();
} catch (PDOException $e) {
    $quizzes = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apna School - Animated Learning Platform</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 1rem 2rem;
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo {
            font-size: 1.5rem;
            font-weight: bold;
            color: #333;
        }
        .nav-tabs {
            display: flex;
            gap: 1rem;
            background: rgba(255, 255, 255, 0.1);
            padding: 0.5rem;
            border-radius: 10px;
        }
        .nav-tab {
            padding: 0.5rem 1rem;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s;
            color: #333;
            text-decoration: none;
        }
        .nav-tab.active {
            background: #667eea;
            color: white;
        }
        .nav-tab:hover {
            background: rgba(102, 126, 234, 0.2);
        }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        .tab-content {
            display: none;
        }
        .tab-content.active {
            display: block;
        }
        .card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #333;
        }
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }
        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: transform 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
        }
        .alert {
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1rem;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .course-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
        }
        .course-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .course-card:hover {
            transform: translateY(-5px);
        }
        .course-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
        .course-content {
            padding: 1.5rem;
        }
        .course-title {
            font-size: 1.3rem;
            font-weight: bold;
            color: #333;
            margin: 0 0 0.5rem 0;
        }
        .course-description {
            color: #666;
            margin-bottom: 1rem;
            line-height: 1.5;
        }
        .course-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9rem;
            color: #666;
        }
        .difficulty-badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        .difficulty-beginner {
            background: #d4edda;
            color: #155724;
        }
        .difficulty-intermediate {
            background: #fff3cd;
            color: #856404;
        }
        .difficulty-advanced {
            background: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">
            <i class="fas fa-graduation-cap"></i> Apna School
        </div>
        <div class="nav-tabs">
            <a href="?tab=courses" class="nav-tab <?php echo $current_tab === 'courses' ? 'active' : ''; ?>">
                <i class="fas fa-book"></i> Courses
            </a>
            <a href="?tab=lessons" class="nav-tab <?php echo $current_tab === 'lessons' ? 'active' : ''; ?>">
                <i class="fas fa-play"></i> Lessons
            </a>
            <a href="?tab=quizzes" class="nav-tab <?php echo $current_tab === 'quizzes' ? 'active' : ''; ?>">
                <i class="fas fa-question-circle"></i> Quizzes
            </a>
            <a href="?tab=games" class="nav-tab <?php echo $current_tab === 'games' ? 'active' : ''; ?>">
                <i class="fas fa-gamepad"></i> Games
            </a>
        </div>
    </div>

    <div class="container">
        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
            </div>
        <?php endif; ?>

        <!-- Courses Tab -->
        <div id="courses" class="tab-content <?php echo $current_tab === 'courses' ? 'active' : ''; ?>">
            <div class="card">
                <h2><i class="fas fa-plus"></i> Add New Course</h2>
                <form method="POST" id="courseForm">
                    <input type="hidden" name="action" value="add_course">
                    <div class="form-group">
                        <label for="title">Course Title:</label>
                        <input type="text" name="title" id="title" required>
                    </div>
                    <div class="form-group">
                        <label for="description">Description:</label>
                        <textarea name="description" id="description" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="difficulty_level">Difficulty Level:</label>
                        <select name="difficulty_level" id="difficulty_level">
                            <option value="beginner">Beginner</option>
                            <option value="intermediate">Intermediate</option>
                            <option value="advanced">Advanced</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="total_lessons">Total Lessons:</label>
                        <input type="number" name="total_lessons" id="total_lessons" min="1" value="1">
                    </div>
                    <div class="form-group">
                        <label for="course_image">Course Image:</label>
                        <input type="text" name="course_image" id="course_image" value="default-course.jpg">
                    </div>
                    <button type="submit" class="btn">
                        <i class="fas fa-save"></i> Add Course
                    </button>
                </form>
            </div>

            <div class="card">
                <h2><i class="fas fa-book"></i> Available Courses</h2>
                <?php if (empty($courses)): ?>
                    <p>No courses available yet. Add your first course above!</p>
                <?php else: ?>
                    <div class="course-grid">
                        <?php foreach ($courses as $course): ?>
                        <div class="course-card">
                            <img src="assets/images/<?php echo htmlspecialchars($course['course_image']); ?>" 
                                 alt="<?php echo htmlspecialchars($course['title']); ?>" 
                                 class="course-image">
                            <div class="course-content">
                                <h3 class="course-title"><?php echo htmlspecialchars($course['title']); ?></h3>
                                <p class="course-description"><?php echo htmlspecialchars($course['description']); ?></p>
                                <div class="course-meta">
                                    <span class="difficulty-badge difficulty-<?php echo $course['difficulty_level']; ?>">
                                        <?php echo ucfirst($course['difficulty_level']); ?>
                                    </span>
                                    <span><?php echo $course['total_lessons']; ?> lessons</span>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Lessons Tab -->
        <div id="lessons" class="tab-content <?php echo $current_tab === 'lessons' ? 'active' : ''; ?>">
            <div class="card">
                <h2><i class="fas fa-play"></i> Lessons</h2>
                <?php if (empty($lessons)): ?>
                    <p>No lessons available yet.</p>
                <?php else: ?>
                    <div class="course-grid">
                        <?php foreach ($lessons as $lesson): ?>
                        <div class="course-card">
                            <div class="course-content">
                                <h3 class="course-title"><?php echo htmlspecialchars($lesson['title']); ?></h3>
                                <p class="course-description"><?php echo htmlspecialchars($lesson['content']); ?></p>
                                <div class="course-meta">
                                    <span><?php echo htmlspecialchars($lesson['course_title'] ?? 'No Course'); ?></span>
                                    <span><?php echo $lesson['points_reward']; ?> points</span>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Quizzes Tab -->
        <div id="quizzes" class="tab-content <?php echo $current_tab === 'quizzes' ? 'active' : ''; ?>">
            <div class="card">
                <h2><i class="fas fa-question-circle"></i> Quizzes</h2>
                <?php if (empty($quizzes)): ?>
                    <p>No quizzes available yet.</p>
                <?php else: ?>
                    <div class="course-grid">
                        <?php foreach ($quizzes as $quiz): ?>
                        <div class="course-card">
                            <div class="course-content">
                                <h3 class="course-title"><?php echo htmlspecialchars($quiz['title']); ?></h3>
                                <p class="course-description"><?php echo htmlspecialchars($quiz['description']); ?></p>
                                <div class="course-meta">
                                    <span><?php echo htmlspecialchars($quiz['course_title'] ?? 'No Course'); ?></span>
                                    <span><?php echo $quiz['points_reward']; ?> points</span>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Games Tab -->
        <div id="games" class="tab-content <?php echo $current_tab === 'games' ? 'active' : ''; ?>">
            <div class="card">
                <h2><i class="fas fa-gamepad"></i> Learning Games</h2>
                <div class="course-grid">
                    <div class="course-card">
                        <div class="course-content">
                            <h3 class="course-title">Interactive Quiz</h3>
                            <p class="course-description">Test your knowledge with fun and engaging quiz questions.</p>
                            <div class="course-meta">
                                <a href="game.php?type=interactive_quiz" class="btn">
                                    <i class="fas fa-play"></i> Play Now
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="course-card">
                        <div class="course-content">
                            <h3 class="course-title">Memory Challenge</h3>
                            <p class="course-description">Improve your memory skills by matching pairs.</p>
                            <div class="course-meta">
                                <a href="game.php?type=memory_challenge" class="btn">
                                    <i class="fas fa-play"></i> Play Now
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="course-card">
                        <div class="course-content">
                            <h3 class="course-title">Word Puzzle</h3>
                            <p class="course-description">Solve word puzzles and expand your vocabulary.</p>
                            <div class="course-meta">
                                <a href="game.php?type=word_puzzle" class="btn">
                                    <i class="fas fa-play"></i> Play Now
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="course-card">
                        <div class="course-content">
                            <h3 class="course-title">Math Challenge</h3>
                            <p class="course-description">Practice math problems and improve your skills.</p>
                            <div class="course-meta">
                                <a href="game.php?type=math_challenge" class="btn">
                                    <i class="fas fa-play"></i> Play Now
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/tab.js"></script>
</body>
</html>