# WAMP Database Setup Instructions

## Problem Identified
The registration page shows "Database error. Please try again." because the MySQL PDO driver is not enabled in your WAMP installation.

## Solution Steps

### Step 1: Enable MySQL Extensions in WAMP

1. **Open WAMP Control Panel**
   - Right-click on the WAMP icon in your system tray
   - Make sure all services are running (green icon)

2. **Enable PHP Extensions**
   - Click on the WAMP icon
   - Go to **PHP** → **PHP Extensions**
   - Make sure these extensions are **checked**:
     - `pdo_mysql`
     - `mysqli`
     - `mysql`
   - If any are unchecked, click on them to enable

3. **Restart WAMP Services**
   - Right-click on WAMP icon
   - Click **Restart All Services**

### Step 2: Verify PHP Extensions

1. **Check PHP Info**
   - Open browser and go to: `http://localhost/`
   - Click on **phpinfo()** or **phpMyAdmin**
   - Look for these sections:
     - `pdo_mysql`
     - `mysqli`
   - If they're not listed, the extensions are not enabled

### Step 3: Create Database

1. **Using phpMyAdmin**
   - Go to: `http://localhost/phpmyadmin/`
   - Click **New** to create a new database
   - Name it: `animated_teaching`
   - Collation: `utf8mb4_unicode_ci`
   - Click **Create**

2. **Import Database Schema**
   - Select the `animated_teaching` database
   - Click **Import** tab
   - Choose the `complete_database_schema.sql` file
   - Click **Go**

### Step 4: Alternative - Use the Setup Scripts

If you prefer to use the provided scripts:

1. **Run Database Creation Script**
   - Go to: `http://localhost/animated_teaching/create_database_mysqli.php`
   - This will create the database and tables automatically

2. **Or Use the Diagnostic Tool**
   - Go to: `http://localhost/animated_teaching/fix_database_connection.php`
   - This will help diagnose and fix connection issues

### Step 5: Test Registration

1. **Try Registration Again**
   - Go to: `http://localhost/animated_teaching/register.php`
   - The database error should be resolved

2. **Use Fixed Registration Page**
   - If still having issues, try: `http://localhost/animated_teaching/register_fixed.php`
   - This version has fallback support for different database drivers

## Common Issues and Solutions

### Issue: "Class mysqli not found"
**Solution:** Enable the `mysqli` extension in WAMP PHP settings

### Issue: "PDO driver not found"
**Solution:** Enable the `pdo_mysql` extension in WAMP PHP settings

### Issue: "Access denied for user 'root'"
**Solution:** 
- Check if MySQL is running in WAMP
- Default password is usually empty (blank)
- Try password: `root` if empty doesn't work

### Issue: "Database doesn't exist"
**Solution:** Create the database manually in phpMyAdmin or run the setup scripts

## Quick Test Commands

You can test your setup by running these in your browser:

1. `http://localhost/animated_teaching/fix_database_connection.php` - Diagnostic tool
2. `http://localhost/animated_teaching/create_database_mysqli.php` - Database setup
3. `http://localhost/animated_teaching/register_fixed.php` - Fixed registration page

## Contact Support

If you continue to have issues:
1. Check WAMP error logs
2. Verify MySQL service is running
3. Try restarting your computer
4. Consider reinstalling WAMP with all extensions enabled

---

**Note:** The registration system supports three user types:
- **Student**: Login with roll number only (no password)
- **User**: Login with username/email and password
- **Admin**: Full system access with username/email and password
