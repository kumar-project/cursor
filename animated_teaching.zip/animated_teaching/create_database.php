<?php
// Database creation script
$host = 'localhost';
$username = 'root';
$password = '';

try {
    // First connect without specifying database
    $pdo = new PDO("mysql:host=$host", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Connected to MySQL server successfully!<br>";
    
    // Create database if it doesn't exist
    $pdo->exec("CREATE DATABASE IF NOT EXISTS animated_teaching");
    echo "Database 'animated_teaching' created/verified!<br>";
    
    // Now connect to the specific database
    $pdo = new PDO("mysql:host=$host;dbname=animated_teaching", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Connected to animated_teaching database!<br>";
    
    // Create users table
    $sql = "CREATE TABLE IF NOT EXISTS users (
        id INT PRIMARY KEY AUTO_INCREMENT,
        username VARCHAR(50) UNIQUE NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        full_name VARCHAR(100) NOT NULL,
        avatar VARCHAR(255) DEFAULT 'default_avatar.png',
        total_points INT DEFAULT 0,
        level INT DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_login TIMESTAMP NULL
    )";
    $pdo->exec($sql);
    echo "Users table created!<br>";
    
    // Create courses table
    $sql = "CREATE TABLE IF NOT EXISTS courses (
        id INT PRIMARY KEY AUTO_INCREMENT,
        title VARCHAR(200) NOT NULL,
        description TEXT,
        instructor_id INT,
        difficulty_level ENUM('beginner', 'intermediate', 'advanced') DEFAULT 'beginner',
        total_lessons INT DEFAULT 0,
        course_image VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (instructor_id) REFERENCES users(id)
    )";
    $pdo->exec($sql);
    echo "Courses table created!<br>";
    
    // Create lessons table
    $sql = "CREATE TABLE IF NOT EXISTS lessons (
        id INT PRIMARY KEY AUTO_INCREMENT,
        course_id INT NOT NULL,
        title VARCHAR(200) NOT NULL,
        content TEXT,
        lesson_type ENUM('video', 'text', 'interactive', 'quiz') DEFAULT 'text',
        order_index INT NOT NULL,
        points_reward INT DEFAULT 10,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
    )";
    $pdo->exec($sql);
    echo "Lessons table created!<br>";
    
    // Create quizzes table
    $sql = "CREATE TABLE IF NOT EXISTS quizzes (
        id INT PRIMARY KEY AUTO_INCREMENT,
        lesson_id INT NOT NULL,
        title VARCHAR(200) NOT NULL,
        description TEXT,
        time_limit INT DEFAULT 300,
        total_questions INT DEFAULT 0,
        points_reward INT DEFAULT 50,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE
    )";
    $pdo->exec($sql);
    echo "Quizzes table created!<br>";
    
    // Create quiz_questions table
    $sql = "CREATE TABLE IF NOT EXISTS quiz_questions (
        id INT PRIMARY KEY AUTO_INCREMENT,
        quiz_id INT NOT NULL,
        question_text TEXT NOT NULL,
        question_type ENUM('multiple_choice', 'true_false', 'fill_blank') DEFAULT 'multiple_choice',
        points INT DEFAULT 10,
        order_index INT NOT NULL,
        FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
    )";
    $pdo->exec($sql);
    echo "Quiz questions table created!<br>";
    
    // Create quiz_answers table
    $sql = "CREATE TABLE IF NOT EXISTS quiz_answers (
        id INT PRIMARY KEY AUTO_INCREMENT,
        question_id INT NOT NULL,
        answer_text TEXT NOT NULL,
        is_correct BOOLEAN DEFAULT FALSE,
        order_index INT NOT NULL,
        FOREIGN KEY (question_id) REFERENCES quiz_questions(id) ON DELETE CASCADE
    )";
    $pdo->exec($sql);
    echo "Quiz answers table created!<br>";
    
    // Create user_quiz_attempts table
    $sql = "CREATE TABLE IF NOT EXISTS user_quiz_attempts (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        quiz_id INT NOT NULL,
        score INT DEFAULT 0,
        total_questions INT DEFAULT 0,
        time_taken INT DEFAULT 0,
        completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (quiz_id) REFERENCES quizzes(id)
    )";
    $pdo->exec($sql);
    echo "User quiz attempts table created!<br>";
    
    // Create badges table
    $sql = "CREATE TABLE IF NOT EXISTS badges (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(100) NOT NULL,
        description TEXT,
        icon VARCHAR(255) NOT NULL,
        points_required INT DEFAULT 0,
        category ENUM('achievement', 'milestone', 'special') DEFAULT 'achievement',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    $pdo->exec($sql);
    echo "Badges table created!<br>";
    
    // Create user_badges table
    $sql = "CREATE TABLE IF NOT EXISTS user_badges (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        badge_id INT NOT NULL,
        earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (badge_id) REFERENCES badges(id),
        UNIQUE KEY unique_user_badge (user_id, badge_id)
    )";
    $pdo->exec($sql);
    echo "User badges table created!<br>";
    
    // Create user_progress table
    $sql = "CREATE TABLE IF NOT EXISTS user_progress (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        lesson_id INT NOT NULL,
        completed BOOLEAN DEFAULT FALSE,
        points_earned INT DEFAULT 0,
        completed_at TIMESTAMP NULL,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (lesson_id) REFERENCES lessons(id),
        UNIQUE KEY unique_user_lesson (user_id, lesson_id)
    )";
    $pdo->exec($sql);
    echo "User progress table created!<br>";
    
    // Insert sample data
    $sql = "INSERT IGNORE INTO badges (name, description, icon, points_required, category) VALUES
    ('First Steps', 'Complete your first lesson', '<i class="fas fa-bullseye"></i>', 10, 'milestone'),
    ('Quiz Master', 'Score 100% on any quiz', '<i class="fas fa-brain"></i>', 50, 'achievement'),
    ('Speed Demon', 'Complete a quiz in under 2 minutes', '<i class="fas fa-bolt"></i>', 75, 'achievement'),
    ('Perfect Score', 'Get 10 perfect quiz scores in a row', '<i class="fas fa-percentage"></i>', 200, 'achievement'),
    ('Knowledge Seeker', 'Complete 50 lessons', '<i class="fas fa-book"></i>', 500, 'milestone'),
    ('Quiz Champion', 'Complete 20 quizzes', '<i class="fas fa-trophy"></i>', 300, 'achievement'),
    ('Early Bird', 'Complete a lesson before 8 AM', '<i class="fas fa-sun"></i>', 25, 'special'),
    ('Night Owl', 'Complete a lesson after 10 PM', '<i class="fas fa-moon"></i>', 25, 'special'),
    ('Streak Master', 'Study for 7 days in a row', '<i class="fas fa-fire"></i>', 150, 'achievement'),
    ('Point Collector', 'Earn 1000 total points', '<i class="fas fa-gem"></i>', 1000, 'milestone')";
    $pdo->exec($sql);
    echo "Sample badges inserted!<br>";
    
    // Insert sample course (need to create a user first)
    $sql = "INSERT IGNORE INTO users (id, username, email, password, full_name) VALUES (1, 'admin', 'admin@apnaschool.com', '" . password_hash('admin123', PASSWORD_DEFAULT) . "', 'Administrator')";
    $pdo->exec($sql);
    echo "Admin user created!<br>";
    
    $sql = "INSERT IGNORE INTO courses (title, description, instructor_id, difficulty_level, course_image) VALUES
    ('Interactive PHP Programming', 'Learn PHP through animated tutorials and interactive exercises', 1, 'beginner', 'php_course.jpg'),
    ('Web Development Fundamentals', 'Master HTML, CSS, and JavaScript with gamified learning', 1, 'beginner', 'webdev_course.jpg'),
    ('Advanced PHP Techniques', 'Deep dive into advanced PHP concepts and best practices', 1, 'advanced', 'advanced_php.jpg')";
    $pdo->exec($sql);
    echo "Sample courses inserted!<br>";
    
    $sql = "INSERT IGNORE INTO lessons (course_id, title, content, lesson_type, order_index, points_reward) VALUES
    (1, 'Introduction to PHP', 'Learn the basics of PHP programming language', 'interactive', 1, 20),
    (1, 'Variables and Data Types', 'Understanding PHP variables and different data types', 'interactive', 2, 25),
    (1, 'Control Structures', 'If statements, loops, and conditional logic', 'interactive', 3, 30),
    (1, 'Functions in PHP', 'Creating and using functions in PHP', 'interactive', 4, 35),
    (1, 'Arrays and Loops', 'Working with arrays and different types of loops', 'interactive', 5, 40)";
    $pdo->exec($sql);
    echo "Sample lessons inserted!<br>";
    
    $sql = "INSERT IGNORE INTO quizzes (lesson_id, title, description, time_limit, total_questions, points_reward) VALUES
    (1, 'PHP Basics Quiz', 'Test your knowledge of PHP fundamentals', 300, 5, 50),
    (2, 'Variables Quiz', 'Quiz on PHP variables and data types', 240, 4, 40),
    (3, 'Control Structures Quiz', 'Test your understanding of PHP control structures', 300, 6, 60)";
    $pdo->exec($sql);
    echo "Sample quizzes inserted!<br>";
    
    echo "<br><strong>Database setup completed successfully!</strong><br>";
    echo "<a href='index.php'>Go to Login Page</a>";
    
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage() . "<br>";
}
?>
