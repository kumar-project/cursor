<?php
require_once 'config.php';

$game_type = $_GET['type'] ?? '';
$user_id = 1; // Default user ID for demo purposes

// Validate game type
$valid_games = ['interactive_quiz', 'memory_challenge', 'word_puzzle', 'math_challenge'];
if (!in_array($game_type, $valid_games)) {
    $game_type = 'interactive_quiz'; // Default to interactive quiz
}

// Initialize default values
$game_title = "Game";
$game_icon = "fas fa-gamepad";

// Get game data based on type
try {
    switch ($game_type) {
        case 'interactive_quiz':
            // Get quiz questions and create game sessions
            $quiz_questions = $pdo->query("SELECT * FROM quiz_questions ORDER BY RAND() LIMIT 20")->fetchAll();
            $games = [];
            
            // Create game sessions from quiz questions
            if (!empty($quiz_questions)) {
                $games[] = [
                    'id' => 1,
                    'title' => 'General Knowledge Quiz',
                    'description' => 'Test your knowledge with a variety of questions from different categories',
                    'difficulty_level' => 'mixed',
                    'total_questions' => count($quiz_questions),
                    'time_limit' => 300, // 5 minutes
                    'points_per_question' => 10,
                    'level_requirement' => 1,
                    'questions' => $quiz_questions
                ];
                
                // Create category-specific quizzes
                $categories = array_unique(array_column($quiz_questions, 'category'));
                foreach ($categories as $index => $category) {
                    $category_questions = array_filter($quiz_questions, function($q) use ($category) {
                        return $q['category'] === $category;
                    });
                    
                    if (count($category_questions) >= 3) {
                        $games[] = [
                            'id' => $index + 2,
                            'title' => $category . ' Quiz',
                            'description' => 'Focus on ' . $category . ' related questions',
                            'difficulty_level' => 'medium',
                            'total_questions' => min(10, count($category_questions)),
                            'time_limit' => 180, // 3 minutes
                            'points_per_question' => 15,
                            'level_requirement' => 1,
                            'questions' => array_slice($category_questions, 0, 10)
                        ];
                    }
                }
            }
            
            $game_title = "Interactive Quiz";
            $game_icon = "fas fa-question-circle";
            break;
        case 'memory_challenge':
            // Get memory pairs and create game sessions
            $memory_pairs = $pdo->query("SELECT * FROM memory_pairs ORDER BY RAND() LIMIT 12")->fetchAll();
            $games = [];
            
            // Create game sessions from memory pairs
            if (!empty($memory_pairs)) {
                $games[] = [
                    'id' => 1,
                    'title' => 'Memory Challenge',
                    'description' => 'Test your memory by matching pairs of items',
                    'difficulty_level' => 'easy',
                    'total_pairs' => min(8, count($memory_pairs)),
                    'time_limit' => 120, // 2 minutes
                    'points_per_pair' => 10,
                    'level_requirement' => 1,
                    'pairs' => array_slice($memory_pairs, 0, 8)
                ];
                
                if (count($memory_pairs) >= 12) {
                    $games[] = [
                        'id' => 2,
                        'title' => 'Advanced Memory Challenge',
                        'description' => 'More pairs to match - increased difficulty',
                        'difficulty_level' => 'medium',
                        'total_pairs' => 12,
                        'time_limit' => 180, // 3 minutes
                        'points_per_pair' => 15,
                        'level_requirement' => 2,
                        'pairs' => array_slice($memory_pairs, 0, 12)
                    ];
                }
            }
            
            $game_title = "Memory Challenge";
            $game_icon = "fas fa-brain";
            break;
        case 'word_puzzle':
            // Get word puzzles and create game sessions
            $word_puzzles = $pdo->query("SELECT * FROM word_puzzles ORDER BY RAND() LIMIT 15")->fetchAll();
            $games = [];
            
            // Create game sessions from word puzzles
            if (!empty($word_puzzles)) {
                $games[] = [
                    'id' => 1,
                    'title' => 'Word Puzzle Challenge',
                    'description' => 'Unscramble words using the given hints',
                    'difficulty_level' => 'easy',
                    'total_words' => min(10, count($word_puzzles)),
                    'time_limit' => 300, // 5 minutes
                    'points_per_word' => 15,
                    'level_requirement' => 1,
                    'words' => array_slice($word_puzzles, 0, 10)
                ];
                
                if (count($word_puzzles) >= 15) {
                    $games[] = [
                        'id' => 2,
                        'title' => 'Advanced Word Puzzle',
                        'description' => 'More challenging words to unscramble',
                        'difficulty_level' => 'medium',
                        'total_words' => 15,
                        'time_limit' => 450, // 7.5 minutes
                        'points_per_word' => 20,
                        'level_requirement' => 2,
                        'words' => array_slice($word_puzzles, 0, 15)
                    ];
                }
            }
            
            $game_title = "Word Puzzle";
            $game_icon = "fas fa-puzzle-piece";
            break;
        case 'math_challenge':
            // Get math problems and create game sessions
            $math_problems = $pdo->query("SELECT * FROM math_problems ORDER BY RAND() LIMIT 20")->fetchAll();
            $games = [];
            
            // Create game sessions from math problems
            if (!empty($math_problems)) {
                $games[] = [
                    'id' => 1,
                    'title' => 'Math Challenge',
                    'description' => 'Solve mathematical problems and equations',
                    'difficulty_level' => 'easy',
                    'total_problems' => min(15, count($math_problems)),
                    'time_limit' => 300, // 5 minutes
                    'points_per_problem' => 10,
                    'level_requirement' => 1,
                    'problems' => array_slice($math_problems, 0, 15)
                ];
                
                // Create difficulty-specific challenges
                $easy_problems = array_filter($math_problems, function($p) {
                    return $p['difficulty'] === 'easy';
                });
                
                $medium_problems = array_filter($math_problems, function($p) {
                    return $p['difficulty'] === 'medium';
                });
                
                if (count($easy_problems) >= 10) {
                    $games[] = [
                        'id' => 2,
                        'title' => 'Easy Math Practice',
                        'description' => 'Basic arithmetic problems for beginners',
                        'difficulty_level' => 'easy',
                        'total_problems' => min(10, count($easy_problems)),
                        'time_limit' => 240, // 4 minutes
                        'points_per_problem' => 8,
                        'level_requirement' => 1,
                        'problems' => array_slice($easy_problems, 0, 10)
                    ];
                }
                
                if (count($medium_problems) >= 8) {
                    $games[] = [
                        'id' => 3,
                        'title' => 'Intermediate Math Challenge',
                        'description' => 'Medium difficulty math problems',
                        'difficulty_level' => 'medium',
                        'total_problems' => min(8, count($medium_problems)),
                        'time_limit' => 360, // 6 minutes
                        'points_per_problem' => 15,
                        'level_requirement' => 2,
                        'problems' => array_slice($medium_problems, 0, 8)
                    ];
                }
            }
            
            $game_title = "Math Challenge";
            $game_icon = "fas fa-calculator";
            break;
    }
} catch (PDOException $e) {
    $games = [];
}

// Get user progress for this game type
try {
    $progress_stmt = $pdo->prepare("
        SELECT game_id, current_level, total_points, games_played, games_won, best_score 
        FROM user_game_progress 
        WHERE user_id = ? AND game_type = ?
    ");
    $progress_stmt->execute([$user_id, $game_type]);
    $user_progress = $progress_stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    $user_progress = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $game_title; ?> - Apna School</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 1rem 2rem;
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo {
            font-size: 1.5rem;
            font-weight: bold;
            color: #333;
        }
        
        .logo a {
            transition: all 0.3s ease;
            color: inherit !important;
        }
        
        .logo a:hover {
            color: inherit !important;
            transform: scale(1.05);
        }
        
        .logo a:visited {
            color: inherit !important;
        }
        .nav-links {
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        .nav-links a {
            color: #333;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .nav-links a:hover {
            background: #667eea;
            color: white;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        .user-avatar {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 0.9rem;
        }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        .game-header {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            text-align: center;
        }
        .game-title {
            font-size: 2.5rem;
            color: #333;
            margin: 0 0 1rem 0;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 1rem;
        }
        .game-icon {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2rem;
        }
        .game-subtitle {
            color: #666;
            font-size: 1.1rem;
            margin: 0;
        }
        .games-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 2rem;
        }
        .game-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .game-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        .card-title {
            font-size: 1.3rem;
            font-weight: bold;
            color: #333;
            margin: 0;
        }
        .difficulty-badge {
            padding: 4px 12px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        .difficulty-badge.easy {
            background: #d4edda;
            color: #155724;
        }
        .difficulty-badge.medium {
            background: #fff3cd;
            color: #856404;
        }
        .difficulty-badge.hard {
            background: #f8d7da;
            color: #721c24;
        }
        .card-description {
            color: #666;
            margin-bottom: 1.5rem;
            line-height: 1.5;
        }
        .game-stats {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        .stat-item {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 10px;
            text-align: center;
        }
        .stat-number {
            font-size: 1.5rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 0.25rem;
        }
        .stat-label {
            color: #666;
            font-size: 0.9rem;
        }
        .user-progress {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
        }
        .progress-title {
            font-weight: bold;
            margin-bottom: 0.5rem;
        }
        .progress-stats {
            display: flex;
            justify-content: space-between;
            font-size: 0.9rem;
        }
        .play-btn {
            width: 100%;
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            border: none;
            padding: 15px;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s;
            text-decoration: none;
            display: block;
            text-align: center;
        }
        .play-btn:hover {
            transform: translateY(-2px);
        }
        .play-btn:disabled {
            background: #6c757d;
            cursor: not-allowed;
            transform: none;
        }
        .no-games {
            text-align: center;
            padding: 4rem 2rem;
            color: #666;
        }
        .no-games i {
            font-size: 4rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">
            <a href="index.php" style="text-decoration: none; color: inherit; display: flex; align-items: center; gap: 8px;">
                <i class="fas fa-graduation-cap"></i> Apna School
            </a>
        </div>
        <div class="nav-links">
            <a href="index.php">
                <i class="fas fa-home"></i> Home
            </a>
            <a href="game.php?type=interactive_quiz">
                <i class="fas fa-question-circle"></i> Quiz
            </a>
            <a href="game.php?type=memory_challenge">
                <i class="fas fa-brain"></i> Memory
            </a>
            <a href="game.php?type=word_puzzle">
                <i class="fas fa-puzzle-piece"></i> Word Puzzle
            </a>
            <a href="game.php?type=math_challenge">
                <i class="fas fa-calculator"></i> Math
            </a>
            <a href="admin.php">
                <i class="fas fa-cog"></i> Admin
            </a>
        </div>
    </div>

    <div class="container">
        <div class="game-header">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                <a href="index.php" class="back-link" style="background: rgba(255,255,255,0.2); color: white; padding: 8px 16px; border-radius: 5px; text-decoration: none; display: inline-flex; align-items: center; gap: 8px;">
                    <i class="fas fa-arrow-left"></i> Back to Home
                </a>
                <h1 class="game-title" style="margin: 0;">
                    <div class="game-icon">
                        <i class="<?php echo $game_icon; ?>"></i>
                    </div>
                    <?php echo $game_title; ?>
                </h1>
                <div style="width: 120px;"></div> <!-- Spacer for centering -->
            </div>
            <p class="game-subtitle">Choose a game to start playing and improve your skills!</p>
        </div>

        <?php if (empty($games)): ?>
            <div class="no-games">
                <i class="<?php echo $game_icon; ?>"></i>
                <h3>No games available</h3>
                <p>There are currently no <?php echo strtolower($game_title); ?> games available. Please check back later!</p>
                <a href="index.php" class="play-btn" style="display: inline-block; width: auto; padding: 10px 20px; margin-top: 1rem;">
                    <i class="fas fa-arrow-left"></i> Back to Home
                </a>
            </div>
        <?php else: ?>
            <div class="games-grid">
                <?php foreach ($games as $game): ?>
                <div class="game-card">
                    <div class="card-header">
                        <h3 class="card-title"><?php echo htmlspecialchars($game['title']); ?></h3>
                        <span class="difficulty-badge <?php echo $game['difficulty_level']; ?>">
                            <?php echo ucfirst($game['difficulty_level']); ?>
                        </span>
                    </div>
                    
                    <p class="card-description">
                        <?php echo htmlspecialchars($game['description']); ?>
                    </p>
                    
                    <div class="game-stats">
                        <?php if ($game_type == 'interactive_quiz'): ?>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $game['total_questions']; ?></div>
                                <div class="stat-label">Questions</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $game['time_limit']; ?>s</div>
                                <div class="stat-label">Time Limit</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $game['points_per_question']; ?></div>
                                <div class="stat-label">Points Each</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $game['level_requirement']; ?></div>
                                <div class="stat-label">Level Required</div>
                            </div>
                        <?php elseif ($game_type == 'memory_challenge'): ?>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $game['total_pairs']; ?></div>
                                <div class="stat-label">Pairs</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $game['time_limit']; ?>s</div>
                                <div class="stat-label">Time Limit</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $game['points_per_pair']; ?></div>
                                <div class="stat-label">Points Each</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $game['level_requirement']; ?></div>
                                <div class="stat-label">Level Required</div>
                            </div>
                        <?php elseif ($game_type == 'word_puzzle'): ?>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $game['total_words']; ?></div>
                                <div class="stat-label">Words</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $game['time_limit']; ?>s</div>
                                <div class="stat-label">Time Limit</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $game['points_per_word']; ?></div>
                                <div class="stat-label">Points Each</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $game['level_requirement']; ?></div>
                                <div class="stat-label">Level Required</div>
                            </div>
                        <?php elseif ($game_type == 'math_challenge'): ?>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $game['total_problems']; ?></div>
                                <div class="stat-label">Problems</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $game['time_limit']; ?>s</div>
                                <div class="stat-label">Time Limit</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $game['points_per_problem']; ?></div>
                                <div class="stat-label">Points Each</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $game['level_requirement']; ?></div>
                                <div class="stat-label">Level Required</div>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <?php if (isset($user_progress[$game['id']])): ?>
                        <?php $progress = $user_progress[$game['id']]; ?>
                        <div class="user-progress">
                            <div class="progress-title">Your Progress</div>
                            <div class="progress-stats">
                                <span>Level: <?php echo $progress['current_level']; ?></span>
                                <span>Points: <?php echo $progress['total_points']; ?></span>
                                <span>Games: <?php echo $progress['games_played']; ?></span>
                                <span>Best: <?php echo $progress['best_score']; ?></span>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php
                    $play_url = '';
                    switch ($game_type) {
                        case 'interactive_quiz':
                            $play_url = 'play_game.php?type=interactive_quiz&id=' . $game['id'];
                            break;
                        case 'memory_challenge':
                            $play_url = 'play_memory_game.php?type=memory_challenge&id=' . $game['id'];
                            break;
                        case 'word_puzzle':
                            $play_url = 'play_word_game.php?type=word_puzzle&id=' . $game['id'];
                            break;
                        case 'math_challenge':
                            $play_url = 'play_math_game.php?type=math_challenge&id=' . $game['id'];
                            break;
                        default:
                            $play_url = 'play_game.php?type=' . $game_type . '&id=' . $game['id'];
                    }
                    ?>
                    <a href="<?php echo $play_url; ?>" class="play-btn">
                        <i class="fas fa-play"></i> Play Now
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
