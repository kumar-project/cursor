<?php
require_once 'config.php';

echo "Testing import functionality...\n\n";

try {
    // Test database connection
    echo "✓ Database connection successful\n";
    
    // Check if database exists
    $stmt = $pdo->query("SELECT DATABASE() as current_db");
    $result = $stmt->fetch();
    echo "✓ Current database: " . $result['current_db'] . "\n";
    
    // Create tables
    $create_tables_sql = "
        CREATE TABLE IF NOT EXISTS quiz_questions (
            id INT PRIMARY KEY AUTO_INCREMENT,
            question TEXT NOT NULL,
            option_a VARCHAR(255) NOT NULL,
            option_b VARCHAR(255) NOT NULL,
            option_c VARCHAR(255) NOT NULL,
            option_d VARCHAR(255) NOT NULL,
            correct_answer ENUM('A', 'B', 'C', 'D') NOT NULL,
            points INT DEFAULT 10,
            difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
            category VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        );
    ";
    
    $pdo->exec($create_tables_sql);
    echo "✓ Quiz questions table created/verified\n";
    
    // Test inserting a quiz question
    $quizData = ['What is the capital of France?', 'London', 'Berlin', 'Paris', 'Madrid', 'C', 'Geography', 'easy'];
    $stmt = $pdo->prepare("INSERT INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_answer, category, difficulty, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $result = $stmt->execute($quizData);
    
    if ($result) {
        echo "✓ Sample quiz question inserted successfully\n";
        echo "  Question ID: " . $pdo->lastInsertId() . "\n";
    } else {
        echo "✗ Failed to insert quiz question\n";
    }
    
    // Check how many questions are in the table
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM quiz_questions");
    $result = $stmt->fetch();
    echo "✓ Total quiz questions in database: " . $result['count'] . "\n";
    
    echo "\n🎉 Database test completed successfully!\n";
    echo "The import functionality should work now.\n";
    
} catch (PDOException $e) {
    echo "✗ Database error: " . $e->getMessage() . "\n";
    echo "Error code: " . $e->getCode() . "\n";
} catch (Exception $e) {
    echo "✗ General error: " . $e->getMessage() . "\n";
}
?>