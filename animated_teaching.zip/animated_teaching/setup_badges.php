<?php
require_once 'config.php';

echo "Setting up badges and rewards system...\n";

try {
    // Read the updated SQL file
    $sql = file_get_contents('setup_tables.sql');
    
    // Extract only the badges system tables section
    $badgesStart = strpos($sql, '-- Badges & Rewards System Tables');
    $badgesEnd = strpos($sql, '-- Insert sample badges', $badgesStart);
    
    if ($badgesStart !== false && $badgesEnd !== false) {
        $badgesTablesSQL = substr($sql, $badgesStart, $badgesEnd - $badgesStart);
        $badgesDataSQL = substr($sql, $badgesEnd);
        
        // Split by semicolon and execute each statement
        $statements = array_filter(array_map('trim', explode(';', $badgesTablesSQL . $badgesDataSQL)));
        
        foreach ($statements as $statement) {
            if (!empty($statement) && !preg_match('/^--/', $statement)) {
                try {
                    $pdo->exec($statement);
                    echo "✓ Executed: " . substr($statement, 0, 50) . "...\n";
                } catch (PDOException $e) {
                    echo "✗ Error executing statement: " . $e->getMessage() . "\n";
                    echo "Statement: " . substr($statement, 0, 100) . "...\n";
                }
            }
        }
        
        echo "\n🏆 Badges & Rewards system setup completed!\n";
        echo "You can now:\n";
        echo "1. View badges and rewards on the main page\n";
        echo "2. Earn badges by playing games and completing activities\n";
        echo "3. Track your progress and compete on the leaderboard\n";
        echo "4. See real-time notifications when earning badges\n";
        
    } else {
        echo "✗ Could not find badges system tables in setup_tables.sql\n";
    }
    
} catch(PDOException $e) {
    echo "✗ Database error: " . $e->getMessage() . "\n";
}
?>