<?php
require_once 'config.php';

try {
    // Check if tables exist and have data
    $tables = ['interactive_quiz_games', 'memory_challenge_games', 'word_puzzle_games', 'math_challenge_games'];
    
    foreach ($tables as $table) {
        try {
            $result = $pdo->query("SELECT COUNT(*) as count FROM $table");
            $count = $result->fetch()['count'];
            echo "$table: $count records\n";
        } catch (Exception $e) {
            echo "$table: Error - " . $e->getMessage() . "\n";
        }
    }
    
    // Test the specific query from game.php
    echo "\nTesting game.php query:\n";
    $games = $pdo->query("SELECT * FROM interactive_quiz_games ORDER BY created_at DESC")->fetchAll();
    echo "Found " . count($games) . " interactive quiz games\n";
    
    if (count($games) > 0) {
        echo "First game: " . $games[0]['title'] . "\n";
    }
    
} catch (Exception $e) {
    echo "Database error: " . $e->getMessage() . "\n";
}
?>
