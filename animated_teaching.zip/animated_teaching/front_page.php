<?php
require_once 'config.php';

// Get sample data for live examples
$sample_data = [];

try {
    // Get sample quiz questions
    $stmt = $pdo->query("SELECT * FROM quiz_questions ORDER BY RAND() LIMIT 3");
    $sample_data['quiz'] = $stmt->fetchAll();
} catch (PDOException $e) {
    // Fallback sample data
    $sample_data['quiz'] = [
        [
            'question' => 'What is the capital of Japan?',
            'option_a' => 'Tokyo',
            'option_b' => 'Osaka', 
            'option_c' => 'Kyoto',
            'option_d' => 'Hiroshima',
            'correct_answer' => 'A',
            'points' => 10
        ],
        [
            'question' => 'Which planet is closest to the Sun?',
            'option_a' => 'Venus',
            'option_b' => 'Mercury',
            'option_c' => 'Earth',
            'option_d' => 'Mars',
            'correct_answer' => 'B',
            'points' => 10
        ]
    ];
}

try {
    // Get sample memory pairs
    $stmt = $pdo->query("SELECT * FROM memory_pairs ORDER BY RAND() LIMIT 4");
    $sample_data['memory'] = $stmt->fetchAll();
} catch (PDOException $e) {
    // Fallback sample data
    $sample_data['memory'] = [
        ['pair_value' => '<i class="fas fa-heart"></i>', 'display_text' => 'Heart'],
        ['pair_value' => '<i class="fas fa-star"></i>', 'display_text' => 'Star'],
        ['pair_value' => '<i class="fas fa-moon"></i>', 'display_text' => 'Moon'],
        ['pair_value' => '<i class="fas fa-sun"></i>', 'display_text' => 'Sun']
    ];
}

try {
    // Get sample word puzzles
    $stmt = $pdo->query("SELECT * FROM word_puzzles ORDER BY RAND() LIMIT 3");
    $sample_data['word_puzzles'] = $stmt->fetchAll();
} catch (PDOException $e) {
    // Fallback sample data
    $sample_data['word_puzzles'] = [
        ['word' => 'LEARNING', 'hint' => 'The process of acquiring knowledge'],
        ['word' => 'TEACHER', 'hint' => 'Person who educates students'],
        ['word' => 'SCHOOL', 'hint' => 'Place where students learn']
    ];
}

try {
    // Get sample math problems
    $stmt = $pdo->query("SELECT * FROM math_problems ORDER BY RAND() LIMIT 3");
    $sample_data['math'] = $stmt->fetchAll();
} catch (PDOException $e) {
    // Fallback sample data
    $sample_data['math'] = [
        ['problem' => '10 + 5 = ?', 'answer' => 15],
        ['problem' => '20 - 8 = ?', 'answer' => 12],
        ['problem' => '6 × 7 = ?', 'answer' => 42]
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interactive Learning Platform - Apna School</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 4rem 0;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        
        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="75" cy="75" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="50" cy="10" r="0.5" fill="rgba(255,255,255,0.1)"/><circle cx="10" cy="60" r="0.5" fill="rgba(255,255,255,0.1)"/><circle cx="90" cy="40" r="0.5" fill="rgba(255,255,255,0.1)"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
            opacity: 0.3;
        }
        
        .hero-content {
            position: relative;
            z-index: 2;
        }
        
        .hero-title {
            font-size: 3.5rem;
            font-weight: 700;
            margin-bottom: 1rem;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        .hero-subtitle {
            font-size: 1.3rem;
            margin-bottom: 2rem;
            opacity: 0.9;
        }
        
        .cta-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .examples-section {
            padding: 4rem 0;
            background: #f8f9fa;
        }
        
        .section-title {
            text-align: center;
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 3rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .examples-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }
        
        .example-card {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .example-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .example-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }
        
        .example-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .example-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
        }
        
        .example-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: #333;
            margin: 0;
        }
        
        .example-content {
            margin-bottom: 1.5rem;
        }
        
        .quiz-question {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1rem;
            border-left: 4px solid #667eea;
        }
        
        .quiz-question-text {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: #333;
        }
        
        .quiz-options {
            display: grid;
            gap: 0.5rem;
        }
        
        .quiz-option {
            padding: 0.5rem;
            background: white;
            border: 1px solid #e9ecef;
            border-radius: 5px;
            font-size: 0.9rem;
        }
        
        .quiz-option.correct {
            background: #d4edda;
            border-color: #28a745;
            color: #155724;
        }
        
        .memory-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 0.5rem;
        }
        
        .memory-card {
            aspect-ratio: 1;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
            transition: transform 0.2s ease;
        }
        
        .memory-card:hover {
            transform: scale(1.05);
        }
        
        .word-puzzle {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1rem;
            border-left: 4px solid #667eea;
        }
        
        .word-display {
            font-family: 'Courier New', monospace;
            font-size: 1.2rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 0.5rem;
            letter-spacing: 2px;
        }
        
        .word-hint {
            color: #666;
            font-size: 0.9rem;
        }
        
        .math-problem {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1rem;
            border-left: 4px solid #667eea;
            text-align: center;
        }
        
        .math-equation {
            font-family: 'Courier New', monospace;
            font-size: 1.3rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 0.5rem;
        }
        
        .math-answer {
            color: #28a745;
            font-weight: 600;
        }
        
        .try-button {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 25px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            width: 100%;
            justify-content: center;
        }
        
        .try-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
            color: white;
            text-decoration: none;
        }
        
        .features-section {
            padding: 4rem 0;
            background: white;
        }
        
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
        }
        
        .feature-card {
            text-align: center;
            padding: 2rem;
        }
        
        .feature-icon {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2rem;
            margin: 0 auto 1rem;
        }
        
        .feature-title {
            font-size: 1.3rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: #333;
        }
        
        .feature-description {
            color: #666;
            line-height: 1.6;
        }
        
        .admin-link {
            position: fixed;
            top: 20px;
            right: 20px;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            padding: 10px 20px;
            border-radius: 25px;
            text-decoration: none;
            color: #333;
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            z-index: 1000;
        }
        
        .admin-link:hover {
            background: white;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            color: #333;
            text-decoration: none;
        }
        
        @media (max-width: 768px) {
            .hero-title {
                font-size: 2.5rem;
            }
            
            .hero-subtitle {
                font-size: 1.1rem;
            }
            
            .cta-buttons {
                flex-direction: column;
                align-items: center;
            }
            
            .examples-grid {
                grid-template-columns: 1fr;
            }
            
            .memory-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .admin-link {
                position: static;
                display: block;
                text-align: center;
                margin: 1rem auto;
                width: fit-content;
            }
        }
    </style>
</head>
<body>
    <a href="admin.php" class="admin-link">
        <i class="fas fa-cog"></i> Admin Panel
    </a>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="hero-content">
                <h1 class="hero-title">
                    <i class="fas fa-graduation-cap"></i>
                    Interactive Learning Platform
                </h1>
                <p class="hero-subtitle">
                    Experience engaging educational games with quiz questions, memory challenges, word puzzles, and math problems
                </p>
                <div class="cta-buttons">
                    <a href="game.php?type=interactive_quiz" class="btn btn-primary btn-large">
                        <i class="fas fa-play"></i> Start Learning
                    </a>
                    <a href="#examples" class="btn btn-success btn-large">
                        <i class="fas fa-eye"></i> View Examples
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Examples Section -->
    <section id="examples" class="examples-section">
        <div class="container">
            <h2 class="section-title">Live Examples</h2>
            
            <div class="examples-grid">
                <!-- Quiz Questions Example -->
                <div class="example-card">
                    <div class="example-header">
                        <div class="example-icon">
                            <i class="fas fa-question-circle"></i>
                        </div>
                        <h3 class="example-title">Quiz Questions</h3>
                    </div>
                    <div class="example-content">
                        <?php foreach (array_slice($sample_data['quiz'], 0, 1) as $question): ?>
                        <div class="quiz-question">
                            <div class="quiz-question-text"><?php echo htmlspecialchars($question['question']); ?></div>
                            <div class="quiz-options">
                                <div class="quiz-option">A) <?php echo htmlspecialchars($question['option_a']); ?></div>
                                <div class="quiz-option">B) <?php echo htmlspecialchars($question['option_b']); ?></div>
                                <div class="quiz-option">C) <?php echo htmlspecialchars($question['option_c']); ?></div>
                                <div class="quiz-option">D) <?php echo htmlspecialchars($question['option_d']); ?></div>
                                <div class="quiz-option correct">✓ Correct: <?php echo $question['correct_answer']; ?>) <?php echo htmlspecialchars($question['option_' . strtolower($question['correct_answer'])]); ?></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <a href="game.php?type=interactive_quiz" class="try-button">
                        <i class="fas fa-play"></i> Try Quiz Games
                    </a>
                </div>

                <!-- Memory Pairs Example -->
                <div class="example-card">
                    <div class="example-header">
                        <div class="example-icon">
                            <i class="fas fa-brain"></i>
                        </div>
                        <h3 class="example-title">Memory Pairs</h3>
                    </div>
                    <div class="example-content">
                        <div class="memory-grid">
                            <?php foreach (array_slice($sample_data['memory'], 0, 4) as $pair): ?>
                            <div class="memory-card">
                                <?php echo $pair['pair_value']; ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <p style="text-align: center; color: #666; font-size: 0.9rem; margin-top: 1rem;">
                            Match the pairs to test your memory!
                        </p>
                    </div>
                    <a href="game.php?type=memory_challenge" class="try-button">
                        <i class="fas fa-play"></i> Try Memory Games
                    </a>
                </div>

                <!-- Word Puzzles Example -->
                <div class="example-card">
                    <div class="example-header">
                        <div class="example-icon">
                            <i class="fas fa-puzzle-piece"></i>
                        </div>
                        <h3 class="example-title">Word Puzzles</h3>
                    </div>
                    <div class="example-content">
                        <?php foreach (array_slice($sample_data['word_puzzles'], 0, 2) as $puzzle): ?>
                        <div class="word-puzzle">
                            <div class="word-display"><?php echo strtoupper($puzzle['word']); ?></div>
                            <div class="word-hint"><?php echo htmlspecialchars($puzzle['hint']); ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <a href="game.php?type=word_puzzle" class="try-button">
                        <i class="fas fa-play"></i> Try Word Puzzles
                    </a>
                </div>

                <!-- Math Problems Example -->
                <div class="example-card">
                    <div class="example-header">
                        <div class="example-icon">
                            <i class="fas fa-calculator"></i>
                        </div>
                        <h3 class="example-title">Math Problems</h3>
                    </div>
                    <div class="example-content">
                        <?php foreach (array_slice($sample_data['math'], 0, 2) as $problem): ?>
                        <div class="math-problem">
                            <div class="math-equation"><?php echo htmlspecialchars($problem['problem']); ?></div>
                            <div class="math-answer">Answer: <?php echo $problem['answer']; ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <a href="game.php?type=math_challenge" class="try-button">
                        <i class="fas fa-play"></i> Try Math Games
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features-section">
        <div class="container">
            <h2 class="section-title">Why Choose Our Platform?</h2>
            
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-gamepad"></i>
                    </div>
                    <h3 class="feature-title">Interactive Learning</h3>
                    <p class="feature-description">
                        Engage with educational content through fun, interactive games that make learning enjoyable and effective.
                    </p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <h3 class="feature-title">Progress Tracking</h3>
                    <p class="feature-description">
                        Monitor your learning progress with detailed statistics, scores, and achievement tracking.
                    </p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3 class="feature-title">Multiple Game Types</h3>
                    <p class="feature-description">
                        Choose from various game formats including quizzes, memory challenges, word puzzles, and math problems.
                    </p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <h3 class="feature-title">Responsive Design</h3>
                    <p class="feature-description">
                        Access your learning platform on any device with our fully responsive and mobile-friendly design.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <script>
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Add some interactive animations
        document.addEventListener('DOMContentLoaded', function() {
            // Animate cards on scroll
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            };

            const observer = new IntersectionObserver(function(entries) {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, observerOptions);

            // Observe all example cards
            document.querySelectorAll('.example-card').forEach(card => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(30px)';
                card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                observer.observe(card);
            });
        });
    </script>
</body>
</html>
