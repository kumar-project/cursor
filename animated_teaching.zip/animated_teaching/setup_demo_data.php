<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setup Demo Data - Apna School</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .setup-container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
        }
        
        .setup-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .setup-title {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 1rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .setup-button {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 50px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .setup-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.6);
        }
        
        .result {
            margin-top: 2rem;
            padding: 1rem;
            border-radius: 10px;
            border-left: 4px solid;
        }
        
        .result.success {
            background: rgba(78, 205, 196, 0.1);
            border-color: #4ecdc4;
            color: #2d5a5a;
        }
        
        .result.error {
            background: rgba(255, 107, 107, 0.1);
            border-color: #ff6b6b;
            color: #8b2c2c;
        }
        
        .back-links {
            text-align: center;
            margin-top: 2rem;
        }
        
        .back-links a {
            color: #667eea;
            text-decoration: none;
            margin: 0 1rem;
            font-weight: 600;
        }
        
        .back-links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="setup-container">
        <div class="setup-header">
            <h1 class="setup-title">
                <i class="fas fa-database"></i>
                Setup Demo Data
            </h1>
            <p>Add sample questions and content to your database for better examples</p>
        </div>

        <?php
        if ($_POST['action'] ?? '' === 'setup_demo') {
            require_once 'config.php';
            
            try {
                // Add demo quiz questions
                $quiz_questions = [
                    [
                        'question' => 'What is the capital of France?',
                        'option_a' => 'London',
                        'option_b' => 'Berlin', 
                        'option_c' => 'Paris',
                        'option_d' => 'Madrid',
                        'correct_answer' => 'C',
                        'category' => 'Geography',
                        'difficulty' => 'easy',
                        'points' => 10
                    ],
                    [
                        'question' => 'Which planet is known as the Red Planet?',
                        'option_a' => 'Venus',
                        'option_b' => 'Mars',
                        'option_c' => 'Jupiter',
                        'option_d' => 'Saturn',
                        'correct_answer' => 'B',
                        'category' => 'Science',
                        'difficulty' => 'easy',
                        'points' => 10
                    ],
                    [
                        'question' => 'What is 15 + 27?',
                        'option_a' => '40',
                        'option_b' => '42',
                        'option_c' => '41',
                        'option_d' => '43',
                        'correct_answer' => 'B',
                        'category' => 'Math',
                        'difficulty' => 'easy',
                        'points' => 10
                    ],
                    [
                        'question' => 'Who painted the Mona Lisa?',
                        'option_a' => 'Van Gogh',
                        'option_b' => 'Picasso',
                        'option_c' => 'Da Vinci',
                        'option_d' => 'Michelangelo',
                        'correct_answer' => 'C',
                        'category' => 'Art',
                        'difficulty' => 'medium',
                        'points' => 15
                    ],
                    [
                        'question' => 'What is the largest ocean on Earth?',
                        'option_a' => 'Atlantic',
                        'option_b' => 'Indian',
                        'option_c' => 'Pacific',
                        'option_d' => 'Arctic',
                        'correct_answer' => 'C',
                        'category' => 'Geography',
                        'difficulty' => 'easy',
                        'points' => 10
                    ],
                    [
                        'question' => 'Which programming language is known for web development?',
                        'option_a' => 'Python',
                        'option_b' => 'JavaScript',
                        'option_c' => 'C++',
                        'option_d' => 'Java',
                        'correct_answer' => 'B',
                        'category' => 'Technology',
                        'difficulty' => 'medium',
                        'points' => 15
                    ],
                    [
                        'question' => 'What is the chemical symbol for gold?',
                        'option_a' => 'Go',
                        'option_b' => 'Gd',
                        'option_c' => 'Au',
                        'option_d' => 'Ag',
                        'correct_answer' => 'C',
                        'category' => 'Science',
                        'difficulty' => 'medium',
                        'points' => 15
                    ],
                    [
                        'question' => 'Which country is known as the Land of the Rising Sun?',
                        'option_a' => 'China',
                        'option_b' => 'Japan',
                        'option_c' => 'Korea',
                        'option_d' => 'Thailand',
                        'correct_answer' => 'B',
                        'category' => 'Geography',
                        'difficulty' => 'easy',
                        'points' => 10
                    ]
                ];

                // Add demo memory pairs
                $memory_pairs = [
                    ['pair_value' => '<i class="fas fa-heart"></i>', 'display_text' => 'Heart', 'category' => 'Icons', 'difficulty' => 'easy'],
                    ['pair_value' => '<i class="fas fa-star"></i>', 'display_text' => 'Star', 'category' => 'Icons', 'difficulty' => 'easy'],
                    ['pair_value' => '<i class="fas fa-moon"></i>', 'display_text' => 'Moon', 'category' => 'Icons', 'difficulty' => 'easy'],
                    ['pair_value' => '<i class="fas fa-sun"></i>', 'display_text' => 'Sun', 'category' => 'Icons', 'difficulty' => 'easy'],
                    ['pair_value' => '<i class="fas fa-tree"></i>', 'display_text' => 'Tree', 'category' => 'Icons', 'difficulty' => 'medium'],
                    ['pair_value' => '<i class="fas fa-mountain"></i>', 'display_text' => 'Mountain', 'category' => 'Icons', 'difficulty' => 'medium'],
                    ['pair_value' => '<i class="fas fa-car"></i>', 'display_text' => 'Car', 'category' => 'Icons', 'difficulty' => 'easy'],
                    ['pair_value' => '<i class="fas fa-plane"></i>', 'display_text' => 'Plane', 'category' => 'Icons', 'difficulty' => 'easy'],
                    ['pair_value' => '<i class="fas fa-book"></i>', 'display_text' => 'Book', 'category' => 'Icons', 'difficulty' => 'easy'],
                    ['pair_value' => '<i class="fas fa-music"></i>', 'display_text' => 'Music', 'category' => 'Icons', 'difficulty' => 'easy'],
                    ['pair_value' => '<i class="fas fa-camera"></i>', 'display_text' => 'Camera', 'category' => 'Icons', 'difficulty' => 'medium'],
                    ['pair_value' => '<i class="fas fa-gift"></i>', 'display_text' => 'Gift', 'category' => 'Icons', 'difficulty' => 'easy']
                ];

                // Add demo word puzzles
                $word_puzzles = [
                    ['word' => 'LEARNING', 'hint' => 'The process of acquiring knowledge', 'category' => 'Education', 'difficulty' => 'easy', 'points' => 15],
                    ['word' => 'TEACHER', 'hint' => 'Person who educates students', 'category' => 'Education', 'difficulty' => 'easy', 'points' => 15],
                    ['word' => 'SCHOOL', 'hint' => 'Place where students learn', 'category' => 'Education', 'difficulty' => 'easy', 'points' => 15],
                    ['word' => 'KNOWLEDGE', 'hint' => 'Information and understanding', 'category' => 'Education', 'difficulty' => 'medium', 'points' => 20],
                    ['word' => 'EDUCATION', 'hint' => 'Formal learning process', 'category' => 'Education', 'difficulty' => 'medium', 'points' => 20],
                    ['word' => 'COMPUTER', 'hint' => 'Electronic device for processing data', 'category' => 'Technology', 'difficulty' => 'easy', 'points' => 15],
                    ['word' => 'SCIENCE', 'hint' => 'Systematic study of the natural world', 'category' => 'Science', 'difficulty' => 'easy', 'points' => 15],
                    ['word' => 'MATHEMATICS', 'hint' => 'Study of numbers and shapes', 'category' => 'Math', 'difficulty' => 'medium', 'points' => 20],
                    ['word' => 'CREATIVITY', 'hint' => 'The ability to create new ideas', 'category' => 'General', 'difficulty' => 'medium', 'points' => 20],
                    ['word' => 'ADVENTURE', 'hint' => 'An exciting or unusual experience', 'category' => 'General', 'difficulty' => 'easy', 'points' => 15]
                ];

                // Add demo math problems
                $math_problems = [
                    ['problem' => '10 + 5 = ?', 'answer' => 15, 'operation' => 'addition', 'difficulty' => 'easy', 'points' => 10],
                    ['problem' => '20 - 8 = ?', 'answer' => 12, 'operation' => 'subtraction', 'difficulty' => 'easy', 'points' => 10],
                    ['problem' => '6 × 7 = ?', 'answer' => 42, 'operation' => 'multiplication', 'difficulty' => 'medium', 'points' => 15],
                    ['problem' => '48 ÷ 6 = ?', 'answer' => 8, 'operation' => 'division', 'difficulty' => 'medium', 'points' => 15],
                    ['problem' => '15 + 25 = ?', 'answer' => 40, 'operation' => 'addition', 'difficulty' => 'easy', 'points' => 10],
                    ['problem' => '100 - 37 = ?', 'answer' => 63, 'operation' => 'subtraction', 'difficulty' => 'medium', 'points' => 15],
                    ['problem' => '9 × 8 = ?', 'answer' => 72, 'operation' => 'multiplication', 'difficulty' => 'medium', 'points' => 15],
                    ['problem' => '84 ÷ 12 = ?', 'answer' => 7, 'operation' => 'division', 'difficulty' => 'medium', 'points' => 15],
                    ['problem' => '25 + 17 = ?', 'answer' => 42, 'operation' => 'addition', 'difficulty' => 'easy', 'points' => 10],
                    ['problem' => '56 - 19 = ?', 'answer' => 37, 'operation' => 'subtraction', 'difficulty' => 'medium', 'points' => 15],
                    ['problem' => '7 × 9 = ?', 'answer' => 63, 'operation' => 'multiplication', 'difficulty' => 'medium', 'points' => 15],
                    ['problem' => '72 ÷ 8 = ?', 'answer' => 9, 'operation' => 'division', 'difficulty' => 'medium', 'points' => 15]
                ];

                // Insert quiz questions
                $stmt = $pdo->prepare("INSERT IGNORE INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_answer, category, difficulty, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $quiz_count = 0;
                foreach ($quiz_questions as $question) {
                    $stmt->execute([
                        $question['question'],
                        $question['option_a'],
                        $question['option_b'],
                        $question['option_c'],
                        $question['option_d'],
                        $question['correct_answer'],
                        $question['category'],
                        $question['difficulty'],
                        $question['points']
                    ]);
                    if ($stmt->rowCount() > 0) $quiz_count++;
                }

                // Insert memory pairs
                $stmt = $pdo->prepare("INSERT IGNORE INTO memory_pairs (pair_value, display_text, category, difficulty) VALUES (?, ?, ?, ?)");
                $memory_count = 0;
                foreach ($memory_pairs as $pair) {
                    $stmt->execute([
                        $pair['pair_value'],
                        $pair['display_text'],
                        $pair['category'],
                        $pair['difficulty']
                    ]);
                    if ($stmt->rowCount() > 0) $memory_count++;
                }

                // Insert word puzzles
                $stmt = $pdo->prepare("INSERT IGNORE INTO word_puzzles (word, hint, category, difficulty, points) VALUES (?, ?, ?, ?, ?)");
                $word_count = 0;
                foreach ($word_puzzles as $puzzle) {
                    $stmt->execute([
                        $puzzle['word'],
                        $puzzle['hint'],
                        $puzzle['category'],
                        $puzzle['difficulty'],
                        $puzzle['points']
                    ]);
                    if ($stmt->rowCount() > 0) $word_count++;
                }

                // Insert math problems
                $stmt = $pdo->prepare("INSERT IGNORE INTO math_problems (problem, answer, operation, difficulty, points) VALUES (?, ?, ?, ?, ?)");
                $math_count = 0;
                foreach ($math_problems as $problem) {
                    $stmt->execute([
                        $problem['problem'],
                        $problem['answer'],
                        $problem['operation'],
                        $problem['difficulty'],
                        $problem['points']
                    ]);
                    if ($stmt->rowCount() > 0) $math_count++;
                }

                echo '<div class="result success">';
                echo '<h3><i class="fas fa-check-circle"></i> Demo Data Added Successfully!</h3>';
                echo '<ul>';
                echo '<li>Added ' . $quiz_count . ' new quiz questions</li>';
                echo '<li>Added ' . $memory_count . ' new memory pairs</li>';
                echo '<li>Added ' . $word_count . ' new word puzzles</li>';
                echo '<li>Added ' . $math_count . ' new math problems</li>';
                echo '</ul>';
                echo '<p><strong>Your front page now has plenty of demo content to showcase!</strong></p>';
                echo '</div>';

            } catch (PDOException $e) {
                echo '<div class="result error">';
                echo '<h3><i class="fas fa-exclamation-triangle"></i> Database Error</h3>';
                echo '<p>Error: ' . htmlspecialchars($e->getMessage()) . '</p>';
                echo '</div>';
            }
        } else {
            echo '<div style="text-align: center;">';
            echo '<form method="POST">';
            echo '<input type="hidden" name="action" value="setup_demo">';
            echo '<button type="submit" class="setup-button">';
            echo '<i class="fas fa-database"></i>';
            echo 'Add Demo Data to Database';
            echo '</button>';
            echo '</form>';
            echo '</div>';
        }
        ?>

        <div class="back-links">
            <a href="front_page.php"><i class="fas fa-eye"></i> View Front Page</a>
            <a href="admin.php"><i class="fas fa-cogs"></i> Admin Panel</a>
            <a href="index.php"><i class="fas fa-home"></i> Home</a>
        </div>
    </div>
</body>
</html>
