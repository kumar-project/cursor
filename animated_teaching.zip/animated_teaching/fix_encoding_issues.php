<?php
require_once 'config.php';

echo "<h2>Fixing Encoding Issues in Quiz Questions</h2>";

try {
    // Step 1: Check current database state
    echo "<h3>Step 1: Analyzing Current Database State</h3>";
    
    $stmt = $pdo->query("SHOW TABLES LIKE 'quiz_questions'");
    if ($stmt->rowCount() > 0) {
        echo "✓ quiz_questions table exists<br>";
        
        // Check current data
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM quiz_questions");
        $count = $stmt->fetch();
        echo "Total questions in database: " . $count['count'] . "<br>";
        
        // Check for corrupted data (contains non-ASCII characters that look like encoding issues)
        $stmt = $pdo->query("SELECT id, question, category FROM quiz_questions WHERE question LIKE '%Ā%' OR category LIKE '%Ā%' LIMIT 5");
        $corrupted = $stmt->fetchAll();
        echo "Found " . count($corrupted) . " potentially corrupted entries<br>";
        
        if (count($corrupted) > 0) {
            echo "<strong>Corrupted entries:</strong><br>";
            foreach ($corrupted as $row) {
                echo "ID: " . $row['id'] . " - Question: " . htmlspecialchars(substr($row['question'], 0, 50)) . "...<br>";
            }
        }
    } else {
        echo "✗ quiz_questions table does not exist<br>";
    }
    
    // Step 2: Fix database encoding
    echo "<h3>Step 2: Fixing Database and Table Encoding</h3>";
    
    // Set database charset to utf8mb4
    $pdo->exec("ALTER DATABASE animated_teaching CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    echo "✓ Database charset set to utf8mb4<br>";
    
    // Drop and recreate the quiz_questions table with proper encoding
    $pdo->exec("DROP TABLE IF EXISTS quiz_questions");
    echo "✓ Dropped existing quiz_questions table<br>";
    
    // Create table with proper encoding
    $create_table_sql = "
        CREATE TABLE quiz_questions (
            id INT PRIMARY KEY AUTO_INCREMENT,
            question TEXT NOT NULL,
            option_a VARCHAR(255) NOT NULL,
            option_b VARCHAR(255) NOT NULL,
            option_c VARCHAR(255) NOT NULL,
            option_d VARCHAR(255) NOT NULL,
            correct_answer ENUM('A', 'B', 'C', 'D') NOT NULL,
            points INT DEFAULT 10,
            difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
            category VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ";
    
    $pdo->exec($create_table_sql);
    echo "✓ Created new quiz_questions table with utf8mb4 encoding<br>";
    
    // Step 3: Insert clean sample data
    echo "<h3>Step 3: Inserting Clean Sample Data</h3>";
    
    $cleanQuizData = [
        ['What is the capital of France?', 'London', 'Berlin', 'Paris', 'Madrid', 'C', 'Geography', 'easy', 10],
        ['Which planet is known as the Red Planet?', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'B', 'Science', 'easy', 10],
        ['What is 15 + 27?', '40', '42', '41', '43', 'B', 'Math', 'easy', 10],
        ['Who painted the Mona Lisa?', 'Van Gogh', 'Picasso', 'Da Vinci', 'Michelangelo', 'C', 'Art', 'medium', 15],
        ['What is the largest ocean on Earth?', 'Atlantic', 'Indian', 'Pacific', 'Arctic', 'C', 'Geography', 'easy', 10],
        ['What is the chemical symbol for gold?', 'Go', 'Gd', 'Au', 'Ag', 'C', 'Science', 'medium', 15],
        ['Which country has the most population?', 'India', 'China', 'USA', 'Brazil', 'B', 'Geography', 'medium', 15],
        ['What is 8 × 7?', '54', '56', '58', '60', 'B', 'Math', 'easy', 10],
        ['What is the speed of light?', '299,792,458 m/s', '300,000,000 m/s', '299,000,000 m/s', '301,000,000 m/s', 'A', 'Science', 'hard', 20],
        ['What is the smallest country in the world?', 'Monaco', 'Vatican City', 'San Marino', 'Liechtenstein', 'B', 'Geography', 'hard', 20]
    ];
    
    $stmt = $pdo->prepare("INSERT INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_answer, category, difficulty, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    $imported = 0;
    foreach ($cleanQuizData as $data) {
        if ($stmt->execute($data)) {
            $imported++;
        }
    }
    
    echo "✓ Successfully imported $imported clean quiz questions<br>";
    
    // Step 4: Verify the fix
    echo "<h3>Step 4: Verifying the Fix</h3>";
    
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM quiz_questions");
    $count = $stmt->fetch();
    echo "Total questions after fix: " . $count['count'] . "<br>";
    
    // Check for any remaining encoding issues
    $stmt = $pdo->query("SELECT id, question, category FROM quiz_questions WHERE question LIKE '%Ā%' OR category LIKE '%Ā%'");
    $remaining_corrupted = $stmt->fetchAll();
    
    if (count($remaining_corrupted) == 0) {
        echo "✓ No encoding issues found - all data is clean!<br>";
    } else {
        echo "⚠ Warning: " . count($remaining_corrupted) . " entries still have encoding issues<br>";
    }
    
    // Show sample of clean data
    echo "<h3>Sample of Clean Data:</h3>";
    $stmt = $pdo->query("SELECT id, question, category, difficulty, points FROM quiz_questions LIMIT 5");
    $sample = $stmt->fetchAll();
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr style='background-color: #f0f0f0;'><th>ID</th><th>Question</th><th>Category</th><th>Difficulty</th><th>Points</th></tr>";
    foreach ($sample as $row) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['id']) . "</td>";
        echo "<td>" . htmlspecialchars($row['question']) . "</td>";
        echo "<td>" . htmlspecialchars($row['category']) . "</td>";
        echo "<td>" . htmlspecialchars($row['difficulty']) . "</td>";
        echo "<td>" . htmlspecialchars($row['points']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<h3>✅ Fix Complete!</h3>";
    echo "<p>The encoding issues have been resolved. Your quiz questions should now display correctly in the admin panel.</p>";
    echo "<p><a href='admin.php?tab=quiz'>Go to Admin Panel</a> | <a href='index.php'>Go to Home</a></p>";
    
} catch (Exception $e) {
    echo "<h3>❌ Error occurred:</h3>";
    echo "<p style='color: red;'>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p>Please check your database connection and try again.</p>";
}
?>
