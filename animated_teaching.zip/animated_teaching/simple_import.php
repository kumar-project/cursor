<?php
require_once 'config.php';

echo "<h2>Simple Import - Working Solution</h2>";
echo "<p>This will import all your game content without any form issues.</p>";

try {
    echo "<h3>Step 1: Setting up database tables</h3>";
    
    // Drop and recreate tables to ensure correct structure
    $pdo->exec("DROP TABLE IF EXISTS quiz_questions");
    $pdo->exec("DROP TABLE IF EXISTS memory_pairs");
    $pdo->exec("DROP TABLE IF EXISTS word_puzzles");
    $pdo->exec("DROP TABLE IF EXISTS math_problems");
    
    // Create quiz_questions table
    $pdo->exec("CREATE TABLE quiz_questions (
        id INT PRIMARY KEY AUTO_INCREMENT,
        question TEXT NOT NULL,
        option_a VARCHAR(255) NOT NULL,
        option_b VARCHAR(255) NOT NULL,
        option_c VARCHAR(255) NOT NULL,
        option_d VARCHAR(255) NOT NULL,
        correct_answer ENUM('A', 'B', 'C', 'D') NOT NULL,
        points INT DEFAULT 10,
        difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
        category VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");
    echo "✓ Quiz questions table created<br>";
    
    // Create memory_pairs table
    $pdo->exec("CREATE TABLE memory_pairs (
        id INT PRIMARY KEY AUTO_INCREMENT,
        pair_value VARCHAR(255) NOT NULL,
        display_text VARCHAR(255) NOT NULL,
        category VARCHAR(100),
        difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");
    echo "✓ Memory pairs table created<br>";
    
    // Create word_puzzles table
    $pdo->exec("CREATE TABLE word_puzzles (
        id INT PRIMARY KEY AUTO_INCREMENT,
        word VARCHAR(255) NOT NULL,
        hint TEXT NOT NULL,
        category VARCHAR(100),
        difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
        points INT DEFAULT 15,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");
    echo "✓ Word puzzles table created<br>";
    
    // Create math_problems table
    $pdo->exec("CREATE TABLE math_problems (
        id INT PRIMARY KEY AUTO_INCREMENT,
        problem TEXT NOT NULL,
        answer DECIMAL(10,2) NOT NULL,
        operation ENUM('addition', 'subtraction', 'multiplication', 'division', 'mixed') DEFAULT 'mixed',
        difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
        points INT DEFAULT 10,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");
    echo "✓ Math problems table created<br>";
    
    echo "<h3>Step 2: Importing Quiz Questions</h3>";
    
    $quizQuestions = [
        ['What is the capital of France?', 'London', 'Berlin', 'Paris', 'Madrid', 'C', 'Geography', 'easy', 10],
        ['Which planet is known as the Red Planet?', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'B', 'Science', 'easy', 10],
        ['What is 15 + 27?', '40', '42', '41', '43', 'B', 'Math', 'easy', 10],
        ['Who painted the Mona Lisa?', 'Van Gogh', 'Picasso', 'Da Vinci', 'Michelangelo', 'C', 'Art', 'medium', 15],
        ['What is the largest ocean on Earth?', 'Atlantic', 'Indian', 'Pacific', 'Arctic', 'C', 'Geography', 'easy', 10],
        ['What is the chemical symbol for gold?', 'Go', 'Gd', 'Au', 'Ag', 'C', 'Science', 'medium', 15],
        ['Which country has the most population?', 'India', 'China', 'USA', 'Brazil', 'B', 'Geography', 'medium', 15],
        ['What is 8 × 7?', '54', '56', '58', '60', 'B', 'Math', 'easy', 10],
        ['What is the smallest country in the world?', 'Monaco', 'Vatican City', 'San Marino', 'Liechtenstein', 'B', 'Geography', 'hard', 20],
        ['What is the speed of light?', '300,000 km/s', '299,792,458 m/s', '186,000 miles/s', 'All of the above', 'D', 'Science', 'hard', 20]
    ];
    
    $stmt = $pdo->prepare("INSERT INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_answer, category, difficulty, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $quizCount = 0;
    foreach ($quizQuestions as $question) {
        if ($stmt->execute($question)) {
            $quizCount++;
        }
    }
    echo "✓ Imported $quizCount quiz questions<br>";
    
    echo "<h3>Step 3: Importing Memory Pairs</h3>";
    
    $memoryPairs = [
        ['<i class="fas fa-bullseye"></i>', 'Target', 'Icon', 'easy'],
        ['<i class="fas fa-gamepad"></i>', 'Game Controller', 'Icon', 'easy'],
        ['<i class="fas fa-palette"></i>', 'Artist Palette', 'Icon', 'easy'],
        ['<i class="fas fa-tent"></i>', 'Circus Tent', 'Icon', 'easy'],
        ['<i class="fas fa-theater-masks"></i>', 'Theater Masks', 'Icon', 'medium'],
        ['<i class="fas fa-guitar"></i>', 'Guitar', 'Icon', 'medium'],
        ['<i class="fas fa-music"></i>', 'Trumpet', 'Icon', 'medium'],
        ['<i class="fas fa-star"></i>', 'Star', 'Icon', 'easy'],
        ['<i class="fas fa-heart"></i>', 'Heart', 'Icon', 'easy'],
        ['<i class="fas fa-sun"></i>', 'Sun', 'Icon', 'easy']
    ];
    
    $stmt = $pdo->prepare("INSERT INTO memory_pairs (pair_value, display_text, category, difficulty) VALUES (?, ?, ?, ?)");
    $memoryCount = 0;
    foreach ($memoryPairs as $pair) {
        if ($stmt->execute($pair)) {
            $memoryCount++;
        }
    }
    echo "✓ Imported $memoryCount memory pairs<br>";
    
    echo "<h3>Step 4: Importing Word Puzzles</h3>";
    
    $wordPuzzles = [
        ['EDUCATION', 'The process of learning', 'General', 'easy', 15],
        ['KNOWLEDGE', 'Information and understanding', 'General', 'medium', 20],
        ['TEACHER', 'Someone who educates', 'General', 'easy', 15],
        ['STUDENT', 'Someone who learns', 'General', 'easy', 15],
        ['SCHOOL', 'A place of learning', 'General', 'easy', 15],
        ['COMPUTER', 'Electronic device for processing data', 'Technology', 'easy', 15],
        ['SCIENCE', 'Systematic study of the natural world', 'General', 'medium', 20],
        ['MATHEMATICS', 'Study of numbers and shapes', 'General', 'hard', 25],
        ['PROGRAMMING', 'Writing computer code', 'Technology', 'medium', 20],
        ['EXPERIMENT', 'Scientific test or trial', 'Science', 'medium', 20]
    ];
    
    $stmt = $pdo->prepare("INSERT INTO word_puzzles (word, hint, category, difficulty, points) VALUES (?, ?, ?, ?, ?)");
    $wordCount = 0;
    foreach ($wordPuzzles as $puzzle) {
        if ($stmt->execute($puzzle)) {
            $wordCount++;
        }
    }
    echo "✓ Imported $wordCount word puzzles<br>";
    
    echo "<h3>Step 5: Importing Math Problems</h3>";
    
    $mathProblems = [
        ['12 + 8 = ?', 20, 'addition', 'easy', 10],
        ['25 - 7 = ?', 18, 'subtraction', 'easy', 10],
        ['6 × 4 = ?', 24, 'multiplication', 'easy', 10],
        ['36 ÷ 6 = ?', 6, 'division', 'easy', 10],
        ['15 + 23 = ?', 38, 'addition', 'easy', 10],
        ['45 - 18 = ?', 27, 'subtraction', 'medium', 15],
        ['7 × 8 = ?', 56, 'multiplication', 'medium', 15],
        ['72 ÷ 9 = ?', 8, 'division', 'medium', 15],
        ['125 + 75 = ?', 200, 'addition', 'medium', 15],
        ['144 ÷ 12 = ?', 12, 'division', 'medium', 15]
    ];
    
    $stmt = $pdo->prepare("INSERT INTO math_problems (problem, answer, operation, difficulty, points) VALUES (?, ?, ?, ?, ?)");
    $mathCount = 0;
    foreach ($mathProblems as $problem) {
        if ($stmt->execute($problem)) {
            $mathCount++;
        }
    }
    echo "✓ Imported $mathCount math problems<br>";
    
    echo "<h3>🎉 Import Complete!</h3>";
    echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h4>Successfully imported:</h4>";
    echo "<ul>";
    echo "<li><strong>$quizCount Quiz Questions</strong> - Geography, Science, Math, Art topics</li>";
    echo "<li><strong>$memoryCount Memory Pairs</strong> - FontAwesome icons for matching</li>";
    echo "<li><strong>$wordCount Word Puzzles</strong> - Educational terms with hints</li>";
    echo "<li><strong>$mathCount Math Problems</strong> - Addition, subtraction, multiplication, division</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<h3>What's Next?</h3>";
    echo "<div style='margin: 20px 0;'>";
    echo "<a href='admin.php?tab=quiz' style='background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin-right: 10px; display: inline-block;'>📝 View Quiz Questions</a>";
    echo "<a href='admin.php?tab=memory' style='background: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin-right: 10px; display: inline-block;'>🧠 View Memory Pairs</a>";
    echo "<a href='admin.php?tab=word' style='background: #ffc107; color: black; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin-right: 10px; display: inline-block;'>🧩 View Word Puzzles</a>";
    echo "<a href='admin.php?tab=math' style='background: #dc3545; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin-right: 10px; display: inline-block;'>🔢 View Math Problems</a>";
    echo "<a href='index.php' style='background: #6f42c1; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block;'>🎮 Test Games</a>";
    echo "</div>";
    
    echo "<div style='background: #e2e3e5; border: 1px solid #d6d8db; color: #383d41; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h4>✅ Import Status: SUCCESS</h4>";
    echo "<p>All game content has been successfully imported. You can now:</p>";
    echo "<ul>";
    echo "<li>View and manage questions in the admin panel</li>";
    echo "<li>Play the games on your main page</li>";
    echo "<li>Add more questions using the admin forms</li>";
    echo "</ul>";
    echo "</div>";
    
} catch (PDOException $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; padding: 15px; border-radius: 5px;'>";
    echo "<h4>❌ Database Error</h4>";
    echo "<p>Error: " . $e->getMessage() . "</p>";
    echo "<p>Please check your WAMP server is running and MySQL is accessible.</p>";
    echo "</div>";
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; padding: 15px; border-radius: 5px;'>";
    echo "<h4>❌ General Error</h4>";
    echo "<p>Error: " . $e->getMessage() . "</p>";
    echo "</div>";
}
?>
