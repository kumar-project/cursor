<?php
require_once 'config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apna School - Interactive Learning Platform</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .landing-container {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 2rem;
        }
        
        .landing-content {
            max-width: 800px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 3rem;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
        }
        
        .landing-title {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 1rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .landing-subtitle {
            font-size: 1.3rem;
            color: #666;
            margin-bottom: 2rem;
            line-height: 1.6;
        }
        
        .landing-buttons {
            display: flex;
            gap: 1.5rem;
            justify-content: center;
            flex-wrap: wrap;
            margin-bottom: 2rem;
        }
        
        .landing-btn {
            padding: 15px 30px;
            border-radius: 50px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            min-width: 200px;
            justify-content: center;
        }
        
        .landing-btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        
        .landing-btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.6);
            color: white;
            text-decoration: none;
        }
        
        .landing-btn-secondary {
            background: linear-gradient(135deg, #4ecdc4 0%, #44a08d 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(78, 205, 196, 0.4);
        }
        
        .landing-btn-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(78, 205, 196, 0.6);
            color: white;
            text-decoration: none;
        }
        
        .landing-btn-admin {
            background: linear-gradient(135deg, #feca57 0%, #ff9ff3 100%);
            color: #333;
            box-shadow: 0 4px 15px rgba(254, 202, 87, 0.4);
        }
        
        .landing-btn-admin:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(254, 202, 87, 0.6);
            color: #333;
            text-decoration: none;
        }
        
        .features-preview {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }
        
        .feature-preview {
            text-align: center;
            padding: 1.5rem;
            background: rgba(102, 126, 234, 0.05);
            border-radius: 15px;
            transition: transform 0.3s ease;
        }
        
        .feature-preview:hover {
            transform: translateY(-5px);
        }
        
        .feature-preview-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
            margin: 0 auto 1rem;
        }
        
        .feature-preview-title {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: #333;
        }
        
        .feature-preview-desc {
            color: #666;
            font-size: 0.9rem;
        }
        
        @media (max-width: 768px) {
            .landing-title {
                font-size: 2.5rem;
            }
            
            .landing-subtitle {
                font-size: 1.1rem;
            }
            
            .landing-buttons {
                flex-direction: column;
                align-items: center;
            }
            
            .landing-btn {
                width: 100%;
                max-width: 300px;
            }
            
            .features-preview {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>
</head>
<body>
    <div class="landing-container">
        <div class="landing-content">
            <h1 class="landing-title">
                <i class="fas fa-graduation-cap"></i>
                Apna School
            </h1>
            <p class="landing-subtitle">
                Welcome to our Interactive Learning Platform! Experience engaging educational games with quiz questions, memory challenges, word puzzles, and math problems designed to make learning fun and effective.
            </p>
            
            <div class="landing-buttons">
                <a href="front_page.php" class="landing-btn landing-btn-primary">
                    <i class="fas fa-eye"></i>
                    View Examples
                </a>
                <a href="game.php?type=interactive_quiz" class="landing-btn landing-btn-secondary">
                    <i class="fas fa-play"></i>
                    Start Learning
                </a>
                <a href="admin.php" class="landing-btn landing-btn-admin">
                    <i class="fas fa-cogs"></i>
                    Admin Panel
                </a>
            </div>
            
            <div class="features-preview">
                <div class="feature-preview">
                    <div class="feature-preview-icon">
                        <i class="fas fa-question-circle"></i>
                    </div>
                    <div class="feature-preview-title">Quiz Questions</div>
                    <div class="feature-preview-desc">Test your knowledge with interactive quizzes</div>
                </div>
                
                <div class="feature-preview">
                    <div class="feature-preview-icon">
                        <i class="fas fa-brain"></i>
                    </div>
                    <div class="feature-preview-title">Memory Pairs</div>
                    <div class="feature-preview-desc">Challenge your memory with matching games</div>
                </div>
                
                <div class="feature-preview">
                    <div class="feature-preview-icon">
                        <i class="fas fa-puzzle-piece"></i>
                    </div>
                    <div class="feature-preview-title">Word Puzzles</div>
                    <div class="feature-preview-desc">Solve word puzzles and expand vocabulary</div>
                </div>
                
                <div class="feature-preview">
                    <div class="feature-preview-icon">
                        <i class="fas fa-calculator"></i>
                    </div>
                    <div class="feature-preview-title">Math Problems</div>
                    <div class="feature-preview-desc">Practice math with fun problem-solving games</div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Add some interactive animations
        document.addEventListener('DOMContentLoaded', function() {
            // Animate feature previews on load
            const features = document.querySelectorAll('.feature-preview');
            features.forEach((feature, index) => {
                feature.style.opacity = '0';
                feature.style.transform = 'translateY(30px)';
                feature.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                
                setTimeout(() => {
                    feature.style.opacity = '1';
                    feature.style.transform = 'translateY(0)';
                }, index * 100);
            });
        });
    </script>
</body>
</html>
