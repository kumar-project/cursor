<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Custom Data Type Creation</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select, textarea { width: 100%; padding: 8px; margin-bottom: 10px; }
        .field-row { display: flex; gap: 10px; align-items: center; margin-bottom: 10px; }
        .field-row input, .field-row select { flex: 1; }
        button { padding: 10px 20px; margin: 5px; cursor: pointer; }
        .btn-primary { background: #007cba; color: white; border: none; }
        .btn-secondary { background: #6c757d; color: white; border: none; }
        .btn-remove { background: #dc3545; color: white; border: none; padding: 5px 10px; }
        .response { margin-top: 20px; padding: 15px; border-radius: 5px; }
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .debug { background: #f8f9fa; color: #495057; border: 1px solid #dee2e6; }
    </style>
</head>
<body>
    <h1>Test Custom Data Type Creation</h1>
    
    <form id="testForm" method="POST">
        <input type="hidden" name="action" value="create_custom_datatype">
        
        <div class="form-group">
            <label for="name">Name (Internal):</label>
            <input type="text" name="name" id="name" value="test_type" required>
        </div>
        
        <div class="form-group">
            <label for="display_name">Display Name:</label>
            <input type="text" name="display_name" id="display_name" value="Test Type" required>
        </div>
        
        <div class="form-group">
            <label for="description">Description:</label>
            <textarea name="description" id="description">Test custom data type for debugging</textarea>
        </div>
        
        <div class="form-group">
            <label>Fields:</label>
            <div id="fields-container">
                <div class="field-row">
                    <input type="text" name="fields[0][name]" value="question" placeholder="Field Name" required>
                    <select name="fields[0][type]" required>
                        <option value="">Select Type</option>
                        <option value="VARCHAR(255)" selected>Text (Short)</option>
                        <option value="TEXT">Text (Long)</option>
                        <option value="INT">Number</option>
                        <option value="DECIMAL(10,2)">Decimal</option>
                        <option value="DATE">Date</option>
                    </select>
                    <label><input type="checkbox" name="fields[0][required]" checked> Required</label>
                    <input type="text" name="fields[0][default]" placeholder="Default Value">
                    <button type="button" class="btn-remove" onclick="removeField(this)">Remove</button>
                </div>
                <div class="field-row">
                    <input type="text" name="fields[1][name]" value="answer" placeholder="Field Name" required>
                    <select name="fields[1][type]" required>
                        <option value="">Select Type</option>
                        <option value="VARCHAR(255)" selected>Text (Short)</option>
                        <option value="TEXT">Text (Long)</option>
                        <option value="INT">Number</option>
                        <option value="DECIMAL(10,2)">Decimal</option>
                        <option value="DATE">Date</option>
                    </select>
                    <label><input type="checkbox" name="fields[1][required]" checked> Required</label>
                    <input type="text" name="fields[1][default]" placeholder="Default Value">
                    <button type="button" class="btn-remove" onclick="removeField(this)">Remove</button>
                </div>
            </div>
            <button type="button" onclick="addField()">Add Field</button>
        </div>
        
        <button type="submit" class="btn-primary">Test Create Custom Data Type</button>
    </form>
    
    <div id="response"></div>
    
    <script>
        let fieldIndex = 2;
        
        function addField() {
            const container = document.getElementById('fields-container');
            const fieldRow = document.createElement('div');
            fieldRow.className = 'field-row';
            fieldRow.innerHTML = `
                <input type="text" name="fields[${fieldIndex}][name]" placeholder="Field Name" required>
                <select name="fields[${fieldIndex}][type]" required>
                    <option value="">Select Type</option>
                    <option value="VARCHAR(255)">Text (Short)</option>
                    <option value="TEXT">Text (Long)</option>
                    <option value="INT">Number</option>
                    <option value="DECIMAL(10,2)">Decimal</option>
                    <option value="DATE">Date</option>
                </select>
                <label><input type="checkbox" name="fields[${fieldIndex}][required]"> Required</label>
                <input type="text" name="fields[${fieldIndex}][default]" placeholder="Default Value">
                <button type="button" class="btn-remove" onclick="removeField(this)">Remove</button>
            `;
            container.appendChild(fieldRow);
            fieldIndex++;
        }
        
        function removeField(button) {
            const container = document.getElementById('fields-container');
            if (container.children.length > 1) {
                button.parentElement.remove();
            }
        }
        
        document.getElementById('testForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const responseDiv = document.getElementById('response');
            
            // Show form data for debugging
            let debugInfo = '<div class="debug"><h3>Form Data Being Sent:</h3><ul>';
            for (let [key, value] of formData.entries()) {
                debugInfo += `<li><strong>${key}:</strong> ${value}</li>`;
            }
            debugInfo += '</ul></div>';
            responseDiv.innerHTML = debugInfo;
            
            // Send AJAX request
            fetch(window.location.href, {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => {
                console.log('Response status:', response.status);
                return response.text().then(text => {
                    console.log('Response text:', text);
                    try {
                        return JSON.parse(text);
                    } catch (e) {
                        console.error('JSON parse error:', e);
                        throw new Error('Invalid JSON response: ' + text.substring(0, 200));
                    }
                });
            })
            .then(data => {
                console.log('Parsed data:', data);
                let responseHtml = debugInfo;
                if (data.success) {
                    responseHtml += `<div class="success"><h3>Success!</h3><p>${data.message}</p></div>`;
                } else {
                    responseHtml += `<div class="error"><h3>Error!</h3><p>${data.message}</p></div>`;
                }
                responseDiv.innerHTML = responseHtml;
            })
            .catch(error => {
                console.error('Error:', error);
                responseDiv.innerHTML = debugInfo + `<div class="error"><h3>Error!</h3><p>${error.message}</p></div>`;
            });
        });
    </script>
</body>
</html>

<?php
// Handle the form submission
if ($_POST && isset($_POST['action']) && $_POST['action'] === 'create_custom_datatype') {
    require_once 'config.php';
    
    // Enable error reporting
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    
    $name = $_POST['name'] ?? '';
    $display_name = $_POST['display_name'] ?? '';
    $description = $_POST['description'] ?? '';
    $fields = $_POST['fields'] ?? [];
    
    $error = '';
    $success = '';
    
    if (empty($name) || empty($display_name) || empty($fields)) {
        $error = 'Please fill in all required fields for custom data type';
    } else {
        try {
            // Validate field structure
            $validated_fields = [];
            $valid_types = ['VARCHAR(255)', 'TEXT', 'INT', 'DECIMAL(10,2)', 'BOOLEAN', 'DATE', 'DATETIME'];
            
            foreach ($fields as $field) {
                if (!empty($field['name']) && !empty($field['type'])) {
                    $field_type = $field['type'];
                    
                    if (!in_array($field_type, $valid_types)) {
                        $field_type = 'VARCHAR(255)';
                    }
                    
                    $validated_fields[] = [
                        'name' => $field['name'],
                        'type' => $field_type,
                        'required' => isset($field['required']) ? true : false,
                        'default' => $field['default'] ?? ''
                    ];
                }
            }
            
            if (empty($validated_fields)) {
                throw new Exception('At least one field is required');
            }
            
            $table_name = 'custom_' . strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $name));
            
            // Create custom data type record
            $stmt = $pdo->prepare("INSERT INTO custom_data_types (name, display_name, table_name, description, fields) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $display_name, $table_name, $description, json_encode($validated_fields)]);
            
            // Create the actual table
            $create_table_sql = "CREATE TABLE IF NOT EXISTS `$table_name` (
                id INT PRIMARY KEY AUTO_INCREMENT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP";
            
            foreach ($validated_fields as $field) {
                $field_name = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $field['name']));
                $field_type = $field['type'];
                $field_required = $field['required'] ? 'NOT NULL' : '';
                $field_default = !empty($field['default']) ? "DEFAULT '{$field['default']}'" : '';
                
                $create_table_sql .= ",\n                `$field_name` $field_type $field_required $field_default";
            }
            
            $create_table_sql .= "\n            )";
            
            $result = $pdo->exec($create_table_sql);
            if ($result === false) {
                $error_info = $pdo->errorInfo();
                throw new Exception('Failed to create custom data type table. SQL Error: ' . $error_info[2]);
            }
            
            $success = "Custom data type '$display_name' created successfully!";
            
        } catch (Exception $e) {
            $error = 'Error creating custom data type: ' . $e->getMessage();
        }
    }
    
    // Return JSON response for AJAX requests
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode(['success' => $success ? true : false, 'message' => $success ?: $error]);
        exit;
    }
}
?>
