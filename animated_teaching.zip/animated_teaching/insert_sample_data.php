<?php
// Direct sample data insertion
$host = 'localhost';
$dbname = 'animated_teaching';
$username = 'root';
$password = '';

echo "<h2>📝 Inserting Sample Data</h2>";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<p>✅ Connected to database</p>";
    
    // First, let's check what's in the users table
    $stmt = $pdo->query("SELECT id, username, email, roll_number, full_name, user_role FROM users");
    $users = $stmt->fetchAll();
    
    echo "<h3>Current users in database:</h3>";
    if (empty($users)) {
        echo "<p>No users found in database</p>";
    } else {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>ID</th><th>Username</th><th>Email</th><th>Roll Number</th><th>Full Name</th><th>Role</th></tr>";
        foreach ($users as $user) {
            echo "<tr>";
            echo "<td>" . $user['id'] . "</td>";
            echo "<td>" . ($user['username'] ?? 'NULL') . "</td>";
            echo "<td>" . ($user['email'] ?? 'NULL') . "</td>";
            echo "<td>" . ($user['roll_number'] ?? 'NULL') . "</td>";
            echo "<td>" . $user['full_name'] . "</td>";
            echo "<td>" . $user['user_role'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    // Insert sample data
    echo "<h3>Inserting sample data...</h3>";
    
    // Insert admin
    try {
        $pdo->exec("INSERT IGNORE INTO users (username, email, password, full_name, user_role, is_active, email_verified) VALUES ('admin', 'admin@apnaschool.com', '$2y$10\$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'admin', 1, 1)");
        echo "<p>✅ Admin user inserted/updated</p>";
    } catch (Exception $e) {
        echo "<p>ℹ️ Admin: " . $e->getMessage() . "</p>";
    }
    
    // Insert student STU001
    try {
        $pdo->exec("INSERT IGNORE INTO users (roll_number, full_name, user_role, is_active, email_verified) VALUES ('STU001', 'John Student', 'student', 1, 1)");
        echo "<p>✅ Student STU001 inserted/updated</p>";
    } catch (Exception $e) {
        echo "<p>ℹ️ STU001: " . $e->getMessage() . "</p>";
    }
    
    // Insert student STU002
    try {
        $pdo->exec("INSERT IGNORE INTO users (roll_number, full_name, user_role, is_active, email_verified) VALUES ('STU002', 'Mike Student', 'student', 1, 1)");
        echo "<p>✅ Student STU002 inserted/updated</p>";
    } catch (Exception $e) {
        echo "<p>ℹ️ STU002: " . $e->getMessage() . "</p>";
    }
    
    // Insert regular user
    try {
        $pdo->exec("INSERT IGNORE INTO users (username, email, password, full_name, user_role, is_active, email_verified) VALUES ('sarah_user', 'sarah@user.com', '$2y$10\$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Sarah User', 'user', 1, 1)");
        echo "<p>✅ User sarah_user inserted/updated</p>";
    } catch (Exception $e) {
        echo "<p>ℹ️ sarah_user: " . $e->getMessage() . "</p>";
    }
    
    // Show updated users
    echo "<h3>Updated users in database:</h3>";
    $stmt = $pdo->query("SELECT id, username, email, roll_number, full_name, user_role FROM users ORDER BY id");
    $users = $stmt->fetchAll();
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>ID</th><th>Username</th><th>Email</th><th>Roll Number</th><th>Full Name</th><th>Role</th></tr>";
    foreach ($users as $user) {
        echo "<tr>";
        echo "<td>" . $user['id'] . "</td>";
        echo "<td>" . ($user['username'] ?? 'NULL') . "</td>";
        echo "<td>" . ($user['email'] ?? 'NULL') . "</td>";
        echo "<td>" . ($user['roll_number'] ?? 'NULL') . "</td>";
        echo "<td>" . $user['full_name'] . "</td>";
        echo "<td>" . $user['user_role'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<h3>🎉 Sample data insertion completed!</h3>";
    echo "<p><strong>You can now login with:</strong></p>";
    echo "<ul>";
    echo "<li><strong>Admin:</strong> admin / password</li>";
    echo "<li><strong>Student:</strong> STU001 (no password)</li>";
    echo "<li><strong>Student:</strong> STU002 (no password)</li>";
    echo "<li><strong>User:</strong> sarah_user / password</li>";
    echo "</ul>";
    
    echo "<p><a href='login.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Go to Login</a></p>";
    
} catch (PDOException $e) {
    echo "<h2>❌ Database Error:</h2>";
    echo "<p>" . $e->getMessage() . "</p>";
}
?>
