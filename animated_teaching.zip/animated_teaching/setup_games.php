<?php
require_once 'config.php';

echo "Setting up game content tables...\n";

try {
    // Read the updated SQL file
    $sql = file_get_contents('setup_tables.sql');
    
    // Extract only the game content tables section
    $gameTablesStart = strpos($sql, '-- Game Content Tables');
    $gameTablesEnd = strpos($sql, '-- Insert sample game content', $gameTablesStart);
    
    if ($gameTablesStart !== false && $gameTablesEnd !== false) {
        $gameTablesSQL = substr($sql, $gameTablesStart, $gameTablesEnd - $gameTablesStart);
        $sampleDataSQL = substr($sql, $gameTablesEnd);
        
        // Split by semicolon and execute each statement
        $statements = array_filter(array_map('trim', explode(';', $gameTablesSQL . $sampleDataSQL)));
        
        foreach ($statements as $statement) {
            if (!empty($statement) && !preg_match('/^--/', $statement)) {
                try {
                    $pdo->exec($statement);
                    echo "✓ Executed: " . substr($statement, 0, 50) . "...\n";
                } catch (PDOException $e) {
                    echo "✗ Error executing statement: " . $e->getMessage() . "\n";
                    echo "Statement: " . substr($statement, 0, 100) . "...\n";
                }
            }
        }
        
        echo "\n🎮 Game content tables setup completed!\n";
        echo "You can now:\n";
        echo "1. Visit admin.php to manage game content\n";
        echo "2. Play games on index.php\n";
        echo "3. Add questions, memory pairs, word puzzles, and math problems\n";
        
    } else {
        echo "✗ Could not find game content tables in setup_tables.sql\n";
    }
    
} catch(PDOException $e) {
    echo "✗ Database error: " . $e->getMessage() . "\n";
}
?>