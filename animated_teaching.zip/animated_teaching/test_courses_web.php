<!DOCTYPE html>
<html>
<head>
    <title>Course Functionality Test</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
        .container { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: green; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .error { color: red; background: #f8d7da; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .warning { color: orange; background: #fff3cd; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .btn { background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 10px 5px; }
    </style>
</head>
<body>
<div class='container'>
<h2>🔍 Course Functionality Test</h2>

<?php
require_once 'config.php';

try {
    // Test database connection
    echo "<div class='success'>✅ Database connection successful</div>";
    
    // Check if courses table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'courses'");
    if ($stmt->rowCount() > 0) {
        echo "<div class='success'>✅ Courses table exists</div>";
        
        // Get course count
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM courses");
        $result = $stmt->fetch();
        echo "<div class='success'>📊 Total courses: " . $result['count'] . "</div>";
        
        // Show existing courses
        $stmt = $pdo->query("SELECT * FROM courses ORDER BY created_at DESC LIMIT 5");
        $courses = $stmt->fetchAll();
        
        if (count($courses) > 0) {
            echo "<h3>Recent Courses:</h3>";
            echo "<ul>";
            foreach ($courses as $course) {
                echo "<li><strong>" . htmlspecialchars($course['title']) . "</strong> - " . htmlspecialchars($course['description']) . "</li>";
            }
            echo "</ul>";
        } else {
            echo "<div class='warning'>⚠️ No courses found in database</div>";
        }
        
    } else {
        echo "<div class='error'>❌ Courses table does not exist</div>";
        echo "<div class='warning'>🔧 Please run the database setup first</div>";
        echo "<a href='quick_fix.php' class='btn'>🔧 Quick Database Fix</a>";
    }
    
} catch (PDOException $e) {
    echo "<div class='error'>❌ Database error: " . $e->getMessage() . "</div>";
    echo "<div class='warning'>🔧 Please check your database configuration</div>";
}

// Test course insertion
echo "<h3>Test Course Insertion</h3>";
try {
    $test_title = "Test Course " . date('Y-m-d H:i:s');
    $test_description = "This is a test course to verify functionality";
    
    $stmt = $pdo->prepare("INSERT INTO courses (title, description, difficulty_level, total_lessons, course_image) VALUES (?, ?, ?, ?, ?)");
    $result = $stmt->execute([$test_title, $test_description, 'beginner', 5, 'default-course.jpg']);
    
    if ($result) {
        echo "<div class='success'>✅ Course insertion test successful</div>";
        echo "<div class='success'>📝 Test course: " . $test_title . "</div>";
    } else {
        echo "<div class='error'>❌ Course insertion test failed</div>";
    }
    
} catch (PDOException $e) {
    echo "<div class='error'>❌ Course insertion error: " . $e->getMessage() . "</div>";
}

echo "<br><a href='index.php' class='btn'>🏠 Back to Home</a>";
echo "<a href='quick_fix.php' class='btn'>🔧 Database Fix</a>";
?>

</div>
</body>
</html>
