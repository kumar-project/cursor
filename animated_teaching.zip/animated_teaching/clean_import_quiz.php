<?php
require_once 'config.php';

echo "<h2>Clean Quiz Import with Proper Encoding</h2>";

try {
    // Step 1: Ensure proper database setup
    echo "<h3>Step 1: Setting up Database with Proper Encoding</h3>";
    
    // Set database charset
    $pdo->exec("ALTER DATABASE animated_teaching CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    echo "✓ Database charset set to utf8mb4<br>";
    
    // Drop and recreate table with proper encoding
    $pdo->exec("DROP TABLE IF EXISTS quiz_questions");
    echo "✓ Dropped existing quiz_questions table<br>";
    
    $create_table_sql = "
        CREATE TABLE quiz_questions (
            id INT PRIMARY KEY AUTO_INCREMENT,
            question TEXT NOT NULL,
            option_a VARCHAR(255) NOT NULL,
            option_b VARCHAR(255) NOT NULL,
            option_c VARCHAR(255) NOT NULL,
            option_d VARCHAR(255) NOT NULL,
            correct_answer ENUM('A', 'B', 'C', 'D') NOT NULL,
            points INT DEFAULT 10,
            difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
            category VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ";
    
    $pdo->exec($create_table_sql);
    echo "✓ Created quiz_questions table with utf8mb4 encoding<br>";
    
    // Step 2: Import clean data
    echo "<h3>Step 2: Importing Clean Quiz Data</h3>";
    
    $quizData = [
        // Geography Questions
        ['What is the capital of France?', 'London', 'Berlin', 'Paris', 'Madrid', 'C', 'Geography', 'easy', 10],
        ['What is the largest ocean on Earth?', 'Atlantic', 'Indian', 'Pacific', 'Arctic', 'C', 'Geography', 'easy', 10],
        ['Which country has the most population?', 'India', 'China', 'USA', 'Brazil', 'B', 'Geography', 'medium', 15],
        ['What is the smallest country in the world?', 'Monaco', 'Vatican City', 'San Marino', 'Liechtenstein', 'B', 'Geography', 'hard', 20],
        ['Which continent is Brazil located in?', 'North America', 'South America', 'Europe', 'Africa', 'B', 'Geography', 'easy', 10],
        
        // Science Questions
        ['Which planet is known as the Red Planet?', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'B', 'Science', 'easy', 10],
        ['What is the chemical symbol for gold?', 'Go', 'Gd', 'Au', 'Ag', 'C', 'Science', 'medium', 15],
        ['What is the speed of light?', '299,792,458 m/s', '300,000,000 m/s', '299,000,000 m/s', '301,000,000 m/s', 'A', 'Science', 'hard', 20],
        ['What gas do plants absorb from the atmosphere?', 'Oxygen', 'Carbon Dioxide', 'Nitrogen', 'Hydrogen', 'B', 'Science', 'medium', 15],
        ['What is the hardest natural substance on Earth?', 'Gold', 'Iron', 'Diamond', 'Platinum', 'C', 'Science', 'medium', 15],
        
        // Math Questions
        ['What is 15 + 27?', '40', '42', '41', '43', 'B', 'Math', 'easy', 10],
        ['What is 8 × 7?', '54', '56', '58', '60', 'B', 'Math', 'easy', 10],
        ['What is 144 ÷ 12?', '10', '11', '12', '13', 'C', 'Math', 'easy', 10],
        ['What is the square root of 64?', '6', '7', '8', '9', 'C', 'Math', 'medium', 15],
        ['What is 15% of 200?', '25', '30', '35', '40', 'B', 'Math', 'medium', 15],
        
        // Art & Culture Questions
        ['Who painted the Mona Lisa?', 'Van Gogh', 'Picasso', 'Da Vinci', 'Michelangelo', 'C', 'Art', 'medium', 15],
        ['Which composer wrote "The Four Seasons"?', 'Bach', 'Mozart', 'Vivaldi', 'Beethoven', 'C', 'Art', 'hard', 20],
        ['In which country was the Renaissance period most prominent?', 'France', 'Germany', 'Italy', 'Spain', 'C', 'Art', 'medium', 15],
        
        // General Knowledge
        ['What is the largest mammal in the world?', 'African Elephant', 'Blue Whale', 'Giraffe', 'Hippopotamus', 'B', 'General', 'easy', 10],
        ['Which year did World War II end?', '1944', '1945', '1946', '1947', 'B', 'History', 'medium', 15],
        ['What is the currency of Japan?', 'Won', 'Yuan', 'Yen', 'Dollar', 'C', 'General', 'easy', 10],
        ['Which programming language is known for web development?', 'C++', 'Java', 'JavaScript', 'Python', 'C', 'Technology', 'medium', 15],
        ['What does CPU stand for?', 'Central Processing Unit', 'Computer Processing Unit', 'Central Program Unit', 'Computer Program Unit', 'A', 'Technology', 'easy', 10]
    ];
    
    $stmt = $pdo->prepare("INSERT INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_answer, category, difficulty, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    $imported = 0;
    $errors = 0;
    
    foreach ($quizData as $index => $data) {
        try {
            if ($stmt->execute($data)) {
                $imported++;
            } else {
                $errors++;
                echo "⚠ Error importing question " . ($index + 1) . "<br>";
            }
        } catch (Exception $e) {
            $errors++;
            echo "⚠ Error importing question " . ($index + 1) . ": " . $e->getMessage() . "<br>";
        }
    }
    
    echo "✓ Successfully imported $imported quiz questions<br>";
    if ($errors > 0) {
        echo "⚠ $errors questions failed to import<br>";
    }
    
    // Step 3: Verify the import
    echo "<h3>Step 3: Verifying Import</h3>";
    
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM quiz_questions");
    $count = $stmt->fetch();
    echo "Total questions in database: " . $count['count'] . "<br>";
    
    // Check categories
    $stmt = $pdo->query("SELECT category, COUNT(*) as count FROM quiz_questions GROUP BY category ORDER BY count DESC");
    $categories = $stmt->fetchAll();
    echo "<strong>Questions by category:</strong><br>";
    foreach ($categories as $cat) {
        echo "- " . htmlspecialchars($cat['category']) . ": " . $cat['count'] . " questions<br>";
    }
    
    // Check difficulties
    $stmt = $pdo->query("SELECT difficulty, COUNT(*) as count FROM quiz_questions GROUP BY difficulty ORDER BY count DESC");
    $difficulties = $stmt->fetchAll();
    echo "<strong>Questions by difficulty:</strong><br>";
    foreach ($difficulties as $diff) {
        echo "- " . htmlspecialchars($diff['difficulty']) . ": " . $diff['count'] . " questions<br>";
    }
    
    // Show sample questions
    echo "<h3>Sample Questions:</h3>";
    $stmt = $pdo->query("SELECT id, question, category, difficulty, points FROM quiz_questions ORDER BY RAND() LIMIT 5");
    $sample = $stmt->fetchAll();
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr style='background-color: #f0f0f0;'><th>ID</th><th>Question</th><th>Category</th><th>Difficulty</th><th>Points</th></tr>";
    foreach ($sample as $row) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['id']) . "</td>";
        echo "<td>" . htmlspecialchars($row['question']) . "</td>";
        echo "<td>" . htmlspecialchars($row['category']) . "</td>";
        echo "<td>" . htmlspecialchars($row['difficulty']) . "</td>";
        echo "<td>" . htmlspecialchars($row['points']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<h3>✅ Import Complete!</h3>";
    echo "<p>Your quiz questions have been imported successfully with proper UTF-8 encoding. The garbled text issue should now be resolved.</p>";
    echo "<p><a href='admin.php?tab=quiz' style='background: #007cba; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Go to Admin Panel</a> | <a href='index.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Go to Home</a></p>";
    
} catch (Exception $e) {
    echo "<h3>❌ Error occurred:</h3>";
    echo "<p style='color: red;'>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p>Please check your database connection and try again.</p>";
}
?>
