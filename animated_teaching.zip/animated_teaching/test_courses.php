<?php
require_once 'config.php';

echo "<h2>Course Functionality Test</h2>";

try {
    // Test database connection
    echo "<p>✅ Database connection successful</p>";
    
    // Check if courses table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'courses'");
    if ($stmt->rowCount() > 0) {
        echo "<p>✅ Courses table exists</p>";
        
        // Get course count
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM courses");
        $result = $stmt->fetch();
        echo "<p>📊 Total courses: " . $result['count'] . "</p>";
        
        // Show existing courses
        $stmt = $pdo->query("SELECT * FROM courses ORDER BY created_at DESC LIMIT 5");
        $courses = $stmt->fetchAll();
        
        if (count($courses) > 0) {
            echo "<h3>Recent Courses:</h3>";
            echo "<ul>";
            foreach ($courses as $course) {
                echo "<li><strong>" . htmlspecialchars($course['title']) . "</strong> - " . htmlspecialchars($course['description']) . "</li>";
            }
            echo "</ul>";
        } else {
            echo "<p>⚠️ No courses found in database</p>";
        }
        
    } else {
        echo "<p>❌ Courses table does not exist</p>";
        echo "<p>🔧 Please run the database setup first</p>";
    }
    
} catch (PDOException $e) {
    echo "<p>❌ Database error: " . $e->getMessage() . "</p>";
    echo "<p>🔧 Please check your database configuration</p>";
}

// Test course insertion
echo "<h3>Test Course Insertion</h3>";
try {
    $test_title = "Test Course " . date('Y-m-d H:i:s');
    $test_description = "This is a test course to verify functionality";
    
    $stmt = $pdo->prepare("INSERT INTO courses (title, description, difficulty_level, total_lessons, course_image) VALUES (?, ?, ?, ?, ?)");
    $result = $stmt->execute([$test_title, $test_description, 'beginner', 5, 'default-course.jpg']);
    
    if ($result) {
        echo "<p>✅ Course insertion test successful</p>";
        echo "<p>📝 Test course: " . $test_title . "</p>";
    } else {
        echo "<p>❌ Course insertion test failed</p>";
    }
    
} catch (PDOException $e) {
    echo "<p>❌ Course insertion error: " . $e->getMessage() . "</p>";
}
?>
