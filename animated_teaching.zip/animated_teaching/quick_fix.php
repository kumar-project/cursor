<?php
// Quick database fix for registration issues
$host = 'localhost';
$dbname = 'animated_teaching';
$username = 'root';
$password = '';

echo "<h2>🚀 Quick Database Fix</h2>";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<p>✅ Connected to database</p>";
    
    // Step 1: Fix password field
    try {
        $pdo->exec("ALTER TABLE users MODIFY COLUMN password VARCHAR(255) NULL");
        echo "<p>✅ Fixed password field (made nullable)</p>";
    } catch (Exception $e) {
        echo "<p>ℹ️ Password field: " . $e->getMessage() . "</p>";
    }
    
    // Step 2: Add roll_number field
    try {
        $pdo->exec("ALTER TABLE users ADD COLUMN roll_number VARCHAR(20) UNIQUE");
        echo "<p>✅ Added roll_number field</p>";
    } catch (Exception $e) {
        echo "<p>ℹ️ Roll number field: " . $e->getMessage() . "</p>";
    }
    
    // Step 3: Insert all sample data
    $sample_users = [
        ['username' => 'admin', 'email' => 'admin@apnaschool.com', 'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'full_name' => 'System Administrator', 'user_role' => 'admin'],
        ['roll_number' => 'STU001', 'full_name' => 'John Student', 'user_role' => 'student'],
        ['roll_number' => 'STU002', 'full_name' => 'Mike Student', 'user_role' => 'student'],
        ['username' => 'sarah_user', 'email' => 'sarah@user.com', 'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'full_name' => 'Sarah User', 'user_role' => 'user']
    ];
    
    foreach ($sample_users as $user) {
        try {
            if (isset($user['username'])) {
                // User/Admin with username and password
                $pdo->exec("INSERT IGNORE INTO users (username, email, password, full_name, user_role, is_active, email_verified) VALUES ('{$user['username']}', '{$user['email']}', '{$user['password']}', '{$user['full_name']}', '{$user['user_role']}', 1, 1)");
            } else {
                // Student with roll number only
                $pdo->exec("INSERT IGNORE INTO users (roll_number, full_name, user_role, is_active, email_verified) VALUES ('{$user['roll_number']}', '{$user['full_name']}', '{$user['user_role']}', 1, 1)");
            }
            echo "<p>✅ Added {$user['full_name']} ({$user['user_role']})</p>";
        } catch (Exception $e) {
            echo "<p>ℹ️ {$user['full_name']}: " . $e->getMessage() . "</p>";
        }
    }
    
    // Step 4: Test registration query
    echo "<h3>🧪 Testing Registration</h3>";
    try {
        $test_stmt = $pdo->prepare("INSERT INTO users (roll_number, full_name, user_role, is_active, email_verified) VALUES (?, ?, 'student', 1, 1)");
        $test_stmt->execute(['TEST123', 'Test Student']);
        echo "<p>✅ Student registration test passed</p>";
        
        $pdo->exec("DELETE FROM users WHERE roll_number = 'TEST123'");
        echo "<p>✅ Test data cleaned up</p>";
    } catch (Exception $e) {
        echo "<p>❌ Registration test failed: " . $e->getMessage() . "</p>";
    }
    
    echo "<h3>🎉 Quick Fix Completed!</h3>";
    echo "<p><strong>You can now:</strong></p>";
    echo "<ul>";
    echo "<li>✅ Register new students with roll numbers</li>";
    echo "<li>✅ Register new users with username/email</li>";
    echo "<li>✅ Register new admins with full access</li>";
    echo "<li>✅ Login with existing accounts</li>";
    echo "</ul>";
    
    echo "<p><strong>Demo Accounts:</strong></p>";
    echo "<ul>";
    echo "<li>👑 <strong>Admin:</strong> admin / password</li>";
    echo "<li>🎓 <strong>Student:</strong> STU001 (no password)</li>";
    echo "<li>👤 <strong>User:</strong> sarah_user / password</li>";
    echo "</ul>";
    
    echo "<div style='margin: 20px 0;'>";
    echo "<a href='register.php' style='background: #007bff; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; margin-right: 10px;'>Try Registration</a>";
    echo "<a href='login.php' style='background: #28a745; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px;'>Go to Login</a>";
    echo "</div>";
    
} catch (PDOException $e) {
    echo "<h2>❌ Database Connection Error:</h2>";
    echo "<p><strong>Error:</strong> " . $e->getMessage() . "</p>";
    echo "<p><strong>Solutions:</strong></p>";
    echo "<ul>";
    echo "<li>Make sure WAMP/XAMPP is running</li>";
    echo "<li>Start MySQL service</li>";
    echo "<li>Check if 'animated_teaching' database exists</li>";
    echo "<li>Verify database credentials</li>";
    echo "</ul>";
}
?>