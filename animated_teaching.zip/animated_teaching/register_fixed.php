<?php
// Try PDO first, fallback to MySQLi
$use_mysqli = false;

try {
    require_once 'config.php';
    // Test PDO connection
    $pdo->query("SELECT 1");
} catch (Exception $e) {
    $use_mysqli = true;
    require_once 'config_mysqli.php';
}

require_once 'auth.php';

// Redirect if already logged in
if (is_logged_in()) {
    if (is_admin()) {
        header('Location: admin_dashboard.php');
    } else {
        header('Location: dashboard.php');
    }
    exit();
}

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $roll_number = trim($_POST['roll_number'] ?? '');
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $full_name = trim($_POST['full_name']);
    $user_role = $_POST['user_role'];
    
    // Validation based on user role
    if (empty($full_name)) {
        $error_message = 'Please fill in all required fields.';
    } elseif ($user_role == 'student') {
        // Student validation - only roll number required, no password
        if (empty($roll_number)) {
            $error_message = 'Roll number is required for students.';
        } else {
            try {
                if ($use_mysqli) {
                    // MySQLi version
                    $sql = "SELECT id FROM users WHERE roll_number = ?";
                    $stmt = $mysqli->prepare($sql);
                    $stmt->bind_param('s', $roll_number);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    if ($result->num_rows > 0) {
                        $error_message = 'Roll number already exists.';
                    } else {
                        // Create new student without password
                        $sql = "INSERT INTO users (roll_number, full_name, user_role, is_active, email_verified) VALUES (?, ?, 'student', 1, 1)";
                        $stmt = $mysqli->prepare($sql);
                        $stmt->bind_param('ss', $roll_number, $full_name);
                        
                        if ($stmt->execute()) {
                            $success_message = 'Registration successful! You can now login with just your roll number.';
                            // Clear form data
                            $_POST = array();
                        } else {
                            $error_message = 'Registration failed. Please try again.';
                        }
                    }
                } else {
                    // PDO version
                    $check_stmt = $pdo->prepare("SELECT id FROM users WHERE roll_number = ?");
                    $check_stmt->execute([$roll_number]);
                    
                    if ($check_stmt->fetch()) {
                        $error_message = 'Roll number already exists.';
                    } else {
                        // Create new student without password
                        $stmt = $pdo->prepare("INSERT INTO users (roll_number, full_name, user_role, is_active, email_verified) VALUES (?, ?, 'student', 1, 1)");
                        
                        if ($stmt->execute([$roll_number, $full_name])) {
                            $success_message = 'Registration successful! You can now login with just your roll number.';
                            // Clear form data
                            $_POST = array();
                        } else {
                            $error_message = 'Registration failed. Please try again.';
                        }
                    }
                }
            } catch (Exception $e) {
                $error_message = 'Database error. Please try again.';
            }
        }
    } else {
        // User/Admin validation - username, email, and password required
        if (empty($username) || empty($email) || empty($password)) {
            $error_message = 'Username, email, and password are required for users and admins.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error_message = 'Please enter a valid email address.';
        } elseif (strlen($password) < 6) {
            $error_message = 'Password must be at least 6 characters long.';
        } elseif ($password !== $confirm_password) {
            $error_message = 'Passwords do not match.';
        } elseif (!in_array($user_role, ['user', 'admin'])) {
            $error_message = 'Invalid user role selected.';
        } else {
            try {
                if ($use_mysqli) {
                    // MySQLi version
                    $sql = "SELECT id FROM users WHERE username = ? OR email = ?";
                    $stmt = $mysqli->prepare($sql);
                    $stmt->bind_param('ss', $username, $email);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    if ($result->num_rows > 0) {
                        $error_message = 'Username or email already exists.';
                    } else {
                        // Create new user/admin with password
                        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                        $sql = "INSERT INTO users (username, email, password, full_name, user_role, is_active, email_verified) VALUES (?, ?, ?, ?, ?, 1, 1)";
                        $stmt = $mysqli->prepare($sql);
                        $stmt->bind_param('sssss', $username, $email, $hashed_password, $full_name, $user_role);
                        
                        if ($stmt->execute()) {
                            $role_text = ($user_role == 'admin') ? 'admin' : 'user';
                            $success_message = "Registration successful! You can now login as a $role_text.";
                            // Clear form data
                            $_POST = array();
                        } else {
                            $error_message = 'Registration failed. Please try again.';
                        }
                    }
                } else {
                    // PDO version
                    $check_stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
                    $check_stmt->execute([$username, $email]);
                    
                    if ($check_stmt->fetch()) {
                        $error_message = 'Username or email already exists.';
                    } else {
                        // Create new user/admin with password
                        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                        $stmt = $pdo->prepare("INSERT INTO users (username, email, password, full_name, user_role, is_active, email_verified) VALUES (?, ?, ?, ?, ?, 1, 1)");
                        
                        if ($stmt->execute([$username, $email, $hashed_password, $full_name, $user_role])) {
                            $role_text = ($user_role == 'admin') ? 'admin' : 'user';
                            $success_message = "Registration successful! You can now login as a $role_text.";
                            // Clear form data
                            $_POST = array();
                        } else {
                            $error_message = 'Registration failed. Please try again.';
                        }
                    }
                }
            } catch (Exception $e) {
                $error_message = 'Database error. Please try again.';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Apna School</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .auth-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
        }
        .auth-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            padding: 40px;
            width: 100%;
            max-width: 450px;
        }
        .auth-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .auth-header h1 {
            color: #333;
            margin-bottom: 10px;
            font-size: 2rem;
        }
        .auth-header p {
            color: #666;
            margin: 0;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
            box-sizing: border-box;
        }
        .form-group input:focus, .form-group select:focus {
            outline: none;
            border-color: #667eea;
        }
        .form-row {
            display: flex;
            gap: 15px;
        }
        .form-row .form-group {
            flex: 1;
        }
        .btn-register {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s;
        }
        .btn-register:hover {
            transform: translateY(-2px);
        }
        .error-message {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
        .success-message {
            background: #efe;
            color: #363;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
        .auth-links {
            text-align: center;
            margin-top: 20px;
        }
        .auth-links a {
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
        }
        .auth-links a:hover {
            text-decoration: underline;
        }
        .role-info {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .role-info h4 {
            margin: 0 0 10px 0;
            color: #333;
        }
        .role-info p {
            margin: 5px 0;
            color: #666;
            font-size: 0.9rem;
        }
        .db-status {
            background: #e7f3ff;
            color: #0066cc;
            padding: 8px 12px;
            border-radius: 5px;
            margin-bottom: 15px;
            font-size: 0.9rem;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <h1><i class="fas fa-graduation-cap"></i> Apna School</h1>
                <p>Join our learning community!</p>
            </div>
            
            <?php if ($use_mysqli): ?>
                <div class="db-status">
                    <i class="fas fa-info-circle"></i> Using MySQLi connection (PDO not available)
                </div>
            <?php endif; ?>
            
            <?php if ($error_message): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error_message); ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success_message): ?>
                <div class="success-message">
                    <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success_message); ?>
                </div>
            <?php endif; ?>
            
            <div class="role-info">
                <h4><i class="fas fa-info-circle"></i> Choose Your Role</h4>
                <p><strong>Student:</strong> Use only your roll number to access learning games (no password needed)</p>
                <p><strong>User:</strong> Use username/email and password for full access to games with advanced features</p>
                <p><strong>Admin:</strong> Full system access to manage users, games, and platform settings</p>
            </div>
            
            <form method="POST" action="" id="registrationForm">
                <div class="form-group">
                    <label for="user_role"><i class="fas fa-user-tag"></i> Account Type</label>
                    <select id="user_role" name="user_role" required onchange="toggleFields()">
                        <option value="">Select Account Type</option>
                        <option value="student" <?php echo (($_POST['user_role'] ?? '') == 'student') ? 'selected' : ''; ?>>Student</option>
                        <option value="user" <?php echo (($_POST['user_role'] ?? '') == 'user') ? 'selected' : ''; ?>>User</option>
                        <option value="admin" <?php echo (($_POST['user_role'] ?? '') == 'admin') ? 'selected' : ''; ?>>Admin</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="full_name"><i class="fas fa-user"></i> Full Name</label>
                    <input type="text" id="full_name" name="full_name" required value="<?php echo htmlspecialchars($_POST['full_name'] ?? ''); ?>">
                </div>
                
                <!-- Student Fields -->
                <div id="studentFields" style="display: none;">
                    <div class="form-group">
                        <label for="roll_number"><i class="fas fa-id-card"></i> Roll Number</label>
                        <input type="text" id="roll_number" name="roll_number" value="<?php echo htmlspecialchars($_POST['roll_number'] ?? ''); ?>">
                    </div>
                </div>
                
                <!-- User Fields -->
                <div id="userFields" style="display: none;">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="username"><i class="fas fa-at"></i> Username</label>
                            <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="email"><i class="fas fa-envelope"></i> Email</label>
                            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                        </div>
                    </div>
                </div>
                
                <!-- Password Fields (only for users) -->
                <div id="passwordFields" style="display: none;">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="password"><i class="fas fa-lock"></i> Password</label>
                            <input type="password" id="password" name="password">
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password"><i class="fas fa-lock"></i> Confirm Password</label>
                            <input type="password" id="confirm_password" name="confirm_password">
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn-register">
                    <i class="fas fa-user-plus"></i> Create Account
                </button>
            </form>
            
            <div class="auth-links">
                <p>Already have an account? <a href="login.php">Sign in here</a></p>
            </div>
        </div>
    </div>
    
    <script>
        function toggleFields() {
            const userRole = document.getElementById('user_role').value;
            const studentFields = document.getElementById('studentFields');
            const userFields = document.getElementById('userFields');
            const passwordFields = document.getElementById('passwordFields');
            const rollNumberInput = document.getElementById('roll_number');
            const usernameInput = document.getElementById('username');
            const emailInput = document.getElementById('email');
            const passwordInput = document.getElementById('password');
            const confirmPasswordInput = document.getElementById('confirm_password');
            
            if (userRole === 'student') {
                studentFields.style.display = 'block';
                userFields.style.display = 'none';
                passwordFields.style.display = 'none';
                rollNumberInput.required = true;
                usernameInput.required = false;
                emailInput.required = false;
                passwordInput.required = false;
                confirmPasswordInput.required = false;
            } else if (userRole === 'user' || userRole === 'admin') {
                studentFields.style.display = 'none';
                userFields.style.display = 'block';
                passwordFields.style.display = 'block';
                rollNumberInput.required = false;
                usernameInput.required = true;
                emailInput.required = true;
                passwordInput.required = true;
                confirmPasswordInput.required = true;
            } else {
                studentFields.style.display = 'none';
                userFields.style.display = 'none';
                passwordFields.style.display = 'none';
                rollNumberInput.required = false;
                usernameInput.required = false;
                emailInput.required = false;
                passwordInput.required = false;
                confirmPasswordInput.required = false;
            }
        }
        
        // Initialize fields on page load
        document.addEventListener('DOMContentLoaded', function() {
            toggleFields();
        });
    </script>
</body>
</html>
