<?php
// Comprehensive database fix for registration issues
$host = 'localhost';
$dbname = 'animated_teaching';
$username = 'root';
$password = '';

echo "<h2>🔧 Fixing Database for Registration</h2>";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<p>✅ Connected to database successfully</p>";
    
    // Check current table structure
    $stmt = $pdo->query("DESCRIBE users");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo "<p>📋 Current columns: " . implode(', ', $columns) . "</p>";
    
    // Fix 1: Make password nullable
    if (in_array('password', $columns)) {
        try {
            $pdo->exec("ALTER TABLE users MODIFY COLUMN password VARCHAR(255) NULL");
            echo "<p>✅ Password field made nullable</p>";
        } catch (Exception $e) {
            echo "<p>ℹ️ Password field already nullable</p>";
        }
    }
    
    // Fix 2: Add roll_number field if it doesn't exist
    if (!in_array('roll_number', $columns)) {
        try {
            $pdo->exec("ALTER TABLE users ADD COLUMN roll_number VARCHAR(20) UNIQUE");
            echo "<p>✅ Added roll_number field</p>";
        } catch (Exception $e) {
            echo "<p>❌ Error adding roll_number: " . $e->getMessage() . "</p>";
        }
    } else {
        echo "<p>ℹ️ roll_number field already exists</p>";
    }
    
    // Fix 3: Check if roll_number has unique constraint
    try {
        $stmt = $pdo->query("SHOW INDEX FROM users WHERE Column_name = 'roll_number'");
        $indexes = $stmt->fetchAll();
        if (empty($indexes)) {
            $pdo->exec("ALTER TABLE users ADD UNIQUE KEY unique_roll_number (roll_number)");
            echo "<p>✅ Added unique constraint to roll_number</p>";
        } else {
            echo "<p>ℹ️ roll_number already has unique constraint</p>";
        }
    } catch (Exception $e) {
        echo "<p>ℹ️ Unique constraint already exists or error: " . $e->getMessage() . "</p>";
    }
    
    // Fix 4: Update existing student records
    try {
        $result = $pdo->exec("UPDATE users SET password = NULL WHERE user_role = 'student'");
        echo "<p>✅ Updated $result student records to have NULL passwords</p>";
    } catch (Exception $e) {
        echo "<p>ℹ️ Student update: " . $e->getMessage() . "</p>";
    }
    
    // Fix 5: Add sample data
    try {
        $pdo->exec("INSERT IGNORE INTO users (roll_number, full_name, user_role, total_points, level, is_active, email_verified) VALUES ('STU001', 'John Student', 'student', 150, 2, 1, 1)");
        echo "<p>✅ Added sample student STU001</p>";
    } catch (Exception $e) {
        echo "<p>ℹ️ STU001: " . $e->getMessage() . "</p>";
    }
    
    try {
        $pdo->exec("INSERT IGNORE INTO users (roll_number, full_name, user_role, total_points, level, is_active, email_verified) VALUES ('STU002', 'Mike Student', 'student', 75, 1, 1, 1)");
        echo "<p>✅ Added sample student STU002</p>";
    } catch (Exception $e) {
        echo "<p>ℹ️ STU002: " . $e->getMessage() . "</p>";
    }
    
    // Test the registration query
    echo "<h3>🧪 Testing Registration Query</h3>";
    try {
        $test_stmt = $pdo->prepare("INSERT INTO users (roll_number, full_name, user_role, is_active, email_verified) VALUES (?, ?, 'student', 1, 1)");
        $test_stmt->execute(['TEST001', 'Test Student']);
        echo "<p>✅ Registration query test successful</p>";
        
        // Clean up test record
        $pdo->exec("DELETE FROM users WHERE roll_number = 'TEST001'");
        echo "<p>✅ Test record cleaned up</p>";
    } catch (Exception $e) {
        echo "<p>❌ Registration query test failed: " . $e->getMessage() . "</p>";
    }
    
    echo "<h3>🎉 Database fix completed!</h3>";
    echo "<p><strong>You can now:</strong></p>";
    echo "<ul>";
    echo "<li>Register new students with roll numbers</li>";
    echo "<li>Login with existing accounts</li>";
    echo "<li>Use demo accounts: STU001, STU002, admin, sarah_user</li>";
    echo "</ul>";
    
    echo "<p><a href='register.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Try Registration Again</a></p>";
    echo "<p><a href='login.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Go to Login</a></p>";
    
} catch (PDOException $e) {
    echo "<h2>❌ Database Connection Error:</h2>";
    echo "<p><strong>Error:</strong> " . $e->getMessage() . "</p>";
    echo "<p><strong>Possible solutions:</strong></p>";
    echo "<ul>";
    echo "<li>Make sure WAMP/XAMPP is running</li>";
    echo "<li>Check if MySQL service is started</li>";
    echo "<li>Verify database 'animated_teaching' exists</li>";
    echo "<li>Check database credentials in config.php</li>";
    echo "</ul>";
}
?>
