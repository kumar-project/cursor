# 🔧 Login Issue Fix Instructions

## Problem
You're getting "Invalid username/email/roll number" error when trying to log in with "STU001".

## Root Cause
The PDO MySQL extension is not enabled in your WAMP installation, which prevents the application from connecting to the database.

## Solution

### Step 1: Enable PDO MySQL Extension
1. **Click on the WAMP icon** in your system tray (bottom-right corner of your screen)
2. **Go to PHP → PHP Extensions**
3. **Check the box next to 'pdo_mysql'**
4. **Wait for WAMP to restart services automatically** (you'll see the icon change from red to green)
5. **Refresh your browser**

### Step 2: Run the Database Setup
1. **Open your browser** and go to: `http://localhost/animated_teaching/web_fix_login.php`
2. **Follow the on-screen instructions** to set up the database and create demo accounts
3. **Click "Go to Login Page"** when setup is complete

### Step 3: Test Login
Try logging in with these demo accounts:
- **Admin:** `admin` / `password`
- **User:** `sarah_user` / `password`  
- **Student:** `STU001` (no password required)
- **Student:** `STU002` (no password required)
- **Student:** `STU003` (no password required)

## Alternative: Manual Database Setup
If the web setup doesn't work:

1. **Open phpMyAdmin** at `http://localhost/phpmyadmin`
2. **Create a database** named `animated_teaching`
3. **Run the setup script** `create_database.php` in your browser
4. **Or import** the `database.sql` file

## Verification
After setup, you should be able to:
- ✅ Log in with any of the demo accounts
- ✅ See the dashboard after successful login
- ✅ Access admin features (if using admin account)

## Still Having Issues?
1. **Check WAMP status** - make sure all services are running (green icon)
2. **Restart WAMP** completely
3. **Check PHP version** - ensure you're using a compatible version
4. **Verify database connection** in phpMyAdmin

---
*This fix creates a complete database structure with demo users for testing the login system.*
