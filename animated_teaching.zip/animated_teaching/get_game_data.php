<?php
require_once 'config.php';

header('Content-Type: application/json');

// Default game data
$default_game_data = [
    'quiz' => [
        'title' => 'Interactive Quiz',
        'questions' => [
            [
                'question' => 'What is the capital of France?',
                'options' => ['London', 'Berlin', 'Paris', 'Madrid'],
                'correct' => 2,
                'points' => 10
            ],
            [
                'question' => 'Which planet is known as the Red Planet?',
                'options' => ['Venus', 'Mars', 'Jupiter', 'Saturn'],
                'correct' => 1,
                'points' => 10
            ],
            [
                'question' => 'What is 15 + 27?',
                'options' => ['40', '42', '41', '43'],
                'correct' => 1,
                'points' => 10
            ],
            [
                'question' => 'Who painted the Mona Lisa?',
                'options' => ['Van Gogh', 'Picasso', 'Da Vinci', 'Michelangelo'],
                'correct' => 2,
                'points' => 15
            ],
            [
                'question' => 'What is the largest ocean on Earth?',
                'options' => ['Atlantic', 'Indian', 'Pacific', 'Arctic'],
                'correct' => 2,
                'points' => 10
            ]
        ]
    ],
    'memory' => [
        'title' => 'Memory Challenge',
        'pairs' => [
            '<i class="fas fa-bullseye"></i>',
            '<i class="fas fa-gamepad"></i>',
            '<i class="fas fa-palette"></i>',
            '<i class="fas fa-tent"></i>',
            '<i class="fas fa-theater-masks"></i>',
            '<i class="fas fa-guitar"></i>',
            '<i class="fas fa-music"></i>',
            '<i class="fas fa-star"></i>'
        ]
    ],
    'wordpuzzle' => [
        'title' => 'Word Puzzle',
        'words' => [
            ['word' => 'EDUCATION', 'hint' => 'The process of learning'],
            ['word' => 'KNOWLEDGE', 'hint' => 'Information and understanding'],
            ['word' => 'TEACHER', 'hint' => 'Someone who educates'],
            ['word' => 'STUDENT', 'hint' => 'Someone who learns'],
            ['word' => 'SCHOOL', 'hint' => 'A place of learning'],
            ['word' => 'COMPUTER', 'hint' => 'Electronic device for processing data'],
            ['word' => 'SCIENCE', 'hint' => 'Systematic study of the natural world'],
            ['word' => 'MATHEMATICS', 'hint' => 'Study of numbers and shapes']
        ]
    ],
    'math' => [
        'title' => 'Math Challenge',
        'problems' => [
            ['problem' => '12 + 8 = ?', 'answer' => 20],
            ['problem' => '25 - 7 = ?', 'answer' => 18],
            ['problem' => '6 × 4 = ?', 'answer' => 24],
            ['problem' => '36 ÷ 6 = ?', 'answer' => 6],
            ['problem' => '15 + 23 = ?', 'answer' => 38],
            ['problem' => '45 - 18 = ?', 'answer' => 27],
            ['problem' => '7 × 8 = ?', 'answer' => 56],
            ['problem' => '72 ÷ 9 = ?', 'answer' => 8]
        ]
    ]
];

try {
    // Check if game tables exist
    $tables_exist = true;
    
    // Try to get quiz questions
    try {
        $stmt = $pdo->query("SELECT * FROM quiz_questions ORDER BY RAND() LIMIT 10");
        $quiz_questions = $stmt->fetchAll();
        
        $quiz_data = [];
        foreach ($quiz_questions as $question) {
            $quiz_data[] = [
                'question' => $question['question'],
                'options' => [
                    $question['option_a'],
                    $question['option_b'],
                    $question['option_c'],
                    $question['option_d']
                ],
                'correct' => array_search($question['correct_answer'], ['A', 'B', 'C', 'D']),
                'points' => $question['points']
            ];
        }
    } catch (PDOException $e) {
        $tables_exist = false;
        $quiz_data = $default_game_data['quiz']['questions'];
    }

    // Try to get memory pairs
    try {
        $stmt = $pdo->query("SELECT pair_value FROM memory_pairs ORDER BY RAND() LIMIT 8");
        $memory_pairs = $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) {
        $tables_exist = false;
        $memory_pairs = $default_game_data['memory']['pairs'];
    }

    // Try to get word puzzles
    try {
        $stmt = $pdo->query("SELECT word, hint FROM word_puzzles ORDER BY RAND() LIMIT 10");
        $word_puzzles = $stmt->fetchAll();
        
        $word_data = [];
        foreach ($word_puzzles as $puzzle) {
            $word_data[] = [
                'word' => $puzzle['word'],
                'hint' => $puzzle['hint']
            ];
        }
    } catch (PDOException $e) {
        $tables_exist = false;
        $word_data = $default_game_data['wordpuzzle']['words'];
    }

    // Try to get math problems
    try {
        $stmt = $pdo->query("SELECT problem, answer FROM math_problems ORDER BY RAND() LIMIT 10");
        $math_problems = $stmt->fetchAll();
        
        $math_data = [];
        foreach ($math_problems as $problem) {
            $math_data[] = [
                'problem' => $problem['problem'],
                'answer' => floatval($problem['answer'])
            ];
        }
    } catch (PDOException $e) {
        $tables_exist = false;
        $math_data = $default_game_data['math']['problems'];
    }

    // Return JSON response
    echo json_encode([
        'quiz' => [
            'title' => 'Interactive Quiz',
            'questions' => $quiz_data
        ],
        'memory' => [
            'title' => 'Memory Challenge',
            'pairs' => $memory_pairs
        ],
        'wordpuzzle' => [
            'title' => 'Word Puzzle',
            'words' => $word_data
        ],
        'math' => [
            'title' => 'Math Challenge',
            'problems' => $math_data
        ]
    ]);

} catch (Exception $e) {
    // Return default data if anything goes wrong
    echo json_encode($default_game_data);
}
?>