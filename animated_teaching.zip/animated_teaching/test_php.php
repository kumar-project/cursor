<?php
echo "PHP is working!<br>";
echo "Current time: " . date('Y-m-d H:i:s') . "<br>";
echo "PHP Version: " . phpversion() . "<br>";

// Test database connection
require_once 'config.php';
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    echo "Database connection: <span style='color: green;'>SUCCESS</span><br>";
} catch (PDOException $e) {
    echo "Database connection: <span style='color: red;'>FAILED - " . $e->getMessage() . "</span><br>";
}

// Test file permissions
if (is_readable('admin.php')) {
    echo "admin.php is readable: <span style='color: green;'>YES</span><br>";
} else {
    echo "admin.php is readable: <span style='color: red;'>NO</span><br>";
}

// Test if we can include admin.php
echo "Testing admin.php inclusion...<br>";
try {
    ob_start();
    include 'admin.php';
    $output = ob_get_clean();
    echo "admin.php inclusion: <span style='color: green;'>SUCCESS</span><br>";
    echo "Output length: " . strlen($output) . " characters<br>";
} catch (Exception $e) {
    echo "admin.php inclusion: <span style='color: red;'>FAILED - " . $e->getMessage() . "</span><br>";
}
?>