<?php
// Fix game tables using MySQLi
require_once 'config_mysqli.php';

echo "<h1>🎮 Fixing Game Tables</h1>";

// SQL to create game tables
$tables_sql = [
    'interactive_quiz_games' => "
        CREATE TABLE IF NOT EXISTS interactive_quiz_games (
            id INT PRIMARY KEY AUTO_INCREMENT,
            title VARCHAR(200) NOT NULL,
            description TEXT,
            difficulty_level ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
            total_questions INT DEFAULT 10,
            time_limit INT DEFAULT 300,
            points_per_question INT DEFAULT 10,
            level_requirement INT DEFAULT 1,
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ",
    
    'memory_challenge_games' => "
        CREATE TABLE IF NOT EXISTS memory_challenge_games (
            id INT PRIMARY KEY AUTO_INCREMENT,
            title VARCHAR(200) NOT NULL,
            description TEXT,
            difficulty_level ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
            total_pairs INT DEFAULT 8,
            time_limit INT DEFAULT 180,
            points_per_pair INT DEFAULT 5,
            level_requirement INT DEFAULT 1,
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ",
    
    'word_puzzle_games' => "
        CREATE TABLE IF NOT EXISTS word_puzzle_games (
            id INT PRIMARY KEY AUTO_INCREMENT,
            title VARCHAR(200) NOT NULL,
            description TEXT,
            difficulty_level ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
            total_words INT DEFAULT 10,
            time_limit INT DEFAULT 240,
            points_per_word INT DEFAULT 8,
            level_requirement INT DEFAULT 1,
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ",
    
    'math_challenge_games' => "
        CREATE TABLE IF NOT EXISTS math_challenge_games (
            id INT PRIMARY KEY AUTO_INCREMENT,
            title VARCHAR(200) NOT NULL,
            description TEXT,
            difficulty_level ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
            total_problems INT DEFAULT 15,
            time_limit INT DEFAULT 300,
            points_per_problem INT DEFAULT 7,
            level_requirement INT DEFAULT 1,
            math_type ENUM('addition', 'subtraction', 'multiplication', 'division', 'mixed') DEFAULT 'mixed',
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ",
    
    'user_game_progress' => "
        CREATE TABLE IF NOT EXISTS user_game_progress (
            id INT PRIMARY KEY AUTO_INCREMENT,
            user_id INT NOT NULL,
            game_type VARCHAR(50) NOT NULL,
            game_id INT NOT NULL,
            current_level INT DEFAULT 1,
            total_points INT DEFAULT 0,
            games_played INT DEFAULT 0,
            games_won INT DEFAULT 0,
            best_score INT DEFAULT 0,
            last_played TIMESTAMP NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    "
];

// Create tables
echo "<h2>📋 Creating Tables</h2>";
foreach ($tables_sql as $table_name => $sql) {
    try {
        if ($mysqli->query($sql)) {
            echo "<p>✅ Created table: $table_name</p>";
        } else {
            echo "<p>❌ Error creating $table_name: " . $mysqli->error . "</p>";
        }
    } catch (Exception $e) {
        echo "<p>❌ Error creating $table_name: " . $e->getMessage() . "</p>";
    }
}

// Insert sample data
echo "<h2>📝 Inserting Sample Data</h2>";

$sample_games = [
    'interactive_quiz_games' => [
        ['General Knowledge Quiz', 'Test your general knowledge with fun questions', 'easy', 10, 300, 10, 1],
        ['Science Quiz', 'Explore the world of science through questions', 'medium', 15, 450, 15, 2],
        ['History Challenge', 'Dive deep into historical facts and events', 'hard', 20, 600, 20, 3]
    ],
    'memory_challenge_games' => [
        ['Animal Pairs', 'Match animals with their names', 'easy', 8, 180, 5, 1],
        ['Country Capitals', 'Match countries with their capitals', 'medium', 12, 240, 8, 2],
        ['Famous Quotes', 'Match quotes with their authors', 'hard', 16, 300, 12, 3]
    ],
    'word_puzzle_games' => [
        ['Basic Vocabulary', 'Solve word puzzles with common words', 'easy', 10, 240, 8, 1],
        ['Advanced Vocabulary', 'Challenge yourself with complex words', 'medium', 15, 360, 12, 2],
        ['Technical Terms', 'Master technical and scientific terminology', 'hard', 20, 480, 16, 3]
    ],
    'math_challenge_games' => [
        ['Basic Arithmetic', 'Practice addition and subtraction', 'easy', 15, 300, 7, 1, 'mixed'],
        ['Multiplication Master', 'Master multiplication tables', 'medium', 20, 400, 10, 2, 'multiplication'],
        ['Division Challenge', 'Solve complex division problems', 'hard', 25, 500, 15, 3, 'division']
    ]
];

foreach ($sample_games as $table => $games) {
    try {
        // Check if table has data
        $result = $mysqli->query("SELECT COUNT(*) as count FROM $table");
        $count = $result->fetch_assoc()['count'];
        
        if ($count == 0) {
            echo "<p>📝 Inserting sample data into $table...</p>";
            
            if ($table == 'interactive_quiz_games') {
                $sql = "INSERT INTO $table (title, description, difficulty_level, total_questions, time_limit, points_per_question, level_requirement) VALUES (?, ?, ?, ?, ?, ?, ?)";
            } elseif ($table == 'memory_challenge_games') {
                $sql = "INSERT INTO $table (title, description, difficulty_level, total_pairs, time_limit, points_per_pair, level_requirement) VALUES (?, ?, ?, ?, ?, ?, ?)";
            } elseif ($table == 'word_puzzle_games') {
                $sql = "INSERT INTO $table (title, description, difficulty_level, total_words, time_limit, points_per_word, level_requirement) VALUES (?, ?, ?, ?, ?, ?, ?)";
            } elseif ($table == 'math_challenge_games') {
                $sql = "INSERT INTO $table (title, description, difficulty_level, total_problems, time_limit, points_per_problem, level_requirement, math_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            }
            
            $stmt = $mysqli->prepare($sql);
            if (!$stmt) {
                echo "<p>❌ Prepare failed for $table: " . $mysqli->error . "</p>";
                continue;
            }
            
            foreach ($games as $game) {
                if ($table == 'math_challenge_games') {
                    $stmt->bind_param('sssiiiis', $game[0], $game[1], $game[2], $game[3], $game[4], $game[5], $game[6], $game[7]);
                } else {
                    $stmt->bind_param('sssiiii', $game[0], $game[1], $game[2], $game[3], $game[4], $game[5], $game[6]);
                }
                $stmt->execute();
            }
            
            echo "<p>✅ Inserted " . count($games) . " games into $table</p>";
        } else {
            echo "<p>✅ $table already has $count games</p>";
        }
    } catch (Exception $e) {
        echo "<p>❌ Error inserting data into $table: " . $e->getMessage() . "</p>";
    }
}

// Verify tables and data
echo "<h2>🔍 Verification</h2>";
$tables_to_check = ['interactive_quiz_games', 'memory_challenge_games', 'word_puzzle_games', 'math_challenge_games'];

foreach ($tables_to_check as $table) {
    try {
        $result = $mysqli->query("SELECT COUNT(*) as count FROM $table");
        $count = $result->fetch_assoc()['count'];
        echo "<p>✅ $table: $count games</p>";
    } catch (Exception $e) {
        echo "<p>❌ $table: Error - " . $e->getMessage() . "</p>";
    }
}

echo "<h2>🎯 Next Steps</h2>";
echo "<p>✅ Database tables created successfully!</p>";
echo "<p>🎮 <a href='admin_games.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Go to Admin Games</a></p>";
echo "<p>🎯 <a href='game.php?type=interactive_quiz' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Test Games</a></p>";
echo "<p>👥 <a href='admin_users.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Manage Users</a></p>";

$mysqli->close();
?>
