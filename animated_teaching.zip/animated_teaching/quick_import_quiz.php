<?php
require_once 'config.php';

echo "<h2>Quick Quiz Import</h2>";

try {
    // Create table if it doesn't exist
    $create_table_sql = "
        CREATE TABLE IF NOT EXISTS quiz_questions (
            id INT PRIMARY KEY AUTO_INCREMENT,
            question TEXT NOT NULL,
            option_a VARCHAR(255) NOT NULL,
            option_b VARCHAR(255) NOT NULL,
            option_c VARCHAR(255) NOT NULL,
            option_d VARCHAR(255) NOT NULL,
            correct_answer ENUM('A', 'B', 'C', 'D') NOT NULL,
            points INT DEFAULT 10,
            difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
            category VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
    ";
    
    $pdo->exec($create_table_sql);
    echo "✓ Table created/verified<br>";
    
    // Sample quiz data
    $quizData = [
        ['What is the capital of France?', 'London', 'Berlin', 'Paris', 'Madrid', 'C', 'Geography', 'easy', 10],
        ['Which planet is known as the Red Planet?', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'B', 'Science', 'easy', 10],
        ['What is 15 + 27?', '40', '42', '41', '43', 'B', 'Math', 'easy', 10],
        ['Who painted the Mona Lisa?', 'Van Gogh', 'Picasso', 'Da Vinci', 'Michelangelo', 'C', 'Art', 'medium', 15],
        ['What is the largest ocean on Earth?', 'Atlantic', 'Indian', 'Pacific', 'Arctic', 'C', 'Geography', 'easy', 10]
    ];
    
    $stmt = $pdo->prepare("INSERT INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_answer, category, difficulty, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    $imported = 0;
    foreach ($quizData as $data) {
        if ($stmt->execute($data)) {
            $imported++;
        }
    }
    
    echo "✓ Successfully imported $imported quiz questions!<br>";
    echo "<br><a href='admin.php?tab=quiz'>Go to Admin Panel</a> | <a href='index.php'>Go to Home</a>";
    
} catch (PDOException $e) {
    echo "✗ Error: " . $e->getMessage() . "<br>";
    echo "<br>Please check your WAMP configuration and ensure MySQL extensions are enabled.";
}
?>
