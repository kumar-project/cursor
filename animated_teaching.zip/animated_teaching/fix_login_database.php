<?php
// Fix login database issues
$host = 'localhost';
$dbname = 'animated_teaching';
$username = 'root';
$password = '';

echo "<h2>🔧 Fixing Login Database Issues</h2>";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<p>✅ Connected to database</p>";
    
    // Check if users table exists and has the right structure
    $stmt = $pdo->query("DESCRIBE users");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "<h3>Current users table structure:</h3>";
    echo "<ul>";
    foreach ($columns as $column) {
        echo "<li>" . $column . "</li>";
    }
    echo "</ul>";
    
    // Check if we need to add missing columns
    $needed_columns = ['roll_number', 'user_role', 'is_active', 'email_verified'];
    $missing_columns = [];
    
    foreach ($needed_columns as $needed) {
        if (!in_array($needed, $columns)) {
            $missing_columns[] = $needed;
        }
    }
    
    if (!empty($missing_columns)) {
        echo "<h3>Adding missing columns:</h3>";
        
        foreach ($missing_columns as $column) {
            switch ($column) {
                case 'roll_number':
                    $pdo->exec("ALTER TABLE users ADD COLUMN roll_number VARCHAR(20) UNIQUE");
                    echo "<p>✅ Added roll_number column</p>";
                    break;
                case 'user_role':
                    $pdo->exec("ALTER TABLE users ADD COLUMN user_role ENUM('student', 'user', 'admin') DEFAULT 'student'");
                    echo "<p>✅ Added user_role column</p>";
                    break;
                case 'is_active':
                    $pdo->exec("ALTER TABLE users ADD COLUMN is_active BOOLEAN DEFAULT TRUE");
                    echo "<p>✅ Added is_active column</p>";
                    break;
                case 'email_verified':
                    $pdo->exec("ALTER TABLE users ADD COLUMN email_verified BOOLEAN DEFAULT FALSE");
                    echo "<p>✅ Added email_verified column</p>";
                    break;
            }
        }
    } else {
        echo "<p>✅ All required columns exist</p>";
    }
    
    // Now insert sample users
    echo "<h3>Inserting sample users...</h3>";
    
    // Insert admin user
    try {
        $stmt = $pdo->prepare("INSERT IGNORE INTO users (username, email, password, full_name, user_role, is_active, email_verified) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute(['admin', 'admin@apnaschool.com', password_hash('password', PASSWORD_DEFAULT), 'System Administrator', 'admin', 1, 1]);
        echo "<p>✅ Admin user created/updated</p>";
    } catch (Exception $e) {
        echo "<p>ℹ️ Admin: " . $e->getMessage() . "</p>";
    }
    
    // Insert student STU001
    try {
        $stmt = $pdo->prepare("INSERT IGNORE INTO users (roll_number, full_name, user_role, is_active, email_verified) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute(['STU001', 'John Student', 'student', 1, 1]);
        echo "<p>✅ Student STU001 created/updated</p>";
    } catch (Exception $e) {
        echo "<p>ℹ️ STU001: " . $e->getMessage() . "</p>";
    }
    
    // Insert student STU002
    try {
        $stmt = $pdo->prepare("INSERT IGNORE INTO users (roll_number, full_name, user_role, is_active, email_verified) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute(['STU002', 'Mike Student', 'student', 1, 1]);
        echo "<p>✅ Student STU002 created/updated</p>";
    } catch (Exception $e) {
        echo "<p>ℹ️ STU002: " . $e->getMessage() . "</p>";
    }
    
    // Insert regular user
    try {
        $stmt = $pdo->prepare("INSERT IGNORE INTO users (username, email, password, full_name, user_role, is_active, email_verified) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute(['sarah_user', 'sarah@user.com', password_hash('password', PASSWORD_DEFAULT), 'Sarah User', 'user', 1, 1]);
        echo "<p>✅ User sarah_user created/updated</p>";
    } catch (Exception $e) {
        echo "<p>ℹ️ sarah_user: " . $e->getMessage() . "</p>";
    }
    
    // Show all users
    echo "<h3>All users in database:</h3>";
    $stmt = $pdo->query("SELECT id, username, email, roll_number, full_name, user_role, is_active FROM users ORDER BY id");
    $users = $stmt->fetchAll();
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%; margin: 10px 0;'>";
    echo "<tr style='background: #f0f0f0;'><th>ID</th><th>Username</th><th>Email</th><th>Roll Number</th><th>Full Name</th><th>Role</th><th>Active</th></tr>";
    foreach ($users as $user) {
        echo "<tr>";
        echo "<td>" . $user['id'] . "</td>";
        echo "<td>" . ($user['username'] ?? 'NULL') . "</td>";
        echo "<td>" . ($user['email'] ?? 'NULL') . "</td>";
        echo "<td>" . ($user['roll_number'] ?? 'NULL') . "</td>";
        echo "<td>" . $user['full_name'] . "</td>";
        echo "<td>" . $user['user_role'] . "</td>";
        echo "<td>" . ($user['is_active'] ? 'Yes' : 'No') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<h3>🎉 Database fix completed!</h3>";
    echo "<p><strong>You can now login with:</strong></p>";
    echo "<ul>";
    echo "<li><strong>Admin:</strong> admin / password</li>";
    echo "<li><strong>Student:</strong> STU001 (no password required)</li>";
    echo "<li><strong>Student:</strong> STU002 (no password required)</li>";
    echo "<li><strong>User:</strong> sarah_user / password</li>";
    echo "</ul>";
    
    echo "<p><a href='login.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-right: 10px;'>Go to Login</a>";
    echo "<a href='index.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Go to Home</a></p>";
    
} catch (PDOException $e) {
    echo "<h2>❌ Database Error:</h2>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "<p>Make sure:</p>";
    echo "<ul>";
    echo "<li>WAMP/XAMPP is running</li>";
    echo "<li>MySQL service is started</li>";
    echo "<li>Database 'animated_teaching' exists</li>";
    echo "</ul>";
}
?>
