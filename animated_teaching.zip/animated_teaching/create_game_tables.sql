-- Create game tables for animated_teaching database
-- Run this in phpMyAdmin or MySQL command line

USE animated_teaching;

-- Interactive Quiz Games table
CREATE TABLE IF NOT EXISTS interactive_quiz_games (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    difficulty_level ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
    total_questions INT DEFAULT 10,
    time_limit INT DEFAULT 300,
    points_per_question INT DEFAULT 10,
    level_requirement INT DEFAULT 1,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Memory Challenge Games table
CREATE TABLE IF NOT EXISTS memory_challenge_games (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    difficulty_level ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
    total_pairs INT DEFAULT 8,
    time_limit INT DEFAULT 180,
    points_per_pair INT DEFAULT 5,
    level_requirement INT DEFAULT 1,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Word Puzzle Games table
CREATE TABLE IF NOT EXISTS word_puzzle_games (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    difficulty_level ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
    total_words INT DEFAULT 10,
    time_limit INT DEFAULT 240,
    points_per_word INT DEFAULT 8,
    level_requirement INT DEFAULT 1,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Math Challenge Games table
CREATE TABLE IF NOT EXISTS math_challenge_games (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    difficulty_level ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
    total_problems INT DEFAULT 15,
    time_limit INT DEFAULT 300,
    points_per_problem INT DEFAULT 7,
    level_requirement INT DEFAULT 1,
    math_type ENUM('addition', 'subtraction', 'multiplication', 'division', 'mixed') DEFAULT 'mixed',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- User Game Progress table
CREATE TABLE IF NOT EXISTS user_game_progress (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    game_type VARCHAR(50) NOT NULL,
    game_id INT NOT NULL,
    current_level INT DEFAULT 1,
    total_points INT DEFAULT 0,
    games_played INT DEFAULT 0,
    games_won INT DEFAULT 0,
    best_score INT DEFAULT 0,
    last_played TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample Interactive Quiz Games
INSERT INTO interactive_quiz_games (title, description, difficulty_level, total_questions, time_limit, points_per_question, level_requirement) VALUES
('General Knowledge Quiz', 'Test your general knowledge with fun questions', 'easy', 10, 300, 10, 1),
('Science Quiz', 'Explore the world of science through questions', 'medium', 15, 450, 15, 2),
('History Challenge', 'Dive deep into historical facts and events', 'hard', 20, 600, 20, 3);

-- Insert sample Memory Challenge Games
INSERT INTO memory_challenge_games (title, description, difficulty_level, total_pairs, time_limit, points_per_pair, level_requirement) VALUES
('Animal Pairs', 'Match animals with their names', 'easy', 8, 180, 5, 1),
('Country Capitals', 'Match countries with their capitals', 'medium', 12, 240, 8, 2),
('Famous Quotes', 'Match quotes with their authors', 'hard', 16, 300, 12, 3);

-- Insert sample Word Puzzle Games
INSERT INTO word_puzzle_games (title, description, difficulty_level, total_words, time_limit, points_per_word, level_requirement) VALUES
('Basic Vocabulary', 'Solve word puzzles with common words', 'easy', 10, 240, 8, 1),
('Advanced Vocabulary', 'Challenge yourself with complex words', 'medium', 15, 360, 12, 2),
('Technical Terms', 'Master technical and scientific terminology', 'hard', 20, 480, 16, 3);

-- Insert sample Math Challenge Games
INSERT INTO math_challenge_games (title, description, difficulty_level, total_problems, time_limit, points_per_problem, level_requirement, math_type) VALUES
('Basic Arithmetic', 'Practice addition and subtraction', 'easy', 15, 300, 7, 1, 'mixed'),
('Multiplication Master', 'Master multiplication tables', 'medium', 20, 400, 10, 2, 'multiplication'),
('Division Challenge', 'Solve complex division problems', 'hard', 25, 500, 15, 3, 'division');
