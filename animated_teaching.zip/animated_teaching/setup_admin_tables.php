<?php
require_once 'config.php';

echo "Setting up admin tables for game content management...\n";

try {
    // Read the SQL file and extract game content tables
    $sql = file_get_contents('setup_tables.sql');
    
    // Extract game content tables section
    $gameTablesStart = strpos($sql, '-- Game Content Tables');
    $gameTablesEnd = strpos($sql, '-- Badges & Rewards System Tables', $gameTablesStart);
    
    if ($gameTablesStart !== false && $gameTablesEnd !== false) {
        $gameTablesSQL = substr($sql, $gameTablesStart, $gameTablesEnd - $gameTablesStart);
        
        // Split by semicolon and execute each statement
        $statements = array_filter(array_map('trim', explode(';', $gameTablesSQL)));
        
        foreach ($statements as $statement) {
            if (!empty($statement) && !preg_match('/^--/', $statement)) {
                try {
                    $pdo->exec($statement);
                    echo "✓ Executed: " . substr($statement, 0, 50) . "...\n";
                } catch (PDOException $e) {
                    echo "✗ Error executing statement: " . $e->getMessage() . "\n";
                    echo "Statement: " . substr($statement, 0, 100) . "...\n";
                }
            }
        }
        
        echo "\n🎮 Game content tables setup completed!\n";
        echo "You can now:\n";
        echo "1. Visit admin.php to manage game content\n";
        echo "2. Add quiz questions, memory pairs, word puzzles, and math problems\n";
        echo "3. Games will load content from the database\n";
        
    } else {
        echo "✗ Could not find game content tables in setup_tables.sql\n";
    }
    
} catch(PDOException $e) {
    echo "✗ Database error: " . $e->getMessage() . "\n";
}
?>