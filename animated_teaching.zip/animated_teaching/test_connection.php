<?php
// Simple database connection test
echo "<h2>Database Connection Test</h2>";
echo "<style>body{font-family:Arial,sans-serif;margin:20px;} .success{color:green;} .error{color:red;} .info{color:blue;}</style>";

// Test 1: Check PHP Extensions
echo "<h3>1. PHP Extensions Check</h3>";
echo "PDO Available: " . (extension_loaded('pdo') ? "<span class='success'>✅ Yes</span>" : "<span class='error'>❌ No</span>") . "<br>";
echo "PDO MySQL Available: " . (extension_loaded('pdo_mysql') ? "<span class='success'>✅ Yes</span>" : "<span class='error'>❌ No</span>") . "<br>";
echo "MySQLi Available: " . (extension_loaded('mysqli') ? "<span class='success'>✅ Yes</span>" : "<span class='error'>❌ No</span>") . "<br>";

// Test 2: Try PDO Connection
echo "<h3>2. PDO Connection Test</h3>";
try {
    $pdo = new PDO('mysql:host=localhost;dbname=animated_teaching;charset=utf8mb4', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "<span class='success'>✅ PDO connection successful!</span><br>";
    
    // Test query
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
    $result = $stmt->fetch();
    echo "Users in database: " . $result['count'] . "<br>";
    
} catch (PDOException $e) {
    echo "<span class='error'>❌ PDO connection failed: " . $e->getMessage() . "</span><br>";
}

// Test 3: Try MySQLi Connection
echo "<h3>3. MySQLi Connection Test</h3>";
try {
    $mysqli = new mysqli('localhost', 'root', '', 'animated_teaching');
    if ($mysqli->connect_error) {
        echo "<span class='error'>❌ MySQLi connection failed: " . $mysqli->connect_error . "</span><br>";
    } else {
        echo "<span class='success'>✅ MySQLi connection successful!</span><br>";
        
        // Test query
        $result = $mysqli->query("SELECT COUNT(*) as count FROM users");
        $row = $result->fetch_assoc();
        echo "Users in database: " . $row['count'] . "<br>";
        
        $mysqli->close();
    }
} catch (Exception $e) {
    echo "<span class='error'>❌ MySQLi connection error: " . $e->getMessage() . "</span><br>";
}

// Test 4: Check if database exists
echo "<h3>4. Database Existence Check</h3>";
try {
    $mysqli = new mysqli('localhost', 'root', '');
    if (!$mysqli->connect_error) {
        $result = $mysqli->query("SHOW DATABASES LIKE 'animated_teaching'");
        if ($result->num_rows > 0) {
            echo "<span class='success'>✅ Database 'animated_teaching' exists</span><br>";
        } else {
            echo "<span class='error'>❌ Database 'animated_teaching' does not exist</span><br>";
        }
        $mysqli->close();
    }
} catch (Exception $e) {
    echo "<span class='error'>❌ Could not check database: " . $e->getMessage() . "</span><br>";
}

// Test 5: Check if users table exists
echo "<h3>5. Users Table Check</h3>";
try {
    $mysqli = new mysqli('localhost', 'root', '', 'animated_teaching');
    if (!$mysqli->connect_error) {
        $result = $mysqli->query("SHOW TABLES LIKE 'users'");
        if ($result->num_rows > 0) {
            echo "<span class='success'>✅ Users table exists</span><br>";
            
            // Show table structure
            $result = $mysqli->query("DESCRIBE users");
            echo "<h4>Users table structure:</h4>";
            echo "<table border='1' cellpadding='5' cellspacing='0'>";
            echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['Field'] . "</td>";
                echo "<td>" . $row['Type'] . "</td>";
                echo "<td>" . $row['Null'] . "</td>";
                echo "<td>" . $row['Key'] . "</td>";
                echo "<td>" . $row['Default'] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<span class='error'>❌ Users table does not exist</span><br>";
        }
        $mysqli->close();
    }
} catch (Exception $e) {
    echo "<span class='error'>❌ Could not check users table: " . $e->getMessage() . "</span><br>";
}

echo "<h3>Next Steps</h3>";
echo "<p>If you see any ❌ errors above, please:</p>";
echo "<ol>";
echo "<li>Enable the required PHP extensions in WAMP</li>";
echo "<li>Create the database and tables using the setup scripts</li>";
echo "<li>Check the WAMP_SETUP_INSTRUCTIONS.md file for detailed steps</li>";
echo "</ol>";

echo "<p><strong>Quick Links:</strong></p>";
echo "<a href='fix_database_connection.php' style='background:#007cba;color:white;padding:10px;text-decoration:none;margin:5px;display:inline-block;'>Diagnostic Tool</a>";
echo "<a href='create_database_mysqli.php' style='background:#28a745;color:white;padding:10px;text-decoration:none;margin:5px;display:inline-block;'>Setup Database</a>";
echo "<a href='register_fixed.php' style='background:#6c757d;color:white;padding:10px;text-decoration:none;margin:5px;display:inline-block;'>Test Registration</a>";
?>
