<?php
// Database configuration using MySQLi (alternative to PDO)
define('DB_HOST', 'localhost');
define('DB_NAME', 'animated_teaching');
define('DB_USER', 'root');
define('DB_PASS', '');

// Site configuration
define('SITE_URL', 'http://localhost/animated_teaching');
define('SITE_NAME', 'Apna School - Animated Learning Platform');

// Session configuration
// Note: session_start() should be called in individual files that need sessions

// Database connection using MySQLi
$mysqli = null;
try {
    $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($mysqli->connect_error) {
        throw new Exception("Connection failed: " . $mysqli->connect_error);
    }
    
    // Set charset
    $mysqli->set_charset("utf8mb4");
    
} catch (Exception $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Helper functions
function sanitize_input($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Database helper functions using MySQLi
function execute_query($sql, $params = []) {
    global $mysqli;
    
    $stmt = $mysqli->prepare($sql);
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $mysqli->error);
    }
    
    if (!empty($params)) {
        $types = str_repeat('s', count($params)); // All parameters as strings for simplicity
        $stmt->bind_param($types, ...$params);
    }
    
    if (!$stmt->execute()) {
        throw new Exception("Execute failed: " . $stmt->error);
    }
    
    return $stmt;
}

function fetch_all($sql, $params = []) {
    $stmt = execute_query($sql, $params);
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function fetch_one($sql, $params = []) {
    $stmt = execute_query($sql, $params);
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

function insert_id() {
    global $mysqli;
    return $mysqli->insert_id;
}

function affected_rows() {
    global $mysqli;
    return $mysqli->affected_rows;
}

// Authentication functions moved to auth.php

function add_points($user_id, $points, $reason = '') {
    global $mysqli;
    
    $sql = "UPDATE users SET total_points = total_points + ? WHERE id = ?";
    execute_query($sql, [$points, $user_id]);
    
    // Check for level up
    $sql = "SELECT total_points, level FROM users WHERE id = ?";
    $user = fetch_one($sql, [$user_id]);
    
    if ($user) {
        $new_level = floor($user['total_points'] / 100) + 1;
        if ($new_level > $user['level']) {
            $sql = "UPDATE users SET level = ? WHERE id = ?";
            execute_query($sql, [$new_level, $user_id]);
        }
    }
    
    // Check for badge eligibility
    check_badge_eligibility($user_id);
}

function check_badge_eligibility($user_id) {
    global $mysqli;
    
    // Get user data directly from database
    $sql = "SELECT total_points FROM users WHERE id = ?";
    $user = fetch_one($sql, [$user_id]);
    
    if (!$user) return;
    
    // Get all badges user doesn't have yet
    $sql = "
        SELECT * FROM badges 
        WHERE id NOT IN (
            SELECT badge_id FROM user_badges WHERE user_id = ?
        ) AND points_required <= ?
    ";
    $eligible_badges = fetch_all($sql, [$user_id, $user['total_points']]);
    
    foreach ($eligible_badges as $badge) {
        // Award the badge
        $sql = "INSERT INTO user_badges (user_id, badge_id) VALUES (?, ?)";
        execute_query($sql, [$user_id, $badge['id']]);
    }
}

function get_leaderboard($limit = 10) {
    // Ensure limit is a positive integer
    $limit = max(1, intval($limit));
    
    $sql = "
        SELECT 
            u.id,
            u.username,
            u.full_name,
            u.avatar,
            u.total_points,
            u.level,
            COUNT(ub.badge_id) as badge_count
        FROM users u
        LEFT JOIN user_badges ub ON u.id = ub.user_id
        GROUP BY u.id, u.username, u.full_name, u.avatar, u.total_points, u.level
        ORDER BY u.total_points DESC
        LIMIT ?
    ";
    return fetch_all($sql, [$limit]);
}

function get_user_badges($user_id) {
    $sql = "
        SELECT b.*, ub.earned_at 
        FROM badges b 
        JOIN user_badges ub ON b.id = ub.badge_id 
        WHERE ub.user_id = ? 
        ORDER BY ub.earned_at DESC
    ";
    return fetch_all($sql, [$user_id]);
}

function get_user_progress($user_id) {
    $sql = "
        SELECT l.*, up.completed, up.points_earned, up.completed_at, c.title as course_title
        FROM lessons l
        JOIN courses c ON l.course_id = c.id
        LEFT JOIN user_progress up ON l.id = up.lesson_id AND up.user_id = ?
        ORDER BY c.id, l.order_index
    ";
    return fetch_all($sql, [$user_id]);
}
?>
