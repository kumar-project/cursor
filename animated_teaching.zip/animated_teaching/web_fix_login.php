<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fix Login Issues - Apna School</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }
        .success { color: #28a745; }
        .error { color: #dc3545; }
        .warning { color: #ffc107; }
        .info { color: #17a2b8; }
        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin: 10px 5px;
        }
        .btn:hover { transform: translateY(-2px); }
        .step {
            background: #f8f9fa;
            padding: 15px;
            margin: 10px 0;
            border-radius: 8px;
            border-left: 4px solid #667eea;
        }
        pre {
            background: #f1f1f1;
            padding: 15px;
            border-radius: 5px;
            overflow-x: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔧 Fix Login Issues - Apna School</h1>
        
        <?php
        // Check if PDO MySQL is available
        if (!extension_loaded('pdo_mysql')) {
            echo "<div class='error'>";
            echo "<h2>❌ PDO MySQL Extension Not Loaded</h2>";
            echo "<p>The PDO MySQL extension is required for database connectivity but is not currently enabled.</p>";
            echo "</div>";
            
            echo "<div class='step'>";
            echo "<h3>📋 How to Enable PDO MySQL in WAMP:</h3>";
            echo "<ol>";
            echo "<li>Click on the <strong>WAMP icon</strong> in your system tray (bottom-right corner)</li>";
            echo "<li>Go to <strong>PHP → PHP Extensions</strong></li>";
            echo "<li>Check the box next to <strong>'pdo_mysql'</strong></li>";
            echo "<li>Wait for WAMP to restart services automatically</li>";
            echo "<li>Refresh this page</li>";
            echo "</ol>";
            echo "</div>";
            
            echo "<div class='step'>";
            echo "<h3>🔍 Alternative: Check PHP Configuration</h3>";
            echo "<p>You can also check your PHP configuration by running:</p>";
            echo "<pre>php -m | findstr pdo</pre>";
            echo "<p>Or check the php.ini file and ensure this line is uncommented:</p>";
            echo "<pre>extension=pdo_mysql</pre>";
            echo "</div>";
            
            echo "<div class='step'>";
            echo "<h3>🌐 Manual Database Setup</h3>";
            echo "<p>If you prefer to set up the database manually:</p>";
            echo "<ol>";
            echo "<li>Open phpMyAdmin (usually at <a href='http://localhost/phpmyadmin' target='_blank'>http://localhost/phpmyadmin</a>)</li>";
            echo "<li>Create a database named <strong>'animated_teaching'</strong></li>";
            echo "<li>Import the SQL file or run the setup scripts</li>";
            echo "</ol>";
            echo "</div>";
            
            echo "<p><a href='login.php' class='btn'>← Back to Login</a></p>";
            exit;
        }
        
        echo "<div class='success'>";
        echo "<h2>✅ PDO MySQL Extension Loaded</h2>";
        echo "<p>Great! The PDO MySQL extension is available.</p>";
        echo "</div>";
        
        $host = 'localhost';
        $username = 'root';
        $password = '';
        
        try {
            // Connect to MySQL server
            $pdo = new PDO("mysql:host=$host", $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            echo "<div class='success'>✅ Connected to MySQL server</div>";
            
            // Create database if it doesn't exist
            $pdo->exec("CREATE DATABASE IF NOT EXISTS animated_teaching CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            echo "<div class='success'>✅ Database 'animated_teaching' created/verified</div>";
            
            // Connect to the specific database
            $pdo = new PDO("mysql:host=$host;dbname=animated_teaching;charset=utf8mb4", $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
            
            // Create users table with all necessary fields
            $sql = "CREATE TABLE IF NOT EXISTS users (
                id INT PRIMARY KEY AUTO_INCREMENT,
                username VARCHAR(50) UNIQUE NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                password VARCHAR(255),
                full_name VARCHAR(100) NOT NULL,
                roll_number VARCHAR(20) UNIQUE,
                user_role ENUM('student', 'user', 'admin') DEFAULT 'student',
                avatar VARCHAR(255) DEFAULT 'default_avatar.png',
                total_points INT DEFAULT 0,
                level INT DEFAULT 1,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_login TIMESTAMP NULL
            )";
            $pdo->exec($sql);
            echo "<div class='success'>✅ Users table created/updated</div>";
            
            // Create other essential tables
            $tables = [
                'courses' => "CREATE TABLE IF NOT EXISTS courses (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    title VARCHAR(200) NOT NULL,
                    description TEXT,
                    instructor_id INT,
                    difficulty_level ENUM('beginner', 'intermediate', 'advanced') DEFAULT 'beginner',
                    total_lessons INT DEFAULT 0,
                    course_image VARCHAR(255),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )",
                
                'lessons' => "CREATE TABLE IF NOT EXISTS lessons (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    course_id INT NOT NULL,
                    title VARCHAR(200) NOT NULL,
                    content TEXT,
                    lesson_type ENUM('video', 'text', 'interactive', 'quiz') DEFAULT 'text',
                    order_index INT NOT NULL,
                    points_reward INT DEFAULT 10,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )",
                
                'badges' => "CREATE TABLE IF NOT EXISTS badges (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    name VARCHAR(100) NOT NULL,
                    description TEXT,
                    icon VARCHAR(255) NOT NULL,
                    points_required INT DEFAULT 0,
                    category ENUM('achievement', 'milestone', 'special') DEFAULT 'achievement',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )",
                
                'user_badges' => "CREATE TABLE IF NOT EXISTS user_badges (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    user_id INT NOT NULL,
                    badge_id INT NOT NULL,
                    earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_user_badge (user_id, badge_id)
                )",
                
                'user_progress' => "CREATE TABLE IF NOT EXISTS user_progress (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    user_id INT NOT NULL,
                    lesson_id INT NOT NULL,
                    completed BOOLEAN DEFAULT FALSE,
                    points_earned INT DEFAULT 0,
                    completed_at TIMESTAMP NULL,
                    UNIQUE KEY unique_user_lesson (user_id, lesson_id)
                )"
            ];
            
            foreach ($tables as $table => $sql) {
                $pdo->exec($sql);
                echo "<div class='success'>✅ $table table created/verified</div>";
            }
            
            // Insert demo users
            $demo_users = [
                [
                    'username' => 'admin',
                    'email' => 'admin@apnaschool.com',
                    'password' => password_hash('password', PASSWORD_DEFAULT),
                    'full_name' => 'Administrator',
                    'roll_number' => 'ADMIN001',
                    'user_role' => 'admin'
                ],
                [
                    'username' => 'sarah_user',
                    'email' => 'sarah@apnaschool.com',
                    'password' => password_hash('password', PASSWORD_DEFAULT),
                    'full_name' => 'Sarah Johnson',
                    'roll_number' => 'USER001',
                    'user_role' => 'user'
                ],
                [
                    'username' => 'STU001',
                    'email' => 'student001@apnaschool.com',
                    'password' => null,
                    'full_name' => 'John Student',
                    'roll_number' => 'STU001',
                    'user_role' => 'student'
                ],
                [
                    'username' => 'STU002',
                    'email' => 'student002@apnaschool.com',
                    'password' => null,
                    'full_name' => 'Jane Student',
                    'roll_number' => 'STU002',
                    'user_role' => 'student'
                ],
                [
                    'username' => 'STU003',
                    'email' => 'student003@apnaschool.com',
                    'password' => null,
                    'full_name' => 'Mike Student',
                    'roll_number' => 'STU003',
                    'user_role' => 'student'
                ]
            ];
            
            echo "<h3>👥 Creating Demo Users:</h3>";
            
            foreach ($demo_users as $user) {
                // Check if user already exists
                $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ? OR roll_number = ?");
                $stmt->execute([$user['username'], $user['email'], $user['roll_number']]);
                
                if (!$stmt->fetch()) {
                    $sql = "INSERT INTO users (username, email, password, full_name, roll_number, user_role) VALUES (?, ?, ?, ?, ?, ?)";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([
                        $user['username'],
                        $user['email'],
                        $user['password'],
                        $user['full_name'],
                        $user['roll_number'],
                        $user['user_role']
                    ]);
                    echo "<div class='success'>✅ Created user: {$user['username']} ({$user['user_role']})</div>";
                } else {
                    echo "<div class='warning'>⚠️ User already exists: {$user['username']}</div>";
                }
            }
            
            // Insert sample badges
            $badges = [
                ['First Steps', 'Complete your first lesson', '<i class="fas fa-bullseye"></i>', 10, 'milestone'],
                ['Quiz Master', 'Score 100% on any quiz', '<i class="fas fa-brain"></i>', 50, 'achievement'],
                ['Speed Demon', 'Complete a quiz in under 2 minutes', '<i class="fas fa-bolt"></i>', 75, 'achievement'],
                ['Knowledge Seeker', 'Complete 50 lessons', '<i class="fas fa-book"></i>', 500, 'milestone'],
                ['Point Collector', 'Earn 1000 total points', '<i class="fas fa-gem"></i>', 1000, 'milestone']
            ];
            
            echo "<h3>🏆 Creating Sample Badges:</h3>";
            foreach ($badges as $badge) {
                $stmt = $pdo->prepare("INSERT IGNORE INTO badges (name, description, icon, points_required, category) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute($badge);
            }
            echo "<div class='success'>✅ Sample badges created</div>";
            
            // Insert sample course
            $stmt = $pdo->prepare("INSERT IGNORE INTO courses (title, description, instructor_id, difficulty_level) VALUES (?, ?, ?, ?)");
            $stmt->execute(['Interactive PHP Programming', 'Learn PHP through animated tutorials and interactive exercises', 1, 'beginner']);
            echo "<div class='success'>✅ Sample course created</div>";
            
            echo "<div class='success'>";
            echo "<h2>🎉 Setup Complete!</h2>";
            echo "<h3>Demo Accounts Available:</h3>";
            echo "<ul>";
            echo "<li><strong>Admin:</strong> admin / password</li>";
            echo "<li><strong>User:</strong> sarah_user / password</li>";
            echo "<li><strong>Student:</strong> STU001 (no password required)</li>";
            echo "<li><strong>Student:</strong> STU002 (no password required)</li>";
            echo "<li><strong>Student:</strong> STU003 (no password required)</li>";
            echo "</ul>";
            echo "</div>";
            
        } catch(PDOException $e) {
            echo "<div class='error'>";
            echo "<h2>❌ Database Error</h2>";
            echo "<p>" . $e->getMessage() . "</p>";
            echo "</div>";
        }
        ?>
        
        <div style="text-align: center; margin-top: 30px;">
            <a href="login.php" class="btn">🔐 Go to Login Page</a>
            <a href="index.php" class="btn">🏠 Go to Home</a>
        </div>
    </div>
</body>
</html>
