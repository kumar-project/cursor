<?php
// Simple database fix script
$host = 'localhost';
$dbname = 'animated_teaching';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<h2>Database Fix Results:</h2>";
    
    // Fix 1: Make password nullable
    try {
        $pdo->exec("ALTER TABLE users MODIFY COLUMN password VARCHAR(255) NULL");
        echo "✅ Password field made nullable<br>";
    } catch (Exception $e) {
        echo "ℹ️ Password field already nullable or error: " . $e->getMessage() . "<br>";
    }
    
    // Fix 2: Add roll_number field
    try {
        $pdo->exec("ALTER TABLE users ADD COLUMN roll_number VARCHAR(20) UNIQUE");
        echo "✅ Roll number field added<br>";
    } catch (Exception $e) {
        echo "ℹ️ Roll number field already exists or error: " . $e->getMessage() . "<br>";
    }
    
    // Fix 3: Update student passwords
    try {
        $result = $pdo->exec("UPDATE users SET password = NULL WHERE user_role = 'student'");
        echo "✅ Updated $result student records<br>";
    } catch (Exception $e) {
        echo "ℹ️ Student update error: " . $e->getMessage() . "<br>";
    }
    
    // Fix 4: Add sample students
    try {
        $pdo->exec("INSERT IGNORE INTO users (roll_number, full_name, user_role, total_points, level, is_active, email_verified) VALUES ('STU001', 'John Student', 'student', 150, 2, 1, 1)");
        echo "✅ Added sample student STU001<br>";
    } catch (Exception $e) {
        echo "ℹ️ STU001 already exists or error: " . $e->getMessage() . "<br>";
    }
    
    try {
        $pdo->exec("INSERT IGNORE INTO users (roll_number, full_name, user_role, total_points, level, is_active, email_verified) VALUES ('STU002', 'Mike Student', 'student', 75, 1, 1, 1)");
        echo "✅ Added sample student STU002<br>";
    } catch (Exception $e) {
        echo "ℹ️ STU002 already exists or error: " . $e->getMessage() . "<br>";
    }
    
    echo "<br><h3>🎉 Database fix completed!</h3>";
    echo "<p>You can now login with:</p>";
    echo "<ul>";
    echo "<li><strong>Admin:</strong> admin / password</li>";
    echo "<li><strong>Student:</strong> STU001 (no password)</li>";
    echo "<li><strong>User:</strong> sarah_user / password</li>";
    echo "</ul>";
    
    echo "<p><a href='login.php'>Go to Login Page</a></p>";
    
} catch (PDOException $e) {
    echo "<h2>❌ Database Connection Error:</h2>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "<p>Please check your database connection settings.</p>";
}
?>
