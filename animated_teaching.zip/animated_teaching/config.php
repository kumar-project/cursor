<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'animated_teaching');
define('DB_USER', 'root');
define('DB_PASS', '');

// Site configuration
define('SITE_URL', 'http://localhost/apna%20school');
define('SITE_NAME', 'Apna School - Animated Learning Platform');

// Session configuration
// Note: session_start() should be called in individual files that need sessions

// Database connection
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    // Set charset for the connection
    $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Helper functions
function sanitize_input($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Authentication functions moved to auth.php

function add_points($user_id, $points, $reason = '') {
    global $pdo;
    
    $stmt = $pdo->prepare("UPDATE users SET total_points = total_points + ? WHERE id = ?");
    $stmt->execute([$points, $user_id]);
    
    // Check for level up
    $stmt = $pdo->prepare("SELECT total_points, level FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if ($user) {
        $new_level = floor($user['total_points'] / 100) + 1;
        if ($new_level > $user['level']) {
            $stmt = $pdo->prepare("UPDATE users SET level = ? WHERE id = ?");
            $stmt->execute([$new_level, $user_id]);
        }
    }
    
    // Check for badge eligibility
    check_badge_eligibility($user_id);
}

function check_badge_eligibility($user_id) {
    global $pdo;
    
    // Get user data directly from database
    $stmt = $pdo->prepare("SELECT total_points FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!$user) return;
    
    // Get all badges user doesn't have yet
    $stmt = $pdo->prepare("
        SELECT * FROM badges 
        WHERE id NOT IN (
            SELECT badge_id FROM user_badges WHERE user_id = ?
        ) AND points_required <= ?
    ");
    $stmt->execute([$user_id, $user['total_points']]);
    $eligible_badges = $stmt->fetchAll();
    
    foreach ($eligible_badges as $badge) {
        // Award the badge
        $stmt = $pdo->prepare("INSERT INTO user_badges (user_id, badge_id) VALUES (?, ?)");
        $stmt->execute([$user_id, $badge['id']]);
    }
}

function get_leaderboard($limit = 10) {
    global $pdo;
    
    // Ensure limit is a positive integer
    $limit = max(1, intval($limit));
    
    $stmt = $pdo->prepare("
        SELECT 
            u.id,
            u.username,
            u.full_name,
            u.avatar,
            u.total_points,
            u.level,
            COUNT(ub.badge_id) as badge_count
        FROM users u
        LEFT JOIN user_badges ub ON u.id = ub.user_id
        GROUP BY u.id, u.username, u.full_name, u.avatar, u.total_points, u.level
        ORDER BY u.total_points DESC
        LIMIT " . $limit
    );
    $stmt->execute();
    return $stmt->fetchAll();
}

function get_user_badges($user_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT b.*, ub.earned_at 
        FROM badges b 
        JOIN user_badges ub ON b.id = ub.badge_id 
        WHERE ub.user_id = ? 
        ORDER BY ub.earned_at DESC
    ");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}

function get_user_progress($user_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT l.*, up.completed, up.points_earned, up.completed_at, c.title as course_title
        FROM lessons l
        JOIN courses c ON l.course_id = c.id
        LEFT JOIN user_progress up ON l.id = up.lesson_id AND up.user_id = ?
        ORDER BY c.id, l.order_index
    ");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}
?>
