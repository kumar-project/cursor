<?php
require_once 'config.php';

echo "<h2>Import Section Diagnostic</h2>";

try {
    echo "<h3>1. Database Connection Test</h3>";
    echo "✓ Database connected successfully<br>";
    echo "Database: " . DB_NAME . "<br>";
    
    echo "<h3>2. Checking Table Structure</h3>";
    $stmt = $pdo->query("SHOW TABLES LIKE 'quiz_questions'");
    if ($stmt->rowCount() > 0) {
        echo "✓ quiz_questions table exists<br>";
        
        // Check the structure
        $stmt = $pdo->query("DESCRIBE quiz_questions");
        $columns = $stmt->fetchAll();
        echo "Table columns:<br>";
        foreach ($columns as $column) {
            echo "- " . $column['Field'] . " (" . $column['Type'] . ")<br>";
        }
        
        // Check if it has the right structure for imports
        $hasQuestion = false;
        $hasOptionA = false;
        foreach ($columns as $column) {
            if ($column['Field'] === 'question') $hasQuestion = true;
            if ($column['Field'] === 'option_a') $hasOptionA = true;
        }
        
        if ($hasQuestion && $hasOptionA) {
            echo "✓ Table has correct structure for imports<br>";
        } else {
            echo "✗ Table has wrong structure - this is why imports fail<br>";
            echo "Expected: question, option_a, option_b, option_c, option_d columns<br>";
        }
        
    } else {
        echo "✗ quiz_questions table does not exist<br>";
    }
    
    echo "<h3>3. Testing Import Process</h3>";
    
    // Simulate the import process
    $testData = ['Test Question?', 'Option A', 'Option B', 'Option C', 'Option D', 'A', 'Test', 'easy', 10];
    
    try {
        $stmt = $pdo->prepare("INSERT INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_answer, category, difficulty, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        if ($stmt->execute($testData)) {
            echo "✓ Test insert successful - imports should work<br>";
            
            // Clean up test data
            $pdo->exec("DELETE FROM quiz_questions WHERE question = 'Test Question?'");
            echo "✓ Test data cleaned up<br>";
        } else {
            echo "✗ Test insert failed<br>";
        }
    } catch (PDOException $e) {
        echo "✗ Test insert failed with error: " . $e->getMessage() . "<br>";
        echo "This explains why the import section isn't working<br>";
    }
    
    echo "<h3>4. Current Quiz Questions Count</h3>";
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM quiz_questions");
    $result = $stmt->fetch();
    echo "Total quiz questions: " . $result['count'] . "<br>";
    
    echo "<h3>5. Recommendations</h3>";
    if (!$hasQuestion || !$hasOptionA) {
        echo "<strong>Action needed:</strong> Run the fix script to correct the table structure<br>";
        echo "<a href='fix_quiz_import.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>🔧 Fix Quiz Import</a><br>";
    } else {
        echo "✓ Table structure is correct - imports should work<br>";
        echo "If imports still don't work, check browser console for JavaScript errors<br>";
    }
    
} catch (PDOException $e) {
    echo "✗ Database error: " . $e->getMessage() . "<br>";
} catch (Exception $e) {
    echo "✗ General error: " . $e->getMessage() . "<br>";
}
?>
