<?php
// Final database setup script
echo "<h1>🔧 Database Setup - Final Configuration</h1>";

// Check PHP extensions
echo "<h2>📋 PHP Extensions Check</h2>";
echo "<p>PDO: " . (extension_loaded('pdo') ? '✅ Available' : '❌ Missing') . "</p>";
echo "<p>PDO MySQL: " . (extension_loaded('pdo_mysql') ? '✅ Available' : '❌ Missing') . "</p>";
echo "<p>MySQLi: " . (extension_loaded('mysqli') ? '✅ Available' : '❌ Missing') . "</p>";

if (!extension_loaded('pdo_mysql')) {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 1rem; border-radius: 5px; margin: 1rem 0;'>";
    echo "<h3>⚠️ PDO MySQL Extension Missing</h3>";
    echo "<p>To fix this, you need to enable the PDO MySQL extension in your WAMP server:</p>";
    echo "<ol>";
    echo "<li>Click on the WAMP icon in your system tray</li>";
    echo "<li>Go to PHP → PHP Extensions</li>";
    echo "<li>Check 'pdo_mysql' to enable it</li>";
    echo "<li>Restart WAMP server</li>";
    echo "</ol>";
    echo "<p>Alternatively, you can edit your php.ini file and uncomment the line: <code>extension=pdo_mysql</code></p>";
    echo "</div>";
}

// Try to connect using MySQLi as fallback
echo "<h2>🔌 Database Connection Test</h2>";

$host = 'localhost';
$dbname = 'animated_teaching';
$username = 'root';
$password = '';

// Try PDO first
if (extension_loaded('pdo_mysql')) {
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        echo "<p>✅ PDO Connection successful</p>";
        
        // Check if tables exist
        $tables = ['users', 'interactive_quiz_games', 'memory_challenge_games', 'word_puzzle_games', 'math_challenge_games'];
        echo "<h3>📊 Table Status</h3>";
        foreach ($tables as $table) {
            try {
                $result = $pdo->query("SELECT COUNT(*) as count FROM $table");
                $count = $result->fetch()['count'];
                echo "<p>$table: $count records</p>";
            } catch (Exception $e) {
                echo "<p>$table: ❌ Error - " . $e->getMessage() . "</p>";
            }
        }
        
    } catch (PDOException $e) {
        echo "<p>❌ PDO Connection failed: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p>⚠️ PDO MySQL not available, trying MySQLi...</p>";
    
    // Try MySQLi
    if (extension_loaded('mysqli')) {
        try {
            $mysqli = new mysqli($host, $username, $password, $dbname);
            if ($mysqli->connect_error) {
                echo "<p>❌ MySQLi Connection failed: " . $mysqli->connect_error . "</p>";
            } else {
                echo "<p>✅ MySQLi Connection successful</p>";
                
                // Check if tables exist
                $tables = ['users', 'interactive_quiz_games', 'memory_challenge_games', 'word_puzzle_games', 'math_challenge_games'];
                echo "<h3>📊 Table Status</h3>";
                foreach ($tables as $table) {
                    $result = $mysqli->query("SELECT COUNT(*) as count FROM $table");
                    if ($result) {
                        $row = $result->fetch_assoc();
                        echo "<p>$table: " . $row['count'] . " records</p>";
                    } else {
                        echo "<p>$table: ❌ Error - " . $mysqli->error . "</p>";
                    }
                }
            }
        } catch (Exception $e) {
            echo "<p>❌ MySQLi Connection failed: " . $e->getMessage() . "</p>";
        }
    } else {
        echo "<p>❌ Neither PDO MySQL nor MySQLi is available</p>";
    }
}

// Create a simple test to insert sample games if tables are empty
echo "<h2>🎮 Sample Games Setup</h2>";

if (extension_loaded('pdo_mysql')) {
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Check if interactive_quiz_games table has data
        $result = $pdo->query("SELECT COUNT(*) as count FROM interactive_quiz_games");
        $count = $result->fetch()['count'];
        
        if ($count == 0) {
            echo "<p>📝 Inserting sample games...</p>";
            
            // Insert sample interactive quiz games
            $games = [
                ['General Knowledge Quiz', 'Test your general knowledge with fun questions', 'easy', 10, 300, 10, 1],
                ['Science Quiz', 'Explore the world of science through questions', 'medium', 15, 450, 15, 2],
                ['History Challenge', 'Dive deep into historical facts and events', 'hard', 20, 600, 20, 3]
            ];
            
            $stmt = $pdo->prepare("INSERT INTO interactive_quiz_games (title, description, difficulty_level, total_questions, time_limit, points_per_question, level_requirement) VALUES (?, ?, ?, ?, ?, ?, ?)");
            
            foreach ($games as $game) {
                $stmt->execute($game);
            }
            
            echo "<p>✅ Sample interactive quiz games inserted</p>";
        } else {
            echo "<p>✅ Interactive quiz games already exist ($count games)</p>";
        }
        
        // Check other game tables
        $tables = [
            'memory_challenge_games' => [
                ['Animal Pairs', 'Match animals with their names', 'easy', 8, 180, 5, 1],
                ['Country Capitals', 'Match countries with their capitals', 'medium', 12, 240, 8, 2]
            ],
            'word_puzzle_games' => [
                ['Basic Vocabulary', 'Solve word puzzles with common words', 'easy', 10, 240, 8, 1],
                ['Advanced Vocabulary', 'Challenge yourself with complex words', 'medium', 15, 360, 12, 2]
            ],
            'math_challenge_games' => [
                ['Basic Arithmetic', 'Practice addition and subtraction', 'easy', 15, 300, 7, 1, 'mixed'],
                ['Multiplication Master', 'Master multiplication tables', 'medium', 20, 400, 10, 2, 'multiplication']
            ]
        ];
        
        foreach ($tables as $table => $games) {
            $result = $pdo->query("SELECT COUNT(*) as count FROM $table");
            $count = $result->fetch()['count'];
            
            if ($count == 0) {
                echo "<p>📝 Inserting sample $table...</p>";
                
                if ($table == 'memory_challenge_games') {
                    $stmt = $pdo->prepare("INSERT INTO $table (title, description, difficulty_level, total_pairs, time_limit, points_per_pair, level_requirement) VALUES (?, ?, ?, ?, ?, ?, ?)");
                } elseif ($table == 'word_puzzle_games') {
                    $stmt = $pdo->prepare("INSERT INTO $table (title, description, difficulty_level, total_words, time_limit, points_per_word, level_requirement) VALUES (?, ?, ?, ?, ?, ?, ?)");
                } elseif ($table == 'math_challenge_games') {
                    $stmt = $pdo->prepare("INSERT INTO $table (title, description, difficulty_level, total_problems, time_limit, points_per_problem, level_requirement, math_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                }
                
                foreach ($games as $game) {
                    $stmt->execute($game);
                }
                
                echo "<p>✅ Sample $table inserted</p>";
            } else {
                echo "<p>✅ $table already exists ($count games)</p>";
            }
        }
        
    } catch (PDOException $e) {
        echo "<p>❌ Error setting up games: " . $e->getMessage() . "</p>";
    }
}

echo "<h2>🎯 Next Steps</h2>";
echo "<ol>";
echo "<li>If PDO MySQL is missing, enable it in WAMP server</li>";
echo "<li>Restart WAMP server after enabling extensions</li>";
echo "<li>Refresh this page to verify everything is working</li>";
echo "<li>Go to <a href='game.php?type=interactive_quiz'>game.php?type=interactive_quiz</a> to test games</li>";
echo "<li>Go to <a href='admin_users.php'>admin_users.php</a> to manage users</li>";
echo "</ol>";

echo "<h2>🔗 Quick Links</h2>";
echo "<p><a href='game.php?type=interactive_quiz' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>🎮 Test Games</a></p>";
echo "<p><a href='admin_users.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>👥 Manage Users</a></p>";
echo "<p><a href='dashboard.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>🏠 Dashboard</a></p>";
?>
