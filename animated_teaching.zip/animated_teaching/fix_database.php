<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Fix - Apna School</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .success {
            color: #28a745;
            background: #d4edda;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        }
        .error {
            color: #dc3545;
            background: #f8d7da;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        }
        .info {
            color: #0c5460;
            background: #d1ecf1;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        }
        .btn {
            background: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin: 10px 5px;
        }
        .btn:hover {
            background: #0056b3;
        }
        .btn-success {
            background: #28a745;
        }
        .btn-success:hover {
            background: #1e7e34;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔧 Database Fix Tool</h1>
        <p>This tool will update your database schema to support the new authentication system.</p>
        
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['fix_database'])) {
            try {
                // Database connection
                $pdo = new PDO("mysql:host=localhost;dbname=animated_teaching;charset=utf8mb4", "root", "");
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                echo "<div class='info'>Starting database updates...</div>";
                
                // Make password field nullable
                $pdo->exec("ALTER TABLE users MODIFY COLUMN password VARCHAR(255) NULL");
                echo "<div class='success'>✓ Made password field nullable</div>";
                
                // Add roll_number field if it doesn't exist
                try {
                    $pdo->exec("ALTER TABLE users ADD COLUMN roll_number VARCHAR(20) UNIQUE");
                    echo "<div class='success'>✓ Added roll_number field</div>";
                } catch (PDOException $e) {
                    if (strpos($e->getMessage(), 'Duplicate column name') !== false) {
                        echo "<div class='info'>ℹ roll_number field already exists</div>";
                    } else {
                        throw $e;
                    }
                }
                
                // Update existing student records to have NULL passwords
                $stmt = $pdo->prepare("SELECT id, username, user_role FROM users WHERE user_role = 'student'");
                $stmt->execute();
                $students = $stmt->fetchAll();
                
                if (!empty($students)) {
                    $pdo->exec("UPDATE users SET password = NULL WHERE user_role = 'student'");
                    echo "<div class='success'>✓ Updated " . count($students) . " student records to have NULL passwords</div>";
                }
                
                // Insert sample data if not exists
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE roll_number = 'STU001'");
                $stmt->execute();
                if ($stmt->fetchColumn() == 0) {
                    $pdo->exec("INSERT INTO users (roll_number, full_name, user_role, total_points, level, is_active, email_verified) VALUES ('STU001', 'John Student', 'student', 150, 2, 1, 1)");
                    echo "<div class='success'>✓ Added sample student STU001</div>";
                }
                
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE roll_number = 'STU002'");
                $stmt->execute();
                if ($stmt->fetchColumn() == 0) {
                    $pdo->exec("INSERT INTO users (roll_number, full_name, user_role, total_points, level, is_active, email_verified) VALUES ('STU002', 'Mike Student', 'student', 75, 1, 1, 1)");
                    echo "<div class='success'>✓ Added sample student STU002</div>";
                }
                
                echo "<div class='success'><strong>🎉 Database update completed successfully!</strong></div>";
                echo "<div class='info'>";
                echo "<h3>Demo Accounts:</h3>";
                echo "<ul>";
                echo "<li><strong>Admin:</strong> admin / password</li>";
                echo "<li><strong>Student:</strong> STU001 (no password needed)</li>";
                echo "<li><strong>User:</strong> sarah_user / password</li>";
                echo "</ul>";
                echo "</div>";
                
                echo "<a href='login.php' class='btn btn-success'>Go to Login Page</a>";
                
            } catch (PDOException $e) {
                echo "<div class='error'><strong>❌ Database Error:</strong> " . htmlspecialchars($e->getMessage()) . "</div>";
                echo "<div class='info'>Please check your database connection and make sure the 'animated_teaching' database exists.</div>";
            }
        } else {
            ?>
            <div class="info">
                <h3>What this tool will do:</h3>
                <ul>
                    <li>Make the password field optional (nullable) in the users table</li>
                    <li>Add roll_number field for students</li>
                    <li>Update existing student records to have NULL passwords</li>
                    <li>Add sample student accounts (STU001, STU002)</li>
                </ul>
            </div>
            
            <form method="POST">
                <button type="submit" name="fix_database" class="btn">🔧 Fix Database</button>
            </form>
            <?php
        }
        ?>
        
        <hr>
        <p><a href="login.php" class="btn">← Back to Login</a></p>
    </div>
</body>
</html>