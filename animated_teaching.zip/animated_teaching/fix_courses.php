<!DOCTYPE html>
<html>
<head>
    <title>Course Functionality Fix</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
        .container { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: green; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .error { color: red; background: #f8d7da; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .warning { color: orange; background: #fff3cd; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .btn { background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 10px 5px; }
        .code { background: #f8f9fa; padding: 10px; border-radius: 5px; font-family: monospace; margin: 10px 0; }
    </style>
</head>
<body>
<div class='container'>
<h2>🔧 Course Functionality Fix</h2>

<?php
require_once 'config.php';

echo "<h3>1. Database Connection Test</h3>";
try {
    $pdo->query("SELECT 1");
    echo "<div class='success'>✅ Database connection successful</div>";
} catch (PDOException $e) {
    echo "<div class='error'>❌ Database connection failed: " . $e->getMessage() . "</div>";
    echo "<div class='warning'>Please check your database configuration in config.php</div>";
    exit;
}

echo "<h3>2. Courses Table Check</h3>";
try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'courses'");
    if ($stmt->rowCount() > 0) {
        echo "<div class='success'>✅ Courses table exists</div>";
        
        // Check table structure
        $stmt = $pdo->query("DESCRIBE courses");
        $columns = $stmt->fetchAll();
        echo "<div class='code'>Table structure:<br>";
        foreach ($columns as $column) {
            echo "- " . $column['Field'] . " (" . $column['Type'] . ")<br>";
        }
        echo "</div>";
        
    } else {
        echo "<div class='error'>❌ Courses table does not exist</div>";
        echo "<div class='warning'>Creating courses table...</div>";
        
        $sql = "CREATE TABLE IF NOT EXISTS courses (
            id INT PRIMARY KEY AUTO_INCREMENT,
            title VARCHAR(200) NOT NULL,
            description TEXT,
            instructor_id INT,
            difficulty_level ENUM('beginner', 'intermediate', 'advanced') DEFAULT 'beginner',
            total_lessons INT DEFAULT 0,
            course_image VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        
        $pdo->exec($sql);
        echo "<div class='success'>✅ Courses table created successfully</div>";
    }
} catch (PDOException $e) {
    echo "<div class='error'>❌ Error checking courses table: " . $e->getMessage() . "</div>";
}

echo "<h3>3. Course Data Check</h3>";
try {
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM courses");
    $result = $stmt->fetch();
    echo "<div class='success'>📊 Total courses: " . $result['count'] . "</div>";
    
    if ($result['count'] == 0) {
        echo "<div class='warning'>⚠️ No courses found. Adding sample courses...</div>";
        
        $sample_courses = [
            [
                'title' => 'Introduction to Web Development',
                'description' => 'Learn the basics of HTML, CSS, and JavaScript for building modern websites.',
                'difficulty_level' => 'beginner',
                'total_lessons' => 12,
                'course_image' => 'web-dev.jpg'
            ],
            [
                'title' => 'Advanced PHP Programming',
                'description' => 'Master advanced PHP concepts including OOP, databases, and security.',
                'difficulty_level' => 'advanced',
                'total_lessons' => 20,
                'course_image' => 'php-advanced.jpg'
            ],
            [
                'title' => 'Database Design Fundamentals',
                'description' => 'Learn how to design efficient and scalable database systems.',
                'difficulty_level' => 'intermediate',
                'total_lessons' => 15,
                'course_image' => 'database-design.jpg'
            ]
        ];
        
        $stmt = $pdo->prepare("INSERT INTO courses (title, description, difficulty_level, total_lessons, course_image) VALUES (?, ?, ?, ?, ?)");
        
        foreach ($sample_courses as $course) {
            $stmt->execute([
                $course['title'],
                $course['description'],
                $course['difficulty_level'],
                $course['total_lessons'],
                $course['course_image']
            ]);
        }
        
        echo "<div class='success'>✅ Sample courses added successfully</div>";
    }
    
    // Show existing courses
    $stmt = $pdo->query("SELECT * FROM courses ORDER BY created_at DESC LIMIT 5");
    $courses = $stmt->fetchAll();
    
    if (count($courses) > 0) {
        echo "<h4>Recent Courses:</h4>";
        echo "<ul>";
        foreach ($courses as $course) {
            echo "<li><strong>" . htmlspecialchars($course['title']) . "</strong> - " . htmlspecialchars($course['description']) . "</li>";
        }
        echo "</ul>";
    }
    
} catch (PDOException $e) {
    echo "<div class='error'>❌ Error checking course data: " . $e->getMessage() . "</div>";
}

echo "<h3>4. Course Form Test</h3>";
if ($_POST['test_course']) {
    $title = sanitize_input($_POST['title'] ?? '');
    $description = sanitize_input($_POST['description'] ?? '');
    $difficulty_level = sanitize_input($_POST['difficulty_level'] ?? 'beginner');
    $total_lessons = intval($_POST['total_lessons'] ?? 0);
    $course_image = sanitize_input($_POST['course_image'] ?? 'default-course.jpg');
    
    if (empty($title) || empty($description)) {
        echo "<div class='error'>❌ Please fill in all required fields</div>";
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO courses (title, description, difficulty_level, total_lessons, course_image) VALUES (?, ?, ?, ?, ?)");
            if ($stmt->execute([$title, $description, $difficulty_level, $total_lessons, $course_image])) {
                echo "<div class='success'>✅ Test course added successfully!</div>";
                echo "<div class='success'>📝 Course: " . htmlspecialchars($title) . "</div>";
            } else {
                echo "<div class='error'>❌ Failed to add test course</div>";
            }
        } catch (PDOException $e) {
            echo "<div class='error'>❌ Database error: " . $e->getMessage() . "</div>";
        }
    }
}

echo "<form method='POST' style='background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0;'>";
echo "<h4>Test Course Form:</h4>";
echo "<p><label>Title: <input type='text' name='title' placeholder='Test Course Title' required></label></p>";
echo "<p><label>Description: <textarea name='description' placeholder='Test course description' required></textarea></label></p>";
echo "<p><label>Difficulty: <select name='difficulty_level'><option value='beginner'>Beginner</option><option value='intermediate'>Intermediate</option><option value='advanced'>Advanced</option></select></label></p>";
echo "<p><label>Lessons: <input type='number' name='total_lessons' value='5' min='0'></label></p>";
echo "<p><label>Image: <input type='text' name='course_image' value='test-course.jpg'></label></p>";
echo "<p><button type='submit' name='test_course' class='btn'>Test Add Course</button></p>";
echo "</form>";

echo "<h3>5. JavaScript Test</h3>";
echo "<div class='code'>";
echo "// Test if course form JavaScript is working<br>";
echo "// Open browser console and check for errors<br>";
echo "// Look for: addCourseToDisplay, updateStats, showMessage functions<br>";
echo "</div>";

echo "<h3>6. Next Steps</h3>";
echo "<div class='success'>";
echo "✅ If all tests pass, the course functionality should work<br>";
echo "✅ If there are errors, please check the specific error messages above<br>";
echo "✅ Make sure to test the actual course form on the main page<br>";
echo "</div>";

echo "<br><a href='index.php' class='btn'>🏠 Back to Home</a>";
echo "<a href='test_courses_web.php' class='btn'>🔍 Run Full Test</a>";
?>

</div>
</body>
</html>
