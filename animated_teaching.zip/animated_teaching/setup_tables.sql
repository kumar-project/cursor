-- Animated Teaching Platform Database Tables
-- Use this file to set up the database tables

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    avatar VARCHAR(255) DEFAULT 'default_avatar.png',
    total_points INT DEFAULT 0,
    level INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL
);

-- Courses table
CREATE TABLE IF NOT EXISTS courses (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    instructor_id INT,
    difficulty_level ENUM('beginner', 'intermediate', 'advanced') DEFAULT 'beginner',
    total_lessons INT DEFAULT 0,
    course_image VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (instructor_id) REFERENCES users(id)
);

-- Lessons table
CREATE TABLE IF NOT EXISTS lessons (
    id INT PRIMARY KEY AUTO_INCREMENT,
    course_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    content TEXT,
    lesson_type ENUM('video', 'text', 'interactive', 'quiz') DEFAULT 'text',
    order_index INT NOT NULL,
    points_reward INT DEFAULT 10,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

-- Quizzes table
CREATE TABLE IF NOT EXISTS quizzes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    lesson_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    time_limit INT DEFAULT 300,
    total_questions INT DEFAULT 0,
    points_reward INT DEFAULT 50,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE
);

-- Quiz questions table
CREATE TABLE IF NOT EXISTS quiz_questions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    quiz_id INT NOT NULL,
    question_text TEXT NOT NULL,
    question_type ENUM('multiple_choice', 'true_false', 'fill_blank') DEFAULT 'multiple_choice',
    points INT DEFAULT 10,
    order_index INT NOT NULL,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
);

-- Quiz answers table
CREATE TABLE IF NOT EXISTS quiz_answers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    question_id INT NOT NULL,
    answer_text TEXT NOT NULL,
    is_correct BOOLEAN DEFAULT FALSE,
    order_index INT NOT NULL,
    FOREIGN KEY (question_id) REFERENCES quiz_questions(id) ON DELETE CASCADE
);

-- User quiz attempts
CREATE TABLE IF NOT EXISTS user_quiz_attempts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    quiz_id INT NOT NULL,
    score INT DEFAULT 0,
    total_questions INT DEFAULT 0,
    time_taken INT DEFAULT 0,
    completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id)
);

-- Badges table
CREATE TABLE IF NOT EXISTS badges (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(255) NOT NULL,
    points_required INT DEFAULT 0,
    category ENUM('achievement', 'milestone', 'special') DEFAULT 'achievement',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User badges
CREATE TABLE IF NOT EXISTS user_badges (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    badge_id INT NOT NULL,
    earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (badge_id) REFERENCES badges(id),
    UNIQUE KEY unique_user_badge (user_id, badge_id)
);

-- User progress
CREATE TABLE IF NOT EXISTS user_progress (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    lesson_id INT NOT NULL,
    completed BOOLEAN DEFAULT FALSE,
    points_earned INT DEFAULT 0,
    completed_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (lesson_id) REFERENCES lessons(id),
    UNIQUE KEY unique_user_lesson (user_id, lesson_id)
);

-- Leaderboard view
CREATE OR REPLACE VIEW leaderboard AS
SELECT 
    u.id,
    u.username,
    u.full_name,
    u.avatar,
    u.total_points,
    u.level,
    COUNT(ub.badge_id) as badge_count,
    ROW_NUMBER() OVER (ORDER BY u.total_points DESC) as rank
FROM users u
LEFT JOIN user_badges ub ON u.id = ub.user_id
GROUP BY u.id, u.username, u.full_name, u.avatar, u.total_points, u.level
ORDER BY u.total_points DESC;

-- Insert sample badges
INSERT INTO badges (name, description, icon, points_required, category) VALUES
('First Steps', 'Complete your first lesson', '<i class="fas fa-bullseye"></i>', 10, 'milestone'),
('Quiz Master', 'Score 100% on any quiz', '<i class="fas fa-brain"></i>', 50, 'achievement'),
('Speed Demon', 'Complete a quiz in under 2 minutes', '<i class="fas fa-bolt"></i>', 75, 'achievement'),
('Perfect Score', 'Get 10 perfect quiz scores in a row', '<i class="fas fa-percentage"></i>', 200, 'achievement'),
('Knowledge Seeker', 'Complete 50 lessons', '<i class="fas fa-book"></i>', 500, 'milestone'),
('Quiz Champion', 'Complete 20 quizzes', '<i class="fas fa-trophy"></i>', 300, 'achievement'),
('Early Bird', 'Complete a lesson before 8 AM', '<i class="fas fa-sun"></i>', 25, 'special'),
('Night Owl', 'Complete a lesson after 10 PM', '<i class="fas fa-moon"></i>', 25, 'special'),
('Streak Master', 'Study for 7 days in a row', '<i class="fas fa-fire"></i>', 150, 'achievement'),
('Point Collector', 'Earn 1000 total points', '<i class="fas fa-gem"></i>', 1000, 'milestone');

-- Insert sample course
INSERT INTO courses (title, description, instructor_id, difficulty_level, course_image) VALUES
('Interactive PHP Programming', 'Learn PHP through animated tutorials and interactive exercises', 1, 'beginner', 'php_course.jpg'),
('Web Development Fundamentals', 'Master HTML, CSS, and JavaScript with gamified learning', 1, 'beginner', 'webdev_course.jpg'),
('Advanced PHP Techniques', 'Deep dive into advanced PHP concepts and best practices', 1, 'advanced', 'advanced_php.jpg');

-- Insert sample lessons
INSERT INTO lessons (course_id, title, content, lesson_type, order_index, points_reward) VALUES
(1, 'Introduction to PHP', 'Learn the basics of PHP programming language', 'interactive', 1, 20),
(1, 'Variables and Data Types', 'Understanding PHP variables and different data types', 'interactive', 2, 25),
(1, 'Control Structures', 'If statements, loops, and conditional logic', 'interactive', 3, 30),
(1, 'Functions in PHP', 'Creating and using functions in PHP', 'interactive', 4, 35),
(1, 'Arrays and Loops', 'Working with arrays and different types of loops', 'interactive', 5, 40);

-- Insert sample quiz
INSERT INTO quizzes (lesson_id, title, description, time_limit, total_questions, points_reward) VALUES
(1, 'PHP Basics Quiz', 'Test your knowledge of PHP fundamentals', 300, 5, 50),
(2, 'Variables Quiz', 'Quiz on PHP variables and data types', 240, 4, 40),
(3, 'Control Structures Quiz', 'Test your understanding of PHP control structures', 300, 6, 60);

-- Game Content Tables
CREATE TABLE IF NOT EXISTS quiz_questions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    question TEXT NOT NULL,
    option_a VARCHAR(255) NOT NULL,
    option_b VARCHAR(255) NOT NULL,
    option_c VARCHAR(255) NOT NULL,
    option_d VARCHAR(255) NOT NULL,
    correct_answer ENUM('A', 'B', 'C', 'D') NOT NULL,
    points INT DEFAULT 10,
    difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
    category VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS memory_pairs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    pair_value VARCHAR(255) NOT NULL,
    display_text VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS word_puzzles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    word VARCHAR(255) NOT NULL,
    hint TEXT NOT NULL,
    category VARCHAR(100),
    difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
    points INT DEFAULT 15,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS math_problems (
    id INT PRIMARY KEY AUTO_INCREMENT,
    problem TEXT NOT NULL,
    answer DECIMAL(10,2) NOT NULL,
    operation ENUM('addition', 'subtraction', 'multiplication', 'division', 'mixed') DEFAULT 'mixed',
    difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
    points INT DEFAULT 10,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert sample game content
INSERT INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_answer, category, difficulty) VALUES
('What is the capital of France?', 'London', 'Berlin', 'Paris', 'Madrid', 'C', 'Geography', 'easy'),
('Which planet is known as the Red Planet?', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'B', 'Science', 'easy'),
('What is 15 + 27?', '40', '42', '41', '43', 'B', 'Math', 'easy'),
('Who painted the Mona Lisa?', 'Van Gogh', 'Picasso', 'Da Vinci', 'Michelangelo', 'C', 'Art', 'medium'),
('What is the largest ocean on Earth?', 'Atlantic', 'Indian', 'Pacific', 'Arctic', 'C', 'Geography', 'easy');

INSERT INTO memory_pairs (pair_value, display_text, category, difficulty) VALUES
('<i class="fas fa-bullseye"></i>', 'Target', 'Icon', 'easy'),
('<i class="fas fa-gamepad"></i>', 'Game Controller', 'Icon', 'easy'),
('<i class="fas fa-palette"></i>', 'Artist Palette', 'Icon', 'easy'),
('<i class="fas fa-tent"></i>', 'Circus Tent', 'Icon', 'easy'),
('<i class="fas fa-theater-masks"></i>', 'Theater Masks', 'Icon', 'medium'),
('<i class="fas fa-guitar"></i>', 'Guitar', 'Icon', 'medium'),
('<i class="fas fa-music"></i>', 'Trumpet', 'Icon', 'medium'),
('<i class="fas fa-music"></i>', 'Violin', 'Icon', 'medium');

INSERT INTO word_puzzles (word, hint, category, difficulty) VALUES
('EDUCATION', 'The process of learning', 'General', 'easy'),
('KNOWLEDGE', 'Information and understanding', 'General', 'medium'),
('TEACHER', 'Someone who educates', 'General', 'easy'),
('STUDENT', 'Someone who learns', 'General', 'easy'),
('SCHOOL', 'A place of learning', 'General', 'easy'),
('COMPUTER', 'Electronic device for processing data', 'Technology', 'easy'),
('SCIENCE', 'Systematic study of the natural world', 'General', 'medium'),
('MATHEMATICS', 'Study of numbers and shapes', 'General', 'hard');

INSERT INTO math_problems (problem, answer, operation, difficulty) VALUES
('12 + 8 = ?', 20, 'addition', 'easy'),
('25 - 7 = ?', 18, 'subtraction', 'easy'),
('6 × 4 = ?', 24, 'multiplication', 'easy'),
('36 ÷ 6 = ?', 6, 'division', 'easy'),
('15 + 23 = ?', 38, 'addition', 'easy'),
('45 - 18 = ?', 27, 'subtraction', 'medium'),
('7 × 8 = ?', 56, 'multiplication', 'medium'),
('72 ÷ 9 = ?', 8, 'division', 'medium');

-- Badges & Rewards System Tables
CREATE TABLE IF NOT EXISTS badges (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    icon VARCHAR(50) NOT NULL,
    color VARCHAR(20) DEFAULT '#667eea',
    category ENUM('learning', 'achievement', 'streak', 'special') DEFAULT 'learning',
    requirement_type ENUM('lessons_completed', 'quizzes_passed', 'points_earned', 'streak_days', 'perfect_scores', 'games_played') NOT NULL,
    requirement_value INT NOT NULL,
    points_reward INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS user_badges (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    badge_id INT NOT NULL,
    earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (badge_id) REFERENCES badges(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS user_progress (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    total_points INT DEFAULT 0,
    lessons_completed INT DEFAULT 0,
    quizzes_passed INT DEFAULT 0,
    perfect_scores INT DEFAULT 0,
    games_played INT DEFAULT 0,
    current_streak INT DEFAULT 0,
    longest_streak INT DEFAULT 0,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS user_achievements (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    achievement_type VARCHAR(50) NOT NULL,
    achievement_data JSON,
    points_earned INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample badges
INSERT INTO badges (name, description, icon, color, category, requirement_type, requirement_value, points_reward) VALUES
('First Steps', 'Complete your first lesson', '<i class="fas fa-bullseye"></i>', '#28a745', 'learning', 'lessons_completed', 1, 10),
('Quick Learner', 'Complete 5 lessons', '<i class="fas fa-bolt"></i>', '#ffc107', 'learning', 'lessons_completed', 5, 50),
('Knowledge Seeker', 'Complete 10 lessons', '<i class="fas fa-book"></i>', '#17a2b8', 'learning', 'lessons_completed', 10, 100),
('Quiz Master', 'Pass 5 quizzes', '<i class="fas fa-brain"></i>', '#6f42c1', 'achievement', 'quizzes_passed', 5, 75),
('Perfect Score', 'Get a perfect score on any quiz', '<i class="fas fa-star"></i>', '#fd7e14', 'achievement', 'perfect_scores', 1, 25),
('Point Collector', 'Earn 100 points', '<i class="fas fa-coins"></i>', '#20c997', 'achievement', 'points_earned', 100, 0),
('High Roller', 'Earn 500 points', '<i class="fas fa-gem"></i>', '#e83e8c', 'achievement', 'points_earned', 500, 0),
('Game Enthusiast', 'Play 10 games', '<i class="fas fa-gamepad"></i>', '#6c757d', 'achievement', 'games_played', 10, 30),
('Streak Starter', 'Maintain a 3-day streak', '<i class="fas fa-fire"></i>', '#dc3545', 'streak', 'streak_days', 3, 40),
('Dedicated Learner', 'Maintain a 7-day streak', '<i class="fas fa-dumbbell"></i>', '#fd7e14', 'streak', 'streak_days', 7, 100),
('Marathon Runner', 'Maintain a 30-day streak', '<i class="fas fa-running"></i>', '#28a745', 'streak', 'streak_days', 30, 500),
('Speed Demon', 'Complete a quiz in under 30 seconds', '<i class="fas fa-bolt"></i>', '#ffc107', 'special', 'perfect_scores', 1, 50),
('Century Club', 'Earn 1000 points', '<i class="fas fa-percentage"></i>', '#6f42c1', 'achievement', 'points_earned', 1000, 0),
('All-Star', 'Complete all available lessons', '<i class="fas fa-star"></i>', '#17a2b8', 'special', 'lessons_completed', 50, 200),
('Legend', 'Earn 5000 points', '<i class="fas fa-crown"></i>', '#fd7e14', 'special', 'points_earned', 5000, 0);
