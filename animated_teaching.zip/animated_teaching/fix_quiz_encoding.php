<?php
require_once 'config.php';

echo "<h2>Fixing Quiz Questions Encoding Issues...</h2>";

try {
    // Set proper charset for the connection
    $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
    
    // Clear all existing quiz questions (they're corrupted)
    $pdo->exec("DELETE FROM quiz_questions");
    echo "✓ Cleared corrupted quiz questions<br>";
    
    // Insert clean, properly encoded quiz questions
    $clean_questions = [
        [
            'question' => 'What is the capital of France?',
            'option_a' => 'London',
            'option_b' => 'Paris',
            'option_c' => 'Berlin',
            'option_d' => 'Madrid',
            'correct_answer' => 'B',
            'category' => 'Geography',
            'difficulty' => 'easy',
            'points' => 10
        ],
        [
            'question' => 'Which planet is known as the Red Planet?',
            'option_a' => 'Venus',
            'option_b' => 'Mars',
            'option_c' => 'Jupiter',
            'option_d' => 'Saturn',
            'correct_answer' => 'B',
            'category' => 'Science',
            'difficulty' => 'easy',
            'points' => 10
        ],
        [
            'question' => 'What is 15 + 27?',
            'option_a' => '40',
            'option_b' => '42',
            'option_c' => '41',
            'option_d' => '43',
            'correct_answer' => 'B',
            'category' => 'Math',
            'difficulty' => 'easy',
            'points' => 10
        ],
        [
            'question' => 'What is the speed of light in vacuum?',
            'option_a' => '300,000 km/s',
            'option_b' => '299,792,458 m/s',
            'option_c' => '186,000 miles/s',
            'option_d' => 'All of the above',
            'correct_answer' => 'D',
            'category' => 'Science',
            'difficulty' => 'hard',
            'points' => 20
        ],
        [
            'question' => 'What is the smallest country in the world?',
            'option_a' => 'Monaco',
            'option_b' => 'Vatican City',
            'option_c' => 'San Marino',
            'option_d' => 'Liechtenstein',
            'correct_answer' => 'B',
            'category' => 'Geography',
            'difficulty' => 'hard',
            'points' => 20
        ],
        [
            'question' => 'Who wrote "Romeo and Juliet"?',
            'option_a' => 'Charles Dickens',
            'option_b' => 'William Shakespeare',
            'option_c' => 'Mark Twain',
            'option_d' => 'Jane Austen',
            'correct_answer' => 'B',
            'category' => 'Literature',
            'difficulty' => 'medium',
            'points' => 15
        ],
        [
            'question' => 'What is the chemical symbol for gold?',
            'option_a' => 'Go',
            'option_b' => 'Gd',
            'option_c' => 'Au',
            'option_d' => 'Ag',
            'correct_answer' => 'C',
            'category' => 'Science',
            'difficulty' => 'medium',
            'points' => 15
        ],
        [
            'question' => 'Which ocean is the largest?',
            'option_a' => 'Atlantic',
            'option_b' => 'Indian',
            'option_c' => 'Pacific',
            'option_d' => 'Arctic',
            'correct_answer' => 'C',
            'category' => 'Geography',
            'difficulty' => 'easy',
            'points' => 10
        ],
        [
            'question' => 'What is the largest mammal in the world?',
            'option_a' => 'African Elephant',
            'option_b' => 'Blue Whale',
            'option_c' => 'Giraffe',
            'option_d' => 'Hippopotamus',
            'correct_answer' => 'B',
            'category' => 'Science',
            'difficulty' => 'medium',
            'points' => 15
        ],
        [
            'question' => 'Which programming language is known for web development?',
            'option_a' => 'Java',
            'option_b' => 'Python',
            'option_c' => 'JavaScript',
            'option_d' => 'C++',
            'correct_answer' => 'C',
            'category' => 'Technology',
            'difficulty' => 'medium',
            'points' => 15
        ]
    ];
    
    $insert_stmt = $pdo->prepare("
        INSERT INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_answer, category, difficulty, points) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $inserted_count = 0;
    foreach ($clean_questions as $question) {
        $insert_stmt->execute([
            $question['question'],
            $question['option_a'],
            $question['option_b'],
            $question['option_c'],
            $question['option_d'],
            $question['correct_answer'],
            $question['category'],
            $question['difficulty'],
            $question['points']
        ]);
        $inserted_count++;
    }
    
    echo "✓ Inserted $inserted_count clean quiz questions<br>";
    echo "<h3>✅ Quiz Questions Encoding Fixed!</h3>";
    echo "All corrupted data has been replaced with clean, properly encoded questions.<br>";
    echo "The questions will now display correctly in the admin panel.<br>";
    echo "<a href='admin.php?tab=quiz'>← View Quiz Questions</a>";
    
} catch (Exception $e) {
    echo "<h3>❌ Error:</h3>";
    echo "Error fixing quiz encoding: " . $e->getMessage();
    echo "<br><a href='admin.php'>← Back to Admin Panel</a>";
}
?>
