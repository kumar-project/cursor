<!DOCTYPE html>
<html>
<head>
    <title>Application Diagnostic</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
        .container { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: green; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .error { color: red; background: #f8d7da; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .warning { color: orange; background: #fff3cd; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .info { color: blue; background: #d1ecf1; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .btn { background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 10px 5px; }
        .code { background: #f8f9fa; padding: 10px; border-radius: 5px; font-family: monospace; margin: 10px 0; }
    </style>
</head>
<body>
<div class='container'>
<h2><i class="fas fa-stethoscope"></i> Application Diagnostic</h2>

<?php
require_once 'config.php';

echo "<h3>1. Database Connection</h3>";
try {
    $pdo->query("SELECT 1");
    echo "<div class='success'>✅ Database connection successful</div>";
} catch (PDOException $e) {
    echo "<div class='error'>❌ Database connection failed: " . $e->getMessage() . "</div>";
    exit;
}

echo "<h3>2. Required Tables Check</h3>";
$required_tables = ['courses', 'quiz_questions', 'memory_pairs', 'word_puzzles', 'math_problems'];
$missing_tables = [];

foreach ($required_tables as $table) {
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
        if ($stmt->rowCount() > 0) {
            echo "<div class='success'>✅ Table '$table' exists</div>";
        } else {
            echo "<div class='error'>❌ Table '$table' missing</div>";
            $missing_tables[] = $table;
        }
    } catch (PDOException $e) {
        echo "<div class='error'>❌ Error checking table '$table': " . $e->getMessage() . "</div>";
        $missing_tables[] = $table;
    }
}

echo "<h3>3. Course Data Check</h3>";
try {
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM courses");
    $result = $stmt->fetch();
    echo "<div class='info'>📊 Total courses: " . $result['count'] . "</div>";
    
    if ($result['count'] > 0) {
        $stmt = $pdo->query("SELECT * FROM courses ORDER BY id DESC LIMIT 3");
        $courses = $stmt->fetchAll();
        
        echo "<h4>Recent Courses:</h4>";
        foreach ($courses as $course) {
            echo "<div class='info'>";
            echo "• <strong>" . htmlspecialchars($course['title']) . "</strong><br>";
            echo "&nbsp;&nbsp;Description: " . htmlspecialchars($course['description']) . "<br>";
            echo "&nbsp;&nbsp;Lessons: " . $course['total_lessons'] . "<br>";
            echo "&nbsp;&nbsp;Difficulty: " . $course['difficulty_level'] . "<br>";
            echo "</div>";
        }
    } else {
        echo "<div class='warning'>⚠️ No courses found in database</div>";
    }
} catch (PDOException $e) {
    echo "<div class='error'>❌ Error checking courses: " . $e->getMessage() . "</div>";
}

echo "<h3>4. Game Data Check</h3>";
$game_tables = ['quiz_questions', 'memory_pairs', 'word_puzzles', 'math_problems'];
foreach ($game_tables as $table) {
    try {
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM $table");
        $result = $stmt->fetch();
        echo "<div class='info'>📊 $table: " . $result['count'] . " records</div>";
    } catch (PDOException $e) {
        echo "<div class='error'>❌ Error checking $table: " . $e->getMessage() . "</div>";
    }
}

echo "<h3>5. File System Check</h3>";
$required_files = [
    'index.php' => 'Main application file',
    'admin.php' => 'Admin panel',
    'config.php' => 'Database configuration',
    'get_game_data.php' => 'Game data API',
    'assets/css/style.css' => 'Main stylesheet',
    'assets/js/animations.js' => 'Animation script'
];

foreach ($required_files as $file => $description) {
    if (file_exists($file)) {
        echo "<div class='success'>✅ $file ($description)</div>";
    } else {
        echo "<div class='error'>❌ $file ($description) - MISSING</div>";
    }
}

echo "<h3>6. JavaScript Console Check</h3>";
echo "<div class='info'>Open browser developer tools (F12) and check the Console tab for any JavaScript errors</div>";

echo "<h3>7. Common Issues & Solutions</h3>";

if (count($missing_tables) > 0) {
    echo "<div class='warning'>";
    echo "<h4>Missing Tables Detected:</h4>";
    echo "<ul>";
    foreach ($missing_tables as $table) {
        echo "<li>$table</li>";
    }
    echo "</ul>";
    echo "<p><strong>Solution:</strong> Run the database setup to create missing tables.</p>";
    echo "</div>";
}

echo "<div class='info'>";
echo "<h4>Common Issues:</h4>";
echo "<ul>";
echo "<li><strong>Course shows '0 lessons':</strong> This is normal for newly created courses. Add lessons through the admin panel.</li>";
echo "<li><strong>Games not loading:</strong> Check if game tables exist and have data.</li>";
echo "<li><strong>Admin panel not working:</strong> Ensure all required tables are created.</li>";
echo "<li><strong>JavaScript errors:</strong> Check browser console for error messages.</li>";
echo "<li><strong>Database connection issues:</strong> Verify WAMP/MySQL is running and credentials are correct.</li>";
echo "</ul>";
echo "</div>";

echo "<h3>8. Quick Fixes</h3>";
echo "<a href='quick_fix.php' class='btn'><i class='fas fa-wrench'></i> Quick Database Fix</a>";
echo "<a href='fix_courses.php' class='btn'><i class='fas fa-book'></i> Course Fix Tool</a>";
echo "<a href='admin.php' class='btn'><i class='fas fa-cogs'></i> Admin Panel</a>";
echo "<a href='index.php' class='btn'><i class='fas fa-home'></i> Main App</a>";

echo "<h3>9. Test Course Addition</h3>";
if ($_POST['test_course']) {
    $title = sanitize_input($_POST['title'] ?? '');
    $description = sanitize_input($_POST['description'] ?? '');
    
    if (empty($title) || empty($description)) {
        echo "<div class='error'>❌ Please fill in all required fields</div>";
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO courses (title, description, difficulty_level, total_lessons, course_image) VALUES (?, ?, ?, ?, ?)");
            if ($stmt->execute([$title, $description, 'beginner', 5, 'test-course.jpg'])) {
                echo "<div class='success'>✅ Test course added successfully!</div>";
            } else {
                echo "<div class='error'>❌ Failed to add test course</div>";
            }
        } catch (PDOException $e) {
            echo "<div class='error'>❌ Database error: " . $e->getMessage() . "</div>";
        }
    }
}

echo "<form method='POST' style='background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0;'>";
echo "<h4>Test Course Addition:</h4>";
echo "<p><label>Title: <input type='text' name='title' placeholder='Test Course Title' required></label></p>";
echo "<p><label>Description: <textarea name='description' placeholder='Test course description' required></textarea></label></p>";
echo "<p><button type='submit' name='test_course' class='btn'>Test Add Course</button></p>";
echo "</form>";

?>

</div>
</body>
</html>
