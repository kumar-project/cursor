<?php
require_once 'config.php';

echo "<h2>Direct Import - Bypass Admin Panel</h2>";

try {
    echo "<h3>Step 1: Creating/Fixing Tables</h3>";
    
    // Create all required tables
    $tables = [
        'quiz_questions' => "CREATE TABLE IF NOT EXISTS quiz_questions (
            id INT PRIMARY KEY AUTO_INCREMENT,
            question TEXT NOT NULL,
            option_a VARCHAR(255) NOT NULL,
            option_b VARCHAR(255) NOT NULL,
            option_c VARCHAR(255) NOT NULL,
            option_d VARCHAR(255) NOT NULL,
            correct_answer ENUM('A', 'B', 'C', 'D') NOT NULL,
            points INT DEFAULT 10,
            difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
            category VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )",
        
        'memory_pairs' => "CREATE TABLE IF NOT EXISTS memory_pairs (
            id INT PRIMARY KEY AUTO_INCREMENT,
            pair_value VARCHAR(255) NOT NULL,
            display_text VARCHAR(255) NOT NULL,
            category VARCHAR(100),
            difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )",
        
        'word_puzzles' => "CREATE TABLE IF NOT EXISTS word_puzzles (
            id INT PRIMARY KEY AUTO_INCREMENT,
            word VARCHAR(255) NOT NULL,
            hint TEXT NOT NULL,
            category VARCHAR(100),
            difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
            points INT DEFAULT 15,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )",
        
        'math_problems' => "CREATE TABLE IF NOT EXISTS math_problems (
            id INT PRIMARY KEY AUTO_INCREMENT,
            problem TEXT NOT NULL,
            answer DECIMAL(10,2) NOT NULL,
            operation ENUM('addition', 'subtraction', 'multiplication', 'division', 'mixed') DEFAULT 'mixed',
            difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'easy',
            points INT DEFAULT 10,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )"
    ];
    
    foreach ($tables as $tableName => $sql) {
        $pdo->exec($sql);
        echo "✓ $tableName table created/verified<br>";
    }
    
    echo "<h3>Step 2: Importing Quiz Questions</h3>";
    
    // Quiz data
    $quizData = [
        ['What is the capital of France?', 'London', 'Berlin', 'Paris', 'Madrid', 'C', 'Geography', 'easy', 10],
        ['Which planet is known as the Red Planet?', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'B', 'Science', 'easy', 10],
        ['What is 15 + 27?', '40', '42', '41', '43', 'B', 'Math', 'easy', 10],
        ['Who painted the Mona Lisa?', 'Van Gogh', 'Picasso', 'Da Vinci', 'Michelangelo', 'C', 'Art', 'medium', 15],
        ['What is the largest ocean on Earth?', 'Atlantic', 'Indian', 'Pacific', 'Arctic', 'C', 'Geography', 'easy', 10]
    ];
    
    $stmt = $pdo->prepare("INSERT INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_answer, category, difficulty, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $quizImported = 0;
    foreach ($quizData as $data) {
        if ($stmt->execute($data)) {
            $quizImported++;
        }
    }
    echo "✓ Imported $quizImported quiz questions<br>";
    
    echo "<h3>Step 3: Importing Memory Pairs</h3>";
    
    // Memory data
    $memoryData = [
        ['<i class="fas fa-bullseye"></i>', 'Target', 'Icon', 'easy'],
        ['<i class="fas fa-gamepad"></i>', 'Game Controller', 'Icon', 'easy'],
        ['<i class="fas fa-palette"></i>', 'Artist Palette', 'Icon', 'easy'],
        ['<i class="fas fa-tent"></i>', 'Circus Tent', 'Icon', 'easy'],
        ['<i class="fas fa-theater-masks"></i>', 'Theater Masks', 'Icon', 'medium'],
        ['<i class="fas fa-guitar"></i>', 'Guitar', 'Icon', 'medium'],
        ['<i class="fas fa-music"></i>', 'Trumpet', 'Icon', 'medium'],
        ['<i class="fas fa-star"></i>', 'Star', 'Icon', 'easy']
    ];
    
    $stmt = $pdo->prepare("INSERT INTO memory_pairs (pair_value, display_text, category, difficulty) VALUES (?, ?, ?, ?)");
    $memoryImported = 0;
    foreach ($memoryData as $data) {
        if ($stmt->execute($data)) {
            $memoryImported++;
        }
    }
    echo "✓ Imported $memoryImported memory pairs<br>";
    
    echo "<h3>Step 4: Importing Word Puzzles</h3>";
    
    // Word data
    $wordData = [
        ['EDUCATION', 'The process of learning', 'General', 'easy', 15],
        ['KNOWLEDGE', 'Information and understanding', 'General', 'medium', 20],
        ['TEACHER', 'Someone who educates', 'General', 'easy', 15],
        ['STUDENT', 'Someone who learns', 'General', 'easy', 15],
        ['SCHOOL', 'A place of learning', 'General', 'easy', 15],
        ['COMPUTER', 'Electronic device for processing data', 'Technology', 'easy', 15],
        ['SCIENCE', 'Systematic study of the natural world', 'General', 'medium', 20],
        ['MATHEMATICS', 'Study of numbers and shapes', 'General', 'hard', 25]
    ];
    
    $stmt = $pdo->prepare("INSERT INTO word_puzzles (word, hint, category, difficulty, points) VALUES (?, ?, ?, ?, ?)");
    $wordImported = 0;
    foreach ($wordData as $data) {
        if ($stmt->execute($data)) {
            $wordImported++;
        }
    }
    echo "✓ Imported $wordImported word puzzles<br>";
    
    echo "<h3>Step 5: Importing Math Problems</h3>";
    
    // Math data
    $mathData = [
        ['12 + 8 = ?', 20, 'addition', 'easy', 10],
        ['25 - 7 = ?', 18, 'subtraction', 'easy', 10],
        ['6 × 4 = ?', 24, 'multiplication', 'easy', 10],
        ['36 ÷ 6 = ?', 6, 'division', 'easy', 10],
        ['15 + 23 = ?', 38, 'addition', 'easy', 10],
        ['45 - 18 = ?', 27, 'subtraction', 'medium', 15],
        ['7 × 8 = ?', 56, 'multiplication', 'medium', 15],
        ['72 ÷ 9 = ?', 8, 'division', 'medium', 15]
    ];
    
    $stmt = $pdo->prepare("INSERT INTO math_problems (problem, answer, operation, difficulty, points) VALUES (?, ?, ?, ?, ?)");
    $mathImported = 0;
    foreach ($mathData as $data) {
        if ($stmt->execute($data)) {
            $mathImported++;
        }
    }
    echo "✓ Imported $mathImported math problems<br>";
    
    echo "<h3>🎉 Import Complete!</h3>";
    echo "<p>Successfully imported:</p>";
    echo "<ul>";
    echo "<li>$quizImported Quiz Questions</li>";
    echo "<li>$memoryImported Memory Pairs</li>";
    echo "<li>$wordImported Word Puzzles</li>";
    echo "<li>$mathImported Math Problems</li>";
    echo "</ul>";
    
    echo "<h3>Next Steps:</h3>";
    echo "<p><a href='admin.php?tab=quiz' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-right: 10px;'>View Quiz Questions</a>";
    echo "<a href='index.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Test Games</a></p>";
    
} catch (PDOException $e) {
    echo "✗ Database error: " . $e->getMessage() . "<br>";
} catch (Exception $e) {
    echo "✗ General error: " . $e->getMessage() . "<br>";
}
?>
