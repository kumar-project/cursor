<?php
// Database creation script using MySQLi (alternative to PDO)
$host = 'localhost';
$username = 'root';
$password = '';

try {
    // Connect to MySQL server
    $mysqli = new mysqli($host, $username, $password);
    
    if ($mysqli->connect_error) {
        throw new Exception("Connection failed: " . $mysqli->connect_error);
    }
    
    echo "Connected to MySQL server successfully!<br>";
    
    // Create database if it doesn't exist
    $sql = "CREATE DATABASE IF NOT EXISTS animated_teaching CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
    if ($mysqli->query($sql)) {
        echo "Database 'animated_teaching' created/verified!<br>";
    } else {
        throw new Exception("Error creating database: " . $mysqli->error);
    }
    
    // Select the database
    $mysqli->select_db('animated_teaching');
    echo "Connected to animated_teaching database!<br>";
    
    // Create users table with proper structure for registration
    $sql = "CREATE TABLE IF NOT EXISTS users (
        id INT PRIMARY KEY AUTO_INCREMENT,
        username VARCHAR(50) UNIQUE NULL,
        email VARCHAR(100) UNIQUE NULL,
        roll_number VARCHAR(20) UNIQUE NULL,
        password VARCHAR(255) NULL,
        full_name VARCHAR(100) NOT NULL,
        avatar VARCHAR(255) DEFAULT 'default_avatar.png',
        user_role ENUM('student', 'user', 'admin') DEFAULT 'student',
        total_points INT DEFAULT 0,
        level INT DEFAULT 1,
        is_active BOOLEAN DEFAULT TRUE,
        email_verified BOOLEAN DEFAULT FALSE,
        is_demo_account BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_login TIMESTAMP NULL,
        
        -- Ensure at least one identifier is provided
        CONSTRAINT chk_user_identifier CHECK (
            username IS NOT NULL OR 
            email IS NOT NULL OR 
            roll_number IS NOT NULL
        )
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if ($mysqli->query($sql)) {
        echo "Users table created successfully!<br>";
    } else {
        throw new Exception("Error creating users table: " . $mysqli->error);
    }
    
    // Create courses table
    $sql = "CREATE TABLE IF NOT EXISTS courses (
        id INT PRIMARY KEY AUTO_INCREMENT,
        title VARCHAR(200) NOT NULL,
        description TEXT,
        instructor_id INT,
        difficulty_level ENUM('beginner', 'intermediate', 'advanced') DEFAULT 'beginner',
        total_lessons INT DEFAULT 0,
        course_image VARCHAR(255),
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (instructor_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if ($mysqli->query($sql)) {
        echo "Courses table created successfully!<br>";
    } else {
        throw new Exception("Error creating courses table: " . $mysqli->error);
    }
    
    // Create lessons table
    $sql = "CREATE TABLE IF NOT EXISTS lessons (
        id INT PRIMARY KEY AUTO_INCREMENT,
        course_id INT NOT NULL,
        title VARCHAR(200) NOT NULL,
        content TEXT,
        lesson_type ENUM('video', 'text', 'interactive', 'quiz') DEFAULT 'text',
        order_index INT NOT NULL,
        points_reward INT DEFAULT 10,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if ($mysqli->query($sql)) {
        echo "Lessons table created successfully!<br>";
    } else {
        throw new Exception("Error creating lessons table: " . $mysqli->error);
    }
    
    // Create badges table
    $sql = "CREATE TABLE IF NOT EXISTS badges (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(100) NOT NULL,
        description TEXT,
        icon VARCHAR(255) NOT NULL,
        points_required INT DEFAULT 0,
        category ENUM('achievement', 'milestone', 'special') DEFAULT 'achievement',
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if ($mysqli->query($sql)) {
        echo "Badges table created successfully!<br>";
    } else {
        throw new Exception("Error creating badges table: " . $mysqli->error);
    }
    
    // Create user_badges table
    $sql = "CREATE TABLE IF NOT EXISTS user_badges (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        badge_id INT NOT NULL,
        earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (badge_id) REFERENCES badges(id),
        UNIQUE KEY unique_user_badge (user_id, badge_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if ($mysqli->query($sql)) {
        echo "User badges table created successfully!<br>";
    } else {
        throw new Exception("Error creating user_badges table: " . $mysqli->error);
    }
    
    // Create user_progress table
    $sql = "CREATE TABLE IF NOT EXISTS user_progress (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        lesson_id INT NOT NULL,
        completed BOOLEAN DEFAULT FALSE,
        points_earned INT DEFAULT 0,
        completed_at TIMESTAMP NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (lesson_id) REFERENCES lessons(id),
        UNIQUE KEY unique_user_lesson (user_id, lesson_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if ($mysqli->query($sql)) {
        echo "User progress table created successfully!<br>";
    } else {
        throw new Exception("Error creating user_progress table: " . $mysqli->error);
    }
    
    // Insert sample badges
    $sql = "INSERT IGNORE INTO badges (name, description, icon, points_required, category) VALUES
    ('First Steps', 'Complete your first lesson', '<i class=\"fas fa-bullseye\"></i>', 10, 'milestone'),
    ('Quiz Master', 'Score 100% on any quiz', '<i class=\"fas fa-brain\"></i>', 50, 'achievement'),
    ('Speed Demon', 'Complete a quiz in under 2 minutes', '<i class=\"fas fa-bolt\"></i>', 75, 'achievement'),
    ('Perfect Score', 'Get 10 perfect quiz scores in a row', '<i class=\"fas fa-percentage\"></i>', 200, 'achievement'),
    ('Knowledge Seeker', 'Complete 50 lessons', '<i class=\"fas fa-book\"></i>', 500, 'milestone'),
    ('Quiz Champion', 'Complete 20 quizzes', '<i class=\"fas fa-trophy\"></i>', 300, 'achievement'),
    ('Early Bird', 'Complete a lesson before 8 AM', '<i class=\"fas fa-sun\"></i>', 25, 'special'),
    ('Night Owl', 'Complete a lesson after 10 PM', '<i class=\"fas fa-moon\"></i>', 25, 'special'),
    ('Streak Master', 'Study for 7 days in a row', '<i class=\"fas fa-fire\"></i>', 150, 'achievement'),
    ('Point Collector', 'Earn 1000 total points', '<i class=\"fas fa-gem\"></i>', 1000, 'milestone')";
    
    if ($mysqli->query($sql)) {
        echo "Sample badges inserted successfully!<br>";
    } else {
        echo "Warning: Could not insert sample badges: " . $mysqli->error . "<br>";
    }
    
    // Insert sample admin user
    $hashed_password = password_hash('admin123', PASSWORD_DEFAULT);
    $sql = "INSERT IGNORE INTO users (id, username, email, password, full_name, user_role, is_active, email_verified, is_demo_account) VALUES 
    (1, 'admin', 'admin@apnaschool.com', '$hashed_password', 'System Administrator', 'admin', 1, 1, 1)";
    
    if ($mysqli->query($sql)) {
        echo "Admin user created successfully!<br>";
    } else {
        echo "Warning: Could not create admin user: " . $mysqli->error . "<br>";
    }
    
    // Insert sample course
    $sql = "INSERT IGNORE INTO courses (id, title, description, instructor_id, difficulty_level, course_image) VALUES
    (1, 'Interactive PHP Programming', 'Learn PHP through animated tutorials and interactive exercises', 1, 'beginner', 'php_course.jpg'),
    (2, 'Web Development Fundamentals', 'Master HTML, CSS, and JavaScript with gamified learning', 1, 'beginner', 'webdev_course.jpg'),
    (3, 'Advanced PHP Techniques', 'Deep dive into advanced PHP concepts and best practices', 1, 'advanced', 'advanced_php.jpg')";
    
    if ($mysqli->query($sql)) {
        echo "Sample courses inserted successfully!<br>";
    } else {
        echo "Warning: Could not insert sample courses: " . $mysqli->error . "<br>";
    }
    
    // Insert sample lessons
    $sql = "INSERT IGNORE INTO lessons (course_id, title, content, lesson_type, order_index, points_reward) VALUES
    (1, 'Introduction to PHP', 'Learn the basics of PHP programming language', 'interactive', 1, 20),
    (1, 'Variables and Data Types', 'Understanding PHP variables and different data types', 'interactive', 2, 25),
    (1, 'Control Structures', 'If statements, loops, and conditional logic', 'interactive', 3, 30),
    (1, 'Functions in PHP', 'Creating and using functions in PHP', 'interactive', 4, 35),
    (1, 'Arrays and Loops', 'Working with arrays and different types of loops', 'interactive', 5, 40)";
    
    if ($mysqli->query($sql)) {
        echo "Sample lessons inserted successfully!<br>";
    } else {
        echo "Warning: Could not insert sample lessons: " . $mysqli->error . "<br>";
    }
    
    $mysqli->close();
    
    echo "<br><strong>Database setup completed successfully!</strong><br>";
    echo "<p>You can now try registering again.</p>";
    echo "<a href='register.php' style='background: #007cba; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Go to Registration Page</a>";
    echo "<a href='login.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-left: 10px;'>Go to Login Page</a>";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "<br>";
    echo "<p>Please check your WAMP configuration and ensure MySQL is running.</p>";
}
?>
