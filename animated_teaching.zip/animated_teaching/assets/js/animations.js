// Simplified JavaScript without animations for better performance
class SimpleManager {
    constructor() {
        this.init();
    }

    init() {
        this.setupBasicInteractions();
        this.setupProgressBars();
        this.setupQuizInteractions();
    }

    // Basic interactions without animations
    setupBasicInteractions() {
        // Card hover effects (no transform animations)
        document.querySelectorAll('.card').forEach(card => {
            card.addEventListener('mouseenter', () => {
                card.style.boxShadow = '0 20px 40px rgba(0,0,0,0.15)';
            });

            card.addEventListener('mouseleave', () => {
                card.style.boxShadow = '0 10px 30px rgba(0,0,0,0.1)';
            });
        });

        // Button hover effects (no transform animations)
        document.querySelectorAll('.btn').forEach(btn => {
            btn.addEventListener('mouseenter', () => {
                btn.style.boxShadow = '0 8px 25px rgba(102, 126, 234, 0.6)';
            });

            btn.addEventListener('mouseleave', () => {
                btn.style.boxShadow = '0 4px 15px rgba(102, 126, 234, 0.4)';
            });
        });
    }

    // Static progress bars
    setupProgressBars() {
        const progressBars = document.querySelectorAll('.progress-bar');
        
        progressBars.forEach(bar => {
            const width = bar.dataset.width || '0%';
            bar.style.width = width;
        });
    }

    // Quiz interactions without animations
    setupQuizInteractions() {
        // Answer selection (no animations)
        document.querySelectorAll('.answer-option').forEach(option => {
            option.addEventListener('click', () => {
                // Remove previous selections
                document.querySelectorAll('.answer-option').forEach(opt => {
                    opt.classList.remove('selected');
                });

                // Add selection to clicked option
                option.classList.add('selected');
            });
        });
    }

    // Static points counter (no animation)
    updatePointsCounter(element, value) {
        element.textContent = value.toLocaleString();
    }

    // Simple level up notification (no animation)
    showLevelUpNotification(newLevel) {
        const notification = document.createElement('div');
        notification.className = 'level-up-notification';
        notification.innerHTML = `
            <div class="level-up-content">
                <div class="level-up-icon"><i class="fas fa-star"></i></div>
                <h2>Level Up!</h2>
                <p>You've reached level ${newLevel}!</p>
            </div>
        `;

        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            z-index: 10000;
            max-width: 300px;
        `;

        document.body.appendChild(notification);

        // Auto remove after 3 seconds
        setTimeout(() => {
            if (document.body.contains(notification)) {
                document.body.removeChild(notification);
            }
        }, 3000);
    }

    // Simple streak display (no animation)
    updateStreakDisplay(streakCount) {
        const streakElement = document.querySelector('.streak-counter');
        if (streakElement) {
            streakElement.textContent = streakCount;
            
            // Add fire icon for high streaks
            if (streakCount >= 7) {
                streakElement.innerHTML = `<i class="fas fa-fire"></i> ${streakCount}`;
            }
        }
    }

    // Simple quiz completion (no animation)
    showQuizCompletion(score, totalQuestions) {
        const completionModal = document.createElement('div');
        completionModal.className = 'quiz-completion-modal';
        
        const percentage = Math.round((score / totalQuestions) * 100);
        let message = '';
        let emoji = '';
        
        if (percentage >= 90) {
            message = 'Excellent!';
            emoji = '<i class="fas fa-trophy"></i>';
        } else if (percentage >= 70) {
            message = 'Great job!';
            emoji = '<i class="fas fa-star"></i>';
        } else if (percentage >= 50) {
            message = 'Good effort!';
            emoji = '<i class="fas fa-thumbs-up"></i>';
        } else {
            message = 'Keep practicing!';
            emoji = '<i class="fas fa-dumbbell"></i>';
        }

        completionModal.innerHTML = `
            <div class="quiz-completion-content">
                <div class="completion-icon">${emoji}</div>
                <h2>${message}</h2>
                <p>You scored ${score} out of ${totalQuestions} questions</p>
                <div class="score-circle">
                    <div class="score-percentage">${percentage}%</div>
                </div>
                <div class="completion-actions">
                    <button class="btn btn-primary" onclick="location.reload()">Try Again</button>
                    <button class="btn btn-success" onclick="window.location.href='index.php'">Continue Learning</button>
                </div>
            </div>
        `;

        completionModal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
        `;

        document.body.appendChild(completionModal);
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new SimpleManager();
});

// Utility functions
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `message message-${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 10000;
    `;

    document.body.appendChild(notification);

    setTimeout(() => {
        if (document.body.contains(notification)) {
            document.body.removeChild(notification);
        }
    }, 3000);
}

// CSS for animations is now in the main stylesheet to avoid CSP violations