<?php
declare(strict_types=1);

// Update these values for your local MySQL setup.
const DB_HOST = '127.0.0.1';
const DB_PORT = '3306';
const DB_NAME = 'mini_freelancer';
const DB_USER = 'root';
const DB_PASS = '';

const APP_NAME = 'Mini Freelancer';
const BASE_URL = '/Remote%20Work';
const MAX_UPLOAD_SIZE = 5 * 1024 * 1024; // 5 MB

// Client approval emails (PHP mail() — configure sendmail/SMTP in php.ini for production).
const MAIL_NOTIFICATIONS_ENABLED = true;
const MAIL_FROM_ADDRESS = 'noreply@localhost';
const MAIL_FROM_NAME = 'Mini Freelancer';

// Payment gateways — leave keys empty for demo mode; add live keys to enable "Live ready" status.
const PAYMENT_GATEWAY_DEFAULT = 'razorpay';
const RAZORPAY_KEY_ID = '';
const RAZORPAY_KEY_SECRET = '';
const STRIPE_PUBLISHABLE_KEY = '';
const STRIPE_SECRET_KEY = '';
const PAYPAL_CLIENT_ID = '';
const PAYPAL_CLIENT_SECRET = '';
const PAYU_MERCHANT_KEY = '';
const PAYU_MERCHANT_SALT = '';
const CASHFREE_APP_ID = '';
const CASHFREE_SECRET_KEY = '';

