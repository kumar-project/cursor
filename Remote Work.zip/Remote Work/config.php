<?php
declare(strict_types=1);

// Update these values for your local MySQL setup.
const DB_HOST = '127.0.0.1';
const DB_PORT = '3306';
const DB_NAME = 'mini_freelancer';
const DB_USER = 'root';
const DB_PASS = '';

const APP_NAME = 'Mini Freelancer';
const BASE_URL = '/Remote%20Work';
const MAX_UPLOAD_SIZE = 5 * 1024 * 1024; // 5 MB


