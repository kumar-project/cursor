<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';

require_login();
$user = current_user();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_wallet'])) {
        $amount = (float)($_POST['amount'] ?? 0);
        if ($amount > 0) {
            $stmt = db()->prepare('UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?');
            $stmt->execute([$amount, (int)$user['id']]);
            $success = 'Wallet updated.';
        } else {
            $error = 'Enter a valid wallet amount.';
        }
    }

    if (isset($_POST['update_profile'])) {
        $skills = trim($_POST['skills'] ?? '');
        $portfolio = trim($_POST['portfolio'] ?? '');
        $stmt = db()->prepare('UPDATE users SET skills = ?, portfolio = ? WHERE id = ?');
        $stmt->execute([$skills, $portfolio, (int)$user['id']]);
        $success = 'Profile updated.';
    }

    $user = current_user();
}

$myProjects = [];
$myBids = [];
$myAssigned = [];
$freelancers = [];
$staff = is_platform_staff($user);

if ($user['role'] === 'client' || $staff) {
    if ($staff) {
        $myProjects = db()->query('SELECT * FROM projects ORDER BY created_at DESC LIMIT 200')->fetchAll();
    } else {
        $stmt = db()->prepare('SELECT * FROM projects WHERE user_id = ? ORDER BY created_at DESC');
        $stmt->execute([(int)$user['id']]);
        $myProjects = $stmt->fetchAll();
    }

    $freelancersStmt = db()->query(
        "SELECT id, name, email, skills, avg_rating
         FROM users
         WHERE role = 'freelancer'
         ORDER BY avg_rating DESC, created_at DESC"
    );
    $freelancers = $freelancersStmt->fetchAll();
}

if ($user['role'] === 'freelancer' || $staff) {
    if ($staff) {
        $myBids = db()->query(
            "SELECT b.*, p.title AS project_title, u.name AS bidder_name
             FROM bids b
             JOIN projects p ON p.id = b.project_id
             JOIN users u ON u.id = b.freelancer_id
             ORDER BY b.created_at DESC
             LIMIT 200"
        )->fetchAll();
        $myAssigned = db()->query(
            "SELECT p.*, c.name AS client_name
             FROM projects p
             JOIN users c ON c.id = p.user_id
             WHERE p.assigned_freelancer_id IS NOT NULL
             ORDER BY p.created_at DESC
             LIMIT 200"
        )->fetchAll();
    } else {
        $bidsStmt = db()->prepare(
            "SELECT b.*, p.title AS project_title
             FROM bids b
             JOIN projects p ON p.id = b.project_id
             WHERE b.freelancer_id = ?
             ORDER BY b.created_at DESC"
        );
        $bidsStmt->execute([(int)$user['id']]);
        $myBids = $bidsStmt->fetchAll();

        $assignedStmt = db()->prepare(
            "SELECT * FROM projects WHERE assigned_freelancer_id = ? ORDER BY created_at DESC"
        );
        $assignedStmt->execute([(int)$user['id']]);
        $myAssigned = $assignedStmt->fetchAll();
    }
}

$walletStmt = db()->prepare('SELECT wallet_balance FROM users WHERE id = ?');
$walletStmt->execute([(int)$user['id']]);
$wallet = (float)($walletStmt->fetch()['wallet_balance'] ?? 0);

require_once __DIR__ . '/includes/layout.php';
?>
<section class="card">
    <h2>Welcome, <?= h($user['name']) ?></h2>
    <p class="muted">Role: <?= h($user['role']) ?> | Wallet: Rs <?= h(number_format($wallet, 2)) ?> | Rating: <?= h((string)$user['avg_rating']) ?></p>
</section>
<?php if ($error): ?><p class="danger"><?= h($error) ?></p><?php endif; ?>
<?php if ($success): ?><p class="success"><?= h($success) ?></p><?php endif; ?>

<?php if (is_platform_staff($user)): ?>
    <section class="card">
        <h3>Super admin hub</h3>
        <p class="muted">Full access to client and freelancer areas; management tools are on this page.</p>
        <p><a href="<?= BASE_URL ?>/admin.php">Open Super Admin panel</a> — same links as the nav, plus user management, disputes, and payments. Below, you get a client + freelancer snapshot.</p>
    </section>
<?php endif; ?>

<section class="card">
    <h3>Wallet</h3>
    <form method="post" class="row">
        <div>
            <label>Add funds (demo wallet)</label>
            <input type="number" step="0.01" name="amount" required>
        </div>
        <div style="display:flex; align-items:flex-end;">
            <input type="hidden" name="add_wallet" value="1">
            <button type="submit">Add Balance</button>
        </div>
    </form>
</section>

<section class="card">
    <h3>Profile</h3>
    <form method="post">
        <label>Skills (comma separated)</label>
        <input name="skills" value="<?= h((string)$user['skills']) ?>">
        <label>Portfolio URL / text</label>
        <textarea name="portfolio" rows="3"><?= h((string)$user['portfolio']) ?></textarea>
        <input type="hidden" name="update_profile" value="1">
        <button type="submit">Update Profile</button>
    </form>
</section>

<?php if ($user['role'] === 'client' || $staff): ?>
    <section class="card">
        <h3>Available <?= $staff ? 'freelancers (directory)' : 'freelancers' ?></h3>
        <?php foreach ($freelancers as $freelancer): ?>
            <p>
                <strong><?= h($freelancer['name']) ?></strong>
                (<?= h($freelancer['email']) ?>) -
                Rating: <?= h((string)$freelancer['avg_rating']) ?>
                <?php if (!empty($freelancer['skills'])): ?>
                    | Skills: <?= h($freelancer['skills']) ?>
                <?php endif; ?>
                | <a href="<?= BASE_URL ?>/client/assign.php?freelancer_id=<?= (int)$freelancer['id'] ?>">Assign Work</a>
            </p>
        <?php endforeach; ?>
        <?php if (!$freelancers): ?><p class="muted">No freelancers available yet.</p><?php endif; ?>
    </section>

    <section class="card">
        <h3><?= $staff ? 'All projects' : 'My posted projects' ?></h3>
        <?php foreach ($myProjects as $project): ?>
            <p>
                <a href="<?= BASE_URL ?>/project.php?id=<?= (int)$project['id'] ?>"><?= h($project['title']) ?></a>
                - <?= h($project['status']) ?> - Rs <?= h(number_format((float)$project['budget'], 2)) ?>
            </p>
        <?php endforeach; ?>
        <?php if (!$myProjects): ?><p class="muted">No projects yet.</p><?php endif; ?>
    </section>
    <section class="card">
        <a href="<?= BASE_URL ?>/client/assign.php">Go to assignment page</a>
    </section>
<?php endif; ?>

<?php if ($user['role'] === 'freelancer' || $staff): ?>
    <section class="card">
        <h3><?= $staff ? 'All bids' : 'My bids' ?></h3>
        <?php foreach ($myBids as $bid): ?>
            <p>
                <?php if ($staff && isset($bid['bidder_name'])): ?>
                    <span class="muted"><?= h($bid['bidder_name']) ?>: </span>
                <?php endif; ?>
                <a href="<?= BASE_URL ?>/project.php?id=<?= (int)$bid['project_id'] ?>"><?= h($bid['project_title']) ?></a>
                - Rs <?= h(number_format((float)$bid['amount'], 2)) ?> - <?= h($bid['status']) ?>
            </p>
        <?php endforeach; ?>
        <?php if (!$myBids): ?><p class="muted">No bids yet.</p><?php endif; ?>
    </section>

    <section class="card">
        <h3><?= $staff ? 'All assigned work' : 'Assigned projects' ?></h3>
        <?php foreach ($myAssigned as $project): ?>
            <p>
                <a href="<?= BASE_URL ?>/project.php?id=<?= (int)$project['id'] ?>"><?= h($project['title']) ?></a>
                - <?= h($project['status']) ?>
                <?php if ($staff && !empty($project['client_name'])): ?>
                    <span class="muted">(client: <?= h($project['client_name']) ?>)</span>
                <?php endif; ?>
            </p>
        <?php endforeach; ?>
        <?php if (!$myAssigned): ?><p class="muted">No assigned projects yet.</p><?php endif; ?>
    </section>
    <section class="card">
        <a href="<?= BASE_URL ?>/freelancer/assignments.php">View assignment inbox</a>
    </section>
<?php endif; ?>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>

