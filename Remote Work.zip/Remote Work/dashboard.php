<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/project_reminder.php';
require_once __DIR__ . '/includes/skills_catalog.php';

require_active_client_session();
$user = current_user();
if (freelancer_needs_onboarding($user)) {
    header('Location: ' . BASE_URL . '/freelancer/onboarding.php');
    exit;
}
$error = '';
$success = '';
if (!empty($_SESSION['dashboard_flash_success'])) {
    $success = (string) $_SESSION['dashboard_flash_success'];
    unset($_SESSION['dashboard_flash_success']);
}
$staff = is_platform_staff($user);
$superAdmin = is_super_admin($user);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['project_assignment_action'], $_POST['project_id'])) {
        $projectAction = (string) ($_POST['project_assignment_action'] ?? '');
        $projectIdForAssignment = (int) ($_POST['project_id'] ?? 0);
        $allowedProjectActions = ['delete', 'disable'];

        if ($projectIdForAssignment <= 0 || !in_array($projectAction, $allowedProjectActions, true)) {
            $error = 'Invalid assignment action.';
        } elseif ($projectAction === 'delete' && is_platform_staff($user) && !$superAdmin) {
            $error = 'Only Super Admin can delete completed assignments.';
        } else {
            db()->beginTransaction();
            try {
                if ($superAdmin) {
                    $projectStmt = db()->prepare('SELECT id, user_id FROM projects WHERE id = ? FOR UPDATE');
                    $projectStmt->execute([$projectIdForAssignment]);
                } else {
                    $projectStmt = db()->prepare('SELECT id, user_id FROM projects WHERE id = ? AND user_id = ? FOR UPDATE');
                    $projectStmt->execute([$projectIdForAssignment, (int) $user['id']]);
                }
                $projectRow = $projectStmt->fetch();
                if (!$projectRow) {
                    throw new RuntimeException('Project not found.');
                }

                $projectStatusNowStmt = db()->prepare('SELECT status FROM projects WHERE id = ?');
                $projectStatusNowStmt->execute([(int) $projectRow['id']]);
                $projectStatusNow = (string) ($projectStatusNowStmt->fetchColumn() ?: '');
                if ($projectStatusNow !== 'completed' && !($superAdmin && $projectAction === 'delete')) {
                    throw new RuntimeException('Only completed projects can be changed here.');
                }

                $projectAssignmentsStmt = db()->prepare(
                    "SELECT id, file_path
                     FROM assignments
                     WHERE project_id = ? AND client_id = ?
                     FOR UPDATE"
                );
                $projectAssignmentsStmt->execute([(int) $projectRow['id'], (int) $projectRow['user_id']]);
                $assignmentRows = $projectAssignmentsStmt->fetchAll();

                if ($projectAction === 'disable') {
                    if ($projectStatusNow !== 'completed') {
                        throw new RuntimeException('Only completed projects can be disabled.');
                    }
                    $disableStmt = db()->prepare(
                        "UPDATE assignments
                         SET status = 'rejected'
                         WHERE project_id = ? AND client_id = ?"
                    );
                    $disableStmt->execute([(int) $projectRow['id'], (int) $projectRow['user_id']]);

                    $projectStatusStmt = db()->prepare("UPDATE projects SET status = 'cancelled' WHERE id = ?");
                    $projectStatusStmt->execute([(int) $projectRow['id']]);
                    $success = 'Completed assignment disabled.';
                } else {
                    foreach ($assignmentRows as $assignmentRow) {
                        $filePath = isset($assignmentRow['file_path']) && is_string($assignmentRow['file_path']) ? $assignmentRow['file_path'] : '';
                        if ($filePath !== '' && !str_contains($filePath, '..')) {
                            $fullPath = __DIR__ . '/' . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, ltrim($filePath, '/\\'));
                            if (is_file($fullPath)) {
                                @unlink($fullPath);
                            }
                        }
                    }

                    if ($superAdmin) {
                        $projectDeleteStmt = db()->prepare('DELETE FROM projects WHERE id = ?');
                        $projectDeleteStmt->execute([(int) $projectRow['id']]);
                        $success = $projectStatusNow === 'completed'
                            ? 'Completed assignment deleted.'
                            : 'Project deleted.';
                    } else {
                        $deleteStmt = db()->prepare('DELETE FROM assignments WHERE project_id = ? AND client_id = ?');
                        $deleteStmt->execute([(int) $projectRow['id'], (int) $projectRow['user_id']]);

                        $projectResetStmt = db()->prepare("UPDATE projects SET status = 'open', assigned_freelancer_id = NULL WHERE id = ?");
                        $projectResetStmt->execute([(int) $projectRow['id']]);
                        $success = 'Completed assignment deleted. Project reopened.';
                    }
                }

                db()->commit();

                $redirectStatus = (string) ($_POST['redirect_status'] ?? 'completed');
                if (!in_array($redirectStatus, ['open', 'assigned', 'in_progress', 'completed', 'cancelled', 'all'], true)) {
                    $redirectStatus = 'completed';
                }
                $_SESSION['dashboard_flash_success'] = $success;
                header('Location: ' . BASE_URL . '/dashboard.php?status=' . rawurlencode($redirectStatus));
                exit;
            } catch (Throwable) {
                db()->rollBack();
                $error = 'Could not update completed assignment.';
            }
        }
    }

    $user = current_user();
}

$myProjects = [];
$myBids = [];
$myAssigned = [];
$freelancers = [];
$staff = is_platform_staff($user);

if ($user['role'] === 'client' || $staff) {
    if ($staff) {
        $myProjects = db()->query('SELECT * FROM projects ORDER BY created_at DESC LIMIT 200')->fetchAll();
    } else {
        $stmt = db()->prepare('SELECT * FROM projects WHERE user_id = ? ORDER BY created_at DESC');
        $stmt->execute([(int)$user['id']]);
        $myProjects = $stmt->fetchAll();
    }

    $freelancersStmt = db()->query(
        "SELECT id, name, email, skills, avg_rating
         FROM users
         WHERE role = 'freelancer'
         ORDER BY avg_rating DESC, created_at DESC"
    );
    $freelancers = $freelancersStmt->fetchAll();
}

if ($user['role'] === 'freelancer' || $staff) {
    if ($staff) {
        $myBids = db()->query(
            "SELECT b.*, p.title AS project_title, u.name AS bidder_name
             FROM bids b
             JOIN projects p ON p.id = b.project_id
             JOIN users u ON u.id = b.freelancer_id
             ORDER BY b.created_at DESC
             LIMIT 200"
        )->fetchAll();
        $myAssigned = db()->query(
            "SELECT p.*, c.name AS client_name
             FROM projects p
             JOIN users c ON c.id = p.user_id
             WHERE p.assigned_freelancer_id IS NOT NULL
             ORDER BY p.created_at DESC
             LIMIT 200"
        )->fetchAll();
    } else {
        $bidsStmt = db()->prepare(
            "SELECT b.*, p.title AS project_title
             FROM bids b
             JOIN projects p ON p.id = b.project_id
             WHERE b.freelancer_id = ?
             ORDER BY b.created_at DESC"
        );
        $bidsStmt->execute([(int)$user['id']]);
        $myBids = $bidsStmt->fetchAll();

        $assignedStmt = db()->prepare(
            "SELECT * FROM projects WHERE assigned_freelancer_id = ? ORDER BY created_at DESC"
        );
        $assignedStmt->execute([(int)$user['id']]);
        $myAssigned = $assignedStmt->fetchAll();
    }
}

$walletStmt = db()->prepare('SELECT wallet_balance FROM users WHERE id = ?');
$walletStmt->execute([(int)$user['id']]);
$wallet = (float) ($walletStmt->fetch()['wallet_balance'] ?? 0);

if (isset($_GET['settings']) && (string) $_GET['settings'] === 'billing') {
    header('Location: ' . BASE_URL . '/payment.php?tab=billing');
    exit;
}

$wideMain = true;
$dashboardStatusFilter = (string) ($_GET['status'] ?? 'open');
$dashboardAllowedStatuses = ['open', 'assigned', 'in_progress', 'completed', 'cancelled', 'all'];
if (!in_array($dashboardStatusFilter, $dashboardAllowedStatuses, true)) {
    $dashboardStatusFilter = 'open';
}
$dashboardQuery = trim((string) ($_GET['q'] ?? ''));
$dashboardSort = (string) ($_GET['sort'] ?? 'recommended');
if (!in_array($dashboardSort, ['recommended', 'newest', 'budget'], true)) {
    $dashboardSort = 'recommended';
}

$dashboardLike = $dashboardQuery !== '' ? '%' . $dashboardQuery . '%' : null;
$dashboardOrderSql = match ($dashboardSort) {
    'newest' => 'ORDER BY p.created_at DESC',
    'budget' => 'ORDER BY p.budget DESC, p.created_at DESC',
    default => 'ORDER BY p.created_at DESC',
};
$dashboardWhere = [];
$dashboardParams = [];
if ($dashboardStatusFilter !== 'all') {
    $dashboardWhere[] = 'p.status = ?';
    $dashboardParams[] = $dashboardStatusFilter;
}
if ($dashboardLike !== null) {
    $dashboardWhere[] = '(p.title LIKE ? OR p.description LIKE ?)';
    $dashboardParams[] = $dashboardLike;
    $dashboardParams[] = $dashboardLike;
}
$dashboardSql = 'SELECT p.*, u.name AS client_name FROM projects p JOIN users u ON u.id = p.user_id';
if ($dashboardWhere) {
    $dashboardSql .= ' WHERE ' . implode(' AND ', $dashboardWhere);
}
$dashboardSql .= ' ' . $dashboardOrderSql;
$dashboardStmt = db()->prepare($dashboardSql);
$dashboardStmt->execute($dashboardParams);
$dashboardProjects = $dashboardStmt->fetchAll();

$dashboardCountSql = 'SELECT COUNT(*) AS n FROM projects p JOIN users u ON u.id = p.user_id';
if ($dashboardWhere) {
    $dashboardCountSql .= ' WHERE ' . implode(' AND ', $dashboardWhere);
}
$dashboardCountStmt = db()->prepare($dashboardCountSql);
$dashboardCountStmt->execute($dashboardParams);
$dashboardTotalCount = (int) ($dashboardCountStmt->fetch()['n'] ?? 0);
$dashboardShownFrom = $dashboardTotalCount > 0 ? 1 : 0;
$dashboardShownTo = min(count($dashboardProjects), $dashboardTotalCount);

$dashboardStatusCounts = [];
$dashboardStatusCountRows = db()->query('SELECT status, COUNT(*) AS c FROM projects GROUP BY status');
foreach ($dashboardStatusCountRows->fetchAll() as $dashboardStatusCountRow) {
    $dashboardStatusCounts[(string) $dashboardStatusCountRow['status']] = (int) $dashboardStatusCountRow['c'];
}
$dashboardAllCount = (int) (db()->query('SELECT COUNT(*) AS n FROM projects')->fetch()['n'] ?? 0);

function dashboard_time_ago(string $datetime): string
{
    $t = strtotime($datetime);
    if ($t === false) {
        return '';
    }
    $diff = time() - $t;
    if ($diff < 45) {
        return 'Just now';
    }
    if ($diff < 3600) {
        return (int) floor($diff / 60) . ' min ago';
    }
    if ($diff < 86400) {
        return (int) floor($diff / 3600) . ' hr ago';
    }
    if ($diff < 604800) {
        $d = (int) floor($diff / 86400);
        return $d . ' day' . ($d === 1 ? '' : 's') . ' ago';
    }
    return date('j M Y', $t);
}

function dashboard_card_tags(array $project): array
{
    $tags = ['Remote', ucwords(str_replace('_', ' ', (string) ($project['status'] ?? '')))];
    if (!empty($project['skills_required'])) {
        foreach (array_slice(nk_skills_parse_blob((string) $project['skills_required']), 0, 3) as $entry) {
            $label = nk_skills_display_label($entry);
            if (strlen($label) > 1 && strlen($label) < 40) {
                $tags[] = $label;
            }
        }
    }
    return array_slice(array_unique($tags), 0, 6);
}

function dashboard_initial(string $name): string
{
    $t = trim($name);
    if ($t === '') {
        return '?';
    }
    return strtoupper(function_exists('mb_substr') ? mb_substr($t, 0, 1, 'UTF-8') : substr($t, 0, 1));
}

require_once __DIR__ . '/includes/layout.php';
$projectJustUpdated = isset($_GET['project_updated']) && (string) $_GET['project_updated'] === '1';
?>
<?php if ($projectJustUpdated): ?>
<script>
window.addEventListener('DOMContentLoaded', function () {
    alert('Project updated successfully.');
    try {
        var u = new URL(window.location.href);
        u.searchParams.delete('project_updated');
        window.history.replaceState({}, '', u.pathname + u.search + u.hash);
    } catch (e) {}
});
</script>
<?php endif; ?>
<script>
window.addEventListener('DOMContentLoaded', function () {
    function removeFullscreenDarkLayers() {
        var nodes = document.querySelectorAll('body *');
        nodes.forEach(function (node) {
            if (!(node instanceof HTMLElement)) {
                return;
            }
            var style = window.getComputedStyle(node);
            if (style.display === 'none' || style.visibility === 'hidden') {
                return;
            }
            if (style.position !== 'fixed' && style.position !== 'absolute') {
                return;
            }
            var rect = node.getBoundingClientRect();
            if (rect.width < window.innerWidth * 0.95 || rect.height < window.innerHeight * 0.95) {
                return;
            }
            var bg = style.backgroundColor || '';
            var match = bg.match(/rgba?\(([^)]+)\)/i);
            if (!match) {
                return;
            }
            var parts = match[1].split(',').map(function (part) { return part.trim(); });
            if (parts.length < 3) {
                return;
            }
            var r = Number(parts[0]);
            var g = Number(parts[1]);
            var b = Number(parts[2]);
            var a = parts.length > 3 ? Number(parts[3]) : 1;
            var isDark = r <= 60 && g <= 60 && b <= 60 && a >= 0.2;
            if (isDark) {
                node.remove();
            }
        });
    }

    removeFullscreenDarkLayers();
    setTimeout(removeFullscreenDarkLayers, 250);
});
</script>
<div class="page-shell">
<section class="card">
    <h2>Welcome, <?= h($user['name']) ?></h2>
    <p class="muted">Role: <?= h($user['role']) ?> | Wallet: Rs <?= h(number_format($wallet, 2)) ?> | Rating: <?= h((string) $user['avg_rating']) ?>
        <span class="muted"> | </span><a href="<?= BASE_URL ?>/payment.php?tab=billing">Billing &amp; payments</a>
        <span class="muted"> · </span><a href="<?= BASE_URL ?>/payment.php?tab=withdrawals">Withdrawals</a>
    </p>
</section>
<?php if ($error): ?><p class="danger"><?= h($error) ?></p><?php endif; ?>
<?php if ($success): ?><p class="success"><?= h($success) ?></p><?php endif; ?>

<div class="nk-shell">
        <aside class="nk-sidebar nk-sidebar--left" aria-label="Filters">
            <div class="nk-filter-head">
                <h2 class="nk-filter-head__title">All Filters</h2>
            </div>
            <details class="nk-filter-block" open>
                <summary>Project status</summary>
                <ul class="nk-checklist">
                    <?php foreach ($dashboardAllowedStatuses as $statusValue): ?>
                        <?php
                        $cnt = $statusValue === 'all' ? $dashboardAllCount : (int) ($dashboardStatusCounts[$statusValue] ?? 0);
                        $label = $statusValue === 'open' ? 'Remote' : ($statusValue === 'all' ? 'All statuses' : ucwords(str_replace('_', ' ', $statusValue)));
                        ?>
                        <li>
                            <a class="nk-check nk-check--link<?= $dashboardStatusFilter === $statusValue ? ' is-active' : '' ?>" href="<?= BASE_URL ?>/dashboard.php?status=<?= urlencode($statusValue) ?><?= $dashboardQuery !== '' ? '&q=' . urlencode($dashboardQuery) : '' ?>">
                                <span class="nk-check__box" aria-hidden="true"></span>
                                <?= h($label) ?> <span class="nk-count">(<?= (int) $cnt ?>)</span>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </details>
        </aside>

        <div class="nk-feed">
            <section class="nk-hero-strip">
                <p class="nk-hero-strip__lead">Find remote projects that match your skills directly from your dashboard.</p>
                <div class="nk-hero-strip__links">
                    <a class="nk-link" href="<?= BASE_URL ?>/index.php">Browse full jobs page</a>
                    <?php if ($user['role'] === 'client' || $staff): ?>
                        <a class="nk-link" href="<?= BASE_URL ?>/post_project.php">Post project</a>
                        <a class="nk-link" href="<?= BASE_URL ?>/client/assign.php">Assign work</a>
                    <?php endif; ?>
                    <?php if ($user['role'] === 'freelancer' || $staff): ?>
                        <a class="nk-link" href="<?= BASE_URL ?>/freelancer/assignments.php">Assignments</a>
                    <?php endif; ?>
                </div>
            </section>

            <header class="nk-results-bar" id="browse-dashboard">
                <div class="nk-results-bar__meta">
                    <span class="nk-results-count"><?= (int) $dashboardShownFrom ?> &ndash; <?= (int) $dashboardShownTo ?> of <?= (int) $dashboardTotalCount ?> remote <?= $dashboardTotalCount === 1 ? 'job' : 'jobs' ?></span>
                </div>
                <form class="nk-sort" method="get" action="<?= BASE_URL ?>/dashboard.php">
                    <input type="hidden" name="status" value="<?= h($dashboardStatusFilter) ?>">
                    <?php if ($dashboardQuery !== ''): ?><input type="hidden" name="q" value="<?= h($dashboardQuery) ?>"><?php endif; ?>
                    <label for="dashboard-sort-by">Sort by:</label>
                    <select id="dashboard-sort-by" name="sort" onchange="this.form.submit()">
                        <option value="recommended" <?= $dashboardSort === 'recommended' ? 'selected' : '' ?>>Recommended</option>
                        <option value="newest" <?= $dashboardSort === 'newest' ? 'selected' : '' ?>>Date</option>
                        <option value="budget" <?= $dashboardSort === 'budget' ? 'selected' : '' ?>>Budget</option>
                    </select>
                </form>
            </header>

            <?php foreach ($dashboardProjects as $project): ?>
                <?php
                $snippet = (string) ($project['description'] ?? '');
                $snippet = preg_replace('/\s+/', ' ', $snippet) ?? '';
                $lenFn = function_exists('mb_strlen') ? 'mb_strlen' : 'strlen';
                $subFn = function_exists('mb_substr') ? 'mb_substr' : 'substr';
                $snippet = ($lenFn($snippet) > 180) ? $subFn($snippet, 0, 180) . '…' : $snippet;
                ?>
                <article class="nk-job-card">
                    <div class="nk-job-card__avatar" aria-hidden="true"><?= h(dashboard_initial((string) ($project['client_name'] ?? ''))) ?></div>
                    <div class="nk-job-card__body">
                        <h3 class="nk-job-card__title">
                            <a href="<?= BASE_URL ?>/project.php?id=<?= (int) $project['id'] ?>"><?= h((string) $project['title']) ?></a>
                        </h3>
                        <p class="nk-job-card__company"><?= h((string) ($project['client_name'] ?? '')) ?></p>
                        <ul class="nk-job-meta">
                            <li><span class="nk-job-meta__icon" aria-hidden="true">₹</span><?= h(number_format((float) $project['budget'], 0)) ?> / project</li>
                            <li><span class="nk-job-meta__icon" aria-hidden="true">◉</span>Remote</li>
                            <?php if (!empty($project['reminder_at'])): ?>
                                <li><span class="nk-job-meta__icon" aria-hidden="true">🕒</span><?= h(project_format_reminder_display((string) $project['reminder_at'])) ?></li>
                            <?php endif; ?>
                        </ul>
                        <p class="nk-job-card__desc"><?= h($snippet) ?></p>
                        <div class="nk-tags">
                            <?php foreach (dashboard_card_tags($project) as $tag): ?>
                                <span class="nk-tag"><?= h($tag) ?></span>
                            <?php endforeach; ?>
                        </div>
                        <footer class="nk-job-card__foot">
                            <time datetime="<?= h((string) $project['created_at']) ?>"><?= h(dashboard_time_ago((string) $project['created_at'])) ?></time>
                            <div class="nk-job-card__actions">
                                <?php
                                $superAdminCanDeleteCard = $superAdmin && in_array(
                                    (string) ($project['status'] ?? ''),
                                    ['completed', 'open', 'cancelled'],
                                    true
                                );
                                ?>
                                <?php if ($superAdminCanDeleteCard): ?>
                                    <form method="post" class="nk-job-card__action-form" onsubmit="return confirm('Permanently delete this project and all related data? This cannot be undone.');">
                                        <input type="hidden" name="project_id" value="<?= (int) $project['id'] ?>">
                                        <input type="hidden" name="redirect_status" value="<?= h($dashboardStatusFilter) ?>">
                                        <button type="submit" name="project_assignment_action" value="delete" class="nk-btn nk-btn--ghost nk-btn--danger">Delete</button>
                                    </form>
                                <?php endif; ?>
                                <a class="nk-save" href="<?= BASE_URL ?>/project.php?id=<?= (int) $project['id'] ?>">View</a>
                            </div>
                        </footer>
                    </div>
                </article>
            <?php endforeach; ?>

            <?php if (!$dashboardProjects): ?>
                <div class="nk-empty">
                    <p>No projects match your filters.</p>
                    <a href="<?= BASE_URL ?>/dashboard.php">Clear filters</a>
                </div>
            <?php endif; ?>
        </div>

        <aside class="nk-sidebar nk-sidebar--right" aria-label="Blog">
            <?php require_once __DIR__ . '/includes/partials/blog_headlines_widget.php'; ?>
        </aside>
    </div>

<?php if (is_platform_staff($user)): ?>
    <section class="card">
        <h3>Super admin hub</h3>
        <p class="muted">Full access to client and freelancer areas; management tools are on this page.</p>
        <p><a href="<?= BASE_URL ?>/admin.php">Super Admin overview</a> · <a href="<?= BASE_URL ?>/admin_assign_work.php">Assign work</a> · <a href="<?= BASE_URL ?>/admin_data.php">Users &amp; data</a> — same as the nav. Below, you get a client + freelancer snapshot.</p>
    </section>
<?php endif; ?>


<?php if ($user['role'] === 'client' || $staff): ?>
    <section class="card">
        <h3>Available <?= $staff ? 'freelancers (directory)' : 'freelancers' ?></h3>
        <?php foreach ($freelancers as $freelancer): ?>
            <p>
                <strong><?= h($freelancer['name']) ?></strong>
                (<?= h($freelancer['email']) ?>) -
                Rating: <?= h((string)$freelancer['avg_rating']) ?>
                <?php if (!empty($freelancer['skills'])): ?>
                    | Skills: <?= h($freelancer['skills']) ?>
                <?php endif; ?>
                | <a href="<?= BASE_URL ?>/client/assign.php?freelancer_id=<?= (int)$freelancer['id'] ?>">Assign Work</a>
            </p>
        <?php endforeach; ?>
        <?php if (!$freelancers): ?><p class="muted">No freelancers available yet.</p><?php endif; ?>
    </section>

    <section class="card">
        <h3><?= $staff ? 'All projects' : 'My posted projects' ?></h3>
        <?php foreach ($myProjects as $project): ?>
            <p>
                <a href="<?= BASE_URL ?>/project.php?id=<?= (int) $project['id'] ?>"><?= h($project['title']) ?></a>
                — <?= h($project['status']) ?> — Rs <?= h(number_format((float) $project['budget'], 2)) ?>
                <span class="muted">|</span> <a href="<?= BASE_URL ?>/edit_project.php?id=<?= (int) $project['id'] ?>">Edit</a>
            </p>
            <?php
            $canManageCompletedProject = (string) ($project['status'] ?? '') === 'completed'
                && ($superAdmin || (!$staff && (int) ($project['user_id'] ?? 0) === (int) $user['id']));
            $canSuperAdminDeleteProject = $superAdmin && in_array(
                (string) ($project['status'] ?? ''),
                ['completed', 'open', 'cancelled'],
                true
            );
            ?>
            <?php if ($canManageCompletedProject || $canSuperAdminDeleteProject): ?>
                <form method="post" style="margin:-6px 0 12px;"<?= $superAdmin ? ' onsubmit="return confirm(\'Permanently delete this project and all related data? This cannot be undone.\');"' : '' ?>>
                    <input type="hidden" name="project_id" value="<?= (int) $project['id'] ?>">
                    <input type="hidden" name="redirect_status" value="<?= h($dashboardStatusFilter) ?>">
                    <?php if ($canManageCompletedProject && ($superAdmin || !$staff)): ?>
                        <button type="submit" name="project_assignment_action" value="disable" class="nk-btn nk-btn--ghost" style="margin-right:8px;">Disable assignment</button>
                    <?php endif; ?>
                    <button type="submit" name="project_assignment_action" value="delete" class="nk-btn<?= $superAdmin ? ' nk-btn--danger' : '' ?>"><?= $superAdmin ? 'Delete project' : 'Delete assignment' ?></button>
                </form>
            <?php endif; ?>
        <?php endforeach; ?>
        <?php if (!$myProjects): ?><p class="muted">No projects yet.</p><?php endif; ?>
    </section>
    <section class="card">
        <h3>Client workflow</h3>
        <ol class="muted" style="margin:0 0 12px 1.1rem;padding:0;">
            <li><a href="<?= BASE_URL ?>/post_project.php">Create a project</a> (title, description, budget, skills, qualifications, optional reminder).</li>
            <li><a href="<?= BASE_URL ?>/client/assign.php">Assign that project</a> to a freelancer with instructions.</li>
        </ol>
    </section>
<?php endif; ?>

<?php if ($user['role'] === 'freelancer' || $staff): ?>
    <section class="card">
        <h3><?= $staff ? 'All bids' : 'My bids' ?></h3>
        <?php foreach ($myBids as $bid): ?>
            <p>
                <?php if ($staff && isset($bid['bidder_name'])): ?>
                    <span class="muted"><?= h($bid['bidder_name']) ?>: </span>
                <?php endif; ?>
                <a href="<?= BASE_URL ?>/project.php?id=<?= (int)$bid['project_id'] ?>"><?= h($bid['project_title']) ?></a>
                - Rs <?= h(number_format((float)$bid['amount'], 2)) ?> - <?= h($bid['status']) ?>
            </p>
        <?php endforeach; ?>
        <?php if (!$myBids): ?><p class="muted">No bids yet.</p><?php endif; ?>
    </section>

    <section class="card">
        <h3><?= $staff ? 'All assigned work' : 'Assigned projects' ?></h3>
        <?php foreach ($myAssigned as $project): ?>
            <p>
                <a href="<?= BASE_URL ?>/project.php?id=<?= (int)$project['id'] ?>"><?= h($project['title']) ?></a>
                - <?= h($project['status']) ?>
                <?php if ($staff && !empty($project['client_name'])): ?>
                    <span class="muted">(client: <?= h($project['client_name']) ?>)</span>
                <?php endif; ?>
            </p>
        <?php endforeach; ?>
        <?php if (!$myAssigned): ?><p class="muted">No assigned projects yet.</p><?php endif; ?>
    </section>
    <section class="card">
        <a href="<?= BASE_URL ?>/freelancer/assignments.php">View assignment inbox</a>
    </section>
<?php endif; ?>
</div>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>

