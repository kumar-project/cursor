<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config.php';

require_login();
require_freelancer_portal();
$user = current_user();
$staff = is_platform_staff($user);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assignment_id'], $_POST['new_status'])) {
    $assignmentId = (int)($_POST['assignment_id'] ?? 0);
    $newStatus = (string)($_POST['new_status'] ?? '');
    $allowed = ['in_progress', 'completed', 'rejected'];

    if ($assignmentId <= 0 || !in_array($newStatus, $allowed, true)) {
        $error = 'Invalid assignment update.';
    } else {
        db()->beginTransaction();
        try {
            if ($staff) {
                $assignmentStmt = db()->prepare(
                    "SELECT id, project_id, status, freelancer_id
                     FROM assignments
                     WHERE id = ?
                     FOR UPDATE"
                );
                $assignmentStmt->execute([$assignmentId]);
            } else {
                $assignmentStmt = db()->prepare(
                    "SELECT id, project_id, status, freelancer_id
                     FROM assignments
                     WHERE id = ? AND freelancer_id = ?
                     FOR UPDATE"
                );
                $assignmentStmt->execute([$assignmentId, (int)$user['id']]);
            }
            $assignment = $assignmentStmt->fetch();
            if (!$assignment) {
                throw new RuntimeException('Assignment not found.');
            }
            $assignmentFreelancerId = (int) $assignment['freelancer_id'];

            if ($staff) {
                $updateStmt = db()->prepare(
                    "UPDATE assignments
                     SET status = ?
                     WHERE id = ?"
                );
                $updateStmt->execute([$newStatus, $assignmentId]);
            } else {
                $updateStmt = db()->prepare(
                    "UPDATE assignments
                     SET status = ?
                     WHERE id = ? AND freelancer_id = ?"
                );
                $updateStmt->execute([$newStatus, $assignmentId, (int)$user['id']]);
            }

            if ($newStatus === 'in_progress' || $newStatus === 'completed') {
                $projectStatus = $newStatus === 'in_progress' ? 'in_progress' : 'completed';
                $projectStmt = db()->prepare(
                    "UPDATE projects
                     SET status = ?
                     WHERE id = ? AND assigned_freelancer_id = ?"
                );
                $projectStmt->execute([$projectStatus, (int)$assignment['project_id'], $assignmentFreelancerId]);
            }

            db()->commit();
            $success = 'Assignment status updated.';
        } catch (Throwable $e) {
            db()->rollBack();
            $error = 'Could not update assignment status.';
        }
    }
}

if ($staff) {
    $assignments = db()->query(
        "SELECT a.*, p.title AS project_title, p.budget, c.name AS client_name, f.name AS freelancer_name
         FROM assignments a
         JOIN projects p ON p.id = a.project_id
         JOIN users c ON c.id = a.client_id
         JOIN users f ON f.id = a.freelancer_id
         ORDER BY a.created_at DESC"
    )->fetchAll();
} else {
    $stmt = db()->prepare(
        "SELECT a.*, p.title AS project_title, p.budget, c.name AS client_name, f.name AS freelancer_name
         FROM assignments a
         JOIN projects p ON p.id = a.project_id
         JOIN users c ON c.id = a.client_id
         JOIN users f ON f.id = a.freelancer_id
         WHERE a.freelancer_id = ?
         ORDER BY a.created_at DESC"
    );
    $stmt->execute([(int)$user['id']]);
    $assignments = $stmt->fetchAll();
}

require_once __DIR__ . '/../includes/layout.php';
?>
<section class="card">
    <h2><?= $staff ? 'All assignment inbox (platform)' : 'My assignments' ?></h2>
    <?php if ($error): ?><p class="danger"><?= h($error) ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?= h($success) ?></p><?php endif; ?>
    <p class="muted">Tasks with instructions and files.<?= $staff ? ' Platform staff can update any record.' : '' ?></p>
</section>

<?php foreach ($assignments as $assignment): ?>
    <section class="card">
        <h3><?= h($assignment['project_title']) ?></h3>
        <p class="muted">Client: <?= h($assignment['client_name']) ?><?= $staff ? ' | Freelancer: ' . h($assignment['freelancer_name'] ?? '') : '' ?>
            | Budget: Rs <?= h(number_format((float)$assignment['budget'], 2)) ?> | Status: <?= h($assignment['status']) ?></p>
        <p><?= nl2br(h($assignment['message'])) ?></p>
        <?php if (!empty($assignment['file_path'])): ?>
            <p><a href="<?= BASE_URL . '/' . h($assignment['file_path']) ?>" target="_blank">Download attachment</a></p>
        <?php endif; ?>

        <form method="post" class="row">
            <input type="hidden" name="assignment_id" value="<?= (int)$assignment['id'] ?>">
            <div>
                <label>Update status</label>
                <select name="new_status">
                    <option value="in_progress">In Progress</option>
                    <option value="completed">Completed</option>
                    <option value="rejected">Rejected</option>
                </select>
            </div>
            <div style="display:flex; align-items:flex-end;">
                <button type="submit">Save</button>
            </div>
        </form>
    </section>
<?php endforeach; ?>

<?php if (!$assignments): ?>
    <section class="card">
        <p class="muted">No assignments received yet.</p>
    </section>
<?php endif; ?>
<?php require_once __DIR__ . '/../includes/layout_footer.php'; ?>

