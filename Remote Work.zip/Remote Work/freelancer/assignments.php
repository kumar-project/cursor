<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/project_payment.php';
require_once __DIR__ . '/../config.php';

require_login();
require_freelancer_portal();
$user = current_user();
$staff = is_platform_staff($user);

if (!$staff && freelancer_needs_onboarding($user)) {
    header('Location: ' . BASE_URL . '/freelancer/onboarding.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assignment_id'], $_POST['new_status'])) {
    $assignmentId = (int) ($_POST['assignment_id'] ?? 0);
    $newStatus = (string) ($_POST['new_status'] ?? '');
    $allowed = ['in_progress', 'completed', 'rejected'];

    if ($assignmentId <= 0 || !in_array($newStatus, $allowed, true)) {
        $error = 'Invalid assignment update.';
    } else {
        db()->beginTransaction();
        try {
            if ($staff) {
                $assignmentStmt = db()->prepare(
                    "SELECT id, project_id, status, freelancer_id
                     FROM assignments
                     WHERE id = ?
                     FOR UPDATE"
                );
                $assignmentStmt->execute([$assignmentId]);
            } else {
                $assignmentStmt = db()->prepare(
                    "SELECT id, project_id, status, freelancer_id
                     FROM assignments
                     WHERE id = ? AND freelancer_id = ?
                     FOR UPDATE"
                );
                $assignmentStmt->execute([$assignmentId, (int) $user['id']]);
            }
            $assignment = $assignmentStmt->fetch();
            if (!$assignment) {
                throw new RuntimeException('Assignment not found.');
            }
            $assignmentFreelancerId = (int) $assignment['freelancer_id'];

            if ($staff) {
                $updateStmt = db()->prepare(
                    "UPDATE assignments
                     SET status = ?
                     WHERE id = ?"
                );
                $updateStmt->execute([$newStatus, $assignmentId]);
            } else {
                $updateStmt = db()->prepare(
                    "UPDATE assignments
                     SET status = ?
                     WHERE id = ? AND freelancer_id = ?"
                );
                $updateStmt->execute([$newStatus, $assignmentId, (int) $user['id']]);
            }

            if ($newStatus === 'completed') {
                $confirmation = fetch_project_payment_confirmation((int) $assignment['project_id']);
                if (!project_payment_is_confirmed($confirmation)) {
                    throw new RuntimeException('Payment not confirmed.');
                }
            }

            if ($newStatus === 'in_progress' || $newStatus === 'completed') {
                $projectStatus = $newStatus === 'in_progress' ? 'in_progress' : 'completed';
                $projectStmt = db()->prepare(
                    "UPDATE projects
                     SET status = ?
                     WHERE id = ? AND assigned_freelancer_id = ?"
                );
                $projectStmt->execute([$projectStatus, (int) $assignment['project_id'], $assignmentFreelancerId]);
            }

            db()->commit();
            $success = 'Assignment status updated.';
        } catch (Throwable $e) {
            db()->rollBack();
            $error = $e->getMessage() === 'Payment not confirmed.'
                ? 'Complete the project from the project page: the client must submit payment details and you must confirm receipt.'
                : 'Could not update assignment status.';
        }
    }
}

if ($staff) {
    $assignments = db()->query(
        "SELECT a.*, p.title AS project_title, p.budget, c.name AS client_name, f.name AS freelancer_name
         FROM assignments a
         JOIN projects p ON p.id = a.project_id
         JOIN users c ON c.id = a.client_id
         JOIN users f ON f.id = a.freelancer_id
         ORDER BY a.created_at DESC"
    )->fetchAll();
} else {
    $stmt = db()->prepare(
        "SELECT a.*, p.title AS project_title, p.budget, c.name AS client_name, f.name AS freelancer_name
         FROM assignments a
         JOIN projects p ON p.id = a.project_id
         JOIN users c ON c.id = a.client_id
         JOIN users f ON f.id = a.freelancer_id
         WHERE a.freelancer_id = ?
         ORDER BY a.created_at DESC"
    );
    $stmt->execute([(int) $user['id']]);
    $assignments = $stmt->fetchAll();
}

$frShellTitle = $staff ? 'Assignment inbox (platform)' : 'Assignment inbox';
$frShellProgress = null;
$frShellLaterHref = BASE_URL . '/dashboard.php';
$frShellLaterLabel = 'Dashboard';

require_once __DIR__ . '/../includes/freelancer_remote_head.php';
?>

<?php if ($error): ?>
    <p class="fr-panel" style="color:#c0392b;border-color:#fab1a0;background:#fff5f5;"><?= h($error) ?></p>
<?php endif; ?>
<?php if ($success): ?>
    <p class="fr-panel" style="color:#006b4f;border-color:#b2e8d3;background:#e8f8f2;"><?= h($success) ?></p>
<?php endif; ?>

<div class="fr-panel">
    <h2 style="margin-bottom:8px;"><?= $staff ? 'All assignment inbox (platform)' : 'My assignments' ?></h2>
    <p class="muted">Tasks with instructions and files.<?= $staff ? ' Platform staff can update any record.' : '' ?></p>
    <p class="muted"><a href="<?= BASE_URL ?>/index.php">Browse projects</a></p>
</div>

<?php foreach ($assignments as $assignment): ?>
    <article class="fr-panel">
        <h3><?= h($assignment['project_title']) ?></h3>
        <p class="muted">Client: <?= h($assignment['client_name']) ?><?= $staff ? ' | Freelancer: ' . h($assignment['freelancer_name'] ?? '') : '' ?>
            | Budget: Rs <?= h(number_format((float) $assignment['budget'], 2)) ?> | Status: <?= h($assignment['status']) ?></p>
        <p><?= nl2br(h($assignment['message'])) ?></p>
        <?php if (!empty($assignment['file_path'])): ?>
            <p><a href="<?= BASE_URL . '/' . h($assignment['file_path']) ?>" target="_blank">Download attachment</a></p>
        <?php endif; ?>

        <p class="muted"><a href="<?= BASE_URL ?>/project.php?id=<?= (int) $assignment['project_id'] ?>">Open project</a> to submit or confirm payment before marking completed.</p>
        <form method="post" class="fr-assign-form">
            <input type="hidden" name="assignment_id" value="<?= (int) $assignment['id'] ?>">
            <div>
                <label for="st-<?= (int) $assignment['id'] ?>">Update status</label>
                <select name="new_status" id="st-<?= (int) $assignment['id'] ?>">
                    <option value="in_progress">In Progress</option>
                    <option value="completed">Completed (after payment confirmed on project)</option>
                    <option value="rejected">Rejected</option>
                </select>
            </div>
            <button type="submit">Save</button>
        </form>
    </article>
<?php endforeach; ?>

<?php if (!$assignments): ?>
    <div class="fr-panel">
        <p class="muted">No assignments received yet.</p>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/freelancer_remote_foot.php'; ?>
