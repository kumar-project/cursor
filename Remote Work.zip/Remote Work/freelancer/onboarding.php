<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config.php';

require_login();
$user = current_user();
if (!$user || !can_access_freelancer_portal($user)) {
    http_response_code(403);
    echo 'Forbidden';
    exit;
}

if (is_platform_staff($user)) {
    header('Location: ' . BASE_URL . '/dashboard.php');
    exit;
}

if (isset($_GET['skip']) && (string) $_GET['skip'] === '1') {
    $stmt = db()->prepare('UPDATE users SET freelancer_onboarding_skipped = 1 WHERE id = ?');
    $stmt->execute([(int) $user['id']]);
    header('Location: ' . BASE_URL . '/dashboard.php');
    exit;
}

$user = current_user();
if (!freelancer_needs_onboarding($user)) {
    header('Location: ' . BASE_URL . '/dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['remote_work_type'])) {
        $v = (string) $_POST['remote_work_type'];
        $allowed = ['100_remote', 'hybrid', 'option_remote'];
        if (!in_array($v, $allowed, true)) {
            $error = 'Please pick one option.';
        } else {
            $stmt = db()->prepare('UPDATE users SET remote_work_type = ? WHERE id = ? AND role = ?');
            $stmt->execute([$v, (int) $user['id'], 'freelancer']);
            header('Location: ' . BASE_URL . '/freelancer/onboarding.php');
            exit;
        }
    } elseif (isset($_POST['availability_timeline'])) {
        $v = (string) $_POST['availability_timeline'];
        $allowed = ['now', 'month', 'browsing'];
        if (!in_array($v, $allowed, true)) {
            $error = 'Please pick one option.';
        } else {
            require_once __DIR__ . '/../includes/freelancer_cv_upload.php';
            $priorCv = isset($user['cv_file_path']) && is_string($user['cv_file_path']) ? $user['cv_file_path'] : null;
            $cvOut = freelancer_cv_process_upload(isset($_FILES['cv_file']) ? $_FILES['cv_file'] : null, (int) $user['id'], $priorCv);
            if ($cvOut['error'] !== null) {
                $error = $cvOut['error'];
            } else {
                if ($cvOut['path'] !== null) {
                    $updCv = db()->prepare('UPDATE users SET availability_timeline = ?, cv_file_path = ? WHERE id = ? AND role = ?');
                    $updCv->execute([$v, $cvOut['path'], (int) $user['id'], 'freelancer']);
                } else {
                    $stmt = db()->prepare('UPDATE users SET availability_timeline = ? WHERE id = ? AND role = ?');
                    $stmt->execute([$v, (int) $user['id'], 'freelancer']);
                }
                header('Location: ' . BASE_URL . '/dashboard.php');
                exit;
            }
        }
    }
}

$user = current_user();
$showStep = 1;
if (!empty($user['remote_work_type']) && empty($user['availability_timeline'])) {
    $showStep = 2;
}

$frShellTitle = $showStep === 1 ? 'Remote preferences' : 'Your timeline';
$frShellProgress = $showStep === 1 ? 40 : 100;
$frShellLaterHref = BASE_URL . '/freelancer/onboarding.php?skip=1';
$frShellLaterLabel = "I'll Do This Later";

require_once __DIR__ . '/../includes/freelancer_remote_head.php';
?>

<?php if ($error): ?>
    <p class="fr-panel" style="color:#c0392b;border-color:#fab1a0;background:#fff5f5;"><?= h($error) ?></p>
<?php endif; ?>

<?php if ($showStep === 1): ?>
    <form class="fr-form" method="post" id="fr-onboard-1">
        <h1 class="fr-question">What kind of remote work are you looking for?</h1>
        <div class="fr-options" role="radiogroup" aria-label="Remote work type">
            <div class="fr-option">
                <input type="radio" name="remote_work_type" value="100_remote" id="rw100" required checked>
                <label for="rw100">100% Remote Work<span class="fr-option__check" aria-hidden="true"> ✓</span></label>
            </div>
            <div class="fr-option">
                <input type="radio" name="remote_work_type" value="hybrid" id="rwhyb" required>
                <label for="rwhyb">Hybrid Remote Work<span class="fr-option__check" aria-hidden="true"> ✓</span></label>
            </div>
            <div class="fr-option">
                <input type="radio" name="remote_work_type" value="option_remote" id="rwopt" required>
                <label for="rwopt">Option for Remote Work<span class="fr-option__check" aria-hidden="true"> ✓</span></label>
            </div>
        </div>
        <div class="fr-feedback" id="fr-feedback" aria-live="polite"></div>
        <div class="fr-actions">
            <button type="submit" class="fr-btn-next" id="fr-next-1" disabled>Next</button>
        </div>
    </form>
    <script>
    (function () {
        var form = document.getElementById('fr-onboard-1');
        var feedback = document.getElementById('fr-feedback');
        var nextBtn = document.getElementById('fr-next-1');
        var messages = {
            '100_remote': '👍 Nice choice! No commute for you!',
            'hybrid': '👍 Hybrid gives you flexibility between home and the office.',
            'option_remote': '👍 Many teams offer optional remote days — great pick.'
        };
        function syncStep1() {
            var sel = form.querySelector('input[name="remote_work_type"]:checked');
            if (sel) {
                feedback.textContent = messages[sel.value] || '';
                feedback.classList.add('is-visible');
                nextBtn.disabled = false;
            }
        }
        form.querySelectorAll('input[name="remote_work_type"]').forEach(function (input) {
            input.addEventListener('change', syncStep1);
        });
        syncStep1();
    })();
    </script>
<?php else: ?>
    <form class="fr-form" method="post" id="fr-onboard-2" enctype="multipart/form-data">
        <h1 class="fr-question">When are you hoping to get started?</h1>
        <p class="fr-lead">This helps us surface the right opportunities for you.</p>
        <div class="fr-options" role="radiogroup" aria-label="Start timeline">
            <div class="fr-option">
                <input type="radio" name="availability_timeline" value="now" id="avn" required>
                <label for="avn">Actively looking now<span class="fr-option__check" aria-hidden="true"> ✓</span></label>
            </div>
            <div class="fr-option">
                <input type="radio" name="availability_timeline" value="month" id="avm" required>
                <label for="avm">Within the next month<span class="fr-option__check" aria-hidden="true"> ✓</span></label>
            </div>
            <div class="fr-option">
                <input type="radio" name="availability_timeline" value="browsing" id="avb" required>
                <label for="avb">Just browsing<span class="fr-option__check" aria-hidden="true"> ✓</span></label>
            </div>
        </div>
        <div class="fr-panel" style="margin-top:1.25rem;padding:14px 16px;text-align:left;">
            <label for="cv_file_onboard" style="display:block;font-weight:600;margin-bottom:8px;font-size:0.95rem;">Résumé / CV <span style="font-weight:400;color:#64748b;">(optional)</span></label>
            <p style="margin:0 0 8px;font-size:0.88rem;color:#64748b;line-height:1.4;">PDF or Word, up to 5 MB — same upload is available anytime under Dashboard → My Profile.</p>
            <input type="file" name="cv_file" id="cv_file_onboard" accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document">
        </div>
        <div class="fr-feedback" id="fr-feedback-2" aria-live="polite"></div>
        <div class="fr-actions">
            <button type="submit" class="fr-btn-next" id="fr-next-2" disabled>Finish</button>
        </div>
    </form>
    <script>
    (function () {
        var form = document.getElementById('fr-onboard-2');
        var feedback = document.getElementById('fr-feedback-2');
        var nextBtn = document.getElementById('fr-next-2');
        var messages = {
            'now': '👍 We will prioritize fresh roles and fast-moving clients.',
            'month': '👍 Good timing — we will mix new listings with longer-term fits.',
            'browsing': '👍 No pressure — explore projects at your own pace.'
        };
        form.querySelectorAll('input[name="availability_timeline"]').forEach(function (input) {
            input.addEventListener('change', function () {
                feedback.textContent = messages[input.value] || '';
                feedback.classList.add('is-visible');
                nextBtn.disabled = false;
            });
        });
    })();
    </script>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/freelancer_remote_foot.php'; ?>
