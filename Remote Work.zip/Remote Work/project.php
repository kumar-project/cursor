<?php
declare(strict_types=1);

$wideMain = true;

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/project_reminder.php';
require_once __DIR__ . '/includes/project_payment.php';
require_once __DIR__ . '/includes/skills_catalog.php';
require_once __DIR__ . '/config.php';

$projectId = (int)($_GET['id'] ?? 0);
if ($projectId <= 0) {
    http_response_code(404);
    echo 'Project not found';
    exit;
}

$user = current_user();
$error = '';
$success = '';

$ctxProject = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $user) {
    if ($projectId > 0) {
        $cStmt = db()->prepare('SELECT p.*, u.id AS client_id FROM projects p JOIN users u ON u.id = p.user_id WHERE p.id = ?');
        $cStmt->execute([$projectId]);
        $ctxProject = $cStmt->fetch();
    }

    if (isset($_POST['place_bid']) && $ctxProject && can_submit_bid($user, $ctxProject)) {
        $amount = (float)($_POST['amount'] ?? 0);
        $proposal = trim($_POST['proposal'] ?? '');
        if ($amount <= 0 || $proposal === '') {
            $error = 'Enter valid amount and proposal.';
        } else {
            try {
                $stmt = db()->prepare('INSERT INTO bids (project_id, freelancer_id, amount, proposal) VALUES (?, ?, ?, ?)');
                $stmt->execute([$projectId, (int)$user['id'], $amount, $proposal]);
                $success = 'Bid submitted successfully.';
            } catch (Throwable $e) {
                $error = 'You have already bid on this project.';
            }
        }
    }

    if (isset($_POST['accept_bid']) && $ctxProject && can_manage_project_as_client($user, $ctxProject)) {
        $bidId = (int)($_POST['bid_id'] ?? 0);
        db()->beginTransaction();
        try {
            $projectStmt = db()->prepare('SELECT user_id, status FROM projects WHERE id = ? FOR UPDATE');
            $projectStmt->execute([$projectId]);
            $project = $projectStmt->fetch();
            if (!$project || $project['status'] !== 'open' || !can_manage_project_as_client(
                $user,
                [
                    'user_id' => $project['user_id'],
                    'client_id' => $project['user_id'],
                ]
            )) {
                throw new RuntimeException('Invalid project state.');
            }

            $bidStmt = db()->prepare('SELECT freelancer_id FROM bids WHERE id = ? AND project_id = ?');
            $bidStmt->execute([$bidId, $projectId]);
            $selectedBid = $bidStmt->fetch();
            if (!$selectedBid) {
                throw new RuntimeException('Bid not found.');
            }

            $accept = db()->prepare("UPDATE bids SET status = 'accepted' WHERE id = ?");
            $accept->execute([$bidId]);
            $rejectOthers = db()->prepare("UPDATE bids SET status = 'rejected' WHERE project_id = ? AND id <> ?");
            $rejectOthers->execute([$projectId, $bidId]);

            $assign = db()->prepare("UPDATE projects SET status = 'assigned', assigned_freelancer_id = ? WHERE id = ?");
            $assign->execute([(int)$selectedBid['freelancer_id'], $projectId]);

            db()->commit();
            $success = 'Bid accepted and project assigned.';
        } catch (Throwable $e) {
            db()->rollBack();
            $error = 'Could not accept bid.';
        }
    }

    if (isset($_POST['mark_in_progress']) && $ctxProject && can_act_as_assigned_freelancer($user, $ctxProject)) {
        if (is_platform_staff($user)) {
            $stmt = db()->prepare(
                "UPDATE projects
                 SET status = 'in_progress'
                 WHERE id = ? AND status = 'assigned' AND assigned_freelancer_id IS NOT NULL"
            );
            $stmt->execute([$projectId]);
        } else {
            $stmt = db()->prepare(
                "UPDATE projects
                 SET status = 'in_progress'
                 WHERE id = ? AND assigned_freelancer_id = ? AND status = 'assigned'"
            );
            $stmt->execute([$projectId, (int)$user['id']]);
        }
        if ($stmt->rowCount() > 0) {
            $success = 'Project moved to in progress.';
        } else {
            $error = 'Could not update project status.';
        }
    }

    if (isset($_POST['create_milestone']) && $ctxProject && can_manage_project_as_client($user, $ctxProject)) {
        $title = trim($_POST['milestone_title'] ?? '');
        $amount = (float)($_POST['milestone_amount'] ?? 0);
        if ($title === '' || $amount <= 0) {
            $error = 'Milestone title and amount are required.';
        } else {
            $ownerId = (int) $ctxProject['user_id'];
            $stmt = db()->prepare(
                "INSERT INTO milestones (project_id, title, amount)
                 SELECT id, ?, ?
                 FROM projects
                 WHERE id = ? AND user_id = ?"
            );
            $stmt->execute([$title, $amount, $projectId, $ownerId]);
            if ($stmt->rowCount() > 0) {
                $success = 'Milestone created.';
            } else {
                $error = 'Could not create milestone.';
            }
        }
    }

    if (isset($_POST['fund_milestone']) && $ctxProject && can_manage_project_as_client($user, $ctxProject)) {
        $milestoneId = (int)($_POST['milestone_id'] ?? 0);
        db()->beginTransaction();
        try {
            $m = db()->prepare(
                "SELECT m.id, m.amount, m.status, p.user_id, p.assigned_freelancer_id
                 FROM milestones m
                 JOIN projects p ON p.id = m.project_id
                 WHERE m.id = ? AND m.project_id = ?
                 FOR UPDATE"
            );
            $m->execute([$milestoneId, $projectId]);
            $milestone = $m->fetch();
            if (!$milestone) {
                throw new RuntimeException('Invalid milestone state.');
            }
            if (!can_manage_project_as_client(
                $user,
                [
                    'user_id' => $milestone['user_id'],
                    'client_id' => $milestone['user_id'],
                ]
            ) || $milestone['status'] !== 'pending') {
                throw new RuntimeException('Invalid milestone state.');
            }
            if (empty($milestone['assigned_freelancer_id'])) {
                throw new RuntimeException('Assign a freelancer before funding.');
            }

            $payerId = (int) $milestone['user_id'];
            $walletStmt = db()->prepare('SELECT wallet_balance FROM users WHERE id = ? FOR UPDATE');
            $walletStmt->execute([$payerId]);
            $wallet = (float)($walletStmt->fetch()['wallet_balance'] ?? 0);
            $amount = (float)$milestone['amount'];
            if ($wallet < $amount) {
                throw new RuntimeException('Low wallet balance.');
            }

            $deduct = db()->prepare('UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?');
            $deduct->execute([$amount, $payerId]);

            $mark = db()->prepare("UPDATE milestones SET status = 'funded' WHERE id = ?");
            $mark->execute([$milestoneId]);

            $pay = db()->prepare(
                "INSERT INTO payments (project_id, payer_id, payee_id, amount, milestone_id, status, gateway)
                 VALUES (?, ?, ?, ?, ?, 'escrowed', 'wallet')"
            );
            $pay->execute([$projectId, $payerId, (int)$milestone['assigned_freelancer_id'], $amount, $milestoneId]);

            db()->commit();
            $success = 'Milestone funded into escrow.';
        } catch (Throwable $e) {
            db()->rollBack();
            $error = $e->getMessage() === 'Low wallet balance.' ? 'Wallet balance is low. Add funds from dashboard.' : 'Could not fund milestone.';
        }
    }

    if (isset($_POST['release_milestone']) && $ctxProject && can_manage_project_as_client($user, $ctxProject)) {
        $milestoneId = (int)($_POST['milestone_id'] ?? 0);
        db()->beginTransaction();
        try {
            $m = db()->prepare(
                "SELECT m.id, m.amount, m.status, p.user_id, p.assigned_freelancer_id
                 FROM milestones m
                 JOIN projects p ON p.id = m.project_id
                 WHERE m.id = ? AND m.project_id = ?
                 FOR UPDATE"
            );
            $m->execute([$milestoneId, $projectId]);
            $milestone = $m->fetch();
            if (
                !$milestone
                || $milestone['status'] !== 'funded'
                || !can_manage_project_as_client(
                    $user,
                    [
                        'user_id' => $milestone['user_id'],
                        'client_id' => $milestone['user_id'],
                    ]
                )
            ) {
                throw new RuntimeException('Invalid release state.');
            }

            $mark = db()->prepare("UPDATE milestones SET status = 'released' WHERE id = ?");
            $mark->execute([$milestoneId]);

            $pay = db()->prepare(
                "UPDATE payments
                 SET status = 'released'
                 WHERE milestone_id = ? AND project_id = ? AND status = 'escrowed'"
            );
            $pay->execute([$milestoneId, $projectId]);

            $credit = db()->prepare('UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?');
            $credit->execute([(float)$milestone['amount'], (int)$milestone['assigned_freelancer_id']]);

            db()->commit();
            $success = 'Milestone payment released to freelancer.';
        } catch (Throwable $e) {
            db()->rollBack();
            $error = 'Could not release milestone.';
        }
    }

    if (isset($_POST['submit_payment_confirmation']) && $ctxProject && can_manage_project_as_client($user, $ctxProject)) {
        $paymentStatus = (string) ($_POST['payment_status'] ?? '');
        $paymentMethod = (string) ($_POST['payment_method'] ?? '');
        $paymentAmount = (float) ($_POST['payment_amount'] ?? 0);
        $referenceType = (string) ($_POST['reference_type'] ?? '');
        $referenceNumber = trim((string) ($_POST['reference_number'] ?? ''));
        $notes = trim((string) ($_POST['payment_notes'] ?? ''));
        $freelancerId = (int) ($ctxProject['assigned_freelancer_id'] ?? 0);
        $clientOwner = (int) $ctxProject['user_id'];

        $statusOptions = project_payment_status_options();
        $methodOptions = project_payment_method_options();
        $refOptions = project_payment_reference_type_options();

        if ($freelancerId <= 0) {
            $error = 'Assign a freelancer before submitting payment details.';
        } elseif (!in_array($ctxProject['status'], ['assigned', 'in_progress'], true)) {
            $error = 'Payment details can only be submitted for active projects.';
        } elseif (
            !isset($statusOptions[$paymentStatus])
            || !isset($methodOptions[$paymentMethod])
            || !isset($refOptions[$referenceType])
            || $paymentAmount <= 0
            || $referenceNumber === ''
        ) {
            $error = 'Enter payment status, method, amount, reference type, and reference number.';
        } else {
            $existing = fetch_project_payment_confirmation($projectId);
            if ($existing && project_payment_is_confirmed($existing)) {
                $error = 'Payment is already confirmed. This project cannot be updated.';
            } else {
                try {
                    if ($existing) {
                        $stmt = db()->prepare(
                            "UPDATE project_payment_confirmations
                             SET payment_status = ?, payment_method = ?, payment_amount = ?,
                                 reference_type = ?, reference_number = ?, notes = ?,
                                 client_submitted_at = CURRENT_TIMESTAMP
                             WHERE project_id = ? AND freelancer_confirmed_at IS NULL"
                        );
                        $stmt->execute([
                            $paymentStatus,
                            $paymentMethod,
                            $paymentAmount,
                            $referenceType,
                            $referenceNumber,
                            $notes !== '' ? $notes : null,
                            $projectId,
                        ]);
                    } else {
                        $stmt = db()->prepare(
                            "INSERT INTO project_payment_confirmations
                             (project_id, client_id, freelancer_id, payment_status, payment_method,
                              payment_amount, reference_type, reference_number, notes)
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
                        );
                        $stmt->execute([
                            $projectId,
                            $clientOwner,
                            $freelancerId,
                            $paymentStatus,
                            $paymentMethod,
                            $paymentAmount,
                            $referenceType,
                            $referenceNumber,
                            $notes !== '' ? $notes : null,
                        ]);
                    }
                    if ($stmt->rowCount() > 0) {
                        $success = 'Payment details sent to the freelancer for confirmation.';
                    } else {
                        $error = 'Could not save payment details.';
                    }
                } catch (Throwable) {
                    $error = 'Could not save payment details.';
                }
            }
        }
    }

    if (isset($_POST['confirm_payment_received']) && $ctxProject && can_act_as_assigned_freelancer($user, $ctxProject)) {
        $freelancerId = is_platform_staff($user)
            ? (int) ($ctxProject['assigned_freelancer_id'] ?? 0)
            : (int) $user['id'];
        if ($freelancerId <= 0) {
            $error = 'No assigned freelancer on this project.';
        } elseif (!in_array($ctxProject['status'], ['assigned', 'in_progress'], true)) {
            $error = 'This project is not awaiting payment confirmation.';
        } else {
            db()->beginTransaction();
            try {
                $lock = db()->prepare(
                    "SELECT id, freelancer_id
                     FROM project_payment_confirmations
                     WHERE project_id = ? AND freelancer_confirmed_at IS NULL
                     FOR UPDATE"
                );
                $lock->execute([$projectId]);
                $confirmation = $lock->fetch();
                if (!$confirmation || (int) $confirmation['freelancer_id'] !== $freelancerId) {
                    throw new RuntimeException('Payment details not found.');
                }

                $confirm = db()->prepare(
                    "UPDATE project_payment_confirmations
                     SET freelancer_confirmed_at = NOW(), freelancer_confirmed_by = ?
                     WHERE id = ?"
                );
                $confirm->execute([(int) $user['id'], (int) $confirmation['id']]);

                if (is_platform_staff($user)) {
                    $complete = db()->prepare(
                        "UPDATE projects
                         SET status = 'completed'
                         WHERE id = ? AND status IN ('assigned', 'in_progress') AND assigned_freelancer_id = ?"
                    );
                    $complete->execute([$projectId, $freelancerId]);
                } else {
                    $complete = db()->prepare(
                        "UPDATE projects
                         SET status = 'completed'
                         WHERE id = ? AND assigned_freelancer_id = ? AND status IN ('assigned', 'in_progress')"
                    );
                    $complete->execute([$projectId, $freelancerId]);
                }
                if ($complete->rowCount() === 0) {
                    throw new RuntimeException('Could not complete project.');
                }

                sync_assignment_completed_for_project($projectId, $freelancerId);
                db()->commit();
                $success = 'Payment confirmed. Project marked as completed.';
            } catch (Throwable) {
                db()->rollBack();
                $error = 'Confirm payment only after the client has submitted payment details.';
            }
        }
    }

    if (isset($_POST['submit_review']) && $ctxProject) {
        $rating = (int)($_POST['rating'] ?? 0);
        $feedback = trim($_POST['feedback'] ?? '');
        $revieweeId = (int)($_POST['reviewee_id'] ?? 0);
        if ($rating < 1 || $rating > 5 || $revieweeId <= 0) {
            $error = 'Invalid review values.';
        } else {
            $allowed = false;
            if (is_platform_staff($user) && $ctxProject['status'] === 'completed') {
                $cid = (int) $ctxProject['client_id'];
                $fid = (int) ($ctxProject['assigned_freelancer_id'] ?? 0);
                $allowed = in_array($revieweeId, array_filter([$cid, $fid]), true);
            } else {
                $canReview = db()->prepare(
                    "SELECT id
                     FROM projects
                     WHERE id = ?
                     AND status = 'completed'
                     AND (user_id = ? OR assigned_freelancer_id = ?)"
                );
                $canReview->execute([$projectId, (int)$user['id'], (int)$user['id']]);
                $allowed = (bool) $canReview->fetch();
            }
            if ($allowed) {
                try {
                    $stmt = db()->prepare(
                        "INSERT INTO reviews (project_id, reviewer_id, reviewee_id, rating, feedback)
                         VALUES (?, ?, ?, ?, ?)"
                    );
                    $stmt->execute([$projectId, (int)$user['id'], $revieweeId, $rating, $feedback]);
                    $avgStmt = db()->prepare('UPDATE users SET avg_rating = (SELECT COALESCE(AVG(rating),0) FROM reviews WHERE reviewee_id = ?) WHERE id = ?');
                    $avgStmt->execute([$revieweeId, $revieweeId]);
                    $success = 'Review submitted.';
                } catch (Throwable $e) {
                    $error = 'You already reviewed this user for this project or invalid review.';
                }
            } else {
                $error = 'You cannot review this project.';
            }
        }
    }
}

$projectStmt = db()->prepare(
    "SELECT p.*, u.name AS client_name, u.id AS client_id
     FROM projects p
     JOIN users u ON u.id = p.user_id
     WHERE p.id = ?"
);
$projectStmt->execute([$projectId]);
$project = $projectStmt->fetch();
if (!$project) {
    http_response_code(404);
    echo 'Project not found';
    exit;
}

$bidsStmt = db()->prepare(
    "SELECT b.*, u.name AS freelancer_name, u.avg_rating
     FROM bids b
     JOIN users u ON u.id = b.freelancer_id
     WHERE b.project_id = ?
     ORDER BY b.created_at ASC"
);
$bidsStmt->execute([$projectId]);
$bids = $bidsStmt->fetchAll();

$milestonesStmt = db()->prepare('SELECT * FROM milestones WHERE project_id = ? ORDER BY id ASC');
$milestonesStmt->execute([$projectId]);
$milestones = $milestonesStmt->fetchAll();

$reviewsStmt = db()->prepare(
    "SELECT r.*, u.name AS reviewer_name
     FROM reviews r
     JOIN users u ON u.id = r.reviewer_id
     WHERE r.project_id = ?
     ORDER BY r.created_at DESC"
);
$reviewsStmt->execute([$projectId]);
$reviews = $reviewsStmt->fetchAll();

$paymentConfirmation = fetch_project_payment_confirmation($projectId);
$paymentConfirmed = project_payment_is_confirmed($paymentConfirmation);
$awaitingPaymentConfirm = $paymentConfirmation !== null && !$paymentConfirmed;
$canSubmitPaymentDetails = $user
    && can_manage_project_as_client($user, $project)
    && in_array($project['status'], ['assigned', 'in_progress'], true)
    && !empty($project['assigned_freelancer_id'])
    && !$paymentConfirmed;
$canConfirmPaymentReceived = $user
    && can_act_as_assigned_freelancer($user, $project)
    && $awaitingPaymentConfirm;
$showPaymentSection = !empty($project['assigned_freelancer_id'])
    && in_array($project['status'], ['assigned', 'in_progress', 'completed'], true)
    && (
        $canSubmitPaymentDetails
        || $paymentConfirmation
        || $canConfirmPaymentReceived
        || ($user && can_act_as_assigned_freelancer($user, $project) && !$paymentConfirmed)
        || ($user && can_manage_project_as_client($user, $project) && in_array($project['status'], ['assigned', 'in_progress'], true))
    );
$paymentFormDefaults = is_array($paymentConfirmation) ? $paymentConfirmation : [];

require_once __DIR__ . '/includes/layout.php';
$reminderLabel = project_format_reminder_display($project['reminder_at'] ?? null);
$statusLabel = ucwords(str_replace('_', ' ', (string) $project['status']));
$skillsEntries = nk_skills_parse_blob((string) ($project['skills_required'] ?? ''));
$qualLines = array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', (string) ($project['qualifications'] ?? '')) ?: [])));
if ($qualLines === [] && !empty($project['qualifications'])) {
    $qualLines = [trim((string) $project['qualifications'])];
}
?>
<div class="page-shell project-view-shell">
<article class="card project-hero">
    <div class="project-hero__head">
        <div>
            <p class="project-hero__kicker">Project details</p>
            <h2 class="project-hero__title"><?= h($project['title']) ?></h2>
        </div>
        <div class="project-hero__actions">
            <?php if ($user && can_manage_project_as_client($user, $project)): ?>
                <a class="nk-btn nk-btn--ghost" href="<?= BASE_URL ?>/edit_project.php?id=<?= (int) $project['id'] ?>">Edit Project</a>
            <?php endif; ?>
            <?php if ($user && can_access_project_chat($user, $project)): ?>
                <a class="nk-btn" href="<?= BASE_URL ?>/chat.php?project_id=<?= (int) $project['id'] ?>">Open Chat</a>
            <?php endif; ?>
        </div>
    </div>

    <ul class="project-meta">
        <li><span class="project-meta__label">Client</span><strong><?= h($project['client_name']) ?></strong></li>
        <li><span class="project-meta__label">Budget</span><strong>Rs <?= h(number_format((float) $project['budget'], 2)) ?></strong></li>
        <li><span class="project-meta__label">Status</span><span class="project-status-badge project-status-badge--<?= h((string) $project['status']) ?>"><?= h($statusLabel) ?></span></li>
        <?php if ($reminderLabel !== ''): ?>
            <li><span class="project-meta__label">Reminder</span><strong><?= h($reminderLabel) ?></strong></li>
        <?php endif; ?>
    </ul>

    <div class="project-hero__desc">
        <?= nl2br(h((string) $project['description'])) ?>
    </div>

    <?php if ($skillsEntries !== [] || $qualLines !== []): ?>
        <div class="project-brief-grid">
            <?php if ($skillsEntries !== []): ?>
                <section class="project-brief">
                    <h3>Skills Required</h3>
                    <div class="project-brief__tags project-brief__tags--skills">
                        <?php foreach ($skillsEntries as $skillEntry): ?>
                            <span class="nk-tag nk-tag--skill">
                                <strong><?= h($skillEntry['name']) ?></strong>
                                <small><?= h(nk_skills_experience_label($skillEntry)) ?></small>
                            </span>
                        <?php endforeach; ?>
                    </div>
                </section>
            <?php endif; ?>
            <?php if ($qualLines !== []): ?>
                <section class="project-brief">
                    <h3>Qualifications</h3>
                    <ul class="project-brief__list">
                        <?php foreach ($qualLines as $line): ?>
                            <li><?= h($line) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </section>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</article>

<?php if ($error): ?><p class="danger"><?= h($error) ?></p><?php endif; ?>
<?php if ($success): ?><p class="success"><?= h($success) ?></p><?php endif; ?>

<div class="project-layout">
    <div class="project-layout__main">
        <?php if ($user && can_submit_bid($user, $project)): ?>
            <section class="card project-card">
                <h3>Submit a Bid</h3>
                <form method="post">
                    <input type="hidden" name="place_bid" value="1">
                    <label>Your Bid Amount (INR)</label>
                    <input type="number" step="0.01" name="amount" required>
                    <label>Proposal</label>
                    <textarea name="proposal" rows="5" required></textarea>
                    <button type="submit">Place Bid</button>
                </form>
            </section>
        <?php endif; ?>

        <section class="card project-card">
            <h3>Bids (<?= count($bids) ?>)</h3>
            <?php foreach ($bids as $bid): ?>
                <article class="project-list-item">
                    <header class="project-list-item__head">
                        <p>
                            <strong><?= h($bid['freelancer_name']) ?></strong>
                            <span class="muted">| Rating: <?= h((string) $bid['avg_rating']) ?></span>
                        </p>
                        <p><strong>Rs <?= h(number_format((float) $bid['amount'], 2)) ?></strong> <span class="muted">| <?= h((string) $bid['status']) ?></span></p>
                    </header>
                    <p class="project-list-item__body"><?= nl2br(h((string) $bid['proposal'])) ?></p>
                    <?php if ($user && can_manage_project_as_client($user, $project) && $project['status'] === 'open'): ?>
                        <form method="post">
                            <input type="hidden" name="accept_bid" value="1">
                            <input type="hidden" name="bid_id" value="<?= (int) $bid['id'] ?>">
                            <button type="submit">Accept Bid</button>
                        </form>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>

            <?php if (!$bids): ?>
                <p class="muted">No bids yet.</p>
            <?php endif; ?>
        </section>

        <section class="card project-card">
            <h3>Milestones / Escrow</h3>
            <?php if ($user && can_manage_project_as_client($user, $project)): ?>
                <form method="post" class="row">
                    <div>
                        <label>Milestone title</label>
                        <input name="milestone_title">
                    </div>
                    <div>
                        <label>Amount</label>
                        <input name="milestone_amount" type="number" step="0.01">
                    </div>
                    <div class="project-milestone-form-action">
                        <input type="hidden" name="create_milestone" value="1">
                        <button type="submit">Create Milestone</button>
                    </div>
                </form>
            <?php endif; ?>

            <?php foreach ($milestones as $m): ?>
                <article class="project-list-item">
                    <header class="project-list-item__head">
                        <p><strong><?= h((string) $m['title']) ?></strong></p>
                        <p><strong>Rs <?= h(number_format((float) $m['amount'], 2)) ?></strong> <span class="muted">| <?= h((string) $m['status']) ?></span></p>
                    </header>
                    <?php if ($user && can_manage_project_as_client($user, $project)): ?>
                        <?php if ($m['status'] === 'pending'): ?>
                            <form method="post">
                                <input type="hidden" name="fund_milestone" value="1">
                                <input type="hidden" name="milestone_id" value="<?= (int) $m['id'] ?>">
                                <button type="submit">Fund Escrow</button>
                            </form>
                        <?php elseif ($m['status'] === 'funded'): ?>
                            <form method="post">
                                <input type="hidden" name="release_milestone" value="1">
                                <input type="hidden" name="milestone_id" value="<?= (int) $m['id'] ?>">
                                <button type="submit">Release Payment</button>
                            </form>
                        <?php endif; ?>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
            <?php if (!$milestones): ?><p class="muted">No milestones yet.</p><?php endif; ?>
        </section>

        <?php if ($user && can_act_as_assigned_freelancer($user, $project) && $project['status'] === 'assigned'): ?>
            <section class="card project-card project-action-card">
                <form method="post">
                    <input type="hidden" name="mark_in_progress" value="1">
                    <button type="submit">Start Work (In Progress)</button>
                </form>
            </section>
        <?php endif; ?>

        <?php if ($showPaymentSection): ?>
            <section class="card project-card project-payment-card">
                <h3>Payment confirmation</h3>
                <p class="muted">Before this project can complete, the client must share how payment was made. The assigned freelancer must confirm they received the funds.</p>

                <?php if ($paymentConfirmation): ?>
                    <dl class="project-payment-summary">
                        <div><dt>Payment status</dt><dd><?= h(project_payment_label('payment_status', (string) $paymentConfirmation['payment_status'])) ?></dd></div>
                        <div><dt>Method</dt><dd><?= h(project_payment_label('payment_method', (string) $paymentConfirmation['payment_method'])) ?></dd></div>
                        <div><dt>Amount</dt><dd>Rs <?= h(number_format((float) $paymentConfirmation['payment_amount'], 2)) ?></dd></div>
                        <div><dt><?= h(project_payment_label('reference_type', (string) $paymentConfirmation['reference_type'])) ?></dt><dd><?= h((string) $paymentConfirmation['reference_number']) ?></dd></div>
                        <?php if (!empty($paymentConfirmation['notes'])): ?>
                            <div class="project-payment-summary__full"><dt>Notes</dt><dd><?= nl2br(h((string) $paymentConfirmation['notes'])) ?></dd></div>
                        <?php endif; ?>
                        <div><dt>Submitted</dt><dd><?= h((string) $paymentConfirmation['client_submitted_at']) ?></dd></div>
                        <?php if ($paymentConfirmed): ?>
                            <div><dt>Confirmed</dt><dd><?= h((string) $paymentConfirmation['freelancer_confirmed_at']) ?></dd></div>
                        <?php endif; ?>
                    </dl>
                <?php endif; ?>

                <?php if ($canSubmitPaymentDetails): ?>
                    <form method="post" class="project-payment-form">
                        <input type="hidden" name="submit_payment_confirmation" value="1">
                        <p class="muted"><?= $paymentConfirmation ? 'Update payment details (freelancer has not confirmed yet).' : 'Submit payment details for the freelancer to verify.' ?></p>
                        <div class="row">
                            <div>
                                <label for="payment_status">Payment status</label>
                                <select name="payment_status" id="payment_status" required>
                                    <?php foreach (project_payment_status_options() as $value => $label): ?>
                                        <option value="<?= h($value) ?>" <?= ($paymentFormDefaults['payment_status'] ?? '') === $value ? 'selected' : '' ?>><?= h($label) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div>
                                <label for="payment_method">Payment method</label>
                                <select name="payment_method" id="payment_method" required>
                                    <?php foreach (project_payment_method_options() as $value => $label): ?>
                                        <option value="<?= h($value) ?>" <?= ($paymentFormDefaults['payment_method'] ?? '') === $value ? 'selected' : '' ?>><?= h($label) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div>
                                <label for="payment_amount">Payment amount (INR)</label>
                                <input type="number" step="0.01" min="0.01" name="payment_amount" id="payment_amount" required value="<?= $paymentFormDefaults !== [] ? h((string) $paymentFormDefaults['payment_amount']) : h((string) $project['budget']) ?>">
                            </div>
                        </div>
                        <div class="row">
                            <div>
                                <label for="reference_type">Reference type</label>
                                <select name="reference_type" id="reference_type" required>
                                    <?php foreach (project_payment_reference_type_options() as $value => $label): ?>
                                        <option value="<?= h($value) ?>" <?= ($paymentFormDefaults['reference_type'] ?? 'utr') === $value ? 'selected' : '' ?>><?= h($label) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div>
                                <label for="reference_number">Transaction / invoice / UTR number</label>
                                <input type="text" name="reference_number" id="reference_number" maxlength="150" required value="<?= h((string) ($paymentFormDefaults['reference_number'] ?? '')) ?>" placeholder="e.g. UTR123456789012">
                            </div>
                        </div>
                        <label for="payment_notes">Additional notes (optional)</label>
                        <textarea name="payment_notes" id="payment_notes" rows="3" placeholder="Bank name, payment date, payer account last digits, etc."><?= h((string) ($paymentFormDefaults['notes'] ?? '')) ?></textarea>
                        <button type="submit"><?= $paymentConfirmation ? 'Update payment details' : 'Submit payment details to freelancer' ?></button>
                    </form>
                <?php elseif ($awaitingPaymentConfirm && $user && can_manage_project_as_client($user, $project)): ?>
                    <p class="muted">Waiting for the freelancer to confirm they received this payment.</p>
                <?php endif; ?>

                <?php if ($canConfirmPaymentReceived): ?>
                    <form method="post" class="project-payment-confirm-form">
                        <input type="hidden" name="confirm_payment_received" value="1">
                        <p>Review the payment details above. Confirm only if the amount has reached your account.</p>
                        <button type="submit">I received the payment — complete project</button>
                    </form>
                <?php elseif ($user && can_act_as_assigned_freelancer($user, $project) && in_array($project['status'], ['assigned', 'in_progress'], true) && !$paymentConfirmation): ?>
                    <p class="muted">The client has not submitted payment details yet. Ask them to complete the form above before you can finish this project.</p>
                <?php endif; ?>
            </section>
        <?php endif; ?>

        <?php if ($user && $project['status'] === 'completed'): ?>
    <?php
    $defaultReviewee = 0;
    if ($user['role'] === 'client' && !empty($project['assigned_freelancer_id'])) {
        $defaultReviewee = (int) $project['assigned_freelancer_id'];
    } elseif ($user['role'] === 'freelancer') {
        $defaultReviewee = (int) $project['client_id'];
    } elseif (is_platform_staff($user) && !empty($project['assigned_freelancer_id'])) {
        $defaultReviewee = (int) $project['assigned_freelancer_id'];
    }
    ?>
            <?php if (is_platform_staff($user) && !empty($project['assigned_freelancer_id'])): ?>
                <section class="card project-card">
            <h3>Leave review (platform)</h3>
            <p class="muted">You can review the client or the assigned freelancer. Submit once per person you are reviewing (same as client/freelancer flow).</p>
            <form method="post">
                <input type="hidden" name="submit_review" value="1">
                <label>Reviewing</label>
                <select name="reviewee_id" required>
                    <option value="<?= (int) $project['assigned_freelancer_id'] ?>">Freelancer (assigned)</option>
                    <option value="<?= (int) $project['client_id'] ?>">Client</option>
                </select>
                <label>Rating</label>
                <select name="rating" required>
                    <option value="5">5</option>
                    <option value="4">4</option>
                    <option value="3">3</option>
                    <option value="2">2</option>
                    <option value="1">1</option>
                </select>
                <label>Feedback</label>
                <textarea name="feedback" rows="3"></textarea>
                <button type="submit">Submit review</button>
            </form>
        </section>
            <?php elseif ($defaultReviewee > 0): ?>
                <section class="card project-card">
            <h3>Leave review</h3>
            <form method="post">
                <input type="hidden" name="submit_review" value="1">
                <input type="hidden" name="reviewee_id" value="<?= $defaultReviewee ?>">
                <label>Rating</label>
                <select name="rating" required>
                    <option value="5">5</option>
                    <option value="4">4</option>
                    <option value="3">3</option>
                    <option value="2">2</option>
                    <option value="1">1</option>
                </select>
                <label>Feedback</label>
                <textarea name="feedback" rows="3"></textarea>
                <button type="submit">Submit review</button>
            </form>
        </section>
            <?php endif; ?>
        <?php endif; ?>

        <section class="card project-card">
            <h3>Reviews</h3>
            <?php foreach ($reviews as $r): ?>
                <article class="project-review-item">
                    <p><strong><?= h((string) $r['reviewer_name']) ?></strong> rated <strong><?= (int) $r['rating'] ?>/5</strong></p>
                    <?php if (!empty($r['feedback'])): ?>
                        <p class="muted"><?= h((string) $r['feedback']) ?></p>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
            <?php if (!$reviews): ?><p class="muted">No reviews yet.</p><?php endif; ?>
        </section>
    </div>

    <aside class="project-layout__side">
        <section class="card project-side-card">
            <h3>Quick Snapshot</h3>
            <ul class="project-side-list">
                <li><span>Total bids</span><strong><?= (int) count($bids) ?></strong></li>
                <li><span>Milestones</span><strong><?= (int) count($milestones) ?></strong></li>
                <li><span>Reviews</span><strong><?= (int) count($reviews) ?></strong></li>
                <li><span>Current status</span><strong><?= h($statusLabel) ?></strong></li>
            </ul>
            <?php if ($user && can_access_project_chat($user, $project)): ?>
                <a class="nk-btn" href="<?= BASE_URL ?>/chat.php?project_id=<?= (int) $project['id'] ?>">Continue Conversation</a>
            <?php endif; ?>
        </section>
    </aside>
</div>
</div>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>

