<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';

$projectId = (int)($_GET['id'] ?? 0);
if ($projectId <= 0) {
    http_response_code(404);
    echo 'Project not found';
    exit;
}

$user = current_user();
$error = '';
$success = '';

$ctxProject = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $user) {
    if ($projectId > 0) {
        $cStmt = db()->prepare('SELECT p.*, u.id AS client_id FROM projects p JOIN users u ON u.id = p.user_id WHERE p.id = ?');
        $cStmt->execute([$projectId]);
        $ctxProject = $cStmt->fetch();
    }

    if (isset($_POST['place_bid']) && $ctxProject && can_submit_bid($user, $ctxProject)) {
        $amount = (float)($_POST['amount'] ?? 0);
        $proposal = trim($_POST['proposal'] ?? '');
        if ($amount <= 0 || $proposal === '') {
            $error = 'Enter valid amount and proposal.';
        } else {
            try {
                $stmt = db()->prepare('INSERT INTO bids (project_id, freelancer_id, amount, proposal) VALUES (?, ?, ?, ?)');
                $stmt->execute([$projectId, (int)$user['id'], $amount, $proposal]);
                $success = 'Bid submitted successfully.';
            } catch (Throwable $e) {
                $error = 'You have already bid on this project.';
            }
        }
    }

    if (isset($_POST['accept_bid']) && $ctxProject && can_manage_project_as_client($user, $ctxProject)) {
        $bidId = (int)($_POST['bid_id'] ?? 0);
        db()->beginTransaction();
        try {
            $projectStmt = db()->prepare('SELECT user_id, status FROM projects WHERE id = ? FOR UPDATE');
            $projectStmt->execute([$projectId]);
            $project = $projectStmt->fetch();
            if (!$project || $project['status'] !== 'open' || !can_manage_project_as_client(
                $user,
                [
                    'user_id' => $project['user_id'],
                    'client_id' => $project['user_id'],
                ]
            )) {
                throw new RuntimeException('Invalid project state.');
            }

            $bidStmt = db()->prepare('SELECT freelancer_id FROM bids WHERE id = ? AND project_id = ?');
            $bidStmt->execute([$bidId, $projectId]);
            $selectedBid = $bidStmt->fetch();
            if (!$selectedBid) {
                throw new RuntimeException('Bid not found.');
            }

            $accept = db()->prepare("UPDATE bids SET status = 'accepted' WHERE id = ?");
            $accept->execute([$bidId]);
            $rejectOthers = db()->prepare("UPDATE bids SET status = 'rejected' WHERE project_id = ? AND id <> ?");
            $rejectOthers->execute([$projectId, $bidId]);

            $assign = db()->prepare("UPDATE projects SET status = 'assigned', assigned_freelancer_id = ? WHERE id = ?");
            $assign->execute([(int)$selectedBid['freelancer_id'], $projectId]);

            db()->commit();
            $success = 'Bid accepted and project assigned.';
        } catch (Throwable $e) {
            db()->rollBack();
            $error = 'Could not accept bid.';
        }
    }

    if (isset($_POST['mark_in_progress']) && $ctxProject && can_act_as_assigned_freelancer($user, $ctxProject)) {
        if (is_platform_staff($user)) {
            $stmt = db()->prepare(
                "UPDATE projects
                 SET status = 'in_progress'
                 WHERE id = ? AND status = 'assigned' AND assigned_freelancer_id IS NOT NULL"
            );
            $stmt->execute([$projectId]);
        } else {
            $stmt = db()->prepare(
                "UPDATE projects
                 SET status = 'in_progress'
                 WHERE id = ? AND assigned_freelancer_id = ? AND status = 'assigned'"
            );
            $stmt->execute([$projectId, (int)$user['id']]);
        }
        if ($stmt->rowCount() > 0) {
            $success = 'Project moved to in progress.';
        } else {
            $error = 'Could not update project status.';
        }
    }

    if (isset($_POST['create_milestone']) && $ctxProject && can_manage_project_as_client($user, $ctxProject)) {
        $title = trim($_POST['milestone_title'] ?? '');
        $amount = (float)($_POST['milestone_amount'] ?? 0);
        if ($title === '' || $amount <= 0) {
            $error = 'Milestone title and amount are required.';
        } else {
            $ownerId = (int) $ctxProject['user_id'];
            $stmt = db()->prepare(
                "INSERT INTO milestones (project_id, title, amount)
                 SELECT id, ?, ?
                 FROM projects
                 WHERE id = ? AND user_id = ?"
            );
            $stmt->execute([$title, $amount, $projectId, $ownerId]);
            if ($stmt->rowCount() > 0) {
                $success = 'Milestone created.';
            } else {
                $error = 'Could not create milestone.';
            }
        }
    }

    if (isset($_POST['fund_milestone']) && $ctxProject && can_manage_project_as_client($user, $ctxProject)) {
        $milestoneId = (int)($_POST['milestone_id'] ?? 0);
        db()->beginTransaction();
        try {
            $m = db()->prepare(
                "SELECT m.id, m.amount, m.status, p.user_id, p.assigned_freelancer_id
                 FROM milestones m
                 JOIN projects p ON p.id = m.project_id
                 WHERE m.id = ? AND m.project_id = ?
                 FOR UPDATE"
            );
            $m->execute([$milestoneId, $projectId]);
            $milestone = $m->fetch();
            if (!$milestone) {
                throw new RuntimeException('Invalid milestone state.');
            }
            if (!can_manage_project_as_client(
                $user,
                [
                    'user_id' => $milestone['user_id'],
                    'client_id' => $milestone['user_id'],
                ]
            ) || $milestone['status'] !== 'pending') {
                throw new RuntimeException('Invalid milestone state.');
            }
            if (empty($milestone['assigned_freelancer_id'])) {
                throw new RuntimeException('Assign a freelancer before funding.');
            }

            $payerId = (int) $milestone['user_id'];
            $walletStmt = db()->prepare('SELECT wallet_balance FROM users WHERE id = ? FOR UPDATE');
            $walletStmt->execute([$payerId]);
            $wallet = (float)($walletStmt->fetch()['wallet_balance'] ?? 0);
            $amount = (float)$milestone['amount'];
            if ($wallet < $amount) {
                throw new RuntimeException('Low wallet balance.');
            }

            $deduct = db()->prepare('UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?');
            $deduct->execute([$amount, $payerId]);

            $mark = db()->prepare("UPDATE milestones SET status = 'funded' WHERE id = ?");
            $mark->execute([$milestoneId]);

            $pay = db()->prepare(
                "INSERT INTO payments (project_id, payer_id, payee_id, amount, milestone_id, status, gateway)
                 VALUES (?, ?, ?, ?, ?, 'escrowed', 'wallet')"
            );
            $pay->execute([$projectId, $payerId, (int)$milestone['assigned_freelancer_id'], $amount, $milestoneId]);

            db()->commit();
            $success = 'Milestone funded into escrow.';
        } catch (Throwable $e) {
            db()->rollBack();
            $error = $e->getMessage() === 'Low wallet balance.' ? 'Wallet balance is low. Add funds from dashboard.' : 'Could not fund milestone.';
        }
    }

    if (isset($_POST['release_milestone']) && $ctxProject && can_manage_project_as_client($user, $ctxProject)) {
        $milestoneId = (int)($_POST['milestone_id'] ?? 0);
        db()->beginTransaction();
        try {
            $m = db()->prepare(
                "SELECT m.id, m.amount, m.status, p.user_id, p.assigned_freelancer_id
                 FROM milestones m
                 JOIN projects p ON p.id = m.project_id
                 WHERE m.id = ? AND m.project_id = ?
                 FOR UPDATE"
            );
            $m->execute([$milestoneId, $projectId]);
            $milestone = $m->fetch();
            if (
                !$milestone
                || $milestone['status'] !== 'funded'
                || !can_manage_project_as_client(
                    $user,
                    [
                        'user_id' => $milestone['user_id'],
                        'client_id' => $milestone['user_id'],
                    ]
                )
            ) {
                throw new RuntimeException('Invalid release state.');
            }

            $mark = db()->prepare("UPDATE milestones SET status = 'released' WHERE id = ?");
            $mark->execute([$milestoneId]);

            $pay = db()->prepare(
                "UPDATE payments
                 SET status = 'released'
                 WHERE milestone_id = ? AND project_id = ? AND status = 'escrowed'"
            );
            $pay->execute([$milestoneId, $projectId]);

            $credit = db()->prepare('UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?');
            $credit->execute([(float)$milestone['amount'], (int)$milestone['assigned_freelancer_id']]);

            db()->commit();
            $success = 'Milestone payment released to freelancer.';
        } catch (Throwable $e) {
            db()->rollBack();
            $error = 'Could not release milestone.';
        }
    }

    if (isset($_POST['mark_completed']) && $ctxProject && can_manage_project_as_client($user, $ctxProject)) {
        $clientOwner = (int) $ctxProject['user_id'];
        $stmt = db()->prepare(
            "UPDATE projects
             SET status = 'completed'
             WHERE id = ? AND user_id = ? AND status IN ('assigned', 'in_progress')"
        );
        $stmt->execute([$projectId, $clientOwner]);
        if ($stmt->rowCount() > 0) {
            $success = 'Project marked as completed.';
        } else {
            $error = 'Could not mark completed.';
        }
    }

    if (isset($_POST['submit_review']) && $ctxProject) {
        $rating = (int)($_POST['rating'] ?? 0);
        $feedback = trim($_POST['feedback'] ?? '');
        $revieweeId = (int)($_POST['reviewee_id'] ?? 0);
        if ($rating < 1 || $rating > 5 || $revieweeId <= 0) {
            $error = 'Invalid review values.';
        } else {
            $allowed = false;
            if (is_platform_staff($user) && $ctxProject['status'] === 'completed') {
                $cid = (int) $ctxProject['client_id'];
                $fid = (int) ($ctxProject['assigned_freelancer_id'] ?? 0);
                $allowed = in_array($revieweeId, array_filter([$cid, $fid]), true);
            } else {
                $canReview = db()->prepare(
                    "SELECT id
                     FROM projects
                     WHERE id = ?
                     AND status = 'completed'
                     AND (user_id = ? OR assigned_freelancer_id = ?)"
                );
                $canReview->execute([$projectId, (int)$user['id'], (int)$user['id']]);
                $allowed = (bool) $canReview->fetch();
            }
            if ($allowed) {
                try {
                    $stmt = db()->prepare(
                        "INSERT INTO reviews (project_id, reviewer_id, reviewee_id, rating, feedback)
                         VALUES (?, ?, ?, ?, ?)"
                    );
                    $stmt->execute([$projectId, (int)$user['id'], $revieweeId, $rating, $feedback]);
                    $avgStmt = db()->prepare('UPDATE users SET avg_rating = (SELECT COALESCE(AVG(rating),0) FROM reviews WHERE reviewee_id = ?) WHERE id = ?');
                    $avgStmt->execute([$revieweeId, $revieweeId]);
                    $success = 'Review submitted.';
                } catch (Throwable $e) {
                    $error = 'You already reviewed this user for this project or invalid review.';
                }
            } else {
                $error = 'You cannot review this project.';
            }
        }
    }
}

$projectStmt = db()->prepare(
    "SELECT p.*, u.name AS client_name, u.id AS client_id
     FROM projects p
     JOIN users u ON u.id = p.user_id
     WHERE p.id = ?"
);
$projectStmt->execute([$projectId]);
$project = $projectStmt->fetch();
if (!$project) {
    http_response_code(404);
    echo 'Project not found';
    exit;
}

$bidsStmt = db()->prepare(
    "SELECT b.*, u.name AS freelancer_name, u.avg_rating
     FROM bids b
     JOIN users u ON u.id = b.freelancer_id
     WHERE b.project_id = ?
     ORDER BY b.created_at ASC"
);
$bidsStmt->execute([$projectId]);
$bids = $bidsStmt->fetchAll();

$milestonesStmt = db()->prepare('SELECT * FROM milestones WHERE project_id = ? ORDER BY id ASC');
$milestonesStmt->execute([$projectId]);
$milestones = $milestonesStmt->fetchAll();

$reviewsStmt = db()->prepare(
    "SELECT r.*, u.name AS reviewer_name
     FROM reviews r
     JOIN users u ON u.id = r.reviewer_id
     WHERE r.project_id = ?
     ORDER BY r.created_at DESC"
);
$reviewsStmt->execute([$projectId]);
$reviews = $reviewsStmt->fetchAll();

require_once __DIR__ . '/includes/layout.php';
?>
<article class="card">
    <h2><?= h($project['title']) ?></h2>
    <p class="muted">Client: <?= h($project['client_name']) ?> | Status: <?= h($project['status']) ?> | Budget: Rs <?= h(number_format((float)$project['budget'], 2)) ?></p>
    <p><?= nl2br(h($project['description'])) ?></p>
    <?php if ($user): ?>
        <p><a href="<?= BASE_URL ?>/chat.php?project_id=<?= (int)$project['id'] ?>">Open project chat</a></p>
    <?php endif; ?>
</article>

<?php if ($error): ?><p class="danger"><?= h($error) ?></p><?php endif; ?>
<?php if ($success): ?><p class="success"><?= h($success) ?></p><?php endif; ?>

<?php if ($user && can_submit_bid($user, $project)): ?>
    <section class="card">
        <h3>Submit a Bid</h3>
        <form method="post">
            <input type="hidden" name="place_bid" value="1">
            <label>Your Bid Amount (INR)</label>
            <input type="number" step="0.01" name="amount" required>
            <label>Proposal</label>
            <textarea name="proposal" rows="5" required></textarea>
            <button type="submit">Place Bid</button>
        </form>
    </section>
<?php endif; ?>

<section class="card">
    <h3>Bids (<?= count($bids) ?>)</h3>
    <?php foreach ($bids as $bid): ?>
        <div style="padding:10px 0; border-bottom:1px solid #e5e7eb;">
            <p><strong><?= h($bid['freelancer_name']) ?></strong> | Rating: <?= h((string)$bid['avg_rating']) ?> | Rs <?= h(number_format((float)$bid['amount'], 2)) ?> | <?= h($bid['status']) ?></p>
            <p><?= nl2br(h($bid['proposal'])) ?></p>
            <?php if ($user && can_manage_project_as_client($user, $project) && $project['status'] === 'open'): ?>
                <form method="post">
                    <input type="hidden" name="accept_bid" value="1">
                    <input type="hidden" name="bid_id" value="<?= (int)$bid['id'] ?>">
                    <button type="submit">Accept Bid</button>
                </form>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>

    <?php if (!$bids): ?>
        <p class="muted">No bids yet.</p>
    <?php endif; ?>
</section>

<section class="card">
    <h3>Milestones / Escrow</h3>
    <?php if ($user && can_manage_project_as_client($user, $project)): ?>
        <form method="post" class="row">
            <div>
                <label>Milestone title</label>
                <input name="milestone_title">
            </div>
            <div>
                <label>Amount</label>
                <input name="milestone_amount" type="number" step="0.01">
            </div>
            <div style="grid-column: 1 / -1;">
                <input type="hidden" name="create_milestone" value="1">
                <button type="submit">Create Milestone</button>
            </div>
        </form>
    <?php endif; ?>

    <?php foreach ($milestones as $m): ?>
        <div style="padding:10px 0; border-bottom:1px solid #e5e7eb;">
            <p><strong><?= h($m['title']) ?></strong> | Rs <?= h(number_format((float)$m['amount'], 2)) ?> | <?= h($m['status']) ?></p>
            <?php if ($user && can_manage_project_as_client($user, $project)): ?>
                <?php if ($m['status'] === 'pending'): ?>
                    <form method="post" style="display:inline-block;">
                        <input type="hidden" name="fund_milestone" value="1">
                        <input type="hidden" name="milestone_id" value="<?= (int)$m['id'] ?>">
                        <button type="submit">Fund Escrow</button>
                    </form>
                <?php elseif ($m['status'] === 'funded'): ?>
                    <form method="post" style="display:inline-block;">
                        <input type="hidden" name="release_milestone" value="1">
                        <input type="hidden" name="milestone_id" value="<?= (int)$m['id'] ?>">
                        <button type="submit">Release Payment</button>
                    </form>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
    <?php if (!$milestones): ?><p class="muted">No milestones yet.</p><?php endif; ?>
</section>

<?php if ($user && can_act_as_assigned_freelancer($user, $project) && $project['status'] === 'assigned'): ?>
    <section class="card">
        <form method="post">
            <input type="hidden" name="mark_in_progress" value="1">
            <button type="submit">Start Work (In Progress)</button>
        </form>
    </section>
<?php endif; ?>

<?php if ($user && can_manage_project_as_client($user, $project) && in_array($project['status'], ['assigned', 'in_progress'], true)): ?>
    <section class="card">
        <form method="post">
            <input type="hidden" name="mark_completed" value="1">
            <button type="submit">Mark Project Completed</button>
        </form>
    </section>
<?php endif; ?>

<?php if ($user && $project['status'] === 'completed'): ?>
    <?php
    $defaultReviewee = 0;
    if ($user['role'] === 'client' && !empty($project['assigned_freelancer_id'])) {
        $defaultReviewee = (int) $project['assigned_freelancer_id'];
    } elseif ($user['role'] === 'freelancer') {
        $defaultReviewee = (int) $project['client_id'];
    } elseif (is_platform_staff($user) && !empty($project['assigned_freelancer_id'])) {
        $defaultReviewee = (int) $project['assigned_freelancer_id'];
    }
    ?>
    <?php if (is_platform_staff($user) && !empty($project['assigned_freelancer_id'])): ?>
        <section class="card">
            <h3>Leave review (platform)</h3>
            <p class="muted">You can review the client or the assigned freelancer. Submit once per person you are reviewing (same as client/freelancer flow).</p>
            <form method="post">
                <input type="hidden" name="submit_review" value="1">
                <label>Reviewing</label>
                <select name="reviewee_id" required>
                    <option value="<?= (int) $project['assigned_freelancer_id'] ?>">Freelancer (assigned)</option>
                    <option value="<?= (int) $project['client_id'] ?>">Client</option>
                </select>
                <label>Rating</label>
                <select name="rating" required>
                    <option value="5">5</option>
                    <option value="4">4</option>
                    <option value="3">3</option>
                    <option value="2">2</option>
                    <option value="1">1</option>
                </select>
                <label>Feedback</label>
                <textarea name="feedback" rows="3"></textarea>
                <button type="submit">Submit review</button>
            </form>
        </section>
    <?php elseif ($defaultReviewee > 0): ?>
        <section class="card">
            <h3>Leave review</h3>
            <form method="post">
                <input type="hidden" name="submit_review" value="1">
                <input type="hidden" name="reviewee_id" value="<?= $defaultReviewee ?>">
                <label>Rating</label>
                <select name="rating" required>
                    <option value="5">5</option>
                    <option value="4">4</option>
                    <option value="3">3</option>
                    <option value="2">2</option>
                    <option value="1">1</option>
                </select>
                <label>Feedback</label>
                <textarea name="feedback" rows="3"></textarea>
                <button type="submit">Submit review</button>
            </form>
        </section>
    <?php endif; ?>
<?php endif; ?>

<section class="card">
    <h3>Reviews</h3>
    <?php foreach ($reviews as $r): ?>
        <p><strong><?= h($r['reviewer_name']) ?></strong> rated <?= (int)$r['rating'] ?>/5 - <?= h($r['feedback'] ?? '') ?></p>
    <?php endforeach; ?>
    <?php if (!$reviews): ?><p class="muted">No reviews yet.</p><?php endif; ?>
</section>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>

