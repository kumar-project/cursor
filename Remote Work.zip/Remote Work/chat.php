<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';

require_login();
$user = current_user();
$projectId = (int)($_GET['project_id'] ?? 0);

$stmt = db()->prepare('SELECT id, title, user_id, assigned_freelancer_id FROM projects WHERE id = ?');
$stmt->execute([$projectId]);
$project = $stmt->fetch();
if (
    !$project ||
    (
        (int)$project['user_id'] !== (int)$user['id'] &&
        (int)$project['assigned_freelancer_id'] !== (int)$user['id'] &&
        !is_platform_staff($user)
    )
) {
    http_response_code(403);
    echo 'Forbidden';
    exit;
}

require_once __DIR__ . '/includes/layout.php';
?>
<section class="card">
    <h2>Project Chat: <?= h($project['title']) ?></h2>
    <p class="muted">Messages auto-refresh every 3 seconds.</p>
    <div id="chat-box" style="height:300px; overflow:auto; border:1px solid #e5e7eb; padding:10px; border-radius:6px; background:#fff;"></div>
</section>

<section class="card">
    <form id="chat-form" enctype="multipart/form-data">
        <label>Message</label>
        <textarea name="message" rows="3" required></textarea>
        <label>Attach file (optional)</label>
        <input type="file" name="chat_file" accept=".pdf,.docx,.jpg,.png,.txt">
        <button type="submit">Send</button>
    </form>
</section>

<script>
const projectId = <?= (int)$projectId ?>;
const chatBox = document.getElementById('chat-box');
const chatForm = document.getElementById('chat-form');

async function loadMessages() {
    const res = await fetch(`<?= BASE_URL ?>/chat_fetch.php?project_id=${projectId}`);
    if (!res.ok) return;
    const data = await res.json();
    chatBox.innerHTML = data.map(item => {
        const fileLink = item.file_url ? ` | <a href="${item.file_url}" target="_blank">file</a>` : '';
        return `<p><strong>${item.sender_name}</strong>: ${item.message}${fileLink}<br><small>${item.created_at}</small></p>`;
    }).join('');
    chatBox.scrollTop = chatBox.scrollHeight;
}

chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(chatForm);
    formData.append('project_id', projectId);
    const res = await fetch('<?= BASE_URL ?>/chat_send.php', {
        method: 'POST',
        body: formData
    });
    if (res.ok) {
        chatForm.reset();
        loadMessages();
    } else {
        alert('Message failed.');
    }
});

loadMessages();
setInterval(loadMessages, 3000);
</script>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>

