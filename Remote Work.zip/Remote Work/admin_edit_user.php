<?php
declare(strict_types=1);

$wideMain = true;
$page_title = 'Edit user';
$nk_admin_nav = 'data';

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/admin_helpers.php';

require_privileged();

$id = (int) ($_GET['id'] ?? $_POST['user_id'] ?? 0);
if ($id <= 0) {
    $_SESSION['admin_data_flash_error'] = 'Invalid user.';
    header('Location: ' . BASE_URL . '/admin_data.php');
    exit;
}

$stmt = db()->prepare(
    'SELECT id, name, mobile, email, role, password, client_approved FROM users WHERE id = ?'
);
$stmt->execute([$id]);
$userRow = $stmt->fetch();
if (!$userRow || !in_array((string) ($userRow['role'] ?? ''), ['client', 'freelancer'], true)) {
    $_SESSION['admin_data_flash_error'] = 'That user cannot be edited here.';
    header('Location: ' . BASE_URL . '/admin_data.php');
    exit;
}

$superAdmin = is_super_admin(current_user());
$error = '';
$values = [
    'name' => trim((string) ($userRow['name'] ?? '')),
    'mobile' => trim((string) preg_replace('/\s+/', ' ', trim((string) ($userRow['mobile'] ?? '')))),
    'email' => trim((string) ($userRow['email'] ?? '')),
    'client_approved' => (int) ($userRow['client_approved'] ?? 0) === 1,
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_user'])) {
    $values['name'] = trim((string) ($_POST['name'] ?? ''));
    $values['mobile'] = trim((string) preg_replace('/\s+/', ' ', trim((string) ($_POST['mobile'] ?? ''))));
    $values['email'] = trim((string) ($_POST['email'] ?? ''));
    $newPassword = isset($_POST['new_password']) && is_string($_POST['new_password']) ? $_POST['new_password'] : '';
    $role = (string) ($userRow['role'] ?? '');

    $mobileDigits = preg_replace('/\D/', '', $values['mobile']) ?? '';
    if ($values['name'] === '' || $values['email'] === '') {
        $error = 'Name and email are required.';
    } elseif (strlen($values['name']) > 100) {
        $error = 'Name is too long.';
    } elseif (strlen($values['mobile']) > 32) {
        $error = 'Mobile number is too long.';
    } elseif ($values['mobile'] !== '' && (strlen($mobileDigits) < 8 || strlen($mobileDigits) > 15)) {
        $error = 'Enter a valid mobile number (8–15 digits), or leave blank for legacy accounts.';
    } elseif (!filter_var($values['email'], FILTER_VALIDATE_EMAIL)) {
        $error = 'Enter a valid email address.';
    } elseif ($newPassword !== '' && strlen($newPassword) < 6) {
        $error = 'New password must be at least 6 characters, or leave blank to keep the current password.';
    } else {
        $dup = db()->prepare('SELECT id FROM users WHERE LOWER(email) = LOWER(?) AND id <> ?');
        $dup->execute([$values['email'], $id]);
        if ($dup->fetch()) {
            $error = 'That email is already used by another account.';
        } else {
            $clientApprovedVal = (int) ($userRow['client_approved'] ?? 0);
            if ($role === 'client' && $superAdmin) {
                $clientApprovedVal = isset($_POST['client_approved']) && (string) $_POST['client_approved'] === '1' ? 1 : 0;
            }

            $mobileSave = $values['mobile'] === '' ? null : $values['mobile'];

            try {
                if ($newPassword !== '') {
                    $hash = password_hash($newPassword, PASSWORD_DEFAULT);
                    if ($role === 'client' && $superAdmin) {
                        $upd = db()->prepare(
                            'UPDATE users SET name = ?, mobile = ?, email = ?, password = ?, client_approved = ? WHERE id = ? AND role = ?'
                        );
                        $upd->execute([
                            $values['name'],
                            $mobileSave,
                            $values['email'],
                            $hash,
                            $clientApprovedVal,
                            $id,
                            $role,
                        ]);
                    } else {
                        $upd = db()->prepare(
                            'UPDATE users SET name = ?, mobile = ?, email = ?, password = ? WHERE id = ? AND role = ?'
                        );
                        $upd->execute([
                            $values['name'],
                            $mobileSave,
                            $values['email'],
                            $hash,
                            $id,
                            $role,
                        ]);
                    }
                } elseif ($role === 'client' && $superAdmin) {
                    $upd = db()->prepare(
                        'UPDATE users SET name = ?, mobile = ?, email = ?, client_approved = ? WHERE id = ? AND role = ?'
                    );
                    $upd->execute([
                        $values['name'],
                        $mobileSave,
                        $values['email'],
                        $clientApprovedVal,
                        $id,
                        $role,
                    ]);
                } else {
                    $upd = db()->prepare(
                        'UPDATE users SET name = ?, mobile = ?, email = ? WHERE id = ? AND role = ?'
                    );
                    $upd->execute([
                        $values['name'],
                        $mobileSave,
                        $values['email'],
                        $id,
                        $role,
                    ]);
                }
                $_SESSION['admin_data_flash'] = $values['name'] . ' (' . $role . ') updated.';
                header('Location: ' . BASE_URL . '/admin_data.php');
                exit;
            } catch (Throwable) {
                $error = 'Could not save changes.';
            }
        }
    }
}

require_once __DIR__ . '/includes/layout.php';
$roleLabel = (string) ($userRow['role'] ?? '');
?>
<div class="page-shell">
    <?php require __DIR__ . '/includes/partials/admin_subnav.php'; ?>

    <section class="card" style="max-width: 520px;">
        <h2>Edit <?= h(ucfirst($roleLabel)) ?><?= trim((string) ($userRow['name'] ?? '')) !== '' ? ': ' . h((string) $userRow['name']) : '' ?></h2>
        <p class="muted"><a href="<?= BASE_URL ?>/admin_data.php">← Back to Users &amp; data</a></p>
        <?php if ($error): ?><p class="danger"><?= h($error) ?></p><?php endif; ?>
        <form method="post" class="login-form">
            <input type="hidden" name="user_id" value="<?= (int) $id ?>">
            <label for="eu_name">Full name</label>
            <input id="eu_name" type="text" name="name" value="<?= h($values['name']) ?>" required maxlength="100" autocomplete="name">

            <label for="eu_mobile">Mobile number</label>
            <input id="eu_mobile" type="tel" name="mobile" value="<?= h($values['mobile']) ?>" maxlength="32" autocomplete="tel" inputmode="tel" placeholder="Optional for older accounts">

            <label for="eu_email">Email</label>
            <input id="eu_email" type="email" name="email" value="<?= h($values['email']) ?>" required autocomplete="email">

            <label for="eu_pw">New password (optional)</label>
            <input id="eu_pw" type="password" name="new_password" value="" autocomplete="new-password" placeholder="Leave blank to keep current">
            <p class="muted" style="margin-top:-8px;">Minimum 6 characters if you set a new password.</p>

            <?php if ($roleLabel === 'client' && $superAdmin): ?>
                <label class="admin-edit-user__check">
                    <input type="checkbox" name="client_approved" value="1" <?= $values['client_approved'] ? ' checked' : '' ?>>
                    Client approved (can use client features)
                </label>
            <?php endif; ?>

            <button type="submit" name="save_user" value="1">Save changes</button>
        </form>
    </section>
</div>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
