<?php
declare(strict_types=1);

$wideMain = true;
$page_title = 'Blog';

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/blog_cms.php';

require_once __DIR__ . '/includes/layout.php';

$categorySlug = trim((string) ($_GET['category'] ?? ''));
$categoriesWithCounts = blog_categories_with_published_counts();
$totalPublished = blog_published_posts_count(null);
$posts = blog_posts_list_published($categorySlug !== '' ? $categorySlug : null, 5);
$activeCategoryLabel = '';
if ($categorySlug !== '') {
    foreach ($categoriesWithCounts as $cc) {
        if ($cc['slug'] === $categorySlug) {
            $activeCategoryLabel = (string) $cc['name'];
            break;
        }
    }
    if ($activeCategoryLabel === '') {
        $activeCategoryLabel = $categorySlug;
    }
}
?>
<div class="page-shell nk-blog-page">
    <header class="nk-blog-page__head">
        <h1 class="nk-blog-page__title">Blog</h1>
        <p class="nk-blog-page__lead">Ideas on remote work, proposals, and running projects without friction.</p>
        <?php if ($categorySlug !== ''): ?>
            <p class="nk-blog-page__filter-note muted">
                Showing latest posts in <strong><?= h($activeCategoryLabel) ?></strong>.
                <a href="<?= h(BASE_URL) ?>/blog.php">Clear filter</a>
            </p>
        <?php endif; ?>
    </header>

    <section class="nk-blog-page__section" aria-labelledby="blog-latest-heading">
        <h2 id="blog-latest-heading" class="nk-blog-page__section-title">Latest articles</h2>
        <p class="nk-blog-page__section-sub muted">Up to five most recent published posts<?= $categorySlug !== '' ? ' in this category' : '' ?>.</p>
        <div class="nk-blog-page__list nk-blog-page__list--latest">
            <?php if (!$posts): ?>
                <p class="muted card">No published posts yet. Check back soon.</p>
            <?php endif; ?>
            <?php foreach ($posts as $post): ?>
                <article class="nk-blog-post card nk-blog-post--summary">
                    <?php $img = blog_featured_public_url($post['featured_image_path'] ?? null); ?>
                    <?php if ($img): ?>
                        <a href="<?= h(BASE_URL) ?>/blog_post.php?id=<?= (int) $post['id'] ?>" class="nk-blog-post__image-link">
                            <img src="<?= h($img) ?>" alt="" class="nk-blog-post__featured">
                        </a>
                    <?php endif; ?>
                    <div class="nk-blog-post__body">
                        <?php if (!empty($post['published_at'])): ?>
                            <p class="nk-blog-post__meta">
                                <time datetime="<?= h((string) $post['published_at']) ?>"><?= h((string) $post['published_at']) ?></time>
                            </p>
                        <?php endif; ?>
                        <h3 class="nk-blog-post__title">
                            <a href="<?= h(BASE_URL) ?>/blog_post.php?id=<?= (int) $post['id'] ?>"><?= h((string) $post['title']) ?></a>
                        </h3>
                        <p class="nk-blog-post__blurb"><?= h(blog_format_excerpt($post)) ?></p>
                        <a class="nk-blog-post__readmore" href="<?= h(BASE_URL) ?>/blog_post.php?id=<?= (int) $post['id'] ?>">Read more</a>
                        <?php if (!empty($post['category_name'])): ?>
                            <p class="nk-blog-post__category-below">
                                <a href="<?= h(BASE_URL) ?>/blog.php?category=<?= h(urlencode((string) ($post['category_slug'] ?? ''))) ?>"><?= h((string) $post['category_name']) ?></a>
                            </p>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <?php if ($categoriesWithCounts !== []): ?>
        <section class="nk-blog-page__section nk-blog-page__section--categories" aria-labelledby="blog-categories-heading">
            <h2 id="blog-categories-heading" class="nk-blog-page__section-title">Categories</h2>
            <p class="nk-blog-page__section-sub muted">Number of published posts per category. Select a category to filter the latest articles above.</p>
            <div class="blog-category-grid">
                <a href="<?= h(BASE_URL) ?>/blog.php" class="blog-category-card<?= $categorySlug === '' ? ' is-active' : '' ?>">
                    <span class="blog-category-card__name">All posts</span>
                    <span class="blog-category-card__count"><?= (int) $totalPublished ?></span>
                </a>
                <?php foreach ($categoriesWithCounts as $cat): ?>
                    <a href="<?= h(BASE_URL) ?>/blog.php?category=<?= h(urlencode((string) $cat['slug'])) ?>"
                       class="blog-category-card<?= $categorySlug === (string) $cat['slug'] ? ' is-active' : '' ?>">
                        <span class="blog-category-card__name"><?= h((string) $cat['name']) ?></span>
                        <span class="blog-category-card__count"><?= (int) $cat['post_count'] ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>
</div>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
