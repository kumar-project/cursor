<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/project_reminder.php';
require_once __DIR__ . '/includes/skills_catalog.php';
require_once __DIR__ . '/config.php';

$wideMain = true;
$user = current_user();
$staff = is_platform_staff($user);

$statusFilter = $_GET['status'] ?? 'open';
$allowed = ['open', 'assigned', 'in_progress', 'completed', 'cancelled', 'all'];
if (!in_array($statusFilter, $allowed, true)) {
    $statusFilter = 'open';
}

$sort = (string) ($_GET['sort'] ?? 'recommended');
if (!in_array($sort, ['recommended', 'newest', 'budget'], true)) {
    $sort = 'recommended';
}
$actionError = '';
$actionSuccess = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['project_card_action'], $_POST['project_id']) && $user) {
    $projectAction = (string) ($_POST['project_card_action'] ?? '');
    $projectId = (int) ($_POST['project_id'] ?? 0);
    if ($projectId <= 0 || !in_array($projectAction, ['disable', 'delete'], true)) {
        $actionError = 'Invalid project action.';
    } else {
        try {
            if ($staff) {
                $ownStmt = db()->prepare('SELECT id FROM projects WHERE id = ?');
                $ownStmt->execute([$projectId]);
            } else {
                $ownStmt = db()->prepare('SELECT id FROM projects WHERE id = ? AND user_id = ?');
                $ownStmt->execute([$projectId, (int) $user['id']]);
            }
            $owned = $ownStmt->fetch();
            if (!$owned) {
                $actionError = 'You cannot update this project.';
            } elseif ($projectAction === 'disable') {
                $upd = db()->prepare("UPDATE projects SET status = 'cancelled' WHERE id = ?");
                $upd->execute([$projectId]);
                $actionSuccess = 'Project disabled.';
            } else {
                $del = db()->prepare('DELETE FROM projects WHERE id = ?');
                $del->execute([$projectId]);
                $actionSuccess = 'Project deleted.';
            }
        } catch (Throwable) {
            $actionError = 'Could not update project.';
        }
    }
}

$projectTitleOptions = [];
try {
    if ($statusFilter === 'all') {
        $ts = db()->query("SELECT DISTINCT title FROM projects WHERE title <> '' ORDER BY title ASC");
    } else {
        $ts = db()->prepare('SELECT DISTINCT title FROM projects WHERE title <> \'\' AND status = ? ORDER BY title ASC');
        $ts->execute([$statusFilter]);
    }
    if ($ts) {
        foreach ($ts->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $t = trim((string) ($row['title'] ?? ''));
            if ($t !== '') {
                $projectTitleOptions[] = $t;
            }
        }
    }
} catch (Throwable) {
    $projectTitleOptions = [];
}

$projectTitle = trim((string) ($_GET['project_title'] ?? ''));
if ($projectTitle !== '' && !in_array($projectTitle, $projectTitleOptions, true)) {
    $projectTitle = '';
}

$orderSql = match ($sort) {
    'newest' => 'ORDER BY p.created_at DESC',
    'budget' => 'ORDER BY p.budget DESC, p.created_at DESC',
    default => 'ORDER BY p.created_at DESC',
};

$sqlBase = 'SELECT p.*, u.name AS client_name FROM projects p JOIN users u ON u.id = p.user_id ';
$where = [];
$params = [];

if ($statusFilter !== 'all') {
    $where[] = 'p.status = ?';
    $params[] = $statusFilter;
}
if ($projectTitle !== '') {
    $where[] = 'p.title = ?';
    $params[] = $projectTitle;
}
$sql = $sqlBase;
if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ' . $orderSql;

$stmt = db()->prepare($sql);
$stmt->execute($params);
$projects = $stmt->fetchAll();

$sqlCount = 'SELECT COUNT(*) AS n FROM projects p JOIN users u ON u.id = p.user_id ';
if ($where) {
    $sqlCount .= ' WHERE ' . implode(' AND ', $where);
}
$cstmt = db()->prepare($sqlCount);
$cstmt->execute($params);
$totalCount = (int) ($cstmt->fetch()['n'] ?? 0);

$statusCounts = [];
$scRows = db()->query('SELECT status, COUNT(*) AS c FROM projects GROUP BY status');
foreach ($scRows->fetchAll() as $row) {
    $statusCounts[(string) $row['status']] = (int) $row['c'];
}
$countAllProjects = (int) (db()->query('SELECT COUNT(*) AS n FROM projects')->fetch()['n'] ?? 0);

$appliedFilters = 0;
if ($statusFilter !== 'open') {
    $appliedFilters++;
}
if ($projectTitle !== '') {
    $appliedFilters++;
}

function nk_time_ago(string $datetime): string
{
    $t = strtotime($datetime);
    if ($t === false) {
        return '';
    }
    $diff = time() - $t;
    if ($diff < 45) {
        return 'Just now';
    }
    if ($diff < 3600) {
        $m = (int) floor($diff / 60);

        return $m . ' min ago';
    }
    if ($diff < 86400) {
        $h = (int) floor($diff / 3600);

        return $h . ' hr ago';
    }
    if ($diff < 604800) {
        $d = (int) floor($diff / 86400);

        return $d . ' day' . ($d === 1 ? '' : 's') . ' ago';
    }

    return date('j M Y', $t);
}

/** @param array<string, mixed> $project */
function nk_tags(array $project): array
{
    $tags = ['Remote', ucwords(str_replace('_', ' ', (string) $project['status']))];
    $b = (float) $project['budget'];
    if ($b >= 100000) {
        $tags[] = 'Lead';
    } elseif ($b >= 50000) {
        $tags[] = 'Mid budget';
    }
    $words = preg_split('/\s+/', strip_tags((string) $project['title']), 5);
    $words = array_values(array_filter($words ?? [], static fn ($w) => strlen((string) $w) > 2));
    foreach (array_slice($words, 0, 2) as $w) {
        $tags[] = $w;
    }
    if (!empty($project['skills_required'])) {
        foreach (array_slice(nk_skills_parse_blob((string) $project['skills_required']), 0, 3) as $entry) {
            $label = nk_skills_display_label($entry);
            if (strlen($label) > 1 && strlen($label) < 40) {
                $tags[] = $label;
            }
        }
    }

    return array_slice(array_unique($tags), 0, 6);
}

function nk_initial(string $name): string
{
    $t = trim($name);
    if ($t === '') {
        return '?';
    }

    return strtoupper(function_exists('mb_substr') ? mb_substr($t, 0, 1, 'UTF-8') : substr($t, 0, 1));
}

$shownFrom = $totalCount > 0 ? 1 : 0;
$shownTo = min(count($projects), $totalCount);

$page_title = 'Remote jobs';

$nkIxQs = static function (array $overrides = []) use ($statusFilter, $projectTitle, $sort): string {
    $p = array_merge([
        'status' => $statusFilter,
        'project_title' => $projectTitle,
        'sort' => $sort,
    ], $overrides);
    $parts = [];
    foreach ($p as $k => $v) {
        if ($v === '' || $v === null) {
            continue;
        }
        if ($k === 'sort' && $v === 'recommended') {
            continue;
        }
        $parts[] = urlencode((string) $k) . '=' . urlencode((string) $v);
    }

    return $parts !== [] ? implode('&', $parts) : '';
};

$viewer = $user;

require_once __DIR__ . '/includes/layout.php';
?>
<div class="nk-page">
    <div class="nk-shell">
        <aside class="nk-sidebar nk-sidebar--left" aria-label="Filters">
            <div class="nk-filter-head">
                <h2 class="nk-filter-head__title">All Filters</h2>
                <?php if ($appliedFilters > 0): ?>
                    <span class="nk-filter-head__applied">Applied (<?= (int) $appliedFilters ?>)</span>
                <?php endif; ?>
            </div>

            <details class="nk-filter-block" open>
                <summary>Project status</summary>
                <ul class="nk-checklist">
                    <?php foreach ($allowed as $value): ?>
                        <?php
                        $cnt = $value === 'all' ? $countAllProjects : (int) ($statusCounts[$value] ?? 0);
                        $label = $value === 'open' ? 'Remote' : ($value === 'all' ? 'All statuses' : ucwords(str_replace('_', ' ', $value)));
                        ?>
                        <li>
                            <a class="nk-check nk-check--link<?= $statusFilter === $value ? ' is-active' : '' ?>" href="<?= BASE_URL ?>/index.php?<?= h($nkIxQs(['status' => $value])) ?>">
                                <span class="nk-check__box" aria-hidden="true"></span>
                                <?= h($label) ?> <span class="nk-count">(<?= (int) $cnt ?>)</span>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </details>

            <details class="nk-filter-block">
                <summary>Experience</summary>
                <div class="nk-slider-note">
                    <span>0 Yrs</span>
                    <span>Any</span>
                </div>
                <input class="nk-range" type="range" min="0" max="15" value="15" disabled title="Cosmetic filter">
            </details>

            <details class="nk-filter-block">
                <summary>Quick pick title</summary>
                <div class="nk-chips">
                    <?php if ($projectTitleOptions === []): ?>
                        <span class="nk-muted-inline">No project titles in this status yet.</span>
                    <?php else: ?>
                        <?php foreach (array_slice($projectTitleOptions, 0, 5) as $chipTitle): ?>
                            <?php
                            $chipLabel = $chipTitle;
                            if (function_exists('mb_strimwidth')) {
                                $chipLabel = (string) mb_strimwidth($chipTitle, 0, 36, '…', 'UTF-8');
                            } elseif (strlen($chipTitle) > 36) {
                                $chipLabel = substr($chipTitle, 0, 33) . '…';
                            }
                            ?>
                            <a class="nk-chip" href="<?= BASE_URL ?>/index.php?<?= h($nkIxQs(['project_title' => $chipTitle])) ?>"><?= h($chipLabel) ?></a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </details>
        </aside>

        <div class="nk-feed">
            <section class="nk-hero-strip">
                <p class="nk-hero-strip__lead">Find remote projects that match your skills. Post work, bid, and collaborate in one place.</p>
                <div class="nk-job-search-shell" aria-label="Job search">
                    <span class="nk-job-search-shell__rule" aria-hidden="true"></span>
                    <form class="nk-job-search" method="get" action="<?= BASE_URL ?>/index.php" role="search">
                        <input type="hidden" name="status" value="<?= h($statusFilter) ?>">
                        <?php if ($sort !== 'recommended'): ?>
                            <input type="hidden" name="sort" value="<?= h($sort) ?>">
                        <?php endif; ?>
                        <label class="nk-job-search__box">
                            <span class="nk-job-search__legend">Project title</span>
                            <select id="nk-hero-project-title" class="nk-job-search__select" name="project_title" autocomplete="off">
                                <option value="">All projects</option>
                                <?php foreach ($projectTitleOptions as $optTitle): ?>
                                    <option value="<?= h($optTitle) ?>"<?= $projectTitle === $optTitle ? ' selected' : '' ?>><?= h($optTitle) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                        <button type="submit" class="nk-job-search__submit">Search Jobs</button>
                    </form>
                    <span class="nk-job-search-shell__rule" aria-hidden="true"></span>
                </div>
                <div class="nk-hero-strip__links">
                    <?php if ($viewer): ?>
                        <?php if (client_account_pending($viewer)): ?>
                            <a class="nk-link" href="<?= BASE_URL ?>/account_pending.php">Account status</a>
                        <?php else: ?>
                            <a class="nk-link" href="<?= BASE_URL ?>/dashboard.php">Dashboard</a>
                        <?php endif; ?>
                    <?php else: ?>
                        <a class="nk-link" href="<?= BASE_URL ?>/login.php">Login</a>
                        <a class="nk-link" href="<?= BASE_URL ?>/register.php">Register</a>
                    <?php endif; ?>
                    <a class="nk-link" href="#browse">Browse</a>
                    <?php if ($viewer && ((($viewer['role'] ?? '') === 'client' && client_account_approved($viewer)) || is_platform_staff($viewer))): ?>
                        <a class="nk-link" href="<?= BASE_URL ?>/post_project.php">Post project</a>
                        <a class="nk-link" href="<?= BASE_URL ?>/client/assign.php">Assign work</a>
                    <?php endif; ?>
                    <?php if ($viewer && ($viewer['role'] === 'freelancer' || is_platform_staff($viewer))): ?>
                        <a class="nk-link" href="<?= BASE_URL ?>/freelancer/assignments.php">Assignments</a>
                    <?php endif; ?>
                    <?php if ($viewer && is_platform_staff($viewer)): ?>
                        <a class="nk-link" href="<?= BASE_URL ?>/admin.php">Super Admin</a>
                    <?php endif; ?>
                </div>
            </section>

            <header class="nk-results-bar" id="browse">
                <div class="nk-results-bar__meta">
                    <span class="nk-results-count"><?= (int) $shownFrom ?> &ndash; <?= (int) $shownTo ?> of <?= (int) $totalCount ?> remote <?= $totalCount === 1 ? 'job' : 'jobs' ?></span>
                    <a class="nk-results-bar__notify" href="<?= BASE_URL ?>/register.php">Send me jobs like these</a>
                </div>
                <form class="nk-sort" method="get" action="<?= BASE_URL ?>/index.php">
                    <input type="hidden" name="status" value="<?= h($statusFilter) ?>">
                    <?php if ($projectTitle !== ''): ?><input type="hidden" name="project_title" value="<?= h($projectTitle) ?>"><?php endif; ?>
                    <label for="sort-by">Sort by:</label>
                    <select id="sort-by" name="sort" onchange="this.form.submit()">
                        <option value="recommended" <?= $sort === 'recommended' ? 'selected' : '' ?>>Recommended</option>
                        <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Date</option>
                        <option value="budget" <?= $sort === 'budget' ? 'selected' : '' ?>>Budget</option>
                    </select>
                </form>
            </header>
            <?php if ($actionError !== ''): ?><p class="danger"><?= h($actionError) ?></p><?php endif; ?>
            <?php if ($actionSuccess !== ''): ?><p class="success"><?= h($actionSuccess) ?></p><?php endif; ?>

            <?php foreach ($projects as $project): ?>
                <?php
                $snippet = (string) $project['description'];
                $snippet = preg_replace('/\s+/', ' ', $snippet) ?? '';
                $lenFn = function_exists('mb_strlen') ? 'mb_strlen' : 'strlen';
                $subFn = function_exists('mb_substr') ? 'mb_substr' : 'substr';
                $snippet = ($lenFn($snippet) > 200) ? $subFn($snippet, 0, 200) . '…' : $snippet;
                ?>
                <article class="nk-job-card">
                    <div class="nk-job-card__avatar" aria-hidden="true"><?= h(nk_initial((string) $project['client_name'])) ?></div>
                    <div class="nk-job-card__body">
                        <h3 class="nk-job-card__title">
                            <a href="<?= BASE_URL ?>/project.php?id=<?= (int) $project['id'] ?>"><?= h($project['title']) ?></a>
                        </h3>
                        <p class="nk-job-card__company"><?= h($project['client_name']) ?></p>
                        <ul class="nk-job-meta">
                            <li>
                                <span class="nk-job-meta__icon" aria-hidden="true">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v2"/></svg>
                                </span>
                                Experience: Any
                            </li>
                            <li>
                                <span class="nk-job-meta__icon" aria-hidden="true">₹</span>
                                <?= h(number_format((float) $project['budget'], 0)) ?> / project
                            </li>
                            <li>
                                <span class="nk-job-meta__icon" aria-hidden="true">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 1118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                                </span>
                                Remote
                            </li>
                            <?php if (!empty($project['reminder_at'])): ?>
                                <li>
                                    <span class="nk-job-meta__icon" aria-hidden="true">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
                                    </span>
                                    <?= h(project_format_reminder_display((string) $project['reminder_at'])) ?>
                                </li>
                            <?php endif; ?>
                        </ul>
                        <p class="nk-job-card__desc"><?= h($snippet) ?></p>
                        <div class="nk-tags">
                            <?php foreach (nk_tags($project) as $tag): ?>
                                <span class="nk-tag"><?= h($tag) ?></span>
                            <?php endforeach; ?>
                        </div>
                        <footer class="nk-job-card__foot">
                            <time datetime="<?= h($project['created_at']) ?>"><?= h(nk_time_ago((string) $project['created_at'])) ?></time>
                            <?php if ($user && can_manage_project_as_client($user, $project)): ?>
                                <div style="display:flex;gap:8px;align-items:center;">
                                    <a class="nk-save" href="<?= BASE_URL ?>/edit_project.php?id=<?= (int) $project['id'] ?>">Edit</a>
                                    <form method="post" style="display:inline;">
                                        <input type="hidden" name="project_id" value="<?= (int) $project['id'] ?>">
                                        <button type="submit" class="nk-save" name="project_card_action" value="disable">Disable</button>
                                    </form>
                                    <form method="post" style="display:inline;" onsubmit="return confirm('Delete this project?');">
                                        <input type="hidden" name="project_id" value="<?= (int) $project['id'] ?>">
                                        <button type="submit" class="nk-save" name="project_card_action" value="delete">Delete</button>
                                    </form>
                                </div>
                            <?php else: ?>
                                <button type="button" class="nk-save" title="Save (demo)">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 012-2h10a2 2 0 012 2z"/></svg>
                                    Save
                                </button>
                            <?php endif; ?>
                        </footer>
                    </div>
                </article>
            <?php endforeach; ?>

            <?php if (!$projects): ?>
                <div class="nk-empty">
                    <p>No projects match your filters.</p>
                    <a href="<?= BASE_URL ?>/index.php">Clear filters</a>
                </div>
            <?php endif; ?>
        </div>

        <aside class="nk-sidebar nk-sidebar--right" aria-label="Blog">
            <?php require_once __DIR__ . '/includes/partials/blog_headlines_widget.php'; ?>
            <div class="nk-widget nk-widget--promo">
                <div class="nk-promo__brand"><?= h(APP_NAME) ?> <strong>FASTFORWARD</strong></div>
                <p class="nk-promo__text">Boost your profile visibility and get discovered by clients posting remote work.</p>
                <a class="nk-promo__cta" href="<?= BASE_URL ?>/register.php">Know more</a>
            </div>
        </aside>
    </div>
</div>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
