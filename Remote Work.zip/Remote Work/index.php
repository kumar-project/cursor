<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';

$statusFilter = $_GET['status'] ?? 'open';
$allowed = ['open', 'assigned', 'in_progress', 'completed', 'cancelled', 'all'];
if (!in_array($statusFilter, $allowed, true)) {
    $statusFilter = 'open';
}

if ($statusFilter === 'all') {
    $stmt = db()->query(
        "SELECT p.*, u.name AS client_name
         FROM projects p
         JOIN users u ON u.id = p.user_id
         ORDER BY p.created_at DESC"
    );
} else {
    $stmt = db()->prepare(
        "SELECT p.*, u.name AS client_name
         FROM projects p
         JOIN users u ON u.id = p.user_id
         WHERE p.status = ?
         ORDER BY p.created_at DESC"
    );
    $stmt->execute([$statusFilter]);
}
$projects = $stmt->fetchAll();

require_once __DIR__ . '/includes/layout.php';
?>
<section class="card">
    <h2>Welcome</h2>
    <p class="muted">Everything starts from this page. Use the quick links to reach any part of the app.</p>
    <div class="home-hub">
        <?php if ($viewer): ?>
            <a href="<?= BASE_URL ?>/dashboard.php">Dashboard</a>
        <?php else: ?>
            <a href="<?= BASE_URL ?>/login.php">Login</a>
            <a href="<?= BASE_URL ?>/register.php">Register</a>
        <?php endif; ?>
        <a href="#browse">Browse projects</a>
        <?php if ($viewer && ($viewer['role'] === 'client' || is_platform_staff($viewer))): ?>
            <a href="<?= BASE_URL ?>/post_project.php">Post project</a>
            <a href="<?= BASE_URL ?>/client/assign.php">Assign work</a>
        <?php endif; ?>
        <?php if ($viewer && ($viewer['role'] === 'freelancer' || is_platform_staff($viewer))): ?>
            <a href="<?= BASE_URL ?>/freelancer/assignments.php">Assignments</a>
        <?php endif; ?>
        <?php if ($viewer && is_platform_staff($viewer)): ?>
            <a href="<?= BASE_URL ?>/admin.php">Super Admin hub</a>
        <?php endif; ?>
    </div>
</section>

<section class="card home-sitemap">
    <h3>All areas (from Home)</h3>
    <p class="muted">Open project details from the list below, then use chat, milestones, and reviews on the project page.</p>
    <a href="<?= BASE_URL ?>/index.php">Home / project listing</a>
    <a href="<?= BASE_URL ?>/register.php">Register</a>
    <a href="<?= BASE_URL ?>/login.php">Login</a>
    <a href="<?= BASE_URL ?>/dashboard.php">Dashboard</a>
    <a href="<?= BASE_URL ?>/post_project.php">Post project (clients)</a>
    <a href="<?= BASE_URL ?>/client/assign.php">Assign work (clients)</a>
    <a href="<?= BASE_URL ?>/freelancer/assignments.php">Freelancer assignments</a>
    <a href="<?= BASE_URL ?>/admin.php">Super admin panel</a>
</section>

<section class="card" id="browse">
    <h2>Browse Projects</h2>
    <form method="get" class="row">
        <div>
            <label>Status</label>
            <select name="status">
                <?php foreach ($allowed as $value): ?>
                    <option value="<?= h($value) ?>" <?= $statusFilter === $value ? 'selected' : '' ?>>
                        <?= h(ucwords(str_replace('_', ' ', $value))) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div style="display:flex; align-items:flex-end;">
            <button type="submit">Filter</button>
        </div>
    </form>
</section>

<?php foreach ($projects as $project): ?>
    <article class="card">
        <h3><?= h($project['title']) ?></h3>
        <p class="muted">Budget: Rs <?= h(number_format((float)$project['budget'], 2)) ?> | Status: <?= h($project['status']) ?></p>
        <p class="muted">Client: <?= h($project['client_name']) ?></p>
        <p><?= nl2br(h(substr($project['description'], 0, 220))) ?>...</p>
        <a href="<?= BASE_URL ?>/project.php?id=<?= (int)$project['id'] ?>">View details</a>
    </article>
<?php endforeach; ?>

<?php if (!$projects): ?>
    <p class="muted">No projects found yet.</p>
<?php endif; ?>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>

