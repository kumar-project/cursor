# Mini Freelancer Platform (PHP + MySQL)

This is a Freelancer-style MVP built in core PHP with MySQL.

## Features Included

- User auth (client, freelancer, admin)
- Profile section (skills, portfolio, ratings)
- Project posting and project browsing
- Bid submission and bid acceptance
- Assigned -> in progress -> completed workflow
- Milestone + escrow-like wallet flow
- Reviews after completion
- Project chat with file sharing (AJAX polling)
- Admin panel (users, projects, disputes, payments)
- Client assignment flow (select freelancer + file + message)
- Freelancer assignment inbox with status updates

## Setup

1. Create DB and tables:
   - Run `schema.sql` manually in MySQL, or
   - Visit `http://localhost/Remote%20Work/setup.php`
   - If you already ran setup before, run `setup.php` again to create the new `assignments` table.
2. Configure DB credentials in `config.php`.
3. Open `http://localhost/Remote%20Work/index.php`.

## Demo Admin

- Email: `admin@mini.local`
- Password: `admin123`

## Project Structure

- `index.php` - project listing
- `register.php`, `login.php`, `logout.php` - authentication
- `post_project.php` - client posts project
- `project.php` - project details, bids, milestones, reviews
- `chat.php`, `chat_fetch.php`, `chat_send.php` - project chat
- `client/assign.php` - client assign work page
- `freelancer/assignments.php` - freelancer assignment inbox
- `dashboard.php` - user dashboard + wallet/profile
- `admin.php` - admin management panel
- `schema.sql` - database schema

## Next Improvements

- Add CSRF protection
- Add Stripe/Razorpay webhook flow
- Add WebSocket/Pusher for true real-time chat
- Add stronger admin actions (approve/reject/dispute resolution)
- Add pagination/search/filter refinements

## Upload Security

- Upload directory: `uploads/`
- Assignment files: `uploads/assignments/`
- Allowed file extensions: `pdf`, `docx`, `jpg`, `png`, `txt`
- Size limit: 5 MB (`MAX_UPLOAD_SIZE` in `config.php`)
- `.htaccess` blocks script execution from upload folders

