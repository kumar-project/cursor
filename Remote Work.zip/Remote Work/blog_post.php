<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/blog_cms.php';

$id = (int) ($_GET['id'] ?? 0);
$viewer = current_user();
$staff = $viewer !== null && is_platform_staff($viewer);
$post = null;
$isDraftPreview = false;
if ($id > 0) {
    $post = blog_post_get_published($id);
    if (!$post && $staff) {
        $post = blog_post_get_by_id($id);
        if ($post) {
            $isDraftPreview = (($post['status'] ?? '') !== 'published');
        }
    }
}

if (!$post) {
    http_response_code(404);
    $wideMain = true;
    $page_title = 'Post not found';
    require_once __DIR__ . '/includes/layout.php';
    ?>
    <div class="page-shell">
        <section class="card">
            <h1>Post not found</h1>
            <p class="muted">This article does not exist or is not published yet.</p>
            <p><a href="<?= h(BASE_URL) ?>/blog.php">Back to blog</a></p>
        </section>
    </div>
    <?php
    require_once __DIR__ . '/includes/layout_footer.php';
    exit;
}

$wideMain = true;
$page_title = (string) $post['title'];
require_once __DIR__ . '/includes/layout.php';

$img = blog_featured_public_url($post['featured_image_path'] ?? null);
?>
<div class="page-shell nk-blog-page nk-blog-page--single">
    <article class="card nk-blog-article">
        <?php if ($isDraftPreview): ?>
            <p class="admin-blog__draft-banner">Draft preview (only staff can see this)</p>
        <?php endif; ?>
        <header class="nk-blog-article__head">
            <?php if (!empty($post['published_at']) || !empty($post['author_name'])): ?>
                <p class="nk-blog-post__meta">
                    <?php if (!empty($post['published_at'])): ?>
                        <time datetime="<?= h((string) $post['published_at']) ?>"><?= h((string) $post['published_at']) ?></time>
                    <?php endif; ?>
                    <?php if (!empty($post['author_name'])): ?>
                        <?php if (!empty($post['published_at'])): ?> · <?php endif; ?><?= h((string) $post['author_name']) ?>
                    <?php endif; ?>
                </p>
            <?php endif; ?>
            <h1 class="nk-blog-article__title"><?= h((string) $post['title']) ?></h1>
        </header>
        <?php if ($img): ?>
            <img src="<?= h($img) ?>" alt="" class="nk-blog-article__featured">
        <?php endif; ?>
        <div class="nk-blog-article__content">
            <?= nl2br(h((string) $post['content']), false) ?>
        </div>
        <?php if (!empty($post['category_name'])): ?>
            <p class="nk-blog-article__category">
                <a href="<?= h(BASE_URL) ?>/blog.php?category=<?= h(urlencode((string) ($post['category_slug'] ?? ''))) ?>"><?= h((string) $post['category_name']) ?></a>
            </p>
        <?php endif; ?>
        <footer class="nk-blog-article__foot">
            <a href="<?= h(BASE_URL) ?>/blog.php">&larr; All posts</a>
        </footer>
    </article>
</div>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
