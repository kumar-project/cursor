<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';

header('Content-Type: application/json');
require_login();
$user = current_user();
$projectId = (int)($_GET['project_id'] ?? 0);

$p = db()->prepare('SELECT id, user_id, assigned_freelancer_id FROM projects WHERE id = ?');
$p->execute([$projectId]);
$project = $p->fetch();
if (
    !$project ||
    (
        (int)$project['user_id'] !== (int)$user['id'] &&
        (int)$project['assigned_freelancer_id'] !== (int)$user['id'] &&
        !is_platform_staff($user)
    )
) {
    http_response_code(403);
    echo json_encode(['error' => 'forbidden']);
    exit;
}

$stmt = db()->prepare(
    "SELECT c.id, c.message, c.file_path, c.created_at, u.name AS sender_name
     FROM chats c
     JOIN users u ON u.id = c.sender_id
     WHERE c.project_id = ?
     ORDER BY c.id ASC"
);
$stmt->execute([$projectId]);
$rows = $stmt->fetchAll();

$result = array_map(
    static function (array $row): array {
        return [
            'id' => (int)$row['id'],
            'sender_name' => $row['sender_name'],
            'message' => htmlspecialchars($row['message'], ENT_QUOTES, 'UTF-8'),
            'file_url' => $row['file_path'] ? BASE_URL . '/' . ltrim($row['file_path'], '/') : null,
            'created_at' => $row['created_at'],
        ];
    },
    $rows
);

echo json_encode($result);

