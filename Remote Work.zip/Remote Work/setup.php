<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

try {
    $dsn = sprintf('mysql:host=%s;port=%s;charset=utf8mb4', DB_HOST, DB_PORT);
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    $sql = file_get_contents(__DIR__ . '/schema.sql');
    if ($sql === false) {
        throw new RuntimeException('Failed to read schema.sql');
    }
    $pdo->exec($sql);

    $pdo->exec("USE `" . DB_NAME . "`");

    try {
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS project_payment_confirmations (
                id INT AUTO_INCREMENT PRIMARY KEY,
                project_id INT NOT NULL,
                client_id INT NOT NULL,
                freelancer_id INT NOT NULL,
                payment_status ENUM('paid', 'partial', 'pending') NOT NULL,
                payment_method VARCHAR(50) NOT NULL,
                payment_amount DECIMAL(10,2) NOT NULL,
                reference_type ENUM('transaction', 'invoice', 'utr', 'other') NOT NULL,
                reference_number VARCHAR(150) NOT NULL,
                notes TEXT NULL,
                client_submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                freelancer_confirmed_at DATETIME NULL,
                freelancer_confirmed_by INT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                CONSTRAINT fk_ppc_project FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
                CONSTRAINT fk_ppc_client FOREIGN KEY (client_id) REFERENCES users(id) ON DELETE CASCADE,
                CONSTRAINT fk_ppc_freelancer FOREIGN KEY (freelancer_id) REFERENCES users(id) ON DELETE CASCADE,
                CONSTRAINT fk_ppc_confirmed_by FOREIGN KEY (freelancer_confirmed_by) REFERENCES users(id) ON DELETE SET NULL,
                UNIQUE KEY unique_project_payment_confirmation (project_id)
            )"
        );
    } catch (Throwable) {
    }

    foreach (
        [
            'ALTER TABLE users ADD COLUMN remote_work_type VARCHAR(40) NULL',
            'ALTER TABLE users ADD COLUMN availability_timeline VARCHAR(40) NULL',
            'ALTER TABLE users ADD COLUMN freelancer_onboarding_skipped TINYINT(1) NOT NULL DEFAULT 0',
            'ALTER TABLE users ADD COLUMN client_approved TINYINT(1) NOT NULL DEFAULT 1',
            'ALTER TABLE users ADD COLUMN mobile VARCHAR(32) NULL',
            'ALTER TABLE projects ADD COLUMN reminder_at DATETIME NULL',
            'ALTER TABLE projects ADD COLUMN skills_required TEXT NULL',
            'ALTER TABLE projects ADD COLUMN qualifications TEXT NULL',
        ] as $alterSql
    ) {
        try {
            $pdo->exec($alterSql);
        } catch (Throwable) {
        }
    }

    // Existing DBs may have the role enum before super_admin was added.
    try {
        $pdo->exec("ALTER TABLE users MODIFY COLUMN role ENUM('client', 'freelancer', 'admin', 'super_admin') NOT NULL DEFAULT 'freelancer'");
    } catch (Throwable) {
    }

    // Keep seed account on super_admin (fixes older DBs where it was only 'admin' or a normal role).
    $pdo->exec("UPDATE users SET role = 'super_admin' WHERE LOWER(email) = LOWER('admin@mini.local')");

    $exists = $pdo->query("SELECT id FROM users WHERE email = 'admin@mini.local' LIMIT 1")->fetch();
    if (!$exists) {
        $password = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)');
        $stmt->execute(['Platform Super Admin', 'admin@mini.local', $password, 'super_admin']);
    }

    require_once __DIR__ . '/db.php';
    db();

    try {
        $pdo->exec(
            "INSERT INTO super_admin_credentials (user_name, password, staff_user_id)
             SELECT u.email, u.password, u.id FROM users u
             WHERE u.role IN ('admin', 'super_admin')
             AND NOT EXISTS (
                 SELECT 1 FROM super_admin_credentials c
                 WHERE LOWER(TRIM(c.user_name)) = LOWER(TRIM(u.email))
             )"
        );
    } catch (Throwable) {
    }

    echo "Setup complete.\n";
    echo "Super admin login: admin@mini.local / admin123 (use the Super Admin tab on login, or any tab)\n";
} catch (Throwable $e) {
    http_response_code(500);
    echo 'Setup failed: ' . $e->getMessage();
}

