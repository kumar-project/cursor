<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

try {
    $dsn = sprintf('mysql:host=%s;port=%s;charset=utf8mb4', DB_HOST, DB_PORT);
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    $sql = file_get_contents(__DIR__ . '/schema.sql');
    if ($sql === false) {
        throw new RuntimeException('Failed to read schema.sql');
    }
    $pdo->exec($sql);

    $pdo->exec("USE `" . DB_NAME . "`");

    // Existing DBs may have the role enum before super_admin was added.
    try {
        $pdo->exec("ALTER TABLE users MODIFY COLUMN role ENUM('client', 'freelancer', 'admin', 'super_admin') NOT NULL DEFAULT 'freelancer'");
    } catch (Throwable) {
    }

    // Keep seed account on super_admin (fixes older DBs where it was only 'admin' or a normal role).
    $pdo->exec("UPDATE users SET role = 'super_admin' WHERE email = 'admin@mini.local'");

    $exists = $pdo->query("SELECT id FROM users WHERE email = 'admin@mini.local' LIMIT 1")->fetch();
    if (!$exists) {
        $password = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)');
        $stmt->execute(['Platform Super Admin', 'admin@mini.local', $password, 'super_admin']);
    }

    echo "Setup complete.\n";
    echo "Super admin login: admin@mini.local / admin123 (use the Super Admin tab on login, or any tab)\n";
} catch (Throwable $e) {
    http_response_code(500);
    echo 'Setup failed: ' . $e->getMessage();
}

