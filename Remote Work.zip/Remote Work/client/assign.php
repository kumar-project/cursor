<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/assign_work_data.php';

require_login();
require_client_portal();
$user = current_user();
$staff = is_platform_staff($user);

$error = '';
$success = '';
$allowedExtensions = ['pdf', 'docx', 'jpg', 'png', 'txt'];

$selectedProjectId = (int)($_GET['project_id'] ?? ($_POST['project_id'] ?? 0));
$selectedFreelancerId = (int)($_GET['freelancer_id'] ?? ($_POST['freelancer_id'] ?? 0));
$messageValue = (string)($_POST['message'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $projectId = (int)($_POST['project_id'] ?? 0);
    $freelancerId = (int)($_POST['freelancer_id'] ?? 0);
    $message = trim($_POST['message'] ?? '');
    $messageValue = (string)($_POST['message'] ?? '');
    $filePath = null;
    $from = (string)($_POST['from'] ?? '');

    if ($projectId <= 0 || $freelancerId <= 0 || $message === '') {
        $error = 'Project, freelancer and instruction message are required.';
    } else {
        if ($staff) {
            $projectCheck = db()->prepare('SELECT id, status, user_id FROM projects WHERE id = ?');
            $projectCheck->execute([$projectId]);
        } else {
            $projectCheck = db()->prepare('SELECT id, status, user_id FROM projects WHERE id = ? AND user_id = ?');
            $projectCheck->execute([$projectId, (int)$user['id']]);
        }
        $project = $projectCheck->fetch();
        $clientIdForRow = (int) ($project['user_id'] ?? 0);

        $freelancerCheck = db()->prepare("SELECT id FROM users WHERE id = ? AND role = 'freelancer'");
        $freelancerCheck->execute([$freelancerId]);
        $freelancer = $freelancerCheck->fetch();

        if (!$project || !$freelancer) {
            $error = 'Invalid project or freelancer selected.';
        } else {
            if (!empty($_FILES['assignment_file']['name'])) {
                if ($_FILES['assignment_file']['error'] !== UPLOAD_ERR_OK) {
                    $error = 'File upload failed.';
                } elseif ((int)$_FILES['assignment_file']['size'] > MAX_UPLOAD_SIZE) {
                    $error = 'File too large. Maximum allowed size is 5 MB.';
                } else {
                    $originalName = (string)$_FILES['assignment_file']['name'];
                    $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
                    if (!in_array($extension, $allowedExtensions, true)) {
                        $error = 'Invalid file type. Allowed: pdf, docx, jpg, png, txt.';
                    } else {
                        $uploadDir = __DIR__ . '/../uploads/assignments';
                        if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) {
                            $error = 'Upload directory is not available.';
                        } else {
                            $safeBaseName = preg_replace('/[^a-zA-Z0-9_.-]/', '_', pathinfo($originalName, PATHINFO_FILENAME));
                            $randomPart = bin2hex(random_bytes(8));
                            $targetFileName = $randomPart . '_' . $safeBaseName . '.' . $extension;
                            $targetPath = $uploadDir . '/' . $targetFileName;
                            if (!move_uploaded_file($_FILES['assignment_file']['tmp_name'], $targetPath)) {
                                $error = 'Could not save uploaded file.';
                            } else {
                                $filePath = 'uploads/assignments/' . $targetFileName;
                            }
                        }
                    }
                }
            }

            if ($error === '') {
                db()->beginTransaction();
                try {
                    $assignStmt = db()->prepare(
                        "INSERT INTO assignments (project_id, client_id, freelancer_id, message, file_path, status)
                         VALUES (?, ?, ?, ?, ?, 'pending')
                         ON DUPLICATE KEY UPDATE
                            message = VALUES(message),
                            file_path = IFNULL(VALUES(file_path), file_path),
                            status = 'pending'"
                    );
                    $assignStmt->execute([$projectId, $clientIdForRow, $freelancerId, $message, $filePath]);

                    if ($staff) {
                        $projectUpdate = db()->prepare(
                            "UPDATE projects
                             SET assigned_freelancer_id = ?, status = 'assigned'
                             WHERE id = ?"
                        );
                        $projectUpdate->execute([$freelancerId, $projectId]);
                    } else {
                        $projectUpdate = db()->prepare(
                            "UPDATE projects
                             SET assigned_freelancer_id = ?, status = 'assigned'
                             WHERE id = ? AND user_id = ?"
                        );
                        $projectUpdate->execute([$freelancerId, $projectId, (int)$user['id']]);
                    }

                    db()->commit();
                    $success = 'Work assigned successfully.';
                    $selectedProjectId = $projectId;
                    $selectedFreelancerId = $freelancerId;
                    $messageValue = '';

                    if ($from === 'admin') {
                        header('Location: ' . BASE_URL . '/admin.php?assign_ok=1');
                        exit;
                    }
                } catch (Throwable $e) {
                    db()->rollBack();
                    $error = 'Could not assign work. Please try again.';
                }
            }
        }
    }
}

$lists = assign_work_load_lists($user);
$projects = $lists['projects'];
$freelancerRows = $lists['freelancers'];
$selectedStaff = $lists['staff'];

if ($staff) {
    $existingAssignments = db()->query(
        "SELECT a.*, p.title AS project_title, f.name AS freelancer_name, c.name AS client_account_name
         FROM assignments a
         JOIN projects p ON p.id = a.project_id
         JOIN users f ON f.id = a.freelancer_id
         JOIN users c ON c.id = a.client_id
         ORDER BY a.created_at DESC"
    )->fetchAll();
} else {
    $existingAssignmentsStmt = db()->prepare(
        "SELECT a.*, p.title AS project_title, f.name AS freelancer_name
         FROM assignments a
         JOIN projects p ON p.id = a.project_id
         JOIN users f ON f.id = a.freelancer_id
         WHERE a.client_id = ?
         ORDER BY a.created_at DESC"
    );
    $existingAssignmentsStmt->execute([(int)$user['id']]);
    $existingAssignments = $existingAssignmentsStmt->fetchAll();
}

$aw_formAction = BASE_URL . '/client/assign.php';
$aw_from = 'client';
$aw_projects = $projects;
$aw_freelancers = $freelancerRows;
$aw_staff = $selectedStaff;
$aw_selectedProjectId = $selectedProjectId;
$aw_selectedFreelancerId = $selectedFreelancerId;
$aw_messageValue = $messageValue;
$aw_error = $error;
$aw_success = $success;

require_once __DIR__ . '/../includes/layout.php';
?>
<section class="card">
    <h2>Assign work</h2>
    <p class="muted">Choose a project and freelancer, add instructions, and attach a file if needed.<?= $staff ? ' As platform staff, you can use any project.' : '' ?></p>
    <?php
    require __DIR__ . '/../includes/partials/assign_work_form.php';
    ?>
</section>

<section class="card">
    <h3><?= $staff ? 'All client assignments' : 'My assignments' ?></h3>
    <?php foreach ($existingAssignments as $assignment): ?>
        <p>
            <?php if ($staff && isset($assignment['client_account_name'])): ?>
                <span class="muted">Client: <?= h($assignment['client_account_name']) ?> |</span>
            <?php endif; ?>
            <strong><?= h($assignment['project_title']) ?></strong> -> <?= h($assignment['freelancer_name']) ?>
            | <?= h($assignment['status']) ?>
            <?php if (!empty($assignment['file_path'])): ?>
                | <a href="<?= BASE_URL . '/' . h($assignment['file_path']) ?>" target="_blank">File</a>
            <?php endif; ?>
        </p>
    <?php endforeach; ?>
    <?php if (!$existingAssignments): ?><p class="muted">No assignments yet.</p><?php endif; ?>
</section>
<?php require_once __DIR__ . '/../includes/layout_footer.php'; ?>
