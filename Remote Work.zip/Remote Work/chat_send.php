<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';

require_login();
$user = current_user();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit;
}

$projectId = (int)($_POST['project_id'] ?? 0);
$message = trim($_POST['message'] ?? '');
if ($projectId <= 0 || $message === '') {
    http_response_code(422);
    echo 'Invalid payload';
    exit;
}

$p = db()->prepare('SELECT id, user_id, assigned_freelancer_id FROM projects WHERE id = ?');
$p->execute([$projectId]);
$project = $p->fetch();
if (
    !$project ||
    (
        (int)$project['user_id'] !== (int)$user['id'] &&
        (int)$project['assigned_freelancer_id'] !== (int)$user['id'] &&
        !is_platform_staff($user)
    )
) {
    http_response_code(403);
    echo 'Forbidden';
    exit;
}

$filePath = null;
if (!empty($_FILES['chat_file']['name'])) {
    $allowedExtensions = ['pdf', 'docx', 'jpg', 'png', 'txt'];
    if ($_FILES['chat_file']['error'] !== UPLOAD_ERR_OK) {
        http_response_code(422);
        echo 'File upload failed';
        exit;
    }
    if ((int)$_FILES['chat_file']['size'] > MAX_UPLOAD_SIZE) {
        http_response_code(422);
        echo 'File too large';
        exit;
    }

    $uploadDir = __DIR__ . '/uploads/chat';
    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) {
        http_response_code(500);
        echo 'Upload directory not available';
        exit;
    }

    $original = basename((string)$_FILES['chat_file']['name']);
    $extension = strtolower(pathinfo($original, PATHINFO_EXTENSION));
    if (!in_array($extension, $allowedExtensions, true)) {
        http_response_code(422);
        echo 'Invalid file type';
        exit;
    }
    $safeBase = preg_replace('/[^a-zA-Z0-9_.-]/', '_', pathinfo($original, PATHINFO_FILENAME));
    $targetName = bin2hex(random_bytes(8)) . '_' . $safeBase . '.' . $extension;
    $targetFile = $uploadDir . '/' . $targetName;
    if (!move_uploaded_file($_FILES['chat_file']['tmp_name'], $targetFile)) {
        http_response_code(500);
        echo 'Could not save file';
        exit;
    }
    $filePath = 'uploads/chat/' . $targetName;
}

$stmt = db()->prepare(
    'INSERT INTO chats (project_id, sender_id, message, file_path) VALUES (?, ?, ?, ?)'
);
$stmt->execute([$projectId, (int)$user['id'], $message, $filePath]);

echo 'ok';

