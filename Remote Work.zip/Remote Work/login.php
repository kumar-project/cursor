<?php
declare(strict_types=1);

$wideMain = true;

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';

// Open DB + migrations even when logged out (current_user() returns before db() otherwise).
db();

if (current_user()) {
    $loggedIn = current_user();
    $landing = (($loggedIn['role'] ?? '') === 'freelancer') ? '/index.php' : '/dashboard.php';
    header('Location: ' . BASE_URL . $landing);
    exit;
}

$error = '';
// POST body must win: ?role= (empty GET) or ?role=client would otherwise override the hidden "role" field and break Super Admin.
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['role'])
    && in_array((string) $_POST['role'], ['client', 'freelancer', 'super_admin'], true)
) {
    $loginRole = (string) $_POST['role'];
} else {
    $cand = (string) ($_GET['role'] ?? 'client');
    $loginRole = in_array($cand, ['client', 'freelancer', 'super_admin'], true) ? $cand : 'client';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($loginRole === 'super_admin') {
        $loginIdentifier = isset($_POST['super_admin_username']) && is_string($_POST['super_admin_username'])
            ? trim($_POST['super_admin_username'])
            : '';
    } else {
        $loginIdentifier = isset($_POST['email']) && is_string($_POST['email']) ? trim($_POST['email']) : '';
    }
    $password = isset($_POST['password']) && is_string($_POST['password']) ? $_POST['password'] : '';

    if ($loginRole === 'super_admin') {
        $pdo = db();
        $stmt = $pdo->prepare(
            'SELECT id, user_name, password, staff_user_id FROM super_admin_credentials
             WHERE LOWER(TRIM(user_name)) = LOWER(TRIM(?)) LIMIT 1'
        );
        $stmt->execute([$loginIdentifier]);
        $cred = $stmt->fetch();
        $stored = isset($cred['password']) ? (string) $cred['password'] : '';
        $passwordOk = $cred && super_admin_verify_stored_password($password, $stored);

        if (!$cred || !$passwordOk) {
            $error = 'Invalid Super Admin username or password. They must match the user_name and password columns in '
                . 'super_admin_credentials (not your staff email unless you use that as user_name). '
                . 'Set staff_user_id on that row to pin the session to a staff user. Run setup.php if no staff user exists.';
        } else {
            super_admin_upgrade_plaintext_password($pdo, (int) $cred['id'], $password, $stored);

            $sessionUserId = resolve_super_admin_session_user_id($pdo, $cred);
            if (
                $sessionUserId > 0
                && (int) ($cred['staff_user_id'] ?? 0) !== $sessionUserId
            ) {
                try {
                    $fix = $pdo->prepare('UPDATE super_admin_credentials SET staff_user_id = ? WHERE id = ?');
                    $fix->execute([$sessionUserId, (int) $cred['id']]);
                } catch (Throwable) {
                }
            }

            $roleStmt = $pdo->prepare('SELECT role FROM users WHERE id = ?');
            $roleStmt->execute([$sessionUserId]);
            $roleRow = $roleStmt->fetch();
            $dbRole = strtolower(trim((string) ($roleRow['role'] ?? '')));

            if ($sessionUserId <= 0 || !in_array($dbRole, ['admin', 'super_admin'], true)) {
                $error = 'Super Admin credentials are valid, but no staff user could be created or found. '
                    . 'Check the database connection and users table, or run setup.php.';
            } else {
                $_SESSION['user_id'] = $sessionUserId;
                header('Location: ' . BASE_URL . '/dashboard.php');
                exit;
            }
        }
    } else {
        $stmt = db()->prepare(
            'SELECT id, password, role, client_approved FROM users WHERE LOWER(email) = LOWER(?)'
        );
        $stmt->execute([$loginIdentifier]);
        $user = $stmt->fetch();

        $dbRole = strtolower(trim((string) ($user['role'] ?? '')));

        if (!$user || !password_verify($password, (string) $user['password'])) {
            $error = 'Invalid email or password.';
        } elseif ($dbRole !== $loginRole && !in_array($dbRole, ['admin', 'super_admin'], true)) {
            $error = 'This account type does not match the tab you selected (e.g. use Freelancer for freelancer accounts).';
        } else {
            $_SESSION['user_id'] = (int) $user['id'];
            if ($dbRole === 'client' && (int) ($user['client_approved'] ?? 0) === 0) {
                header('Location: ' . BASE_URL . '/account_pending.php');
                exit;
            }
            $landing = ($dbRole === 'freelancer') ? '/index.php' : '/dashboard.php';
            header('Location: ' . BASE_URL . $landing);
            exit;
        }
    }
}

$page_title = 'Login';
require_once __DIR__ . '/includes/layout.php';
$prefillLoginField = $loginRole === 'super_admin'
    ? trim((string) ($_POST['super_admin_username'] ?? ''))
    : trim((string) ($_POST['email'] ?? ''));
?>
<div class="page-shell">
<section class="login-shell">
    <div class="login-hero">
        <p class="login-kicker">Welcome to <?= h(APP_NAME) ?></p>
        <h1 class="login-title">Log in</h1>
        <p class="login-lead">Which describes you best?</p>
        <p class="login-sub"><?= $loginRole === 'super_admin'
            ? 'Choose Super Admin below, then sign in with the username and password from super_admin_credentials (not your email).'
            : 'Choose your account type, then sign in with your email and password.' ?></p>
        <div class="login-avatar-row" aria-hidden="true">
            <span class="login-avatar login-avatar--client">C</span>
            <span class="login-avatar login-avatar--freelancer">F</span>
            <span class="login-avatar login-avatar--team">A</span>
        </div>
        <div class="login-role-grid">
            <a href="<?= BASE_URL ?>/login.php?role=client" class="login-role-card <?= $loginRole === 'client' ? 'is-active' : '' ?>">
                <span class="login-role-icon" aria-hidden="true"><i class="fa-solid fa-briefcase"></i></span>
                <strong>Client</strong>
                <small>Post jobs and hire</small>
            </a>
            <a href="<?= BASE_URL ?>/login.php?role=freelancer" class="login-role-card <?= $loginRole === 'freelancer' ? 'is-active' : '' ?>">
                <span class="login-role-icon" aria-hidden="true"><i class="fa-solid fa-laptop-code"></i></span>
                <strong>Freelancer</strong>
                <small>Work and get paid</small>
            </a>
        </div>
        <div class="login-admin-row">
            <a href="<?= BASE_URL ?>/login.php?role=super_admin" class="<?= $loginRole === 'super_admin' ? 'is-active' : '' ?>">Super Admin Login</a>
        </div>
    </div>

    <div class="card login-form-card">
        <h2><i class="fa-solid fa-right-to-bracket" aria-hidden="true"></i> Log in as <?= $loginRole === 'super_admin' ? 'Super Admin' : h(ucfirst($loginRole)) ?></h2>
        <?php if ($loginRole !== 'super_admin'): ?>
            <p class="muted">Already have an account? Enter your details below to log in.</p>
        <?php endif; ?>
        <?php if ($error): ?><p class="danger"><?= h($error) ?></p><?php endif; ?>
        <form method="post" class="login-form" action="<?= h(BASE_URL) ?>/login.php?role=<?= h(urlencode($loginRole)) ?>">
            <input type="hidden" name="role" value="<?= h($loginRole) ?>">
            <?php if ($loginRole === 'super_admin'): ?>
            <label for="login_super_admin_username">Username</label>
            <input id="login_super_admin_username" type="text" name="super_admin_username" value="<?= h($prefillLoginField) ?>" required autocomplete="username" inputmode="text" autocapitalize="none" spellcheck="false">
            <?php else: ?>
            <label for="login_email">Email</label>
            <input id="login_email" type="email" name="email" value="<?= h($prefillLoginField) ?>" required autocomplete="username" inputmode="email" spellcheck="false">
            <?php endif; ?>
            <label for="login_password">Password</label>
            <div class="nk-password-field">
                <input id="login_password" type="password" name="password" required autocomplete="current-password">
                <button type="button" class="nk-password-toggle" aria-controls="login_password" aria-pressed="false" aria-label="Show password">
                    <i class="fa-solid fa-eye" aria-hidden="true"></i>
                </button>
            </div>
            <button type="submit">Continue</button>
        </form>
        <p class="login-foot-note">Don&apos;t have an account? <a href="<?= BASE_URL ?>/register.php">Create one</a></p>
    </div>
</section>
</div>
<script src="<?= BASE_URL ?>/assets/auth-password-toggle.js" defer></script>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>

