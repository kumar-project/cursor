<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';

if (current_user()) {
    header('Location: ' . BASE_URL . '/dashboard.php');
    exit;
}

$error = '';
// POST body must win: ?role= (empty GET) or ?role=client would otherwise override the hidden "role" field and break Super Admin.
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['role'])
    && in_array((string) $_POST['role'], ['client', 'freelancer', 'super_admin'], true)
) {
    $loginRole = (string) $_POST['role'];
} else {
    $cand = (string) ($_GET['role'] ?? 'client');
    $loginRole = in_array($cand, ['client', 'freelancer', 'super_admin'], true) ? $cand : 'client';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim((string) ($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    $stmt = db()->prepare('SELECT id, password, role FROM users WHERE LOWER(email) = LOWER(?)');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, (string) $user['password'])) {
        $error = 'Invalid email or password.';
    } elseif ($loginRole === 'super_admin') {
        if (!in_array($user['role'], ['admin', 'super_admin'], true)) {
            $error = 'This account is not a staff user. Log in on the Super Admin tab only with admin@mini.local (or another admin/super_admin in the database).';
        } else {
            $_SESSION['user_id'] = (int) $user['id'];
            header('Location: ' . BASE_URL . '/dashboard.php');
            exit;
        }
    } elseif ($user['role'] !== $loginRole && !in_array($user['role'], ['admin', 'super_admin'], true)) {
        $error = 'This account type does not match the tab you selected (e.g. use Freelancer for freelancer accounts).';
    } else {
        $_SESSION['user_id'] = (int) $user['id'];
        header('Location: ' . BASE_URL . '/dashboard.php');
        exit;
    }
}

require_once __DIR__ . '/includes/layout.php';
?>
<section class="card">
    <h2>Login</h2>
    <div style="margin-bottom:12px;">
        <a href="<?= BASE_URL ?>/login.php?role=client" style="margin-right:12px; <?= $loginRole === 'client' ? 'font-weight:700;' : '' ?>">Client</a>
        <a href="<?= BASE_URL ?>/login.php?role=freelancer" style="margin-right:12px; <?= $loginRole === 'freelancer' ? 'font-weight:700;' : '' ?>">Freelancer</a>
        <a href="<?= BASE_URL ?>/login.php?role=super_admin" style="<?= $loginRole === 'super_admin' ? 'font-weight:700;' : '' ?>">Super Admin</a>
    </div>
    <?php if ($error): ?><p class="danger"><?= h($error) ?></p><?php endif; ?>
    <form method="post">
        <input type="hidden" name="role" value="<?= h($loginRole) ?>">
        <label>Email</label>
        <input type="email" name="email" required>
        <label>Password</label>
        <input type="password" name="password" required>
        <button type="submit">Login (<?= $loginRole === 'super_admin' ? h('Super Admin') : h(ucfirst($loginRole)) ?>)</button>
    </form>
</section>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>

