<?php
declare(strict_types=1);

$wideMain = true;
$page_title = 'Users & data';
$nk_admin_nav = 'data';

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/admin_helpers.php';
require_once __DIR__ . '/includes/mail_notify.php';

require_privileged();
$flash = '';
$flash_error = '';
$adminActor = current_user();
$superAdminCanApproveClients = is_super_admin($adminActor);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_end_user'])) {
    $uid = (int) ($_POST['user_id'] ?? 0);
    if ($uid <= 0) {
        $flash_error = 'Invalid request.';
    } elseif ($uid === (int) ($adminActor['id'] ?? 0)) {
        $flash_error = 'You cannot delete your own account.';
    } else {
        $check = db()->prepare("SELECT id, role, name, cv_file_path FROM users WHERE id = ?");
        $check->execute([$uid]);
        $rowDel = $check->fetch();
        $delRole = (string) ($rowDel['role'] ?? '');
        if (!$rowDel || !in_array($delRole, ['client', 'freelancer'], true)) {
            $flash_error = 'Only client and freelancer accounts can be deleted here.';
        } else {
            require_once __DIR__ . '/includes/freelancer_cv_upload.php';
            $cvRel = isset($rowDel['cv_file_path']) && is_string($rowDel['cv_file_path']) ? trim($rowDel['cv_file_path']) : '';
            if ($cvRel !== '') {
                freelancer_cv_delete_stored_file($cvRel);
            }
            try {
                $del = db()->prepare("DELETE FROM users WHERE id = ? AND role IN ('client', 'freelancer')");
                $del->execute([$uid]);
                $delName = trim((string) ($rowDel['name'] ?? ''));
                $flash = ($delName !== '' ? $delName : ucfirst($delRole)) . ' (' . $delRole . ') was deleted. Related projects and records were removed or updated per database rules.';
            } catch (Throwable) {
                $flash_error = 'Could not delete this user. They may still be referenced in a way that blocks removal.';
            }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve_client'])) {
    if (!$superAdminCanApproveClients) {
        $flash_error = 'Only a Super Admin can approve client accounts.';
    } else {
        $uid = (int) ($_POST['user_id'] ?? 0);
        if ($uid <= 0) {
            $flash_error = 'Invalid request.';
        } else {
            $check = db()->prepare('SELECT role, client_approved, name, email FROM users WHERE id = ?');
            $check->execute([$uid]);
            $t = $check->fetch();
            if (!$t || ($t['role'] ?? '') !== 'client') {
                $flash_error = 'Only client accounts can be approved here.';
            } elseif ((int) ($t['client_approved'] ?? 0) === 1) {
                $flash_error = 'This client is already approved.';
            } else {
                $u = db()->prepare("UPDATE users SET client_approved = 1 WHERE id = ? AND role = 'client'");
                $u->execute([$uid]);
                $flash = 'Client approved by Super Admin. They can now post projects and use client tools.';
                if (MAIL_NOTIFICATIONS_ENABLED) {
                    $mailSent = mail_notify_client_approved((string) ($t['email'] ?? ''), (string) ($t['name'] ?? ''));
                    $flash .= $mailSent
                        ? ' A confirmation email was sent to their address.'
                        : ' The approval email could not be sent — check MAIL_FROM_ADDRESS / server mail (php.ini).';
                }
            }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_role'])) {
    $uid = (int) ($_POST['user_id'] ?? 0);
    $newRole = (string) ($_POST['new_role'] ?? '');

    if (!in_array($newRole, ['client', 'freelancer'], true) || $uid <= 0) {
        $flash_error = 'Invalid request.';
    } else {
        $check = db()->prepare('SELECT role FROM users WHERE id = ?');
        $check->execute([$uid]);
        $t = $check->fetch();
        if (!$t || in_array($t['role'], ['admin', 'super_admin'], true)) {
            $flash_error = 'This account type cannot be changed from here.';
        } else {
            if ($newRole === 'client') {
                $u = db()->prepare('UPDATE users SET role = ?, client_approved = 0 WHERE id = ?');
                $u->execute([$newRole, $uid]);
                $flash = 'User role updated to client. A Super Admin must approve the account before they can use client features.';
            } else {
                $u = db()->prepare('UPDATE users SET role = ? WHERE id = ?');
                $u->execute([$newRole, $uid]);
                $flash = 'User role updated to ' . $newRole . '.';
            }
        }
    }
}

$users = db()->query(
    'SELECT u.id, u.name, u.mobile, u.email, u.role, u.skills, u.portfolio, u.wallet_balance, u.avg_rating,
            u.remote_work_type, u.availability_timeline, u.freelancer_onboarding_skipped, u.cv_file_path, u.created_at,
            u.client_approved,
            (SELECT COUNT(*) FROM projects p WHERE p.user_id = u.id) AS client_project_count,
            (SELECT COUNT(*) FROM bids b WHERE b.freelancer_id = u.id) AS freelancer_bid_count,
            (SELECT COUNT(*) FROM projects p WHERE p.assigned_freelancer_id = u.id) AS freelancer_assigned_count
     FROM users u
     ORDER BY u.id DESC'
)->fetchAll();
$projects = db()->query(
    "SELECT p.id, p.title, p.status, p.budget, p.created_at, u.name AS client_name
     FROM projects p
     JOIN users u ON u.id = p.user_id
     ORDER BY p.id DESC"
)->fetchAll();
$disputes = db()->query(
    "SELECT d.id, d.project_id, d.status, d.reason, d.created_at, u.name AS raised_by_name
     FROM disputes d
     JOIN users u ON u.id = d.raised_by
     ORDER BY d.id DESC"
)->fetchAll();
$payments = db()->query(
    'SELECT id, project_id, amount, status, gateway, transaction_ref, created_at
     FROM payments
     ORDER BY id DESC'
)->fetchAll();

$clients = array_filter($users, static fn (array $r) => $r['role'] === 'client');
$freelancers = array_filter($users, static fn (array $r) => $r['role'] === 'freelancer');
$staff = array_filter($users, static fn (array $r) => in_array($r['role'], ['admin', 'super_admin'], true));

if ($flash === '' && $flash_error === '' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    if (!empty($_SESSION['admin_data_flash'])) {
        $flash = (string) $_SESSION['admin_data_flash'];
        unset($_SESSION['admin_data_flash']);
    }
    if (!empty($_SESSION['admin_data_flash_error'])) {
        $flash_error = (string) $_SESSION['admin_data_flash_error'];
        unset($_SESSION['admin_data_flash_error']);
    }
}

require_once __DIR__ . '/includes/layout.php';
?>
<div class="page-shell">
    <?php require __DIR__ . '/includes/partials/admin_subnav.php'; ?>

    <section class="card">
        <h2>User &amp; data management</h2>
        <p class="muted">Switch end users between client and freelancer, and review platform activity. Staff accounts are not reassigned here.</p>
        <?php if ($flash_error): ?><p class="danger"><?= h($flash_error) ?></p><?php endif; ?>
        <?php if ($flash): ?><p class="success"><?= h($flash) ?></p><?php endif; ?>
    </section>

    <section class="card">
        <h3>Clients</h3>
        <p class="muted">Every new client (self-registration or role changed to Client) stays <strong>Pending</strong> until a Super Admin uses <strong>Approve client</strong> below. Other platform staff can view the list but cannot approve. Passwords are never shown.</p>
        <?php if (!$superAdminCanApproveClients): ?>
            <p class="muted">Sign in with a Super Admin account to approve pending clients.</p>
        <?php endif; ?>
        <?php if (!$clients): ?>
            <p class="muted">No client accounts yet.</p>
        <?php else: ?>
            <div class="admin-data-table-wrap">
                <table class="admin-data-table">
                    <thead>
                        <tr>
                            <th>Name / email / mobile</th>
                            <th>Wallet</th>
                            <th>Projects</th>
                            <th>Skills</th>
                            <th>Portfolio</th>
                            <th>Remote pref.</th>
                            <th>Availability</th>
                            <th>Joined</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($clients as $row): ?>
                            <?php $clientOk = (int) ($row['client_approved'] ?? 0) === 1; ?>
                            <tr>
                                <td><strong><?= h((string) $row['name']) ?></strong><br><span class="admin-data-table__muted"><?= h((string) $row['email']) ?></span><?php
                                    $m = isset($row['mobile']) ? trim((string) $row['mobile']) : '';
                                    if ($m !== ''): ?><br><span class="admin-data-table__muted"><?= h($m) ?></span><?php endif;
                                ?></td>
                                <td>Rs <?= h(number_format((float) $row['wallet_balance'], 2)) ?></td>
                                <td><?= (int) ($row['client_project_count'] ?? 0) ?></td>
                                <td class="admin-data-table__long"><?php
                                    $sk = isset($row['skills']) ? trim((string) $row['skills']) : '';
                                    echo $sk === '' ? '—' : nl2br(h($sk), false);
                                ?></td>
                                <td class="admin-data-table__long"><?php
                                    $pf = isset($row['portfolio']) ? trim((string) $row['portfolio']) : '';
                                    echo $pf === '' ? '—' : nl2br(h($pf), false);
                                ?></td>
                                <td><?= h(admin_label_remote(isset($row['remote_work_type']) ? (string) $row['remote_work_type'] : null) ?: '—') ?></td>
                                <td><?= h(admin_label_availability(isset($row['availability_timeline']) ? (string) $row['availability_timeline'] : null) ?: '—') ?></td>
                                <td class="admin-data-table__nowrap"><?= h((string) $row['created_at']) ?></td>
                                <td><?= $clientOk ? 'Active' : 'Pending approval' ?></td>
                                <td class="admin-table-actions">
                                    <a class="admin-table-actions__link" href="<?= BASE_URL ?>/admin_edit_user.php?id=<?= (int) $row['id'] ?>">Edit</a>
                                    <form method="post" class="admin-table-actions__form" onsubmit="return confirm('Permanently delete this client and related data (projects, etc.)? This cannot be undone.');">
                                        <input type="hidden" name="user_id" value="<?= (int) $row['id'] ?>">
                                        <button type="submit" name="delete_end_user" value="1" class="admin-btn-danger">Delete</button>
                                    </form>
                                    <?php if (!$clientOk && $superAdminCanApproveClients): ?>
                                        <form method="post" class="admin-table-actions__form">
                                            <input type="hidden" name="user_id" value="<?= (int) $row['id'] ?>">
                                            <button type="submit" name="approve_client" value="1">Approve client</button>
                                        </form>
                                    <?php elseif (!$clientOk): ?>
                                        <p class="muted" style="margin:0; font-size:0.82rem;">Awaiting Super Admin</p>
                                    <?php endif; ?>
                                    <form method="post" class="admin-table-actions__form">
                                        <input type="hidden" name="user_id" value="<?= (int) $row['id'] ?>">
                                        <input type="hidden" name="set_role" value="1">
                                        <input type="hidden" name="new_role" value="freelancer">
                                        <button type="submit" name="reassign" value="1" onclick="return confirm('Move this user to Freelancer?');">Set as Freelancer</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>

    <section class="card">
        <h3>Freelancers</h3>
        <p class="muted">Full account data for every freelancer (bids, assignments, skills, CV, onboarding). Passwords are never shown.</p>
        <?php if (!$freelancers): ?>
            <p class="muted">No freelancer accounts yet.</p>
        <?php else: ?>
            <div class="admin-data-table-wrap">
                <table class="admin-data-table">
                    <thead>
                        <tr>
                            <th>Name / email / mobile</th>
                            <th>Wallet</th>
                            <th>Rating</th>
                            <th>Bids</th>
                            <th>Assigned</th>
                            <th>Skills</th>
                            <th>Portfolio</th>
                            <th>Remote / avail.</th>
                            <th>Onbrd. skip</th>
                            <th>CV</th>
                            <th>Joined</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($freelancers as $row): ?>
                            <?php
                            $cvPath = isset($row['cv_file_path']) && is_string($row['cv_file_path']) ? trim($row['cv_file_path']) : '';
                            ?>
                            <tr>
                                <td><strong><?= h((string) $row['name']) ?></strong><br><span class="admin-data-table__muted"><?= h((string) $row['email']) ?></span><?php
                                    $m = isset($row['mobile']) ? trim((string) $row['mobile']) : '';
                                    if ($m !== ''): ?><br><span class="admin-data-table__muted"><?= h($m) ?></span><?php endif;
                                ?></td>
                                <td>Rs <?= h(number_format((float) $row['wallet_balance'], 2)) ?></td>
                                <td><?= h(number_format((float) $row['avg_rating'], 2)) ?></td>
                                <td><?= (int) ($row['freelancer_bid_count'] ?? 0) ?></td>
                                <td><?= (int) ($row['freelancer_assigned_count'] ?? 0) ?></td>
                                <td class="admin-data-table__long"><?php
                                    $sk = isset($row['skills']) ? trim((string) $row['skills']) : '';
                                    echo $sk === '' ? '—' : nl2br(h($sk), false);
                                ?></td>
                                <td class="admin-data-table__long"><?php
                                    $pf = isset($row['portfolio']) ? trim((string) $row['portfolio']) : '';
                                    echo $pf === '' ? '—' : nl2br(h($pf), false);
                                ?></td>
                                <td><?= h(admin_label_remote(isset($row['remote_work_type']) ? (string) $row['remote_work_type'] : null) ?: '—') ?><br><span class="admin-data-table__muted"><?= h(admin_label_availability(isset($row['availability_timeline']) ? (string) $row['availability_timeline'] : null) ?: '—') ?></span></td>
                                <td><?= ((int) ($row['freelancer_onboarding_skipped'] ?? 0)) !== 0 ? 'Yes' : 'No' ?></td>
                                <td>
                                    <?php if ($cvPath !== ''): ?>
                                        <a href="<?= h(BASE_URL . '/' . $cvPath) ?>" target="_blank" rel="noopener">View CV</a>
                                    <?php else: ?>
                                        —
                                    <?php endif; ?>
                                </td>
                                <td class="admin-data-table__nowrap"><?= h((string) $row['created_at']) ?></td>
                                <td class="admin-table-actions">
                                    <a class="admin-table-actions__link" href="<?= BASE_URL ?>/admin_edit_user.php?id=<?= (int) $row['id'] ?>">Edit</a>
                                    <form method="post" class="admin-table-actions__form" onsubmit="return confirm('Permanently delete this freelancer and related data (bids, etc.)? This cannot be undone.');">
                                        <input type="hidden" name="user_id" value="<?= (int) $row['id'] ?>">
                                        <button type="submit" name="delete_end_user" value="1" class="admin-btn-danger">Delete</button>
                                    </form>
                                    <form method="post" class="admin-table-actions__form">
                                        <input type="hidden" name="user_id" value="<?= (int) $row['id'] ?>">
                                        <input type="hidden" name="set_role" value="1">
                                        <input type="hidden" name="new_role" value="client">
                                        <button type="submit" name="reassign" value="1" onclick="return confirm('Move this user to Client? They will need Super Admin approval as a client.');">Set as Client</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>

    <section class="card">
        <h3>Platform staff</h3>
        <p class="muted">Admins and super-admins. Roles are set in the database, not on this form.</p>
        <?php foreach ($staff as $row): ?>
            <p>#<?= (int) $row['id'] ?> — <?= h($row['name']) ?> (<?= h($row['email']) ?>) | <?= h($row['role']) ?></p>
        <?php endforeach; ?>
        <?php if (!$staff): ?><p class="muted">No staff users.</p><?php endif; ?>
    </section>

    <section class="card">
        <h3>Projects</h3>
        <?php foreach ($projects as $row): ?>
            <p>#<?= (int) $row['id'] ?> - <?= h($row['title']) ?> | <?= h($row['status']) ?> | Client: <?= h($row['client_name']) ?></p>
        <?php endforeach; ?>
    </section>

    <section class="card">
        <h3>Disputes</h3>
        <?php foreach ($disputes as $row): ?>
            <p>#<?= (int) $row['id'] ?> - Project #<?= (int) $row['project_id'] ?> | <?= h($row['status']) ?> | By <?= h($row['raised_by_name']) ?></p>
        <?php endforeach; ?>
        <?php if (!$disputes): ?><p class="muted">No disputes raised.</p><?php endif; ?>
    </section>

    <section class="card">
        <h3>Payment tracking</h3>
        <p class="muted">Summary only. Super Admin can open the full ledger with client and freelancer details on both sides.</p>
        <?php if (is_super_admin($adminActor)): ?>
            <p><a href="<?= BASE_URL ?>/admin_transactions.php">View all transactions &amp; confirmations →</a></p>
        <?php endif; ?>
        <?php foreach (array_slice($payments, 0, 10) as $row): ?>
            <p>#<?= (int) $row['id'] ?> - Project #<?= (int) $row['project_id'] ?> | Rs <?= h(number_format((float) $row['amount'], 2)) ?> | <?= h($row['status']) ?></p>
        <?php endforeach; ?>
        <?php if (!$payments): ?><p class="muted">No payment records yet.</p><?php endif; ?>
        <?php if (count($payments) > 10 && is_super_admin($adminActor)): ?>
            <p class="muted"><a href="<?= BASE_URL ?>/admin_transactions.php">See all <?= count($payments) ?> records</a></p>
        <?php endif; ?>
    </section>
</div>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
