<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';

require_login();
require_client_portal();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $budget = (float)($_POST['budget'] ?? 0);

    if ($title === '' || $description === '' || $budget <= 0) {
        $error = 'Please provide title, description and valid budget.';
    } else {
        $user = current_user();
        $stmt = db()->prepare('INSERT INTO projects (user_id, title, description, budget) VALUES (?, ?, ?, ?)');
        $stmt->execute([(int)$user['id'], $title, $description, $budget]);
        $success = 'Project posted successfully.';
    }
}

require_once __DIR__ . '/includes/layout.php';
?>
<section class="card">
    <h2>Post New Project</h2>
    <?php if ($error): ?><p class="danger"><?= h($error) ?></p><?php endif; ?>
    <?php if ($success): ?><p class="success"><?= h($success) ?></p><?php endif; ?>
    <form method="post">
        <label>Project Title</label>
        <input name="title" required>

        <label>Description</label>
        <textarea name="description" rows="6" required></textarea>

        <label>Budget (INR)</label>
        <input type="number" step="0.01" name="budget" required>

        <button type="submit">Publish Project</button>
    </form>
</section>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>

