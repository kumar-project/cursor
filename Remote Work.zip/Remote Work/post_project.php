<?php
declare(strict_types=1);

$wideMain = true;

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/project_reminder.php';
require_once __DIR__ . '/includes/skills_catalog.php';
require_once __DIR__ . '/config.php';

require_login();
require_client_portal();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $budget = (float) ($_POST['budget'] ?? 0);
    $skillsRequired = nk_normalize_skills_post((string) ($_POST['skills_required'] ?? ''));
    $qualifications = trim((string) ($_POST['qualifications'] ?? ''));
    $qualifications = $qualifications === '' ? null : $qualifications;

    if ($title === '' || $description === '' || $budget <= 0) {
        $error = 'Please provide title, description and valid budget.';
    } else {
        $user = current_user();
        $reminderAt = project_parse_reminder_from_post($_POST);
        $stmt = db()->prepare(
            'INSERT INTO projects (user_id, title, description, budget, reminder_at, skills_required, qualifications)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([(int) $user['id'], $title, $description, $budget, $reminderAt, $skillsRequired, $qualifications]);
        $newProjectId = (int) db()->lastInsertId();
        header('Location: ' . BASE_URL . '/client/assign.php?project_id=' . $newProjectId . '&posted=1');
        exit;
    }
}

$pr_reminder_date = '';
$pr_reminder_time = '';
$pr_skills_required = '';
$pr_qualifications = '';
if ($error !== '' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $pr_reminder_date = trim((string) ($_POST['reminder_date'] ?? ''));
    $pr_reminder_time = trim((string) ($_POST['reminder_time'] ?? ''));
    $pr_skills_required = (string) ($_POST['skills_required'] ?? '');
    $pr_qualifications = (string) ($_POST['qualifications'] ?? '');
}

require_once __DIR__ . '/includes/layout.php';
?>
<div class="page-shell">
<section class="card project-form-card">
    <h2>Post New Project</h2>
    <p class="muted">Create your project here first. After you publish, you will go to <strong>Assign work</strong> to pick a freelancer and send instructions.</p>
    <?php if ($error): ?><p class="danger"><?= h($error) ?></p><?php endif; ?>
    <form method="post">
        <label>Project Title</label>
        <input name="title" required value="<?= h((string) ($_POST['title'] ?? '')) ?>">

        <label>Description</label>
        <textarea name="description" rows="6" required><?= h((string) ($_POST['description'] ?? '')) ?></textarea>

        <label>Budget (INR)</label>
        <input type="number" step="0.01" name="budget" required value="<?= h((string) ($_POST['budget'] ?? '')) ?>">

        <?php require __DIR__ . '/includes/partials/project_skills_qualification_fields.php'; ?>
        <?php require __DIR__ . '/includes/partials/project_reminder_fields.php'; ?>

        <button type="submit">Publish Project</button>
    </form>
</section>
</div>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
