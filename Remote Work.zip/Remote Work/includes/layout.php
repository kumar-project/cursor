<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
$viewer = current_user();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/style.css">
</head>
<body>
<header class="topbar">
    <h1><a href="<?= BASE_URL ?>/index.php"><?= h(APP_NAME) ?></a></h1>
    <nav>
        <a href="<?= BASE_URL ?>/index.php">Home</a>
        <a href="<?= BASE_URL ?>/index.php#browse">Projects</a>
        <?php if ($viewer): ?>
            <a href="<?= BASE_URL ?>/dashboard.php">Dashboard</a>
            <?php if ($viewer['role'] === 'client' || is_platform_staff($viewer)): ?>
                <a href="<?= BASE_URL ?>/post_project.php">Post project</a>
                <a href="<?= BASE_URL ?>/client/assign.php">Assign</a>
            <?php endif; ?>
            <?php if ($viewer['role'] === 'freelancer' || is_platform_staff($viewer)): ?>
                <a href="<?= BASE_URL ?>/freelancer/assignments.php">Assignments</a>
            <?php endif; ?>
            <?php if (is_platform_staff($viewer)): ?>
                <a href="<?= BASE_URL ?>/admin.php">Super Admin</a>
            <?php endif; ?>
            <a href="<?= BASE_URL ?>/logout.php">Logout</a>
        <?php else: ?>
            <a href="<?= BASE_URL ?>/login.php">Login</a>
            <a href="<?= BASE_URL ?>/register.php">Register</a>
        <?php endif; ?>
    </nav>
</header>
<main class="container">

