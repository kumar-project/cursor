<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
$viewer = current_user();
$nk_client_pending = $viewer !== null && client_account_pending($viewer);
$wideMain = $wideMain ?? false;
$page_title = $page_title ?? null;
$nk_current_script = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $nk_doc_title = APP_NAME;
    if ($page_title !== null && trim((string) $page_title) !== '') {
        $nk_doc_title = trim((string) $page_title) . ' — ' . APP_NAME;
    }
    ?>
    <title><?= h($nk_doc_title) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/style.css">
</head>
<body class="nk-body">
<header class="nk-header">
    <div class="nk-header__row">
        <a class="nk-logo" href="<?= BASE_URL ?>/index.php">
            <span class="nk-logo__mark"><?= h(APP_NAME) ?></span>
        </a>
        <nav class="nk-nav" aria-label="Primary">
                <a class="nk-nav__link" href="<?= BASE_URL ?>/index.php">Home</a>
                <a class="nk-nav__link<?= $nk_current_script === 'blog.php' || $nk_current_script === 'blog_post.php' ? ' nk-nav__link--current' : '' ?>" href="<?= BASE_URL ?>/blog.php" <?= ($nk_current_script === 'blog.php' || $nk_current_script === 'blog_post.php') ? 'aria-current="page"' : '' ?>>Blog</a>
                <?php if (!$viewer || !is_platform_staff($viewer)): ?>
                <a class="nk-nav__link nk-nav__link--badge" href="<?= BASE_URL ?>/index.php#browse">
                    Jobs
                    <?php
                    $jobBadge = 0;
                    try {
                        $c = db()->query("SELECT COUNT(*) AS n FROM projects WHERE status = 'open'")->fetch();
                        $jobBadge = (int) ($c['n'] ?? 0);
                    } catch (Throwable) {
                    }
                    if ($jobBadge > 0): ?>
                        <span class="nk-badge"><?= $jobBadge > 99 ? '99+' : (string) $jobBadge ?></span>
                    <?php endif; ?>
                </a>
                <?php endif; ?>
                <?php if ($viewer): ?>
                    <?php if (!is_platform_staff($viewer)): ?>
                        <?php if ($nk_client_pending): ?>
                            <a class="nk-nav__link<?= $nk_current_script === 'account_pending.php' ? ' nk-nav__link--current' : '' ?>" href="<?= BASE_URL ?>/account_pending.php" <?= $nk_current_script === 'account_pending.php' ? 'aria-current="page"' : '' ?>>Account status</a>
                        <?php else: ?>
                            <a class="nk-nav__link" href="<?= BASE_URL ?>/dashboard.php">Dashboard</a>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if (!$nk_client_pending): ?>
                    <a class="nk-nav__link<?= $nk_current_script === 'payment.php' ? ' nk-nav__link--current' : '' ?>" href="<?= BASE_URL ?>/payment.php" <?= $nk_current_script === 'payment.php' ? 'aria-current="page"' : '' ?>>Payments</a>
                    <?php endif; ?>
                    <?php if (($viewer['role'] ?? '') === 'client' && client_account_approved($viewer)): ?>
                        <a class="nk-nav__link" href="<?= BASE_URL ?>/post_project.php">Post project</a>
                        <a class="nk-nav__link" href="<?= BASE_URL ?>/client/assign.php" title="Create a project first, then assign it here">Assign</a>
                    <?php endif; ?>
                    <?php if ($viewer['role'] === 'freelancer' || is_platform_staff($viewer)): ?>
                        <a class="nk-nav__link" href="<?= BASE_URL ?>/freelancer/assignments.php">Assignments</a>
                    <?php endif; ?>
                    <?php if (is_platform_staff($viewer)): ?>
                        <a class="nk-nav__link<?= $nk_current_script === 'admin.php' ? ' nk-nav__link--current' : '' ?>" href="<?= BASE_URL ?>/admin.php" <?= $nk_current_script === 'admin.php' ? 'aria-current="page"' : '' ?>>Super Admin</a>
                        <a class="nk-nav__link<?= $nk_current_script === 'admin_assign_work.php' ? ' nk-nav__link--current' : '' ?>" href="<?= BASE_URL ?>/admin_assign_work.php" <?= $nk_current_script === 'admin_assign_work.php' ? 'aria-current="page"' : '' ?>>Assign work</a>
                        <a class="nk-nav__link<?= $nk_current_script === 'admin_data.php' || $nk_current_script === 'admin_edit_user.php' ? ' nk-nav__link--current' : '' ?>" href="<?= BASE_URL ?>/admin_data.php" <?= $nk_current_script === 'admin_data.php' || $nk_current_script === 'admin_edit_user.php' ? 'aria-current="page"' : '' ?>>Users &amp; data</a>
                        <a class="nk-nav__link<?= $nk_current_script === 'admin_blog.php' ? ' nk-nav__link--current' : '' ?>" href="<?= BASE_URL ?>/admin_blog.php" <?= $nk_current_script === 'admin_blog.php' ? 'aria-current="page"' : '' ?>>Blog CMS</a>
                    <?php endif; ?>
                <?php else: ?>
                    <a class="nk-nav__link<?= $nk_current_script === 'login.php' ? ' nk-nav__link--current' : '' ?>" href="<?= BASE_URL ?>/login.php" <?= $nk_current_script === 'login.php' ? 'aria-current="page"' : '' ?>>Login</a>
                    <a class="nk-nav__link<?= $nk_current_script === 'register.php' ? ' nk-nav__link--current' : '' ?>" href="<?= BASE_URL ?>/register.php" <?= $nk_current_script === 'register.php' ? 'aria-current="page"' : '' ?>>Register</a>
                <?php endif; ?>
        </nav>
        <div class="nk-header__actions">
            <?php if ($viewer): ?>
                <?php
                $nk360Href = BASE_URL . '/dashboard.php';
                if (is_platform_staff($viewer)) {
                    $nk360Href = BASE_URL . '/admin.php';
                } elseif ($nk_client_pending) {
                    $nk360Href = BASE_URL . '/account_pending.php';
                }
                ?>
                <a class="nk-pill" href="<?= h($nk360Href) ?>"><?= h(APP_NAME) ?> 360</a>
                <button type="button" class="nk-icon-btn" aria-label="Notifications">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 006 8c0 7-3 7-3 7h14s-3 0-3-7"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
                    <span class="nk-badge nk-badge--dot">1</span>
                </button>
                <div class="nk-account">
                    <button type="button" class="nk-account__trigger" id="nk-account-trigger" aria-expanded="false" aria-controls="nk-account-menu">
                        <span class="nk-avatar" title="<?= h($viewer['name']) ?>">
                            <?= h(strtoupper(substr($viewer['name'], 0, 1))) ?>
                        </span>
                        <span class="nk-account__chevron" aria-hidden="true">▾</span>
                    </button>
                    <div class="nk-account__menu" id="nk-account-menu" hidden>
                        <div class="nk-account__profile-head">
                            <span class="nk-avatar nk-avatar--small"><?= h(strtoupper(substr($viewer['name'], 0, 1))) ?></span>
                            <div>
                                <strong><?= h($viewer['name']) ?></strong>
                                <small><?= h(ucfirst((string) $viewer['role'])) ?></small>
                            </div>
                        </div>
                        <nav class="nk-account__links" aria-label="Account menu">
                            <a href="<?= BASE_URL ?>/dashboard.php"><span class="nk-account__icon">○</span>Your profile</a>
                            <a href="<?= BASE_URL ?>/dashboard.php?settings=profile"><span class="nk-account__icon">⚙</span>Profile settings</a>
                        </nav>
                        <div class="nk-account__logout">
                            <a href="<?= BASE_URL ?>/logout.php"><span class="nk-account__icon">↩</span>Log out</a>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <a class="nk-pill" href="<?= BASE_URL ?>/register.php">Join <?= h(APP_NAME) ?></a>
                <a class="nk-btn nk-btn--ghost<?= $nk_current_script === 'login.php' ? ' nk-btn--current' : '' ?>" href="<?= BASE_URL ?>/login.php">Login</a>
                <a class="nk-btn<?= $nk_current_script === 'register.php' ? ' nk-btn--current' : '' ?>" href="<?= BASE_URL ?>/register.php">Register</a>
            <?php endif; ?>
        </div>
    </div>
</header>
<?php if ($viewer): ?>
<script>
(function () {
    var trigger = document.getElementById('nk-account-trigger');
    var menu = document.getElementById('nk-account-menu');
    if (!trigger || !menu) {
        return;
    }
    function positionMenu() {
        var rect = trigger.getBoundingClientRect();
        var gap = 8;
        menu.style.top = rect.bottom + gap + 'px';
        menu.style.left = 'auto';
        menu.style.right = Math.max(12, window.innerWidth - rect.right) + 'px';
    }
    function closeMenu() {
        menu.hidden = true;
        trigger.setAttribute('aria-expanded', 'false');
    }
    function openMenu() {
        positionMenu();
        menu.hidden = false;
        trigger.setAttribute('aria-expanded', 'true');
    }
    function onViewportChange() {
        if (!menu.hidden) {
            positionMenu();
        }
    }
    trigger.addEventListener('click', function (e) {
        e.stopPropagation();
        if (menu.hidden) {
            openMenu();
        } else {
            closeMenu();
        }
    });
    window.addEventListener('resize', onViewportChange);
    document.addEventListener('scroll', onViewportChange, true);
    document.addEventListener('click', function (e) {
        if (!menu.hidden && !menu.contains(e.target) && !trigger.contains(e.target)) {
            closeMenu();
        }
    });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            closeMenu();
        }
    });
})();
</script>
<?php endif; ?>
<main class="site-main<?= $wideMain ? ' site-main--wide' : '' ?>">
<?php if (!$wideMain): ?><div class="container"><?php endif; ?>
