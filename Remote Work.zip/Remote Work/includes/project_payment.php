<?php
declare(strict_types=1);

/** @return array<string, string> */
function project_payment_status_options(): array
{
    return [
        'paid' => 'Paid in full',
        'partial' => 'Partially paid',
        'pending' => 'Payment pending',
    ];
}

/** @return array<string, string> */
function project_payment_method_options(): array
{
    return [
        'bank_transfer' => 'Bank transfer (NEFT/IMPS/RTGS)',
        'upi' => 'UPI',
        'card' => 'Credit / debit card',
        'cash' => 'Cash',
        'cheque' => 'Cheque',
        'wallet' => 'Platform wallet',
        'other' => 'Other',
    ];
}

/** @return array<string, string> */
function project_payment_reference_type_options(): array
{
    return [
        'transaction' => 'Transaction number',
        'invoice' => 'Invoice number',
        'utr' => 'UTR number',
        'other' => 'Other reference',
    ];
}

function fetch_project_payment_confirmation(int $projectId): ?array
{
    if ($projectId <= 0) {
        return null;
    }
    $stmt = db()->prepare('SELECT * FROM project_payment_confirmations WHERE project_id = ? LIMIT 1');
    $stmt->execute([$projectId]);

    $row = $stmt->fetch();
    return $row ?: null;
}

function project_payment_is_confirmed(?array $confirmation): bool
{
    return $confirmation !== null && !empty($confirmation['freelancer_confirmed_at']);
}

function project_payment_label(string $field, string $value): string
{
    $maps = [
        'payment_status' => project_payment_status_options(),
        'payment_method' => project_payment_method_options(),
        'reference_type' => project_payment_reference_type_options(),
    ];
    if (isset($maps[$field][$value])) {
        return $maps[$field][$value];
    }

    return $value;
}

function sync_assignment_completed_for_project(int $projectId, int $freelancerId): void
{
    $stmt = db()->prepare(
        "UPDATE assignments
         SET status = 'completed'
         WHERE project_id = ? AND freelancer_id = ? AND status IN ('pending', 'in_progress')"
    );
    $stmt->execute([$projectId, $freelancerId]);
}
