<?php
declare(strict_types=1);

require_once __DIR__ . '/../db.php';

function blog_make_slug(string $title): string
{
    $s = strtolower((string) preg_replace('/[^a-z0-9]+/i', '-', trim($title)));
    $s = trim($s, '-');
    if ($s === '') {
        return 'post';
    }

    return substr($s, 0, 200);
}

function blog_next_unique_slug(string $base, ?int $excludePostId = null): string
{
    $pdo = db();
    $slug = substr($base, 0, 260);
    if ($slug === '') {
        $slug = 'post';
    }
    $candidate = $slug;
    $i = 2;
    while (true) {
        if ($excludePostId !== null) {
            $st = $pdo->prepare('SELECT id FROM blog_posts WHERE slug = ? AND id <> ? LIMIT 1');
            $st->execute([$candidate, $excludePostId]);
        } else {
            $st = $pdo->prepare('SELECT id FROM blog_posts WHERE slug = ? LIMIT 1');
            $st->execute([$candidate]);
        }
        if (!$st->fetch()) {
            return $candidate;
        }
        $candidate = $slug . '-' . $i;
        $i++;
    }
}

function blog_safe_featured_path(?string $relative): bool
{
    if ($relative === null || $relative === '') {
        return false;
    }
    $norm = str_replace('\\', '/', $relative);

    return str_starts_with($norm, 'uploads/blog/')
        && strpos($norm, '..') === false
        && preg_match('#^uploads/blog/[a-zA-Z0-9._-]+$#', $norm) === 1;
}

function blog_delete_featured_file(?string $relative): void
{
    if (!blog_safe_featured_path($relative)) {
        return;
    }
    $full = dirname(__DIR__) . '/' . str_replace('\\', '/', $relative);
    if (is_file($full)) {
        @unlink($full);
    }
}

/**
 * @throws RuntimeException
 */
function blog_upload_featured_image(array $file): ?string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Image upload failed.');
    }
    if ((int) $file['size'] > MAX_UPLOAD_SIZE) {
        throw new RuntimeException('Image exceeds maximum upload size.');
    }
    $ext = strtolower(pathinfo((string) $file['name'], PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    if (!in_array($ext, $allowed, true)) {
        throw new RuntimeException('Use JPG, PNG, GIF, or WebP for featured images.');
    }
    $dir = dirname(__DIR__) . '/uploads/blog';
    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        throw new RuntimeException('Could not create upload directory.');
    }
    $name = 'feat_' . bin2hex(random_bytes(8)) . '.' . $ext;
    $dest = $dir . DIRECTORY_SEPARATOR . $name;
    if (!move_uploaded_file((string) $file['tmp_name'], $dest)) {
        throw new RuntimeException('Could not save uploaded image.');
    }

    return 'uploads/blog/' . $name;
}

/** @return list<array<string,mixed>> */
function blog_categories_all(): array
{
    return db()->query('SELECT id, name, slug FROM blog_categories ORDER BY name ASC')->fetchAll();
}

/** @return list<array<string,mixed>> */
function blog_posts_admin_list(): array
{
    $sql = 'SELECT p.*, c.name AS category_name, u.name AS author_name
            FROM blog_posts p
            JOIN blog_categories c ON c.id = p.category_id
            JOIN users u ON u.id = p.author_id
            ORDER BY p.updated_at DESC';

    return db()->query($sql)->fetchAll();
}

/** @return array<string,mixed>|null */
function blog_post_get_by_id(int $id): ?array
{
    $st = db()->prepare(
        'SELECT p.*, c.name AS category_name, c.slug AS category_slug, u.name AS author_name
         FROM blog_posts p
         JOIN blog_categories c ON c.id = p.category_id
         JOIN users u ON u.id = p.author_id
         WHERE p.id = ?'
    );
    $st->execute([$id]);
    $row = $st->fetch();

    return $row ?: null;
}

/** @return array<string,mixed>|null */
function blog_post_get_published(int $id): ?array
{
    $st = db()->prepare(
        'SELECT p.*, c.name AS category_name, c.slug AS category_slug, u.name AS author_name
         FROM blog_posts p
         JOIN blog_categories c ON c.id = p.category_id
         JOIN users u ON u.id = p.author_id
         WHERE p.id = ? AND p.status = \'published\' AND p.published_at IS NOT NULL'
    );
    $st->execute([$id]);
    $row = $st->fetch();

    return $row ?: null;
}

/**
 * @return list<array<string,mixed>>
 */
function blog_posts_list_published(?string $categorySlug = null, ?int $limit = null): array
{
    $sql = 'SELECT p.*, c.name AS category_name, c.slug AS category_slug
            FROM blog_posts p
            JOIN blog_categories c ON c.id = p.category_id
            WHERE p.status = \'published\' AND p.published_at IS NOT NULL';
    $params = [];
    if ($categorySlug !== null && $categorySlug !== '') {
        $sql .= ' AND c.slug = ?';
        $params[] = $categorySlug;
    }
    $sql .= ' ORDER BY p.published_at DESC';
    if ($limit !== null && $limit > 0) {
        $sql .= ' LIMIT ' . (int) $limit;
    }
    $st = db()->prepare($sql);
    $st->execute($params);

    return $st->fetchAll();
}

/** Total published posts (optionally in one category by slug). */
function blog_published_posts_count(?string $categorySlug = null): int
{
    $sql = 'SELECT COUNT(*) FROM blog_posts p
            JOIN blog_categories c ON c.id = p.category_id
            WHERE p.status = \'published\' AND p.published_at IS NOT NULL';
    $params = [];
    if ($categorySlug !== null && $categorySlug !== '') {
        $sql .= ' AND c.slug = ?';
        $params[] = $categorySlug;
    }
    $st = db()->prepare($sql);
    $st->execute($params);

    return (int) $st->fetchColumn();
}

/**
 * Each category with count of published posts (includes categories with zero posts).
 *
 * @return list<array{id: int, name: string, slug: string, post_count: int}>
 */
function blog_categories_with_published_counts(): array
{
    $sql = 'SELECT c.id, c.name, c.slug, COUNT(p.id) AS post_count
            FROM blog_categories c
            LEFT JOIN blog_posts p ON p.category_id = c.id
                AND p.status = \'published\'
                AND p.published_at IS NOT NULL
            GROUP BY c.id, c.name, c.slug
            ORDER BY c.name ASC';
    $rows = db()->query($sql)->fetchAll();
    $out = [];
    foreach ($rows as $r) {
        $out[] = [
            'id' => (int) $r['id'],
            'name' => (string) $r['name'],
            'slug' => (string) $r['slug'],
            'post_count' => (int) $r['post_count'],
        ];
    }

    return $out;
}

/**
 * @return list<array{id: int, title: string, excerpt: string, thumb_url: ?string, category_name: string, category_slug: string}>
 */
function blog_posts_for_widget(int $limit = 5): array
{
    $limit = max(1, min(20, $limit));
    $st = db()->prepare(
        'SELECT p.id, p.title, p.excerpt, p.featured_image_path, c.name AS category_name, c.slug AS category_slug
         FROM blog_posts p
         JOIN blog_categories c ON c.id = p.category_id
         WHERE p.status = \'published\' AND p.published_at IS NOT NULL
         ORDER BY p.published_at DESC
         LIMIT ' . (int) $limit
    );
    $st->execute();
    $rows = $st->fetchAll();
    $out = [];
    foreach ($rows as $r) {
        $ex = trim((string) ($r['excerpt'] ?? ''));
        $thumb = blog_featured_public_url($r['featured_image_path'] ?? null);
        $out[] = [
            'id' => (int) $r['id'],
            'title' => (string) $r['title'],
            'excerpt' => $ex,
            'thumb_url' => $thumb,
            'category_name' => (string) ($r['category_name'] ?? ''),
            'category_slug' => (string) ($r['category_slug'] ?? ''),
        ];
    }

    return $out;
}

function blog_category_create(string $name): string
{
    $name = trim($name);
    if ($name === '') {
        return 'Category name is required.';
    }
    $slug = blog_next_category_slug(blog_make_slug($name));
    try {
        $st = db()->prepare('INSERT INTO blog_categories (name, slug) VALUES (?, ?)');
        $st->execute([$name, $slug]);
    } catch (Throwable) {
        return 'Could not create category (duplicate slug?).';
    }

    return '';
}

function blog_next_category_slug(string $base): string
{
    $pdo = db();
    $slug = substr($base, 0, 130);
    if ($slug === '') {
        $slug = 'category';
    }
    $candidate = $slug;
    $i = 2;
    while (true) {
        $st = $pdo->prepare('SELECT id FROM blog_categories WHERE slug = ? LIMIT 1');
        $st->execute([$candidate]);
        if (!$st->fetch()) {
            return $candidate;
        }
        $candidate = $slug . '-' . $i;
        $i++;
    }
}

function blog_category_delete(int $id): string
{
    if ($id <= 0) {
        return 'Invalid category.';
    }
    $c = db()->prepare('SELECT COUNT(*) FROM blog_posts WHERE category_id = ?');
    $c->execute([$id]);
    if ((int) $c->fetchColumn() > 0) {
        return 'Move or delete posts in this category first.';
    }
    $d = db()->prepare('DELETE FROM blog_categories WHERE id = ?');
    $d->execute([$id]);

    return '';
}

function blog_post_delete(int $id): string
{
    if ($id <= 0) {
        return 'Invalid post.';
    }
    $st = db()->prepare('SELECT featured_image_path FROM blog_posts WHERE id = ?');
    $st->execute([$id]);
    $row = $st->fetch();
    if (!$row) {
        return 'Post not found.';
    }
    blog_delete_featured_file($row['featured_image_path'] ?? null);
    db()->prepare('DELETE FROM blog_posts WHERE id = ?')->execute([$id]);

    return '';
}

/**
 * @param array<string,mixed> $data
 */
function blog_post_save(array $data, int $authorId, ?array $uploadFile): string
{
    $id = (int) ($data['id'] ?? 0);
    $title = trim((string) ($data['title'] ?? ''));
    $content = (string) ($data['content'] ?? '');
    $categoryId = (int) ($data['category_id'] ?? 0);
    $excerpt = trim((string) ($data['excerpt'] ?? ''));
    $status = (string) ($data['status'] ?? 'draft');
    if (!in_array($status, ['draft', 'published'], true)) {
        $status = 'draft';
    }
    $removeFeatured = !empty($data['remove_featured']);

    if ($title === '' || $content === '') {
        return 'Title and content are required.';
    }
    if ($categoryId <= 0) {
        return 'Choose a category.';
    }

    $catOk = db()->prepare('SELECT id FROM blog_categories WHERE id = ?');
    $catOk->execute([$categoryId]);
    if (!$catOk->fetch()) {
        return 'Invalid category.';
    }

    $existing = null;
    if ($id > 0) {
        $existing = blog_post_get_by_id($id);
        if (!$existing) {
            return 'Post not found.';
        }
    }

    $baseSlug = blog_make_slug($title);
    $slug = blog_next_unique_slug($baseSlug, $id > 0 ? $id : null);

    $featuredPath = $existing['featured_image_path'] ?? null;
    if ($removeFeatured) {
        blog_delete_featured_file($featuredPath);
        $featuredPath = null;
    }

    if ($uploadFile !== null) {
        try {
            $newPath = blog_upload_featured_image($uploadFile);
            if ($newPath !== null) {
                if ($featuredPath !== null && $featuredPath !== '') {
                    blog_delete_featured_file($featuredPath);
                }
                $featuredPath = $newPath;
            }
        } catch (RuntimeException $e) {
            return $e->getMessage();
        }
    }

    $publishedAt = $existing['published_at'] ?? null;
    if ($status === 'published') {
        if ($publishedAt === null || $publishedAt === '') {
            $publishedAt = date('Y-m-d H:i:s');
        }
    } else {
        $publishedAt = null;
    }

    if ($id > 0) {
        $up = db()->prepare(
            'UPDATE blog_posts SET category_id = ?, title = ?, slug = ?, content = ?, excerpt = ?,
             featured_image_path = ?, status = ?, published_at = ?
             WHERE id = ?'
        );
        $up->execute([
            $categoryId,
            $title,
            $slug,
            $content,
            $excerpt === '' ? null : $excerpt,
            $featuredPath,
            $status,
            $publishedAt,
            $id,
        ]);
    } else {
        $ins = db()->prepare(
            'INSERT INTO blog_posts (category_id, author_id, title, slug, content, excerpt, featured_image_path, status, published_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $ins->execute([
            $categoryId,
            $authorId,
            $title,
            $slug,
            $content,
            $excerpt === '' ? null : $excerpt,
            $featuredPath,
            $status,
            $publishedAt,
        ]);
    }

    return '';
}

function blog_featured_public_url(?string $relative): ?string
{
    if (!blog_safe_featured_path($relative)) {
        return null;
    }

    return BASE_URL . '/' . str_replace('\\', '/', $relative);
}

function blog_format_excerpt(array $post, int $maxLen = 200): string
{
    $ex = trim((string) ($post['excerpt'] ?? ''));
    if ($ex !== '') {
        return $ex;
    }
    $plain = trim(preg_replace('/\s+/', ' ', strip_tags((string) ($post['content'] ?? ''))) ?? '');
    if (function_exists('mb_substr')) {
        return mb_strlen($plain) > $maxLen ? mb_substr($plain, 0, $maxLen) . '…' : $plain;
    }

    return strlen($plain) > $maxLen ? substr($plain, 0, $maxLen) . '…' : $plain;
}
