<?php
declare(strict_types=1);

/** @var string $frShellTitle */
/** @var int|null $frShellProgress percent 0–100, or null to hide bar */
/** @var string $frShellLaterHref */
/** @var string $frShellLaterLabel */

$frShellTitle = $frShellTitle ?? APP_NAME;
$frShellProgress = $frShellProgress ?? null;
$frShellLaterHref = $frShellLaterHref ?? (BASE_URL . '/dashboard.php');
$frShellLaterLabel = $frShellLaterLabel ?? "I'll Do This Later";

$brandBits = preg_split('/\s+/', trim(APP_NAME)) ?: [APP_NAME];
$brandWordmark = strtoupper(implode('.', $brandBits));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($frShellTitle) ?> — <?= h(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/freelancer-wizard.css">
</head>
<body class="fr-shell">
<header class="fr-top">
    <div class="fr-top__inner">
        <a class="fr-brand" href="<?= BASE_URL ?>/index.php">
            <span class="fr-brand__name"><?= h($brandWordmark) ?></span>
            <span class="fr-brand__line" aria-hidden="true"></span>
            <span class="fr-brand__tag">grow remotely</span>
        </a>
        <a class="fr-later" href="<?= h($frShellLaterHref) ?>"><?= h($frShellLaterLabel) ?></a>
    </div>
</header>
<?php if ($frShellProgress !== null): ?>
<div class="fr-progress" role="progressbar" aria-valuenow="<?= (int) $frShellProgress ?>" aria-valuemin="0" aria-valuemax="100">
    <div class="fr-progress__fill" style="width: <?= max(0, min(100, (int) $frShellProgress)) ?>%"></div>
</div>
<?php endif; ?>
<main class="fr-main">
<div class="fr-main__inner">
