<?php
declare(strict_types=1);

require_once __DIR__ . '/../config.php';

/**
 * @param array<string,mixed>|null $file Single entry from $_FILES
 * @return array{error: ?string, path: ?string} path is relative to project root when set
 */
function freelancer_cv_process_upload(?array $file, int $userId, ?string $previousRelativePath): array
{
    if ($file === null || (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return ['error' => null, 'path' => null];
    }
    if ((int) $file['error'] !== UPLOAD_ERR_OK) {
        return ['error' => 'CV upload failed.', 'path' => null];
    }
    if ((int) $file['size'] > MAX_UPLOAD_SIZE) {
        return ['error' => 'CV file too large (max 5 MB).', 'path' => null];
    }
    $allowed = ['pdf', 'doc', 'docx'];
    $originalName = (string) ($file['name'] ?? '');
    $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed, true)) {
        return ['error' => 'CV must be a PDF or Word file (.pdf, .doc, .docx).', 'path' => null];
    }
    $uploadDir = __DIR__ . '/../uploads/cvs';
    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) {
        return ['error' => 'Upload directory is not available.', 'path' => null];
    }
    $safeBase = preg_replace('/[^a-zA-Z0-9_.-]/', '_', pathinfo($originalName, PATHINFO_FILENAME)) ?: 'cv';
    $targetName = 'cv_' . $userId . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
    $targetPath = $uploadDir . '/' . $targetName;
    if (!move_uploaded_file((string) $file['tmp_name'], $targetPath)) {
        return ['error' => 'Could not save CV.', 'path' => null];
    }

    freelancer_cv_delete_stored_file($previousRelativePath);

    return ['error' => null, 'path' => 'uploads/cvs/' . $targetName];
}

/** Remove stored CV file from disk when path was saved by this app. */
function freelancer_cv_delete_stored_file(?string $relativePath): void
{
    if ($relativePath === null || $relativePath === '') {
        return;
    }
    if (str_contains($relativePath, '..')) {
        return;
    }
    $full = __DIR__ . '/../' . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $relativePath);
    if (is_file($full)) {
        @unlink($full);
    }
}
