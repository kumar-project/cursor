</main>
<footer class="site-footer">
    <div class="container site-footer__inner">
        <a href="<?= BASE_URL ?>/index.php">Home</a>
        <?php if (isset($viewer) && $viewer): ?>
            <a href="<?= BASE_URL ?>/dashboard.php">Dashboard</a>
        <?php else: ?>
            <a href="<?= BASE_URL ?>/login.php">Login</a>
            <a href="<?= BASE_URL ?>/register.php">Register</a>
        <?php endif; ?>
    </div>
</footer>
</body>
</html>

