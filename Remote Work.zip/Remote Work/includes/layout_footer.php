<?php
$wideMain = $wideMain ?? false;
?>
<?php if (!$wideMain): ?></div><?php endif; ?>
</main>
<footer class="site-footer nk-footer">
    <div class="container site-footer__inner">
        <a href="<?= BASE_URL ?>/index.php">Home</a>
        <a href="<?= BASE_URL ?>/blog.php">Blog</a>
        <?php if (isset($viewer) && $viewer): ?>
            <a href="<?= BASE_URL ?>/dashboard.php">Dashboard</a>
        <?php else: ?>
            <a href="<?= BASE_URL ?>/login.php">Login</a>
            <a href="<?= BASE_URL ?>/register.php">Register</a>
        <?php endif; ?>
    </div>
</footer>
</body>
</html>
