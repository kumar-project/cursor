<?php
declare(strict_types=1);

/**
 * Lists for the "assign work" form (client + platform staff).
 *
 * @return array{projects: list<array>, freelancers: list<array>, staff: bool}
 */
function assign_work_load_lists(array $user): array
{
    if (!can_access_client_portal($user)) {
        return ['projects' => [], 'freelancers' => [], 'staff' => false];
    }
    $staff = is_platform_staff($user);
    $freelancers = db()->query(
        "SELECT id, name, email, skills, avg_rating
         FROM users
         WHERE role = 'freelancer'
         ORDER BY avg_rating DESC, created_at DESC"
    )->fetchAll();

    if ($staff) {
        $projects = db()->query(
            'SELECT p.id, p.title, p.status, p.user_id, u.name AS client_name
             FROM projects p
             JOIN users u ON u.id = p.user_id
             ORDER BY p.created_at DESC'
        )->fetchAll();
    } else {
        $projectStmt = db()->prepare('SELECT id, title, status, user_id FROM projects WHERE user_id = ? ORDER BY created_at DESC');
        $projectStmt->execute([(int)$user['id']]);
        $projects = $projectStmt->fetchAll();
    }

    return ['projects' => $projects, 'freelancers' => $freelancers, 'staff' => $staff];
}
