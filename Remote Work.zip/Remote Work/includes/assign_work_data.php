<?php
declare(strict_types=1);

require_once __DIR__ . '/skills_catalog.php';

/**
 * @return list<string>
 */
function assign_work_skill_tokens(string $value): array
{
    $normalized = strtolower(trim($value));
    if ($normalized === '') {
        return [];
    }

    $normalized = preg_replace('/[^\p{L}\p{N},\/\+\-\s]+/u', ' ', $normalized);
    $parts = preg_split('/[\s,\/\+\-]+/u', (string) $normalized) ?: [];
    $tokens = [];

    foreach ($parts as $part) {
        $token = trim($part);
        if ($token === '' || strlen($token) < 3) {
            continue;
        }
        if (in_array($token, ['and', 'for', 'with', 'the', 'job', 'work', 'year', 'years'], true)) {
            continue;
        }
        $tokens[$token] = true;
    }

    return array_keys($tokens);
}

/**
 * Whether two non-empty skill strings overlap (substring, token, or short-token containment).
 */
function assign_work_skills_pair_match(string $a, string $b): bool
{
    $a = strtolower(trim($a));
    $b = strtolower(trim($b));

    if ($a === '' || $b === '') {
        return false;
    }

    if (str_contains($a, $b) || str_contains($b, $a)) {
        return true;
    }

    $projectTokens = assign_work_skill_tokens($a);
    $freelancerTokens = assign_work_skill_tokens($b);
    if (!$projectTokens || !$freelancerTokens) {
        return false;
    }

    if (count(array_intersect($projectTokens, $freelancerTokens)) > 0) {
        return true;
    }

    foreach ($projectTokens as $projectToken) {
        foreach ($freelancerTokens as $freelancerToken) {
            $minLen = min(strlen($projectToken), strlen($freelancerToken));
            if ($minLen < 3) {
                continue;
            }
            if (str_contains($projectToken, $freelancerToken) || str_contains($freelancerToken, $projectToken)) {
                return true;
            }
        }
    }

    return false;
}

function assign_work_skills_match(string $projectSkills, string $freelancerSkills): bool
{
    $projectSkills = trim($projectSkills);
    $freelancerSkills = trim($freelancerSkills);

    if ($projectSkills === '' || $freelancerSkills === '') {
        return false;
    }

    $pPhrases = nk_skills_split_tokens($projectSkills);
    $fPhrases = nk_skills_split_tokens($freelancerSkills);
    if ($pPhrases !== [] && $fPhrases !== []) {
        foreach ($pPhrases as $p) {
            foreach ($fPhrases as $f) {
                if (assign_work_skills_pair_match((string) $p, (string) $f)) {
                    return true;
                }
            }
        }
    }

    return assign_work_skills_pair_match($projectSkills, $freelancerSkills);
}

/**
 * Lists for the "assign work" form (client + platform staff).
 *
 * @return array{projects: list<array>, freelancers: list<array>, staff: bool}
 */
function assign_work_load_lists(array $user): array
{
    if (!can_access_client_portal($user)) {
        return ['projects' => [], 'freelancers' => [], 'staff' => false];
    }
    $staff = is_platform_staff($user);
    $freelancers = db()->query(
        "SELECT id, name, email, skills, avg_rating
         FROM users
         WHERE role = 'freelancer'
         ORDER BY avg_rating DESC, created_at DESC"
    )->fetchAll();

    if ($staff) {
        $projects = db()->query(
            'SELECT p.id, p.title, p.status, p.user_id, p.reminder_at, p.skills_required, u.name AS client_name
             FROM projects p
             JOIN users u ON u.id = p.user_id
             ORDER BY p.created_at DESC'
        )->fetchAll();
    } else {
        $projectStmt = db()->prepare(
            'SELECT id, title, status, user_id, reminder_at, skills_required FROM projects WHERE user_id = ? ORDER BY created_at DESC'
        );
        $projectStmt->execute([(int) $user['id']]);
        $projects = $projectStmt->fetchAll();
    }

    return ['projects' => $projects, 'freelancers' => $freelancers, 'staff' => $staff];
}
