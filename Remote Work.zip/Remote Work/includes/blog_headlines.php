<?php
declare(strict_types=1);

/**
 * @return list<array{id: string, title: string, blurb: string}>
 */
function nk_blog_headlines(): array
{
    return [
        [
            'id' => 'async-trust',
            'title' => 'Building trust in async-first remote teams',
            'blurb' => 'Clear ownership, written decisions, and predictable response windows replace hallway sync — without burning people out on meetings.',
        ],
        [
            'id' => 'proposal-wins',
            'title' => 'What clients actually read in your first proposal',
            'blurb' => 'Lead with outcomes and a tight plan; save the portfolio links for after you have shown you understood the problem.',
        ],
        [
            'id' => 'rate-negotiation',
            'title' => 'Pricing remote work without racing to the bottom',
            'blurb' => 'Scope in revisions, define milestones, and anchor your rate to value delivered — not hours logged in a tracker.',
        ],
        [
            'id' => 'focus-deep-work',
            'title' => 'Protecting deep work when your office is at home',
            'blurb' => 'Batch notifications, time-block the hard tasks first, and treat calendar gaps as part of the job — not slack to fill.',
        ],
        [
            'id' => 'onboarding-contractors',
            'title' => 'Onboarding freelancers so projects start fast',
            'blurb' => 'Share context, access, and success criteria on day one; a short Loom and a living doc beat a fifty-slide deck.',
        ],
    ];
}
