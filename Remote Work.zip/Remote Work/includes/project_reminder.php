<?php
declare(strict_types=1);

/**
 * Build MySQL datetime from optional HTML date + time fields (date required for any reminder).
 */
function project_parse_reminder_from_post(array $post): ?string
{
    $date = trim((string) ($post['reminder_date'] ?? ''));
    if ($date === '') {
        return null;
    }
    $time = trim((string) ($post['reminder_time'] ?? ''));
    if ($time === '') {
        $time = '09:00';
    }
    $combined = $date . ' ' . $time;
    $ts = strtotime($combined);

    return $ts !== false ? date('Y-m-d H:i:s', $ts) : null;
}

/** @return array{date: string, time: string} */
function project_reminder_split(?string $dbDatetime): array
{
    if ($dbDatetime === null || $dbDatetime === '') {
        return ['date' => '', 'time' => ''];
    }
    try {
        $dt = new DateTimeImmutable($dbDatetime);

        return ['date' => $dt->format('Y-m-d'), 'time' => $dt->format('H:i')];
    } catch (Throwable) {
        return ['date' => '', 'time' => ''];
    }
}

function project_format_reminder_display(?string $dbDatetime): string
{
    if ($dbDatetime === null || $dbDatetime === '') {
        return '';
    }
    try {
        return (new DateTimeImmutable($dbDatetime))->format('D, j M Y \a\t g:i A');
    } catch (Throwable) {
        return (string) $dbDatetime;
    }
}
