<?php
declare(strict_types=1);

/**
 * Supported payment gateways and checkout helpers (demo-ready; wire live keys in config.php).
 *
 * @return array<string, array<string, mixed>>
 */
function payment_gateway_catalog(): array
{
    return [
        'razorpay' => [
            'name' => 'Razorpay',
            'description' => 'India-first gateway for cards, UPI, and netbanking.',
            'icon' => 'fa-bolt',
            'methods' => ['card', 'upi', 'bank'],
            'currencies' => ['INR'],
            'configured' => payment_gateway_has_credentials('razorpay'),
        ],
        'stripe' => [
            'name' => 'Stripe',
            'description' => 'Global payments for cards and bank debits.',
            'icon' => 'fa-stripe-s',
            'methods' => ['card', 'bank'],
            'currencies' => ['INR', 'USD', 'EUR'],
            'configured' => payment_gateway_has_credentials('stripe'),
        ],
        'paypal' => [
            'name' => 'PayPal',
            'description' => 'Pay with PayPal balance or linked cards worldwide.',
            'icon' => 'fa-paypal',
            'methods' => ['paypal'],
            'currencies' => ['USD', 'INR', 'EUR'],
            'configured' => payment_gateway_has_credentials('paypal'),
        ],
        'payu' => [
            'name' => 'PayU',
            'description' => 'Popular Indian gateway for cards, UPI, and wallets.',
            'icon' => 'fa-indian-rupee-sign',
            'methods' => ['card', 'upi', 'bank'],
            'currencies' => ['INR'],
            'configured' => payment_gateway_has_credentials('payu'),
        ],
        'cashfree' => [
            'name' => 'Cashfree',
            'description' => 'Fast settlements with UPI, cards, and bank transfer.',
            'icon' => 'fa-money-bill-wave',
            'methods' => ['card', 'upi', 'bank'],
            'currencies' => ['INR'],
            'configured' => payment_gateway_has_credentials('cashfree'),
        ],
    ];
}

function payment_gateway_ids(): array
{
    return array_keys(payment_gateway_catalog());
}

function payment_gateway_is_valid(string $gatewayId): bool
{
    return isset(payment_gateway_catalog()[$gatewayId]);
}

function payment_gateway_default(): string
{
    $default = defined('PAYMENT_GATEWAY_DEFAULT') ? (string) PAYMENT_GATEWAY_DEFAULT : 'razorpay';

    return payment_gateway_is_valid($default) ? $default : 'razorpay';
}

function payment_gateway_label(string $gatewayId): string
{
    $catalog = payment_gateway_catalog();

    return (string) ($catalog[$gatewayId]['name'] ?? ucfirst($gatewayId));
}

/** @return list<string> */
function payment_gateway_methods(string $gatewayId): array
{
    $catalog = payment_gateway_catalog();
    $methods = $catalog[$gatewayId]['methods'] ?? [];

    return is_array($methods) ? array_values($methods) : [];
}

function payment_gateway_supports_method(string $gatewayId, string $method): bool
{
    return in_array($method, payment_gateway_methods($gatewayId), true);
}

function payment_billing_method_label(string $method): string
{
    return match ($method) {
        'card' => 'Card',
        'upi' => 'UPI',
        'bank' => 'Bank transfer',
        'paypal' => 'PayPal',
        default => ucfirst($method),
    };
}

function payment_gateway_has_credentials(string $gatewayId): bool
{
    return match ($gatewayId) {
        'razorpay' => defined('RAZORPAY_KEY_ID') && RAZORPAY_KEY_ID !== ''
            && defined('RAZORPAY_KEY_SECRET') && RAZORPAY_KEY_SECRET !== '',
        'stripe' => defined('STRIPE_SECRET_KEY') && STRIPE_SECRET_KEY !== '',
        'paypal' => defined('PAYPAL_CLIENT_ID') && PAYPAL_CLIENT_ID !== '',
        'payu' => defined('PAYU_MERCHANT_KEY') && PAYU_MERCHANT_KEY !== '',
        'cashfree' => defined('CASHFREE_APP_ID') && CASHFREE_APP_ID !== '',
        default => false,
    };
}

function payment_gateway_mode_label(string $gatewayId): string
{
    return payment_gateway_has_credentials($gatewayId) ? 'Live ready' : 'Demo mode';
}

function payment_gateway_resolve(string $gatewayId, string $billingMethod): array
{
    $gatewayId = payment_gateway_is_valid($gatewayId) ? $gatewayId : payment_gateway_default();
    $allowedMethods = payment_gateway_methods($gatewayId);
    if (!in_array($billingMethod, $allowedMethods, true)) {
        $billingMethod = $allowedMethods[0] ?? 'card';
    }

    return ['gateway' => $gatewayId, 'method' => $billingMethod];
}

function payment_gateway_create_topup(PDO $pdo, int $userId, float $amount, string $gatewayId, string $billingMethod): string
{
    $ref = strtoupper($gatewayId) . '-' . date('YmdHis') . '-' . bin2hex(random_bytes(3));
    $stmt = $pdo->prepare(
        "INSERT INTO wallet_topups (user_id, amount, gateway, billing_method, transaction_ref, status)
         VALUES (?, ?, ?, ?, ?, 'completed')"
    );
    $stmt->execute([$userId, $amount, $gatewayId, $billingMethod, $ref]);

    return $ref;
}
