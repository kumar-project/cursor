<?php
declare(strict_types=1);

require_once __DIR__ . '/../config.php';

/**
 * Notify a client by email that their account was approved (UTF-8 plain text).
 *
 * @return bool True if PHP mail() reported success (depends on server mail / php.ini).
 */
function mail_notify_client_approved(string $toEmail, string $clientName): bool
{
    if (!MAIL_NOTIFICATIONS_ENABLED) {
        return false;
    }

    $toEmail = trim($toEmail);
    if ($toEmail === '' || !filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    $fromAddr = trim((string) MAIL_FROM_ADDRESS);
    if ($fromAddr === '' || !filter_var($fromAddr, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    $fromName = trim((string) MAIL_FROM_NAME);
    if ($fromName === '') {
        $fromName = APP_NAME;
    }

    $clientName = trim($clientName);
    if ($clientName === '') {
        $clientName = 'there';
    }

    $app = APP_NAME;
    $loginPath = rtrim((string) BASE_URL, '/') . '/login.php';
    $host = isset($_SERVER['HTTP_HOST']) && is_string($_SERVER['HTTP_HOST']) ? trim($_SERVER['HTTP_HOST']) : '';
    if ($host !== '' && $loginPath !== '') {
        $https = !empty($_SERVER['HTTPS']) && (string) $_SERVER['HTTPS'] !== 'off';
        $loginHint = ($https ? 'https://' : 'http://') . $host . $loginPath;
    } else {
        $loginHint = $loginPath !== '' ? $loginPath : 'the site login page';
    }

    $subject = $app . ': Your client account is approved';
    $body = "Hi {$clientName},\r\n\r\n"
        . "Good news — your {$app} client account has been approved. You can now sign in and post projects, assign work, and use all client features.\r\n\r\n"
        . "Log in: {$loginHint}\r\n\r\n"
        . "If you did not register for this service, you can ignore this message.\r\n\r\n"
        . "— {$app} team\r\n";

    $fromHeader = mail_notify_format_from_header($fromName, $fromAddr);
    $headers = [
        'MIME-Version: 1.0',
        'Content-Type: text/plain; charset=UTF-8',
        'Content-Transfer-Encoding: 8bit',
        'From: ' . $fromHeader,
    ];

    return @mail($toEmail, $subject, $body, implode("\r\n", $headers));
}

function mail_notify_format_from_header(string $name, string $email): string
{
    if (preg_match('/[\r\n"]/', $name)) {
        $name = preg_replace('/[\r\n"]+/', ' ', $name) ?? $name;
    }
    if (preg_match('/[^\x20-\x7E]/', $name)) {
        if (function_exists('mb_encode_mimeheader')) {
            $name = mb_encode_mimeheader($name, 'UTF-8', 'B', "\r\n");
        } else {
            $name = APP_NAME;
        }
    }

    return sprintf('"%s" <%s>', addcslashes($name, '"\\'), $email);
}
