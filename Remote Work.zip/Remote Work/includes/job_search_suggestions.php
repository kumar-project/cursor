<?php
declare(strict_types=1);

require_once __DIR__ . '/skills_catalog.php';

/** @return list<string> */
function nk_split_skill_qual_tokens(string $blob): array
{
    $blob = preg_replace('/\r\n|\r|\n/', ',', $blob) ?? '';
    $parts = preg_split('/\s*,\s*/', $blob) ?: [];
    $out = [];
    foreach ($parts as $p) {
        $t = trim((string) $p);
        if (strlen($t) >= 2 && strlen($t) <= 96) {
            $out[] = $t;
        }
    }

    return $out;
}

/**
 * Distinct tokens from client-entered project skills_required and qualifications.
 *
 * @return list<string>
 */
function nk_project_skill_qualification_suggestions(?PDO $pdo = null): array
{
    $pdo = $pdo ?? db();
    $seen = [];
    try {
        $stmt = $pdo->query(
            'SELECT skills_required, qualifications FROM projects
             WHERE COALESCE(skills_required, \'\') <> \'\' OR COALESCE(qualifications, \'\') <> \'\''
        );
        if (!$stmt) {
            return [];
        }
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            foreach (['skills_required', 'qualifications'] as $col) {
                $raw = trim((string) ($row[$col] ?? ''));
                if ($raw === '') {
                    continue;
                }
                if ($col === 'skills_required') {
                    foreach (nk_skills_split_tokens($raw) as $tok) {
                        $key = function_exists('mb_strtolower') ? mb_strtolower($tok, 'UTF-8') : strtolower($tok);
                        if (!isset($seen[$key])) {
                            $seen[$key] = $tok;
                        }
                    }
                    continue;
                }
                foreach (nk_split_skill_qual_tokens($raw) as $tok) {
                    $key = function_exists('mb_strtolower') ? mb_strtolower($tok, 'UTF-8') : strtolower($tok);
                    if (!isset($seen[$key])) {
                        $seen[$key] = $tok;
                    }
                }
            }
        }
    } catch (Throwable) {
        return [];
    }
    $list = array_values($seen);
    sort($list, SORT_NATURAL | SORT_FLAG_CASE);

    return array_slice($list, 0, 300);
}
