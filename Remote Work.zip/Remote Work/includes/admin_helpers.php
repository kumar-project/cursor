<?php
declare(strict_types=1);

/** Human-readable profile codes for the admin user directory. */
function admin_label_remote(?string $v): string
{
    $v = $v !== null ? trim($v) : '';

    return match ($v) {
        '100_remote' => '100% remote',
        'hybrid' => 'Hybrid',
        'option_remote' => 'Optional remote',
        '' => '',
        default => $v,
    };
}

function admin_label_availability(?string $v): string
{
    $v = $v !== null ? trim($v) : '';

    return match ($v) {
        'now' => 'Available now',
        'month' => 'Within a month',
        'browsing' => 'Just browsing',
        '' => '',
        default => $v,
    };
}
