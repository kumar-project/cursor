<?php
declare(strict_types=1);

function nk_skills_max_items(): int
{
    return 50;
}

function nk_skills_max_token_length(): int
{
    return 80;
}

function nk_skills_max_blob_length(): int
{
    return 8000;
}

/** @return list<string> */
function nk_default_project_skills(): array
{
    return [
        'PHP', 'JavaScript', 'TypeScript', 'Python', 'Java', 'C#', 'Go', 'Ruby', 'Swift', 'Kotlin',
        'HTML', 'CSS', 'Tailwind CSS', 'SASS',
        'React', 'Vue.js', 'Angular', 'Next.js',
        'Node.js', 'Express', 'Laravel', 'Symfony', 'Django', 'Flask',
        'MySQL', 'PostgreSQL', 'MongoDB', 'Redis',
        'REST APIs', 'GraphQL', 'Microservices',
        'Docker', 'Kubernetes', 'CI/CD',
        'AWS', 'Azure', 'Google Cloud',
        'Git', 'Linux', 'Bash',
        'UI design', 'UX research', 'Figma', 'Adobe XD',
        'SEO', 'Content writing',
        'Data analysis', 'Machine learning', 'TensorFlow',
        'WordPress', 'Shopify',
        'Project management', 'Agile', 'Scrum',
    ];
}

/**
 * One required skill with minimum experience.
 *
 * @return array{name: string, years: int, months: int}
 */
function nk_skill_entry(string $name, int $years = 0, int $months = 0): array
{
    $name = trim($name);
    $maxLen = nk_skills_max_token_length();
    if (strlen($name) > $maxLen) {
        $name = substr($name, 0, $maxLen);
    }
    $years = max(0, min(50, $years));
    $months = max(0, min(11, $months));

    return ['name' => $name, 'years' => $years, 'months' => $months];
}

/** @param array<string, mixed> $row */
function nk_skill_entry_from_array(array $row): ?array
{
    $name = trim((string) ($row['name'] ?? ''));
    if ($name === '') {
        return null;
    }

    return nk_skill_entry($name, (int) ($row['years'] ?? 0), (int) ($row['months'] ?? 0));
}

/**
 * Parse stored skills_required (JSON array or legacy comma-separated names).
 *
 * @return list<array{name: string, years: int, months: int}>
 */
function nk_skills_parse_blob(?string $blob): array
{
    if ($blob === null) {
        return [];
    }
    $blob = trim($blob);
    if ($blob === '') {
        return [];
    }

    if ($blob[0] === '[') {
        try {
            $decoded = json_decode($blob, true, 512, JSON_THROW_ON_ERROR);
        } catch (Throwable) {
            $decoded = null;
        }
        if (is_array($decoded)) {
            $out = [];
            foreach ($decoded as $item) {
                if (is_string($item)) {
                    $entry = nk_skill_entry($item, 0, 0);
                } elseif (is_array($item)) {
                    $entry = nk_skill_entry_from_array($item);
                    if ($entry === null) {
                        continue;
                    }
                } else {
                    continue;
                }
                $out[] = $entry;
            }

            return nk_skills_dedupe_entries($out);
        }
    }

    $legacy = nk_skills_split_legacy_tokens($blob);

    return array_map(static fn (string $name): array => nk_skill_entry($name, 0, 0), $legacy);
}

/** @return list<string> */
function nk_skills_split_legacy_tokens(?string $blob): array
{
    if ($blob === null || trim($blob) === '') {
        return [];
    }
    $blob = preg_replace('/\r\n|\r|\n/', ',', $blob) ?? '';
    $parts = preg_split('/\s*,\s*/', $blob) ?: [];
    $maxLen = nk_skills_max_token_length();
    $out = [];
    foreach ($parts as $p) {
        $t = trim((string) $p);
        if ($t === '' || strlen($t) > $maxLen) {
            continue;
        }
        $out[] = $t;
    }

    return $out;
}

/** @return list<string> Skill names only (matching, search, tags). */
function nk_skills_split_tokens(?string $blob): array
{
    $names = [];
    foreach (nk_skills_parse_blob($blob) as $entry) {
        $names[] = $entry['name'];
    }

    return $names;
}

/**
 * @param list<array{name: string, years: int, months: int}> $entries
 * @return list<array{name: string, years: int, months: int}>
 */
function nk_skills_dedupe_entries(array $entries): array
{
    $seen = [];
    $out = [];
    foreach ($entries as $entry) {
        $normalized = nk_skill_entry_from_array($entry);
        if ($normalized === null) {
            continue;
        }
        $key = function_exists('mb_strtolower')
            ? mb_strtolower($normalized['name'], 'UTF-8')
            : strtolower($normalized['name']);
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $out[] = $normalized;
    }

    return $out;
}

/** @param list<array{name: string, years: int, months: int}> $entries */
function nk_skills_serialize_entries(array $entries): ?string
{
    $entries = nk_skills_dedupe_entries($entries);
    $maxItems = nk_skills_max_items();
    if (count($entries) > $maxItems) {
        $entries = array_slice($entries, 0, $maxItems);
    }
    if ($entries === []) {
        return null;
    }
    $json = json_encode(array_values($entries), JSON_UNESCAPED_UNICODE);
    if ($json === false || strlen($json) > nk_skills_max_blob_length()) {
        return null;
    }

    return $json;
}

/** @param array{name: string, years: int, months: int} $entry */
function nk_skills_experience_label(array $entry): string
{
    $years = (int) ($entry['years'] ?? 0);
    $months = (int) ($entry['months'] ?? 0);
    if ($years === 0 && $months === 0) {
        return 'Any experience';
    }
    $parts = [];
    if ($years > 0) {
        $parts[] = $years . ' yr' . ($years === 1 ? '' : 's');
    }
    if ($months > 0) {
        $parts[] = $months . ' mo';
    }

    return implode(' ', $parts);
}

/** @param array{name: string, years: int, months: int} $entry */
function nk_skills_display_label(array $entry): string
{
    $exp = nk_skills_experience_label($entry);
    if ($exp === 'Any experience') {
        return $entry['name'];
    }

    return $entry['name'] . ' · ' . $exp;
}

function nk_skills_format_summary(?string $blob, int $maxItems = 3): string
{
    $labels = [];
    foreach (nk_skills_parse_blob($blob) as $entry) {
        $labels[] = nk_skills_display_label($entry);
    }
    if ($labels === []) {
        return '';
    }
    $slice = array_slice($labels, 0, max(1, $maxItems));
    $text = implode(', ', $slice);
    if (count($labels) > count($slice)) {
        $text .= '…';
    }

    return $text;
}

/** @param list<string> $tokens */
function nk_skills_join(array $tokens): string
{
    $clean = nk_skills_dedupe($tokens);

    return implode(', ', $clean);
}

/** @param list<string> $tokens @return list<string> */
function nk_skills_dedupe(array $tokens): array
{
    $seen = [];
    $out = [];
    foreach ($tokens as $t) {
        $t = trim((string) $t);
        if ($t === '') {
            continue;
        }
        $key = function_exists('mb_strtolower') ? mb_strtolower($t, 'UTF-8') : strtolower($t);
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $out[] = $t;
    }

    return $out;
}

/** @return list<string> */
function nk_skills_catalog_from_projects(?PDO $pdo = null): array
{
    $pdo = $pdo ?? db();
    $seen = [];
    try {
        $stmt = $pdo->query('SELECT skills_required FROM projects WHERE COALESCE(skills_required, \'\') <> \'\'');
        if (!$stmt) {
            return [];
        }
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            foreach (nk_skills_split_tokens((string) ($row['skills_required'] ?? '')) as $tok) {
                $key = function_exists('mb_strtolower') ? mb_strtolower($tok, 'UTF-8') : strtolower($tok);
                if (!isset($seen[$key])) {
                    $seen[$key] = $tok;
                }
            }
        }
    } catch (Throwable) {
        return [];
    }

    return array_values($seen);
}

/**
 * Preset plus skills previously saved on projects (for dropdown options).
 *
 * @return list<string>
 */
function nk_project_skills_dropdown_options(?PDO $pdo = null): array
{
    $seen = [];
    foreach (nk_default_project_skills() as $s) {
        $key = function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
        $seen[$key] = $s;
    }
    foreach (nk_skills_catalog_from_projects($pdo) as $s) {
        $key = function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
        if (!isset($seen[$key])) {
            $seen[$key] = $s;
        }
    }
    $list = array_values($seen);
    sort($list, SORT_NATURAL | SORT_FLAG_CASE);

    return $list;
}

/**
 * Normalize POSTed skills (JSON array with experience, or legacy comma-separated names).
 */
function nk_normalize_skills_post(?string $raw): ?string
{
    if ($raw === null) {
        return null;
    }
    $raw = trim($raw);
    if ($raw === '') {
        return null;
    }

    if ($raw[0] === '[') {
        try {
            $decoded = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
        } catch (Throwable) {
            return null;
        }
        if (!is_array($decoded)) {
            return null;
        }
        $entries = [];
        foreach ($decoded as $item) {
            if (is_string($item)) {
                $entries[] = nk_skill_entry($item, 0, 0);
            } elseif (is_array($item)) {
                $entry = nk_skill_entry_from_array($item);
                if ($entry !== null) {
                    $entries[] = $entry;
                }
            }
        }

        return nk_skills_serialize_entries($entries);
    }

    $tokens = nk_skills_dedupe(nk_skills_split_legacy_tokens($raw));
    $entries = array_map(static fn (string $name): array => nk_skill_entry($name, 0, 0), $tokens);

    return nk_skills_serialize_entries($entries);
}
