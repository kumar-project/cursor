<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';

function current_user(): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }

    $stmt = db()->prepare('SELECT id, name, email, role, skills, portfolio, wallet_balance, avg_rating FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    return $user ?: null;
}

function require_login(): void
{
    if (!current_user()) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

function require_role(string $role): void
{
    require_login();
    $user = current_user();
    if (!$user || $user['role'] !== $role) {
        http_response_code(403);
        echo 'Forbidden';
        exit;
    }
}

/** Admins and super-admins: platform staff (not end clients or freelancers). */
function is_platform_staff(?array $user): bool
{
    if ($user === null) {
        return false;
    }
    return in_array($user['role'], ['admin', 'super_admin'], true);
}

/** Full control of clients, freelancers, and the admin panel. */
function require_privileged(): void
{
    require_login();
    $user = current_user();
    if (!$user || !is_platform_staff($user)) {
        http_response_code(403);
        echo 'Access denied. This area is for platform staff only. Log in with a Super Admin account.';
        exit;
    }
}

function can_access_client_portal(?array $user): bool
{
    if ($user === null) {
        return false;
    }
    return $user['role'] === 'client' || is_platform_staff($user);
}

function can_access_freelancer_portal(?array $user): bool
{
    if ($user === null) {
        return false;
    }
    return $user['role'] === 'freelancer' || is_platform_staff($user);
}

function require_client_portal(): void
{
    require_login();
    $user = current_user();
    if (!$user || !can_access_client_portal($user)) {
        http_response_code(403);
        echo 'Forbidden';
        exit;
    }
}

function require_freelancer_portal(): void
{
    require_login();
    $user = current_user();
    if (!$user || !can_access_freelancer_portal($user)) {
        http_response_code(403);
        echo 'Forbidden';
        exit;
    }
}

/** Client-side project actions (owner or platform staff). */
function can_manage_project_as_client(array $user, array $project): bool
{
    if (is_platform_staff($user)) {
        return true;
    }
    return (int) $user['id'] === (int) ($project['user_id'] ?? $project['client_id'] ?? 0);
}

/**
 * Freelancer actions on a project (assigned person or platform staff).
 * $project must include assigned_freelancer_id.
 */
function can_act_as_assigned_freelancer(array $user, array $project): bool
{
    if (is_platform_staff($user)) {
        return !empty($project['assigned_freelancer_id']);
    }
    return (int) $user['id'] === (int) ($project['assigned_freelancer_id'] ?? 0) && $user['role'] === 'freelancer';
}

function can_submit_bid(array $user, array $project): bool
{
    if ($project['status'] !== 'open') {
        return false;
    }
    return $user['role'] === 'freelancer' || is_platform_staff($user);
}

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

