<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';

function current_user(): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }

    $stmt = db()->prepare(
        'SELECT id, name, mobile, email, role, skills, portfolio, wallet_balance, avg_rating,
                remote_work_type, availability_timeline, freelancer_onboarding_skipped, cv_file_path,
                client_approved
         FROM users WHERE id = ?'
    );
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    return $user ?: null;
}

function require_login(): void
{
    if (!current_user()) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

function require_role(string $role): void
{
    require_login();
    $user = current_user();
    if (!$user || $user['role'] !== $role) {
        http_response_code(403);
        echo 'Forbidden';
        exit;
    }
}

/** Admins and super-admins: platform staff (not end clients or freelancers). */
function is_platform_staff(?array $user): bool
{
    if ($user === null) {
        return false;
    }
    return in_array($user['role'], ['admin', 'super_admin'], true);
}

/** Super Admin only (client activation and other restricted actions). */
function is_super_admin(?array $user): bool
{
    return $user !== null && ($user['role'] ?? '') === 'super_admin';
}

/** Full control of clients, freelancers, and the admin panel. */
function require_privileged(): void
{
    require_login();
    $user = current_user();
    if (!$user || !is_platform_staff($user)) {
        http_response_code(403);
        echo 'Access denied. This area is for platform staff only. Log in with a Super Admin account.';
        exit;
    }
}

/** Client accounts activated by platform staff (self-registered clients start pending). */
function client_account_approved(?array $user): bool
{
    if ($user === null || ($user['role'] ?? '') !== 'client') {
        return true;
    }

    return (int) ($user['client_approved'] ?? 0) === 1;
}

function client_account_pending(?array $user): bool
{
    return $user !== null
        && ($user['role'] ?? '') === 'client'
        && !client_account_approved($user);
}

/**
 * Block pending clients from dashboard, payments, etc. Staff and freelancers pass through.
 */
function require_active_client_session(): void
{
    require_login();
    $user = current_user();
    if (client_account_pending($user)) {
        header('Location: ' . BASE_URL . '/account_pending.php');
        exit;
    }
}

function can_access_client_portal(?array $user): bool
{
    if ($user === null) {
        return false;
    }
    if (is_platform_staff($user)) {
        return true;
    }

    return ($user['role'] ?? '') === 'client' && client_account_approved($user);
}

function can_access_freelancer_portal(?array $user): bool
{
    if ($user === null) {
        return false;
    }
    return $user['role'] === 'freelancer' || is_platform_staff($user);
}

function require_client_portal(): void
{
    require_login();
    $user = current_user();
    if (client_account_pending($user)) {
        header('Location: ' . BASE_URL . '/account_pending.php');
        exit;
    }
    if (!$user || !can_access_client_portal($user)) {
        http_response_code(403);
        echo 'Forbidden';
        exit;
    }
}

function require_freelancer_portal(): void
{
    require_login();
    $user = current_user();
    if (!$user || !can_access_freelancer_portal($user)) {
        http_response_code(403);
        echo 'Forbidden';
        exit;
    }
}

/** Freelancer end-users only: incomplete prefs and not skipped. Staff always false. */
function freelancer_needs_onboarding(?array $user): bool
{
    if ($user === null || $user['role'] !== 'freelancer' || is_platform_staff($user)) {
        return false;
    }
    if ((int) ($user['freelancer_onboarding_skipped'] ?? 0) !== 0) {
        return false;
    }

    return empty($user['remote_work_type']) || empty($user['availability_timeline']);
}

/** Client-side project actions (owner or platform staff). */
function can_manage_project_as_client(array $user, array $project): bool
{
    if (is_platform_staff($user)) {
        return true;
    }
    if (($user['role'] ?? '') === 'client' && !client_account_approved($user)) {
        return false;
    }

    return (int) $user['id'] === (int) ($project['user_id'] ?? $project['client_id'] ?? 0);
}

/**
 * Freelancer actions on a project (assigned person or platform staff).
 * $project must include assigned_freelancer_id.
 */
function can_act_as_assigned_freelancer(array $user, array $project): bool
{
    if (is_platform_staff($user)) {
        return !empty($project['assigned_freelancer_id']);
    }
    return (int) $user['id'] === (int) ($project['assigned_freelancer_id'] ?? 0) && $user['role'] === 'freelancer';
}

function can_submit_bid(array $user, array $project): bool
{
    if ($project['status'] !== 'open') {
        return false;
    }
    return $user['role'] === 'freelancer' || is_platform_staff($user);
}

/**
 * Project chat: client owner, assigned freelancer, freelancers who have bid, or platform staff.
 * $project must include id, user_id, assigned_freelancer_id.
 */
function can_access_project_chat(array $user, array $project): bool
{
    if (is_platform_staff($user)) {
        return true;
    }
    $uid = (int) $user['id'];
    if ($uid === (int) ($project['user_id'] ?? $project['client_id'] ?? 0)) {
        return client_account_approved($user);
    }
    $assignedId = (int) ($project['assigned_freelancer_id'] ?? 0);
    if ($assignedId > 0 && $uid === $assignedId) {
        return true;
    }
    if (($user['role'] ?? '') !== 'freelancer') {
        return false;
    }
    $projectId = (int) ($project['id'] ?? 0);
    if ($projectId <= 0) {
        return false;
    }
    $stmt = db()->prepare('SELECT 1 FROM bids WHERE project_id = ? AND freelancer_id = ? LIMIT 1');
    $stmt->execute([$projectId, $uid]);

    return (bool) $stmt->fetchColumn();
}

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

