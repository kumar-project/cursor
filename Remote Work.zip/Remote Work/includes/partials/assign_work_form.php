<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/project_reminder.php';
require_once dirname(__DIR__) . '/assign_work_data.php';
require_once dirname(__DIR__) . '/skills_catalog.php';

/** @var array $aw_projects @var array $aw_freelancers @var bool $aw_staff @var int $aw_selectedProjectId @var int $aw_selectedFreelancerId @var string $aw_messageValue @var string $aw_error @var string $aw_success @var string $aw_formAction @var string $aw_project_change_href_base */
$aw_project_change_href_base = isset($aw_project_change_href_base) ? (string) $aw_project_change_href_base : (string) $aw_formAction;

$aw_required_skills = '';
foreach ($aw_projects as $aw_proj_row) {
    if ((int) ($aw_proj_row['id'] ?? 0) === (int) $aw_selectedProjectId) {
        $aw_required_skills = trim((string) ($aw_proj_row['skills_required'] ?? ''));
        break;
    }
}
?>
<div class="assign-work-form">
    <?php if (!empty($aw_error)): ?><p class="danger"><?= h($aw_error) ?></p><?php endif; ?>
    <?php if (!empty($aw_success)): ?><p class="success"><?= h($aw_success) ?></p><?php endif; ?>
    <form method="post" action="<?= h($aw_formAction) ?>" enctype="multipart/form-data" class="assign-work-form__inner">
        <input type="hidden" name="from" value="<?= h($aw_from) ?>">
        <label for="aw_project_id">Project</label>
        <select id="aw_project_id" name="project_id" required onchange='var v=this.value;if(v){window.location.href=<?= json_encode($aw_project_change_href_base, JSON_HEX_APOS | JSON_HEX_AMP) ?>+"?project_id="+encodeURIComponent(v);}'>
            <option value="">Select project</option>
            <?php foreach ($aw_projects as $project): ?>
                <?php
                $rem = !empty($project['reminder_at']) ? ' — ' . project_format_reminder_display((string) $project['reminder_at']) : '';
                $sk = '';
                if (!empty($project['skills_required'])) {
                    $s = nk_skills_format_summary((string) $project['skills_required'], 2);
                    if ($s !== '') {
                        $sk = ' — Skills: ' . $s;
                    }
                }
                $skillNamesForMatch = nk_skills_join(nk_skills_split_tokens((string) ($project['skills_required'] ?? '')));
                ?>
                <option value="<?= (int) $project['id'] ?>" data-skills="<?= h($skillNamesForMatch) ?>" <?= $aw_selectedProjectId === (int) $project['id'] ? 'selected' : '' ?>>
                    <?= h($project['title']) ?> (<?= h($project['status']) ?>)<?= $aw_staff && !empty($project['client_name']) ? ' — ' . h($project['client_name']) : '' ?><?= h($rem) ?><?= h($sk) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="aw_freelancer_id">Freelancer</label>
        <select id="aw_freelancer_id" name="freelancer_id" required>
            <option value="">Select freelancer</option>
            <?php foreach ($aw_freelancers as $freelancer): ?>
                <?php
                $freelancerSkillsText = trim((string) ($freelancer['skills'] ?? ''));
                $freelancerSkillsLabel = $freelancerSkillsText !== '' ? ' — Skills: ' . $freelancerSkillsText : ' — Skills: (not set on profile)';
                $fits = $aw_required_skills !== '' && assign_work_skills_match($aw_required_skills, $freelancerSkillsText);
                $fitLabel = $fits ? ' — suggested: overlaps project skills' : '';
                ?>
                <option value="<?= (int)$freelancer['id'] ?>" data-skills="<?= h((string) ($freelancer['skills'] ?? '')) ?>" <?= $aw_selectedFreelancerId === (int)$freelancer['id'] ? 'selected' : '' ?>>
                    <?= h($freelancer['name']) ?> - Rating <?= h((string)$freelancer['avg_rating']) ?><?= h($freelancerSkillsLabel) ?><?= h($fitLabel) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <?php if ($aw_required_skills !== ''): ?>
            <p class="muted" style="margin-top:-8px;">Freelancers whose profile skills overlap the project are listed first (optional hint). You may assign any freelancer you choose.</p>
        <?php endif; ?>

        <label for="aw_message">Instruction message</label>
        <textarea id="aw_message" name="message" rows="5" placeholder="Task details for the freelancer..." required><?= h($aw_messageValue) ?></textarea>

        <label for="aw_file">Upload file (optional)</label>
        <input id="aw_file" type="file" name="assignment_file" accept=".pdf,.docx,.jpg,.png,.txt">
        <p class="muted">Types: PDF, docx, jpg, png, txt — max 5MB</p>

        <button type="submit">Assign work</button>
    </form>
</div>
