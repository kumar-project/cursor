<?php
declare(strict_types=1);
/** @var array $aw_projects @var array $aw_freelancers @var bool $aw_staff @var int $aw_selectedProjectId @var int $aw_selectedFreelancerId @var string $aw_messageValue @var string $aw_error @var string $aw_success @var string $aw_formAction */
?>
<div class="assign-work-form">
    <?php if (!empty($aw_error)): ?><p class="danger"><?= h($aw_error) ?></p><?php endif; ?>
    <?php if (!empty($aw_success)): ?><p class="success"><?= h($aw_success) ?></p><?php endif; ?>
    <form method="post" action="<?= h($aw_formAction) ?>" enctype="multipart/form-data" class="assign-work-form__inner">
        <input type="hidden" name="from" value="<?= h($aw_from) ?>">
        <label for="aw_project_id">Project</label>
        <select id="aw_project_id" name="project_id" required>
            <option value="">Select project</option>
            <?php foreach ($aw_projects as $project): ?>
                <option value="<?= (int)$project['id'] ?>" <?= $aw_selectedProjectId === (int)$project['id'] ? 'selected' : '' ?>>
                    <?= h($project['title']) ?> (<?= h($project['status']) ?>)<?= $aw_staff && !empty($project['client_name']) ? ' — ' . h($project['client_name']) : '' ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="aw_freelancer_id">Freelancer</label>
        <select id="aw_freelancer_id" name="freelancer_id" required>
            <option value="">Select freelancer</option>
            <?php foreach ($aw_freelancers as $freelancer): ?>
                <option value="<?= (int)$freelancer['id'] ?>" <?= $aw_selectedFreelancerId === (int)$freelancer['id'] ? 'selected' : '' ?>>
                    <?= h($freelancer['name']) ?> - Rating <?= h((string)$freelancer['avg_rating']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="aw_message">Instruction message</label>
        <textarea id="aw_message" name="message" rows="5" placeholder="Task details for the freelancer..." required><?= h($aw_messageValue) ?></textarea>

        <label for="aw_file">Upload file (optional)</label>
        <input id="aw_file" type="file" name="assignment_file" accept=".pdf,.docx,.jpg,.png,.txt">
        <p class="muted">Types: PDF, docx, jpg, png, txt — max 5MB</p>

        <button type="submit">Assign work</button>
    </form>
</div>
