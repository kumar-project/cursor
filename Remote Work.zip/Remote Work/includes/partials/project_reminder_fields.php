<?php
declare(strict_types=1);
/** @var string $pr_reminder_date @var string $pr_reminder_time */
?>
<fieldset style="border:1px solid var(--nk-border,#e5e7eb);border-radius:8px;padding:12px 14px;margin:0 0 14px;">
    <legend style="font-weight:600;padding:0 6px;">Reminder (optional)</legend>
    <p class="muted" style="margin:0 0 10px;font-size:0.9rem;">Pick a day and time to remind yourself about this project (stored in server time).</p>
    <div class="row">
        <div>
            <label for="pr_reminder_date">Reminder date</label>
            <input id="pr_reminder_date" type="date" name="reminder_date" value="<?= h($pr_reminder_date) ?>">
        </div>
        <div>
            <label for="pr_reminder_time">Reminder time</label>
            <input id="pr_reminder_time" type="time" name="reminder_time" value="<?= h($pr_reminder_time) ?>">
        </div>
    </div>
</fieldset>
