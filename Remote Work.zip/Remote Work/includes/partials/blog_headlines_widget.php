<?php
declare(strict_types=1);

require_once __DIR__ . '/../blog_cms.php';
require_once __DIR__ . '/../blog_headlines.php';

$dbItems = blog_posts_for_widget(5);
?>
<div class="nk-widget">
    <h3 class="nk-widget__title">From the blog</h3>
    <ul class="nk-blog-list nk-blog-list--thumbs">
        <?php if ($dbItems !== []): ?>
            <?php foreach ($dbItems as $nkPost): ?>
                <?php $thumb = $nkPost['thumb_url'] ?? null; ?>
                <li class="nk-blog-list__item">
                    <a class="nk-blog-list__link" href="<?= h(BASE_URL) ?>/blog_post.php?id=<?= (int) $nkPost['id'] ?>">
                        <span class="nk-blog-list__thumb-wrap<?= $thumb ? '' : ' nk-blog-list__thumb-wrap--empty' ?>">
                            <?php if ($thumb): ?>
                                <img class="nk-blog-list__thumb" src="<?= h($thumb) ?>" alt="" width="56" height="56" loading="lazy" decoding="async">
                            <?php endif; ?>
                        </span>
                        <span class="nk-blog-list__headline"><?= h($nkPost['title']) ?></span>
                    </a>
                    <?php if (!empty($nkPost['category_name']) && !empty($nkPost['category_slug'])): ?>
                        <a class="nk-blog-list__category" href="<?= h(BASE_URL) ?>/blog.php?category=<?= h(urlencode((string) $nkPost['category_slug'])) ?>"><?= h((string) $nkPost['category_name']) ?></a>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        <?php else: ?>
            <?php foreach (nk_blog_headlines() as $nkPost): ?>
                <li class="nk-blog-list__item nk-blog-list__item--placeholder">
                    <span class="nk-blog-list__link nk-blog-list__link--static">
                        <span class="nk-blog-list__thumb-wrap nk-blog-list__thumb-wrap--empty" aria-hidden="true"></span>
                        <span class="nk-blog-list__headline nk-blog-list__placeholder"><?= h($nkPost['title']) ?></span>
                    </span>
                </li>
            <?php endforeach; ?>
            <li class="nk-blog-list__hint muted" style="font-size:0.8rem; padding-top:4px;">Add published posts in Blog CMS to link headlines here.</li>
        <?php endif; ?>
    </ul>
    <a class="nk-widget__link" href="<?= h(BASE_URL) ?>/blog.php">Read articles</a>
</div>
