<?php
declare(strict_types=1);

require_once __DIR__ . '/../project_payment.php';
require_once __DIR__ . '/../payment_gateways.php';

/** @var array $user */
/** @var float $wallet */
/** @var array<int, array<string, mixed>> $recentPayments */
/** @var array<int, array<string, mixed>> $recentConfirmations */
/** @var array<int, array<string, mixed>> $recentTopups */
/** @var string $billingMethod */
/** @var string $billingGateway */
/** @var array<string, array<string, mixed>> $gatewayCatalog */

$resolved = payment_gateway_resolve($billingGateway ?? payment_gateway_default(), $billingMethod ?? 'card');
$billingGateway = $resolved['gateway'];
$billingMethod = $resolved['method'];
$allowedMethods = payment_gateway_methods($billingGateway);

$pendingConfirmations = 0;
foreach ($recentConfirmations as $row) {
    if (empty($row['freelancer_confirmed_at'])) {
        $pendingConfirmations++;
    }
}

$methodIcons = [
    'card' => 'fa-regular fa-credit-card',
    'upi' => 'fa-solid fa-mobile-screen',
    'bank' => 'fa-solid fa-building-columns',
    'paypal' => 'fa-brands fa-paypal',
];
?>
<section class="card settings-card payment-hero payment-hero--billing">
    <span class="payment-hero__eyebrow">Billing &amp; wallet</span>
    <h2>Manage payments with confidence</h2>
    <p>Select a payment gateway, choose how to pay, and add funds to your platform wallet.</p>
</section>

<div class="payment-stats">
    <article class="payment-stat">
        <span class="payment-stat__label">Available balance</span>
        <strong class="payment-stat__value">₹ <?= h(number_format($wallet, 2)) ?></strong>
        <small>Instant use on platform</small>
    </article>
    <article class="payment-stat">
        <span class="payment-stat__label">Active gateway</span>
        <strong class="payment-stat__value payment-stat__value--text"><?= h(payment_gateway_label($billingGateway)) ?></strong>
        <small><?= h(payment_gateway_mode_label($billingGateway)) ?></small>
    </article>
    <article class="payment-stat">
        <span class="payment-stat__label">Pending confirmations</span>
        <strong class="payment-stat__value"><?= (int) $pendingConfirmations ?></strong>
        <small>Project payments awaiting review</small>
    </article>
</div>

<div class="payment-billing-grid">
    <section class="card settings-card payment-billing-panel">
        <div class="payment-billing-panel__head">
            <div>
                <h3>Add funds to wallet</h3>
                <p class="muted">Pick a gateway and payment method. Demo mode credits your wallet instantly.</p>
            </div>
            <a class="payment-secure-badge" href="<?= BASE_URL ?>/payment.php?tab=gateways">
                <i class="fa-solid fa-plug" aria-hidden="true"></i> Manage gateways
            </a>
        </div>

        <form method="post" class="payment-checkout-form" action="<?= BASE_URL ?>/payment.php?tab=billing" id="payment-checkout-form">
            <input type="hidden" name="add_wallet" value="1">

            <fieldset class="payment-gateway-picker">
                <legend>Payment gateway</legend>
                <div class="payment-gateway-picker__options">
                    <?php foreach ($gatewayCatalog as $gatewayId => $gateway): ?>
                        <?php
                        $isActive = $billingGateway === $gatewayId;
                        $methodsJson = htmlspecialchars(json_encode(payment_gateway_methods($gatewayId), JSON_THROW_ON_ERROR), ENT_QUOTES, 'UTF-8');
                        ?>
                        <label class="payment-gateway-option<?= $isActive ? ' is-active' : '' ?>" data-gateway="<?= h($gatewayId) ?>" data-methods="<?= $methodsJson ?>">
                            <input type="radio" name="payment_gateway" value="<?= h($gatewayId) ?>"<?= $isActive ? ' checked' : '' ?>>
                            <span class="payment-gateway-option__icon" aria-hidden="true">
                                <i class="fa-brands <?= h((string) ($gateway['icon'] ?? 'fa-credit-card')) ?>"></i>
                            </span>
                            <span class="payment-gateway-option__text">
                                <strong><?= h((string) ($gateway['name'] ?? $gatewayId)) ?></strong>
                                <small><?= h(payment_gateway_mode_label($gatewayId)) ?></small>
                            </span>
                        </label>
                    <?php endforeach; ?>
                </div>
            </fieldset>

            <fieldset class="payment-method-picker">
                <legend>Payment method</legend>
                <div class="payment-method-picker__options" id="billing-method-options" role="radiogroup" aria-label="Payment method">
                    <?php foreach (['card', 'upi', 'bank', 'paypal'] as $methodId): ?>
                        <?php
                        $supported = in_array($methodId, $allowedMethods, true);
                        $isActive = $billingMethod === $methodId;
                        ?>
                        <label class="payment-method-option<?= $isActive ? ' is-active' : '' ?><?= !$supported ? ' is-disabled' : '' ?>" data-method="<?= h($methodId) ?>"<?= !$supported ? ' hidden' : '' ?>>
                            <input type="radio" name="billing_method" value="<?= h($methodId) ?>"<?= $isActive ? ' checked' : '' ?><?= !$supported ? ' disabled' : '' ?>>
                            <span class="payment-method-option__icon" aria-hidden="true"><i class="<?= h($methodIcons[$methodId] ?? 'fa-solid fa-wallet') ?>"></i></span>
                            <span class="payment-method-option__text">
                                <strong><?= h(payment_billing_method_label($methodId)) ?></strong>
                                <small><?= $methodId === 'paypal' ? 'PayPal account' : 'Via ' . payment_gateway_label($billingGateway) ?></small>
                            </span>
                        </label>
                    <?php endforeach; ?>
                </div>
            </fieldset>

            <label class="payment-amount-label" for="wallet_amount">Amount (INR)</label>
            <div class="payment-amount-row">
                <span class="payment-amount-row__prefix">₹</span>
                <input id="wallet_amount" type="number" name="amount" step="0.01" min="100" max="500000" placeholder="5000" required>
            </div>
            <p class="payment-amount-hint">Minimum ₹100 · Maximum ₹5,00,000 per transaction (demo limits)</p>

            <div class="payment-fields payment-fields--card" data-billing-panel="card"<?= $billingMethod !== 'card' ? ' hidden' : '' ?>>
                <label for="billing_card">Card number</label>
                <div class="payment-input-icon">
                    <input id="billing_card" type="text" inputmode="numeric" autocomplete="cc-number" placeholder="1234 5678 9012 3456" maxlength="19">
                    <span class="payment-input-icon__badge">Encrypted</span>
                </div>
                <div class="row payment-field-row">
                    <div>
                        <label for="billing_exp">Expiry</label>
                        <input id="billing_exp" type="text" inputmode="numeric" autocomplete="cc-exp" placeholder="MM / YY" maxlength="7">
                    </div>
                    <div>
                        <label for="billing_cvv">CVV</label>
                        <input id="billing_cvv" type="password" inputmode="numeric" autocomplete="cc-csc" placeholder="***" maxlength="4">
                    </div>
                </div>
                <label for="billing_name">Name on card</label>
                <input id="billing_name" type="text" autocomplete="cc-name" placeholder="<?= h((string) ($user['name'] ?? '')) ?>">
            </div>

            <div class="payment-fields payment-fields--upi" data-billing-panel="upi"<?= $billingMethod !== 'upi' ? ' hidden' : '' ?>>
                <label for="billing_upi">UPI ID</label>
                <input id="billing_upi" type="text" placeholder="yourname@upi" autocomplete="off">
                <p class="payment-inline-note">Redirect to <?= h(payment_gateway_label($billingGateway)) ?> UPI collect (demo).</p>
            </div>

            <div class="payment-fields payment-fields--bank" data-billing-panel="bank"<?= $billingMethod !== 'bank' ? ' hidden' : '' ?>>
                <label for="billing_account">Account number</label>
                <input id="billing_account" type="text" inputmode="numeric" placeholder="Account number">
                <label for="billing_ifsc">IFSC code</label>
                <input id="billing_ifsc" type="text" placeholder="ABCD0123456" style="text-transform:uppercase;">
            </div>

            <div class="payment-fields payment-fields--paypal" data-billing-panel="paypal"<?= $billingMethod !== 'paypal' ? ' hidden' : '' ?>>
                <label for="billing_paypal_email">PayPal email</label>
                <input id="billing_paypal_email" type="email" placeholder="you@email.com" autocomplete="email">
                <p class="payment-inline-note">You will be redirected to PayPal to approve this top-up (demo).</p>
            </div>

            <div class="payment-checkout-foot">
                <p class="payment-checkout-foot__legal">
                    <i class="fa-solid fa-shield-halved" aria-hidden="true"></i>
                    Processing via <strong id="checkout-gateway-label"><?= h(payment_gateway_label($billingGateway)) ?></strong>.
                    <?= payment_gateway_has_credentials($billingGateway) ? 'Live gateway keys detected.' : 'Demo mode — no external charge.' ?>
                </p>
                <button type="submit" class="payment-checkout-submit">
                    <i class="fa-solid fa-circle-check" aria-hidden="true"></i>
                    Pay with <?= h(payment_gateway_label($billingGateway)) ?>
                </button>
            </div>
        </form>
    </section>

    <aside class="payment-billing-aside">
        <section class="card settings-card payment-trust-card">
            <h4>Gateway partners</h4>
            <ul class="payment-trust-list">
                <?php foreach (array_slice($gatewayCatalog, 0, 5) as $gid => $g): ?>
                    <li>
                        <i class="fa-brands <?= h((string) ($g['icon'] ?? 'fa-credit-card')) ?>" aria-hidden="true"></i>
                        <?= h((string) ($g['name'] ?? $gid)) ?>
                        <span class="payment-gateway-inline-status"><?= h(payment_gateway_mode_label($gid)) ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>
        <section class="card settings-card payment-trust-card payment-trust-card--muted">
            <h4>Need live payments?</h4>
            <p class="muted" style="margin:0 0 10px;font-size:0.88rem;">Add API keys in <code>config.php</code>, then refresh this page.</p>
            <a class="nk-btn nk-btn--ghost" href="<?= BASE_URL ?>/payment.php?tab=gateways">Open gateway settings</a>
        </section>
    </aside>
</div>

<section class="card settings-card payment-ledger">
    <div class="payment-ledger__head">
        <h3>Transaction history</h3>
        <span class="muted">Wallet top-ups, platform payments &amp; project confirmations</span>
    </div>

    <?php if ($recentTopups || $recentPayments || $recentConfirmations): ?>
        <div class="payment-ledger-table-wrap">
            <table class="payment-ledger-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Description</th>
                        <th>Gateway</th>
                        <th>Status</th>
                        <th class="payment-ledger-table__amount">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentTopups as $topup): ?>
                        <tr>
                            <td><?= h(date('d M Y', strtotime((string) ($topup['created_at'] ?? 'now')))) ?></td>
                            <td>
                                <strong>Wallet top-up</strong>
                                <small><?= h(payment_billing_method_label((string) ($topup['billing_method'] ?? ''))) ?></small>
                            </td>
                            <td><?= h(payment_gateway_label((string) ($topup['gateway'] ?? ''))) ?></td>
                            <td><span class="payment-status-pill is-success"><?= h(ucfirst((string) ($topup['status'] ?? 'completed'))) ?></span></td>
                            <td class="payment-ledger-table__amount">₹ <?= h(number_format((float) ($topup['amount'] ?? 0), 2)) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php foreach ($recentPayments as $payment): ?>
                        <?php
                        $payStatus = (string) ($payment['status'] ?? '');
                        $statusClass = match ($payStatus) {
                            'released', 'escrowed' => 'is-success',
                            'refunded' => 'is-muted',
                            default => 'is-pending',
                        };
                        ?>
                        <tr>
                            <td><?= h(date('d M Y', strtotime((string) ($payment['created_at'] ?? 'now')))) ?></td>
                            <td>
                                <strong><?= h((string) ($payment['project_title'] ?? 'Platform payment')) ?></strong>
                                <small><?= (int) ($payment['payer_id'] ?? 0) === (int) $user['id'] ? 'Paid out' : 'Received' ?></small>
                            </td>
                            <td><?= h((string) ($payment['gateway'] ?? '—')) ?></td>
                            <td><span class="payment-status-pill <?= h($statusClass) ?>"><?= h(ucfirst($payStatus ?: 'initiated')) ?></span></td>
                            <td class="payment-ledger-table__amount">₹ <?= h(number_format((float) ($payment['amount'] ?? 0), 2)) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php foreach ($recentConfirmations as $conf): ?>
                        <?php $confirmed = !empty($conf['freelancer_confirmed_at']); ?>
                        <tr>
                            <td><?= h(date('d M Y', strtotime((string) ($conf['client_submitted_at'] ?? 'now')))) ?></td>
                            <td>
                                <strong><?= h((string) ($conf['project_title'] ?? 'Project payment')) ?></strong>
                                <small>Client payment confirmation</small>
                            </td>
                            <td><?= h(project_payment_label('payment_method', (string) ($conf['payment_method'] ?? ''))) ?></td>
                            <td>
                                <span class="payment-status-pill <?= $confirmed ? 'is-success' : 'is-pending' ?>">
                                    <?= $confirmed ? 'Confirmed' : 'Pending' ?>
                                </span>
                            </td>
                            <td class="payment-ledger-table__amount">₹ <?= h(number_format((float) ($conf['payment_amount'] ?? 0), 2)) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p class="payment-ledger-empty muted">No transactions yet. Add funds or complete a project payment to see activity here.</p>
    <?php endif; ?>
</section>

<script>
window.addEventListener('DOMContentLoaded', function () {
    var gatewayOptions = document.querySelectorAll('.payment-gateway-option');
    var methodOptions = document.querySelectorAll('#billing-method-options .payment-method-option');
    var panels = document.querySelectorAll('[data-billing-panel]');
    var gatewayLabel = document.getElementById('checkout-gateway-label');
    var submitBtn = document.querySelector('.payment-checkout-submit');

    if (!gatewayOptions.length) return;

    function parseMethods(node) {
        try {
            return JSON.parse(node.getAttribute('data-methods') || '[]');
        } catch (e) {
            return ['card'];
        }
    }

    function syncMethodVisibility(allowed) {
        var firstAllowed = null;
        methodOptions.forEach(function (label) {
            var method = label.getAttribute('data-method');
            var allowedNow = allowed.indexOf(method) !== -1;
            label.hidden = !allowedNow;
            label.classList.toggle('is-disabled', !allowedNow);
            var input = label.querySelector('input[type="radio"]');
            if (input) {
                input.disabled = !allowedNow;
            }
            if (allowedNow && !firstAllowed) {
                firstAllowed = input;
            }
            if (!allowedNow) {
                input.checked = false;
            }
        });
        var checked = document.querySelector('#billing-method-options input[type="radio"]:checked');
        if (!checked || checked.disabled) {
            if (firstAllowed) {
                firstAllowed.checked = true;
            }
        }
        syncPanels();
    }

    function syncPanels() {
        var selected = document.querySelector('#billing-method-options input[type="radio"]:checked');
        var value = selected ? selected.value : 'card';
        methodOptions.forEach(function (label) {
            if (!label.hidden) {
                var input = label.querySelector('input[type="radio"]');
                label.classList.toggle('is-active', input && input.checked);
            }
        });
        panels.forEach(function (panel) {
            panel.hidden = panel.getAttribute('data-billing-panel') !== value;
        });
    }

    function syncGateway() {
        var selected = document.querySelector('.payment-gateway-option input[type="radio"]:checked');
        if (!selected) return;
        var label = selected.closest('.payment-gateway-option');
        gatewayOptions.forEach(function (opt) {
            opt.classList.toggle('is-active', opt === label);
        });
        var allowed = parseMethods(label);
        var name = label.querySelector('strong');
        if (gatewayLabel && name) {
            gatewayLabel.textContent = name.textContent;
        }
        if (submitBtn && name) {
            submitBtn.innerHTML = '<i class="fa-solid fa-circle-check" aria-hidden="true"></i> Pay with ' + name.textContent;
        }
        syncMethodVisibility(allowed);
    }

    gatewayOptions.forEach(function (label) {
        var input = label.querySelector('input[type="radio"]');
        if (input) {
            input.addEventListener('change', syncGateway);
        }
    });
    methodOptions.forEach(function (label) {
        var input = label.querySelector('input[type="radio"]');
        if (input) {
            input.addEventListener('change', syncPanels);
        }
    });
    syncGateway();
});
</script>
