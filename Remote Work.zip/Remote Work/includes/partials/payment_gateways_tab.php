<?php
declare(strict_types=1);

require_once __DIR__ . '/../payment_gateways.php';

/** @var bool $superAdmin */
$gateways = payment_gateway_catalog();
$defaultGateway = payment_gateway_default();
?>
<section class="card settings-card payment-hero payment-hero--gateways">
    <span class="payment-hero__eyebrow">Payment infrastructure</span>
    <h2>Payment gateways</h2>
    <p>Connect a gateway to accept wallet top-ups and project payments. Add API keys in <code>config.php</code> to switch from demo to live mode.</p>
</section>

<section class="card settings-card">
    <div class="payment-ledger__head">
        <h3>Available gateways</h3>
        <span class="muted">Default: <?= h(payment_gateway_label($defaultGateway)) ?></span>
    </div>

    <div class="payment-gateway-grid">
        <?php foreach ($gateways as $gatewayId => $gateway): ?>
            <?php
            $isConfigured = (bool) ($gateway['configured'] ?? false);
            $methods = is_array($gateway['methods'] ?? null) ? $gateway['methods'] : [];
            ?>
            <article class="payment-gateway-card<?= $gatewayId === $defaultGateway ? ' is-default' : '' ?>">
                <div class="payment-gateway-card__head">
                    <span class="payment-gateway-card__icon" aria-hidden="true">
                        <i class="fa-brands <?= h((string) ($gateway['icon'] ?? 'fa-credit-card')) ?>"></i>
                    </span>
                    <div>
                        <h4><?= h((string) ($gateway['name'] ?? $gatewayId)) ?></h4>
                        <?php if ($gatewayId === $defaultGateway): ?>
                            <span class="payment-gateway-card__tag">Platform default</span>
                        <?php endif; ?>
                    </div>
                    <span class="payment-status-pill <?= $isConfigured ? 'is-success' : 'is-pending' ?>">
                        <?= h(payment_gateway_mode_label($gatewayId)) ?>
                    </span>
                </div>
                <p class="payment-gateway-card__desc"><?= h((string) ($gateway['description'] ?? '')) ?></p>
                <div class="payment-gateway-card__methods">
                    <?php foreach ($methods as $method): ?>
                        <span><?= h(payment_billing_method_label((string) $method)) ?></span>
                    <?php endforeach; ?>
                </div>
                <div class="payment-gateway-card__foot">
                    <a class="nk-link" href="<?= BASE_URL ?>/payment.php?tab=billing&amp;gateway=<?= urlencode($gatewayId) ?>">Use for top-up</a>
                    <?php if ($superAdmin): ?>
                        <span class="muted">Keys in config.php</span>
                    <?php endif; ?>
                </div>
            </article>
        <?php endforeach; ?>
    </div>
</section>

<section class="card settings-card">
    <h3>Configuration checklist</h3>
    <ul class="payment-gateway-checklist">
        <li><strong>Razorpay</strong> — Set <code>RAZORPAY_KEY_ID</code> and <code>RAZORPAY_KEY_SECRET</code></li>
        <li><strong>Stripe</strong> — Set <code>STRIPE_PUBLISHABLE_KEY</code> and <code>STRIPE_SECRET_KEY</code></li>
        <li><strong>PayPal</strong> — Set <code>PAYPAL_CLIENT_ID</code> and <code>PAYPAL_CLIENT_SECRET</code></li>
        <li><strong>PayU</strong> — Set <code>PAYU_MERCHANT_KEY</code> and <code>PAYU_MERCHANT_SALT</code></li>
        <li><strong>Cashfree</strong> — Set <code>CASHFREE_APP_ID</code> and <code>CASHFREE_SECRET_KEY</code></li>
    </ul>
    <p class="muted payment-inline-note">Until keys are added, checkout runs in demo mode and credits the wallet instantly without calling external APIs.</p>
</section>
