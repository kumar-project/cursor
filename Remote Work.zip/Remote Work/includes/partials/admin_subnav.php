<?php
declare(strict_types=1);

/** @var string $nk_admin_nav One of: hub, assign, data, transactions */
$nk_admin_nav = $nk_admin_nav ?? 'hub';
?>
<nav class="admin-subnav" aria-label="Super Admin sections">
    <a class="admin-subnav__link<?= $nk_admin_nav === 'hub' ? ' is-active' : '' ?>" href="<?= BASE_URL ?>/admin.php" <?= $nk_admin_nav === 'hub' ? 'aria-current="page"' : '' ?>>Overview</a>
    <a class="admin-subnav__link<?= $nk_admin_nav === 'assign' ? ' is-active' : '' ?>" href="<?= BASE_URL ?>/admin_assign_work.php" <?= $nk_admin_nav === 'assign' ? 'aria-current="page"' : '' ?>>Assign work</a>
    <a class="admin-subnav__link<?= $nk_admin_nav === 'data' ? ' is-active' : '' ?>" href="<?= BASE_URL ?>/admin_data.php" <?= $nk_admin_nav === 'data' ? 'aria-current="page"' : '' ?>>Users &amp; data</a>
    <?php
    $subnavActor = function_exists('current_user') ? current_user() : null;
    if ($subnavActor && function_exists('is_super_admin') && is_super_admin($subnavActor)):
        ?>
    <a class="admin-subnav__link<?= $nk_admin_nav === 'transactions' ? ' is-active' : '' ?>" href="<?= BASE_URL ?>/admin_transactions.php" <?= $nk_admin_nav === 'transactions' ? 'aria-current="page"' : '' ?>>Transactions</a>
    <?php endif; ?>
    <a class="admin-subnav__link" href="<?= BASE_URL ?>/admin_blog.php">Blog CMS</a>
</nav>
