<?php
declare(strict_types=1);

/** @var string $pr_skills_required @var string $pr_qualifications */
require_once dirname(__DIR__) . '/skills_catalog.php';

$catalogSkills = nk_project_skills_dropdown_options();
$pr_skills_initial_entries = nk_skills_parse_blob((string) $pr_skills_required);
$skills_hidden_value = (string) (nk_skills_serialize_entries($pr_skills_initial_entries) ?? '');
$skills_json_boot = json_encode(
    $pr_skills_initial_entries,
    JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
);
if ($skills_json_boot === false) {
    $skills_json_boot = '[]';
}
?>
<label class="pr-skill-picker-label">Skills required</label>
<div class="pr-skill-picker" role="group" aria-labelledby="pr-skill-picker-heading">
    <span id="pr-skill-picker-heading" class="visually-hidden">Choose required skills and minimum experience</span>
    <input type="hidden" name="skills_required" id="pr_skills_required" value="<?= h($skills_hidden_value) ?>">
    <div class="pr-skill-picker__chips-wrap<?= $pr_skills_initial_entries === [] ? ' pr-skill-picker__chips-wrap--empty' : '' ?>">
        <span class="pr-skill-picker__chips-label">Selected (<span id="pr-skill-picker-count"><?= count($pr_skills_initial_entries) ?></span>)</span>
        <ul class="pr-skill-picker__chips" id="pr-skill-picker-chips" aria-live="polite"></ul>
    </div>

    <div class="pr-skill-picker__controls">
        <div class="pr-skill-picker__col">
            <label class="pr-skill-picker__micro" for="pr-skill-picker-select">Suggested skills</label>
            <select id="pr-skill-picker-select" class="pr-skill-picker__select" autocomplete="off" size="1">
                <option value="">Select a skill to add…</option>
                <?php foreach ($catalogSkills as $opt): ?>
                    <option value="<?= h($opt) ?>"><?= h($opt) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="pr-skill-picker__col pr-skill-picker__col--custom">
            <label class="pr-skill-picker__micro" for="pr-skill-picker-custom-input">Custom skill</label>
            <div class="pr-skill-picker__custom-wrap">
                <input type="text" id="pr-skill-picker-custom-input" class="pr-skill-picker__custom-input" maxlength="<?= (int) nk_skills_max_token_length() ?>" placeholder="Type a skill, then Add" autocomplete="off">
                <button type="button" class="pr-skill-picker__add-btn" id="pr-skill-picker-custom-add">Add</button>
            </div>
        </div>
    </div>
    <p class="pr-skill-picker__hint muted">
        Up to <?= (int) nk_skills_max_items() ?> skills. Set minimum years and months of experience for each skill.
    </p>
</div>

<label for="pr_qualifications">Qualifications</label>
<textarea id="pr_qualifications" name="qualifications" rows="4" placeholder="e.g. Relevant degree, certifications, years of experience"><?= h($pr_qualifications) ?></textarea>
<p class="muted" style="margin-top:-8px;">Education, certifications, or experience you expect.</p>

<script>
(function () {
    var initial = <?= $skills_json_boot ?>;
    var maxItems = <?= (int) nk_skills_max_items() ?>;
    var maxTok = <?= (int) nk_skills_max_token_length() ?>;
    var hidden = document.getElementById('pr_skills_required');
    var chipsEl = document.getElementById('pr-skill-picker-chips');
    var chipsWrap = chipsEl ? chipsEl.closest('.pr-skill-picker__chips-wrap') : null;
    var countEl = document.getElementById('pr-skill-picker-count');
    var selectEl = document.getElementById('pr-skill-picker-select');
    var inputEl = document.getElementById('pr-skill-picker-custom-input');
    var addBtn = document.getElementById('pr-skill-picker-custom-add');
    if (!hidden || !chipsEl) {
        return;
    }

    var selected = [];

    function normKey(s) {
        return String(s || '').trim().toLowerCase();
    }

    function clampExp(n, max) {
        var v = parseInt(String(n), 10);
        if (isNaN(v) || v < 0) {
            return 0;
        }
        return Math.min(max, v);
    }

    function entryFromRaw(raw) {
        if (typeof raw === 'string') {
            return { name: String(raw).trim(), years: 0, months: 0 };
        }
        if (raw && typeof raw === 'object') {
            return {
                name: String(raw.name || '').trim(),
                years: clampExp(raw.years, 50),
                months: clampExp(raw.months, 11)
            };
        }
        return null;
    }

    function syncHidden() {
        hidden.value = JSON.stringify(selected);
    }

    function hasSkill(name) {
        var k = normKey(name);
        if (!k) {
            return true;
        }
        for (var i = 0; i < selected.length; i++) {
            if (normKey(selected[i].name) === k) {
                return true;
            }
        }
        return false;
    }

    function addSkill(raw) {
        var entry = entryFromRaw(raw);
        if (!entry || !entry.name.length) {
            return;
        }
        if (entry.name.length > maxTok) {
            entry.name = entry.name.substring(0, maxTok);
        }
        if (hasSkill(entry.name)) {
            return;
        }
        if (selected.length >= maxItems) {
            return;
        }
        selected.push(entry);
        renderChips();
        syncHidden();
    }

    function removeAt(i) {
        selected.splice(i, 1);
        renderChips();
        syncHidden();
    }

    function buildYearOptions(current) {
        var html = '';
        for (var y = 0; y <= 50; y++) {
            html += '<option value="' + y + '"' + (y === current ? ' selected' : '') + '>' + y + '</option>';
        }
        return html;
    }

    function buildMonthOptions(current) {
        var html = '';
        for (var m = 0; m <= 11; m++) {
            html += '<option value="' + m + '"' + (m === current ? ' selected' : '') + '>' + m + '</option>';
        }
        return html;
    }

    function renderChips() {
        chipsEl.innerHTML = '';
        if (chipsWrap) {
            chipsWrap.classList.toggle('pr-skill-picker__chips-wrap--empty', selected.length === 0);
        }
        if (countEl) {
            countEl.textContent = String(selected.length);
        }
        selected.forEach(function (sk, idx) {
            var li = document.createElement('li');
            li.className = 'pr-skill-chip';

            var nameEl = document.createElement('span');
            nameEl.className = 'pr-skill-chip__name';
            nameEl.textContent = sk.name;
            li.appendChild(nameEl);

            var exp = document.createElement('div');
            exp.className = 'pr-skill-chip__exp';

            var yearsWrap = document.createElement('label');
            yearsWrap.className = 'pr-skill-chip__exp-field';
            yearsWrap.innerHTML = '<span>Years</span>';
            var yearsSel = document.createElement('select');
            yearsSel.className = 'pr-skill-chip__exp-select';
            yearsSel.setAttribute('aria-label', 'Years of experience for ' + sk.name);
            yearsSel.innerHTML = buildYearOptions(sk.years);
            yearsSel.addEventListener('change', function () {
                selected[idx].years = clampExp(yearsSel.value, 50);
                syncHidden();
            });
            yearsWrap.appendChild(yearsSel);
            exp.appendChild(yearsWrap);

            var monthsWrap = document.createElement('label');
            monthsWrap.className = 'pr-skill-chip__exp-field';
            monthsWrap.innerHTML = '<span>Months</span>';
            var monthsSel = document.createElement('select');
            monthsSel.className = 'pr-skill-chip__exp-select';
            monthsSel.setAttribute('aria-label', 'Months of experience for ' + sk.name);
            monthsSel.innerHTML = buildMonthOptions(sk.months);
            monthsSel.addEventListener('change', function () {
                selected[idx].months = clampExp(monthsSel.value, 11);
                syncHidden();
            });
            monthsWrap.appendChild(monthsSel);
            exp.appendChild(monthsWrap);

            li.appendChild(exp);

            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'pr-skill-chip__rm';
            btn.setAttribute('aria-label', 'Remove ' + sk.name);
            btn.textContent = '×';
            btn.addEventListener('click', function () {
                removeAt(idx);
            });
            li.appendChild(btn);

            chipsEl.appendChild(li);
        });
    }

    if (Array.isArray(initial)) {
        initial.forEach(function (x) {
            addSkill(x);
        });
    }

    if (selectEl) {
        selectEl.addEventListener('change', function () {
            var v = selectEl.value;
            if (!v) {
                return;
            }
            addSkill({ name: v, years: 0, months: 0 });
            selectEl.value = '';
        });
    }

    function addFromInput() {
        if (!inputEl) {
            return;
        }
        addSkill({ name: inputEl.value, years: 0, months: 0 });
        inputEl.value = '';
        inputEl.focus();
    }

    if (addBtn && inputEl) {
        addBtn.addEventListener('click', addFromInput);
        inputEl.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                addFromInput();
            }
        });
    }
})();
</script>
