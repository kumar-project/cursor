<?php
declare(strict_types=1);

$wideMain = true;
$page_title = 'Transactions & confirmations';
$nk_admin_nav = 'transactions';

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/project_payment.php';
require_once __DIR__ . '/config.php';

require_privileged();
$adminActor = current_user();
if (!is_super_admin($adminActor)) {
    http_response_code(403);
    echo 'Only Super Admin can view all transactions and payment confirmations.';
    exit;
}

$confirmations = [];
$payments = [];
$confirmationsError = '';
$paymentsError = '';

try {
    $confirmations = db()->query(
        "SELECT ppc.*,
                p.title AS project_title,
                p.status AS project_status,
                p.budget AS project_budget,
                c.name AS client_name,
                c.email AS client_email,
                c.mobile AS client_mobile,
                f.name AS freelancer_name,
                f.email AS freelancer_email,
                f.mobile AS freelancer_mobile,
                conf.name AS confirmed_by_name,
                conf.email AS confirmed_by_email,
                conf.role AS confirmed_by_role
         FROM project_payment_confirmations ppc
         JOIN projects p ON p.id = ppc.project_id
         JOIN users c ON c.id = ppc.client_id
         JOIN users f ON f.id = ppc.freelancer_id
         LEFT JOIN users conf ON conf.id = ppc.freelancer_confirmed_by
         ORDER BY ppc.id DESC"
    )->fetchAll();
} catch (Throwable) {
    $confirmationsError = 'Payment confirmation table is not available. Run setup.php or import the latest schema.sql.';
}

try {
    $payments = db()->query(
        "SELECT pay.*,
                p.title AS project_title,
                p.status AS project_status,
                payer.name AS payer_name,
                payer.email AS payer_email,
                payer.role AS payer_role,
                payee.name AS payee_name,
                payee.email AS payee_email,
                payee.role AS payee_role,
                m.title AS milestone_title
         FROM payments pay
         JOIN projects p ON p.id = pay.project_id
         JOIN users payer ON payer.id = pay.payer_id
         LEFT JOIN users payee ON payee.id = pay.payee_id
         LEFT JOIN milestones m ON m.id = pay.milestone_id
         ORDER BY pay.id DESC"
    )->fetchAll();
} catch (Throwable) {
    $paymentsError = 'Could not load platform payment records.';
}

$confirmedCount = 0;
$awaitingCount = 0;
foreach ($confirmations as $row) {
    if (project_payment_is_confirmed($row)) {
        $confirmedCount++;
    } else {
        $awaitingCount++;
    }
}

require_once __DIR__ . '/includes/layout.php';
?>
<div class="page-shell">
    <?php require __DIR__ . '/includes/partials/admin_subnav.php'; ?>

    <section class="card">
        <h2>Transactions &amp; payment confirmations</h2>
        <p class="muted">Super Admin view of all client-submitted payment details and freelancer receipt confirmations, plus platform escrow/wallet payments.</p>
        <ul class="admin-txn-stats">
            <li><span>Completion confirmations</span><strong><?= count($confirmations) ?></strong></li>
            <li><span>Awaiting freelancer</span><strong><?= $awaitingCount ?></strong></li>
            <li><span>Freelancer confirmed</span><strong><?= $confirmedCount ?></strong></li>
            <li><span>Escrow / wallet payments</span><strong><?= count($payments) ?></strong></li>
        </ul>
    </section>

    <section class="card">
        <h3>Project completion — client payment &amp; freelancer confirmation</h3>
        <p class="muted">Client side: status, method, amount, reference (transaction / invoice / UTR), notes, and when submitted. Freelancer side: who confirmed and when.</p>
        <?php if ($confirmationsError): ?>
            <p class="danger"><?= h($confirmationsError) ?></p>
        <?php elseif (!$confirmations): ?>
            <p class="muted">No payment confirmations submitted yet.</p>
        <?php else: ?>
            <div class="admin-data-table-wrap">
                <table class="admin-data-table admin-txn-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Project</th>
                            <th>Client (submitted)</th>
                            <th>Payment details</th>
                            <th>Reference</th>
                            <th>Freelancer (payee)</th>
                            <th>Freelancer confirmation</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($confirmations as $row): ?>
                            <?php
                            $isConfirmed = project_payment_is_confirmed($row);
                            $statusClass = $isConfirmed ? 'admin-txn-badge--ok' : 'admin-txn-badge--wait';
                            ?>
                            <tr>
                                <td class="admin-data-table__nowrap">#<?= (int) $row['id'] ?></td>
                                <td>
                                    <strong><a href="<?= BASE_URL ?>/project.php?id=<?= (int) $row['project_id'] ?>"><?= h((string) $row['project_title']) ?></a></strong>
                                    <br><span class="admin-data-table__muted">#<?= (int) $row['project_id'] ?> · <?= h((string) $row['project_status']) ?> · Budget Rs <?= h(number_format((float) $row['project_budget'], 2)) ?></span>
                                </td>
                                <td>
                                    <strong><?= h((string) $row['client_name']) ?></strong>
                                    <br><span class="admin-data-table__muted"><?= h((string) $row['client_email']) ?></span>
                                    <?php if (!empty($row['client_mobile'])): ?>
                                        <br><span class="admin-data-table__muted"><?= h((string) $row['client_mobile']) ?></span>
                                    <?php endif; ?>
                                    <br><span class="admin-data-table__muted">Submitted: <?= h((string) $row['client_submitted_at']) ?></span>
                                </td>
                                <td>
                                    <strong><?= h(project_payment_label('payment_status', (string) $row['payment_status'])) ?></strong>
                                    <br><?= h(project_payment_label('payment_method', (string) $row['payment_method'])) ?>
                                    <br><strong>Rs <?= h(number_format((float) $row['payment_amount'], 2)) ?></strong>
                                </td>
                                <td>
                                    <span class="admin-data-table__muted"><?= h(project_payment_label('reference_type', (string) $row['reference_type'])) ?></span>
                                    <br><strong><?= h((string) $row['reference_number']) ?></strong>
                                    <?php if (!empty($row['notes'])): ?>
                                        <br><span class="admin-data-table__muted"><?= nl2br(h((string) $row['notes']), false) ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong><?= h((string) $row['freelancer_name']) ?></strong>
                                    <br><span class="admin-data-table__muted"><?= h((string) $row['freelancer_email']) ?></span>
                                    <?php if (!empty($row['freelancer_mobile'])): ?>
                                        <br><span class="admin-data-table__muted"><?= h((string) $row['freelancer_mobile']) ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($isConfirmed): ?>
                                        <strong><?= h((string) ($row['confirmed_by_name'] ?? 'Freelancer')) ?></strong>
                                        <?php if (!empty($row['confirmed_by_email'])): ?>
                                            <br><span class="admin-data-table__muted"><?= h((string) $row['confirmed_by_email']) ?></span>
                                        <?php endif; ?>
                                        <?php if (!empty($row['confirmed_by_role'])): ?>
                                            <br><span class="admin-data-table__muted">Role: <?= h((string) $row['confirmed_by_role']) ?></span>
                                        <?php endif; ?>
                                        <br><span class="admin-data-table__muted">At: <?= h((string) $row['freelancer_confirmed_at']) ?></span>
                                    <?php else: ?>
                                        <span class="admin-data-table__muted">Not confirmed yet</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="admin-txn-badge <?= $statusClass ?>"><?= $isConfirmed ? 'Confirmed' : 'Awaiting freelancer' ?></span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>

    <section class="card">
        <h3>Platform payments (milestones / escrow / wallet)</h3>
        <p class="muted">Records from milestone funding and releases between client and freelancer wallets.</p>
        <?php if ($paymentsError): ?>
            <p class="danger"><?= h($paymentsError) ?></p>
        <?php elseif (!$payments): ?>
            <p class="muted">No escrow or wallet payment records yet.</p>
        <?php else: ?>
            <div class="admin-data-table-wrap">
                <table class="admin-data-table admin-txn-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Project</th>
                            <th>Payer (client)</th>
                            <th>Payee (freelancer)</th>
                            <th>Amount</th>
                            <th>Milestone</th>
                            <th>Gateway / ref</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($payments as $row): ?>
                            <tr>
                                <td class="admin-data-table__nowrap">#<?= (int) $row['id'] ?></td>
                                <td>
                                    <strong><a href="<?= BASE_URL ?>/project.php?id=<?= (int) $row['project_id'] ?>"><?= h((string) ($row['project_title'] ?? 'Project')) ?></a></strong>
                                    <br><span class="admin-data-table__muted">#<?= (int) $row['project_id'] ?> · <?= h((string) ($row['project_status'] ?? '')) ?></span>
                                </td>
                                <td>
                                    <strong><?= h((string) $row['payer_name']) ?></strong>
                                    <br><span class="admin-data-table__muted"><?= h((string) $row['payer_email']) ?> · <?= h((string) $row['payer_role']) ?></span>
                                </td>
                                <td>
                                    <?php if (!empty($row['payee_name'])): ?>
                                        <strong><?= h((string) $row['payee_name']) ?></strong>
                                        <br><span class="admin-data-table__muted"><?= h((string) ($row['payee_email'] ?? '')) ?> · <?= h((string) ($row['payee_role'] ?? '')) ?></span>
                                    <?php else: ?>
                                        <span class="admin-data-table__muted">—</span>
                                    <?php endif; ?>
                                </td>
                                <td><strong>Rs <?= h(number_format((float) $row['amount'], 2)) ?></strong></td>
                                <td><?= !empty($row['milestone_title']) ? h((string) $row['milestone_title']) : '—' ?></td>
                                <td>
                                    <?= h((string) ($row['gateway'] ?? '—')) ?>
                                    <?php if (!empty($row['transaction_ref'])): ?>
                                        <br><span class="admin-data-table__muted"><?= h((string) $row['transaction_ref']) ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><span class="admin-txn-badge admin-txn-badge--neutral"><?= h((string) $row['status']) ?></span></td>
                                <td class="admin-data-table__nowrap"><?= h((string) $row['created_at']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
</div>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
