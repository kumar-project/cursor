<?php
declare(strict_types=1);

$wideMain = true;
$page_title = 'Assign work';
$nk_admin_nav = 'assign';

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/assign_work_data.php';

require_privileged();
$assignOk = isset($_GET['assign_ok']) && (string) $_GET['assign_ok'] === '1';

$assignForForm = current_user();
$assignLists = assign_work_load_lists($assignForForm);
$aw_projects = $assignLists['projects'];
$aw_freelancers = $assignLists['freelancers'];
$aw_staff = $assignLists['staff'];
$aw_selectedProjectId = (int) ($_GET['project_id'] ?? 0);
$aw_selectedFreelancerId = (int) ($_GET['freelancer_id'] ?? 0);
$aw_messageValue = '';
$aw_error = '';
$aw_success = $assignOk ? 'Work assigned successfully. You can send another below.' : '';
$aw_formAction = BASE_URL . '/client/assign.php';
$aw_project_change_href_base = BASE_URL . '/admin_assign_work.php';
$aw_from = 'admin';

require_once __DIR__ . '/includes/layout.php';
?>
<div class="page-shell">
    <?php require __DIR__ . '/includes/partials/admin_subnav.php'; ?>

    <section class="card">
        <h2>Assign work (for any client’s project)</h2>
        <p class="muted">Same form clients use: pick a project, freelancer, enter instructions, and optional file. Submit routes through the client assign handler and returns here when it succeeds.</p>
        <?php require __DIR__ . '/includes/partials/assign_work_form.php'; ?>
    </section>

    <section class="card">
        <h2>Platform access</h2>
        <p class="muted">Everything a client and freelancer can do is available to you. Use the links below or the top navigation. Escrow and milestones debit the <strong>project client’s</strong> wallet, not the staff account.</p>
        <div class="admin-hub-links" style="display:flex; flex-wrap:wrap; gap:10px; margin-top:12px;">
            <a href="<?= BASE_URL ?>/admin_blog.php">Blog CMS</a>
            <a href="<?= BASE_URL ?>/index.php">Browse projects (home)</a>
            <a href="<?= BASE_URL ?>/post_project.php">Post project</a>
            <a href="<?= BASE_URL ?>/client/assign.php">Client: assign work</a>
            <a href="<?= BASE_URL ?>/freelancer/assignments.php">Freelancer: assignment inbox</a>
            <a href="<?= BASE_URL ?>/dashboard.php">Wallet &amp; profile</a>
            <a href="<?= BASE_URL ?>/admin_data.php">Users &amp; data</a>
        </div>
        <p class="muted" style="margin-top:10px;">Open a project from the list to place bids, accept bids, fund milestones, chat, and complete work—same as end users.</p>
    </section>
</div>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
