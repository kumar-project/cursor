<?php
declare(strict_types=1);

$wideMain = true;

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/blog_cms.php';

require_privileged();

$user = current_user();
$flash = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete_post'])) {
        $pid = (int) ($_POST['post_id'] ?? 0);
        $msg = blog_post_delete($pid);
        $flash = $msg === '' ? 'Post deleted.' : '';
        $error = $msg !== '' ? $msg : '';
    } elseif (isset($_POST['save_category'])) {
        $msg = blog_category_create((string) ($_POST['category_name'] ?? ''));
        $flash = $msg === '' ? 'Category added.' : '';
        $error = $msg !== '' ? $msg : '';
    } elseif (isset($_POST['delete_category'])) {
        $cid = (int) ($_POST['category_id'] ?? 0);
        $msg = blog_category_delete($cid);
        $flash = $msg === '' ? 'Category removed.' : '';
        $error = $msg !== '' ? $msg : '';
    } elseif (isset($_POST['save_post'])) {
        $upload = (isset($_FILES['featured_image']) && is_array($_FILES['featured_image']))
            ? $_FILES['featured_image']
            : null;
        $data = [
            'id' => (int) ($_POST['post_id'] ?? 0),
            'title' => (string) ($_POST['title'] ?? ''),
            'content' => (string) ($_POST['content'] ?? ''),
            'category_id' => (int) ($_POST['category_id'] ?? 0),
            'excerpt' => (string) ($_POST['excerpt'] ?? ''),
            'status' => (string) ($_POST['status'] ?? 'draft'),
            'remove_featured' => !empty($_POST['remove_featured']),
        ];
        $msg = blog_post_save($data, (int) $user['id'], $upload);
        if ($msg === '') {
            header('Location: ' . BASE_URL . '/admin_blog.php?tab=posts&saved=1');
            exit;
        }
        $error = $msg;
    }
}

if (isset($_GET['saved']) && (string) $_GET['saved'] === '1') {
    $flash = 'Post saved.';
}

$tab = (string) ($_GET['tab'] ?? 'posts');
if (!in_array($tab, ['posts', 'categories'], true)) {
    $tab = 'posts';
}

$editId = (int) ($_GET['edit'] ?? 0);
$editing = $editId > 0 ? blog_post_get_by_id($editId) : null;
if ($editId > 0 && !$editing) {
    $error = $error !== '' ? $error : 'Post not found.';
}

$categories = blog_categories_all();
$allPosts = blog_posts_admin_list();

$page_title = 'Blog CMS';
require_once __DIR__ . '/includes/layout.php';

$sticky = [];
if ($error !== '' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_post'])) {
    $sticky = [
        'post_id' => (int) ($_POST['post_id'] ?? 0),
        'title' => (string) ($_POST['title'] ?? ''),
        'content' => (string) ($_POST['content'] ?? ''),
        'category_id' => (int) ($_POST['category_id'] ?? 0),
        'excerpt' => (string) ($_POST['excerpt'] ?? ''),
        'status' => (string) ($_POST['status'] ?? 'draft'),
    ];
}
?>
<div class="page-shell admin-blog">
    <header class="admin-blog__head card">
        <h1 class="admin-blog__title">Blog CMS</h1>
        <p class="muted">Create and manage posts, categories, and featured images. Only platform staff can access this page.</p>
        <div class="admin-blog__toolbar">
            <a class="nk-widget__link" href="<?= h(BASE_URL) ?>/blog.php" target="_blank" rel="noopener">View public blog</a>
            <a class="nk-widget__link" href="<?= h(BASE_URL) ?>/admin.php">Back to Super Admin</a>
        </div>
    </header>

    <?php if ($flash): ?><p class="success admin-blog__flash"><?= h($flash) ?></p><?php endif; ?>
    <?php if ($error): ?><p class="danger admin-blog__flash"><?= h($error) ?></p><?php endif; ?>

    <nav class="admin-blog__tabs card" aria-label="Blog CMS sections">
        <a href="<?= h(BASE_URL) ?>/admin_blog.php?tab=posts" class="<?= $tab === 'posts' ? 'is-active' : '' ?>">Posts</a>
        <a href="<?= h(BASE_URL) ?>/admin_blog.php?tab=categories" class="<?= $tab === 'categories' ? 'is-active' : '' ?>">Categories</a>
    </nav>

    <?php if ($tab === 'categories'): ?>
        <section class="card admin-blog__panel">
            <h2>Categories</h2>
            <p class="muted">Posts must belong to one category. You cannot delete a category that still has posts.</p>
            <form method="post" class="admin-blog__inline-form">
                <input type="hidden" name="save_category" value="1">
                <label for="category_name">New category name</label>
                <div class="admin-blog__row">
                    <input id="category_name" name="category_name" type="text" maxlength="120" required placeholder="e.g. Remote work">
                    <button type="submit">Add category</button>
                </div>
            </form>
            <ul class="admin-blog__category-list">
                <?php foreach ($categories as $cat): ?>
                    <li>
                        <span><strong><?= h((string) $cat['name']) ?></strong> <code><?= h((string) $cat['slug']) ?></code></span>
                        <form method="post" class="admin-blog__inline" onsubmit="return confirm('Delete this category?');">
                            <input type="hidden" name="delete_category" value="1">
                            <input type="hidden" name="category_id" value="<?= (int) $cat['id'] ?>">
                            <button type="submit" class="admin-blog__btn-danger">Delete</button>
                        </form>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>
    <?php endif; ?>

    <?php if ($tab === 'posts'): ?>
        <section class="card admin-blog__panel">
            <h2><?= $editing ? 'Edit post' : 'New post' ?></h2>
            <?php
            $formPost = $editing;
            if ($sticky !== []) {
                $formPost = $formPost ?? [];
                $formPost = array_merge($formPost, $sticky);
            }
            $fid = (int) ($formPost['id'] ?? 0);
            $ftitle = (string) ($formPost['title'] ?? '');
            $fcontent = (string) ($formPost['content'] ?? '');
            $fcat = (int) ($formPost['category_id'] ?? 0);
            $fexcerpt = (string) ($formPost['excerpt'] ?? '');
            $fstatus = (string) ($formPost['status'] ?? 'draft');
            $fimg = $formPost['featured_image_path'] ?? null;
            ?>
            <form method="post" enctype="multipart/form-data" class="admin-blog__post-form">
                <input type="hidden" name="save_post" value="1">
                <input type="hidden" name="post_id" value="<?= $fid ?>">

                <label for="blog_title">Title</label>
                <input id="blog_title" name="title" required maxlength="255" value="<?= h($ftitle) ?>">

                <label for="blog_category">Category</label>
                <select id="blog_category" name="category_id" required>
                    <option value="">— Select —</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= (int) $cat['id'] ?>" <?= $fcat === (int) $cat['id'] ? 'selected' : '' ?>>
                            <?= h((string) $cat['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label for="blog_excerpt">Excerpt (optional, shown on listing cards)</label>
                <textarea id="blog_excerpt" name="excerpt" rows="2" maxlength="500"><?= h($fexcerpt) ?></textarea>

                <label for="blog_content">Content</label>
                <textarea id="blog_content" name="content" rows="14" required><?= h($fcontent) ?></textarea>

                <label for="blog_status">Status</label>
                <select id="blog_status" name="status">
                    <option value="draft" <?= $fstatus === 'draft' ? 'selected' : '' ?>>Draft</option>
                    <option value="published" <?= $fstatus === 'published' ? 'selected' : '' ?>>Published</option>
                </select>

                <label for="blog_featured">Featured image</label>
                <?php if ($fimg && blog_safe_featured_path((string) $fimg)): ?>
                    <p class="admin-blog__thumb-wrap">
                        <img src="<?= h((string) blog_featured_public_url((string) $fimg)) ?>" alt="" class="admin-blog__thumb">
                    </p>
                    <label class="admin-blog__check">
                        <input type="checkbox" name="remove_featured" value="1"> Remove current image
                    </label>
                <?php endif; ?>
                <input id="blog_featured" type="file" name="featured_image" accept=".jpg,.jpeg,.png,.gif,.webp,image/jpeg,image/png,image/gif,image/webp">

                <div class="admin-blog__form-actions">
                    <button type="submit"><?= $fid ? 'Update post' : 'Create post' ?></button>
                    <?php if ($editing): ?>
                        <a href="<?= h(BASE_URL) ?>/admin_blog.php?tab=posts" class="admin-blog__cancel">Cancel edit</a>
                    <?php endif; ?>
                </div>
            </form>
        </section>

        <section class="card admin-blog__panel">
            <h2>All posts</h2>
            <?php if (!$allPosts): ?>
                <p class="muted">No posts yet. Create one above.</p>
            <?php else: ?>
                <div class="admin-blog__table-wrap">
                    <table class="admin-blog__table">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Title</th>
                                <th>Category</th>
                                <th>Status</th>
                                <th>Updated</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($allPosts as $p): ?>
                                <tr>
                                    <td class="admin-blog__td-thumb">
                                        <?php
                                        $pu = blog_featured_public_url($p['featured_image_path'] ?? null);
                                        if ($pu): ?>
                                            <img src="<?= h($pu) ?>" alt="" class="admin-blog__table-thumb">
                                        <?php else: ?>
                                            <span class="muted">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= h((string) $p['title']) ?></td>
                                    <td><?= h((string) $p['category_name']) ?></td>
                                    <td><span class="admin-blog__badge admin-blog__badge--<?= $p['status'] === 'published' ? 'pub' : 'draft' ?>"><?= h((string) $p['status']) ?></span></td>
                                    <td><?= h((string) $p['updated_at']) ?></td>
                                    <td class="admin-blog__td-actions">
                                        <a href="<?= h(BASE_URL) ?>/admin_blog.php?tab=posts&amp;edit=<?= (int) $p['id'] ?>">Edit</a>
                                        <a href="<?= h(BASE_URL) ?>/blog_post.php?id=<?= (int) $p['id'] ?>" target="_blank" rel="noopener">View</a>
                                        <form method="post" class="admin-blog__inline" onsubmit="return confirm('Delete this post permanently?');">
                                            <input type="hidden" name="delete_post" value="1">
                                            <input type="hidden" name="post_id" value="<?= (int) $p['id'] ?>">
                                            <button type="submit" class="admin-blog__btn-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>
    <?php endif; ?>
</div>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
