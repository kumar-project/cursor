<?php
declare(strict_types=1);

$wideMain = true;

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';

if (current_user()) {
    header('Location: ' . BASE_URL . '/dashboard.php');
    exit;
}

$error = '';
// POST body must win over GET for role links vs form submit.
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['role'])
    && in_array((string) $_POST['role'], ['client', 'freelancer'], true)
) {
    $registerRole = (string) $_POST['role'];
} else {
    $cand = (string) ($_GET['role'] ?? 'client');
    $registerRole = in_array($cand, ['client', 'freelancer'], true) ? $cand : 'client';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim((string) ($_POST['name'] ?? ''));
    $mobileRaw = trim((string) ($_POST['mobile'] ?? ''));
    $mobile = trim((string) preg_replace('/\s+/', ' ', $mobileRaw));
    $email = trim((string) ($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? $registerRole;

    $mobileDigits = preg_replace('/\D/', '', $mobile) ?? '';
    if ($name === '' || $mobile === '' || $email === '' || $password === '' || !in_array($role, ['client', 'freelancer'], true)) {
        $error = 'Please fill all fields correctly.';
    } elseif (strlen($mobile) > 32) {
        $error = 'Mobile number is too long.';
    } elseif (strlen($mobileDigits) < 8 || strlen($mobileDigits) > 15) {
        $error = 'Enter a valid mobile number (8–15 digits, optional + country code).';
    } else {
        $stmt = db()->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'Email already registered.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $clientApproved = $role === 'client' ? 0 : 1;
            $insert = db()->prepare(
                'INSERT INTO users (name, mobile, email, password, role, client_approved) VALUES (?, ?, ?, ?, ?, ?)'
            );
            $insert->execute([$name, $mobile, $email, $hash, $role, $clientApproved]);
            if ($role === 'client') {
                header('Location: ' . BASE_URL . '/register.php?client_registered=1');
                exit;
            }
            $_SESSION['user_id'] = (int) db()->lastInsertId();
            header('Location: ' . BASE_URL . '/freelancer/onboarding.php');
            exit;
        }
    }
}

$page_title = 'Register';
require_once __DIR__ . '/includes/layout.php';
$prefillName = trim((string) ($_POST['name'] ?? ''));
$prefillMobile = trim((string) ($_POST['mobile'] ?? ''));
$prefillEmail = trim((string) ($_POST['email'] ?? ''));
$clientRegisteredOk = isset($_GET['client_registered']) && (string) $_GET['client_registered'] === '1';
?>
<div class="page-shell">
<section class="login-shell register-shell">
    <div class="login-hero">
        <p class="login-kicker">Welcome to <?= h(APP_NAME) ?></p>
        <h1 class="login-title">Create account</h1>
        <p class="login-lead">Which describes you best?</p>
        <p class="login-sub">Choose your account type, then complete the form below to join <?= h(APP_NAME) ?>.</p>
        <div class="login-avatar-row login-avatar-row--pair" aria-hidden="true">
            <span class="login-avatar login-avatar--client">C</span>
            <span class="login-avatar login-avatar--freelancer">F</span>
        </div>
        <div class="login-role-grid">
            <a href="<?= BASE_URL ?>/register.php?role=client" class="login-role-card <?= $registerRole === 'client' ? 'is-active' : '' ?>">
                <span class="login-role-icon" aria-hidden="true"><i class="fa-solid fa-briefcase"></i></span>
                <strong>Client</strong>
                <small>Post jobs and hire</small>
            </a>
            <a href="<?= BASE_URL ?>/register.php?role=freelancer" class="login-role-card <?= $registerRole === 'freelancer' ? 'is-active' : '' ?>">
                <span class="login-role-icon" aria-hidden="true"><i class="fa-solid fa-laptop-code"></i></span>
                <strong>Freelancer</strong>
                <small>Work and get paid</small>
            </a>
        </div>
        <div class="login-admin-row">
            <a href="<?= BASE_URL ?>/login.php">Already have an account? Log in</a>
        </div>
    </div>

    <div class="card login-form-card">
        <h2><i class="fa-solid fa-user-plus" aria-hidden="true"></i> Register as <?= h(ucfirst($registerRole)) ?></h2>
        <p class="muted">Create your account with a few details. You can switch role above before submitting.</p>
        <?php if ($clientRegisteredOk): ?>
            <p class="success">Your client account was created. A Super Admin must approve it before you can post projects or use client tools. You can <a href="<?= BASE_URL ?>/login.php?role=client">log in</a> any time; until you are approved you will only see your pending status.</p>
        <?php endif; ?>
        <?php if ($error): ?><p class="danger"><?= h($error) ?></p><?php endif; ?>
        <form method="post" class="login-form register-form">
            <input type="hidden" name="role" value="<?= h($registerRole) ?>">
            <label for="register_name">Full name</label>
            <input id="register_name" type="text" name="name" value="<?= h($prefillName) ?>" required autocomplete="name" maxlength="100">

            <label for="register_mobile">Mobile number</label>
            <input id="register_mobile" type="tel" name="mobile" value="<?= h($prefillMobile) ?>" required autocomplete="tel" inputmode="tel" placeholder="e.g. +92 300 1234567" maxlength="32">

            <label for="register_email">Email</label>
            <input id="register_email" type="email" name="email" value="<?= h($prefillEmail) ?>" required autocomplete="email">

            <label for="register_password">Password</label>
            <div class="nk-password-field">
                <input id="register_password" type="password" name="password" required autocomplete="new-password">
                <button type="button" class="nk-password-toggle" aria-controls="register_password" aria-pressed="false" aria-label="Show password">
                    <i class="fa-solid fa-eye" aria-hidden="true"></i>
                </button>
            </div>

            <button type="submit">Create account</button>
        </form>
        <p class="login-foot-note">Already registered? <a href="<?= BASE_URL ?>/login.php">Log in</a></p>
    </div>
</section>
</div>
<script src="<?= BASE_URL ?>/assets/auth-password-toggle.js" defer></script>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
