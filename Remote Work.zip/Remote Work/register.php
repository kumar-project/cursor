<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';

if (current_user()) {
    header('Location: ' . BASE_URL . '/dashboard.php');
    exit;
}

$error = '';
$registerRole = $_GET['role'] ?? ($_POST['role'] ?? 'client');
if (!in_array($registerRole, ['client', 'freelancer'], true)) {
    $registerRole = 'client';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? $registerRole;

    if ($name === '' || $email === '' || $password === '' || !in_array($role, ['client', 'freelancer'], true)) {
        $error = 'Please fill all fields correctly.';
    } else {
        $stmt = db()->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'Email already registered.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $insert = db()->prepare('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)');
            $insert->execute([$name, $email, $hash, $role]);
            $_SESSION['user_id'] = (int)db()->lastInsertId();
            header('Location: ' . BASE_URL . '/dashboard.php');
            exit;
        }
    }
}

require_once __DIR__ . '/includes/layout.php';
?>
<section class="card">
    <h2>Create Account</h2>
    <div style="margin-bottom:12px;">
        <a href="<?= BASE_URL ?>/register.php?role=client" style="margin-right:14px; <?= $registerRole === 'client' ? 'font-weight:700;' : '' ?>">Client Register</a>
        <a href="<?= BASE_URL ?>/register.php?role=freelancer" style="<?= $registerRole === 'freelancer' ? 'font-weight:700;' : '' ?>">Freelancer Register</a>
    </div>
    <?php if ($error): ?><p class="danger"><?= h($error) ?></p><?php endif; ?>
    <form method="post">
        <input type="hidden" name="role" value="<?= h($registerRole) ?>">
        <label>Name</label>
        <input name="name" required>

        <label>Email</label>
        <input type="email" name="email" required>

        <label>Password</label>
        <input type="password" name="password" required>
        <button type="submit">Register as <?= h(ucfirst($registerRole)) ?></button>
    </form>
</section>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>

