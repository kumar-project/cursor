<?php
declare(strict_types=1);

$wideMain = true;
$page_title = 'Super Admin';
$nk_admin_nav = 'hub';

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';

require_privileged();
$adminHubUser = current_user();

require_once __DIR__ . '/includes/layout.php';
?>
<div class="page-shell">
    <?php require __DIR__ . '/includes/partials/admin_subnav.php'; ?>

    <section class="card">
        <h2>Super Admin</h2>
        <p class="muted">Platform staff tools are split into two pages. Use the section links above or open either area below.</p>
        <div class="admin-hub-grid">
            <a class="admin-hub-card" href="<?= BASE_URL ?>/admin_assign_work.php">
                <h3>Assign work</h3>
                <p>Assign freelancers to any client’s project, plus shortcuts to browse the platform as staff.</p>
            </a>
            <a class="admin-hub-card" href="<?= BASE_URL ?>/admin_data.php">
                <h3>Users &amp; data</h3>
                <p>Client and freelancer directory, role changes, projects, disputes, and payment tracking.</p>
            </a>
            <?php if (is_super_admin($adminHubUser)): ?>
            <a class="admin-hub-card" href="<?= BASE_URL ?>/admin_transactions.php">
                <h3>Transactions</h3>
                <p>All client payment submissions, freelancer confirmations, and escrow/wallet payment records.</p>
            </a>
            <?php endif; ?>
        </div>
    </section>

    <section class="card">
        <h2>Platform access</h2>
        <p class="muted">Everything a client and freelancer can do is available to you from the top navigation and these links.</p>
        <div class="admin-hub-links" style="display:flex; flex-wrap:wrap; gap:10px; margin-top:12px;">
            <a href="<?= BASE_URL ?>/admin_blog.php">Blog CMS</a>
            <a href="<?= BASE_URL ?>/index.php">Browse projects (home)</a>
            <a href="<?= BASE_URL ?>/post_project.php">Post project</a>
            <a href="<?= BASE_URL ?>/client/assign.php">Client: assign work</a>
            <a href="<?= BASE_URL ?>/freelancer/assignments.php">Freelancer: assignment inbox</a>
            <a href="<?= BASE_URL ?>/dashboard.php">Wallet &amp; profile</a>
        </div>
    </section>
</div>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
