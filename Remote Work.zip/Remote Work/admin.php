<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/assign_work_data.php';

require_privileged();
$flash = '';
$assignOk = isset($_GET['assign_ok']) && (string) $_GET['assign_ok'] === '1';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_role'])) {
    $uid = (int)($_POST['user_id'] ?? 0);
    $newRole = (string)($_POST['new_role'] ?? '');

    if (!in_array($newRole, ['client', 'freelancer'], true) || $uid <= 0) {
        $flash = 'Invalid request.';
    } else {
        $check = db()->prepare('SELECT role FROM users WHERE id = ?');
        $check->execute([$uid]);
        $t = $check->fetch();
        if (!$t || in_array($t['role'], ['admin', 'super_admin'], true)) {
            $flash = 'This account type cannot be changed from here.';
        } else {
            $u = db()->prepare('UPDATE users SET role = ? WHERE id = ?');
            $u->execute([$newRole, $uid]);
            $flash = 'User role updated to ' . $newRole . '.';
        }
    }
}

$users = db()->query('SELECT id, name, email, role, wallet_balance, avg_rating, created_at FROM users ORDER BY id DESC')->fetchAll();
$projects = db()->query(
    "SELECT p.id, p.title, p.status, p.budget, p.created_at, u.name AS client_name
     FROM projects p
     JOIN users u ON u.id = p.user_id
     ORDER BY p.id DESC"
)->fetchAll();
$disputes = db()->query(
    "SELECT d.id, d.project_id, d.status, d.reason, d.created_at, u.name AS raised_by_name
     FROM disputes d
     JOIN users u ON u.id = d.raised_by
     ORDER BY d.id DESC"
)->fetchAll();
$payments = db()->query(
    "SELECT id, project_id, amount, status, gateway, transaction_ref, created_at
     FROM payments
     ORDER BY id DESC"
)->fetchAll();

$clients = array_filter($users, static fn (array $r) => $r['role'] === 'client');
$freelancers = array_filter($users, static fn (array $r) => $r['role'] === 'freelancer');
$staff = array_filter($users, static fn (array $r) => in_array($r['role'], ['admin', 'super_admin'], true));

$assignForForm = current_user();
$assignLists = assign_work_load_lists($assignForForm);
$aw_projects = $assignLists['projects'];
$aw_freelancers = $assignLists['freelancers'];
$aw_staff = $assignLists['staff'];
$aw_selectedProjectId = (int)($_GET['project_id'] ?? 0);
$aw_selectedFreelancerId = (int)($_GET['freelancer_id'] ?? 0);
$aw_messageValue = '';
$aw_error = '';
$aw_success = $assignOk ? 'Work assigned successfully. You can send another below.' : '';
$aw_formAction = BASE_URL . '/client/assign.php';
$aw_from = 'admin';

require_once __DIR__ . '/includes/layout.php';
?>
<section class="card">
    <h2>Assign work (for any client’s project)</h2>
    <p class="muted">Same form clients use: pick a project, freelancer, enter instructions, and optional file. Submit routes through the client assign handler and returns here when it succeeds.</p>
    <?php
    require __DIR__ . '/includes/partials/assign_work_form.php';
    ?>
</section>

<section class="card">
    <h2>Platform access</h2>
    <p class="muted">Everything a client and freelancer can do is available to you. Use the links below or the top navigation. Escrow and milestones debit the <strong>project client’s</strong> wallet, not the staff account.</p>
    <div class="admin-hub-links" style="display:flex; flex-wrap:wrap; gap:10px; margin-top:12px;">
        <a href="<?= BASE_URL ?>/index.php">Browse projects (home)</a>
        <a href="<?= BASE_URL ?>/post_project.php">Post project</a>
        <a href="<?= BASE_URL ?>/client/assign.php">Client: assign work</a>
        <a href="<?= BASE_URL ?>/freelancer/assignments.php">Freelancer: assignment inbox</a>
        <a href="<?= BASE_URL ?>/dashboard.php">Wallet &amp; profile</a>
    </div>
    <p class="muted" style="margin-top:10px;">Open a project from the list to place bids, accept bids, fund milestones, chat, and complete work—same as end users.</p>
</section>

<section class="card">
    <h2>User &amp; data management</h2>
    <p class="muted">Switch end users between client and freelancer, and review platform activity. Staff accounts are not reassigned here.</p>
    <?php if ($flash): ?><p class="success"><?= h($flash) ?></p><?php endif; ?>
</section>

<section class="card">
    <h3>Clients</h3>
    <?php if (!$clients): ?><p class="muted">No client accounts yet.</p><?php endif; ?>
    <?php foreach ($clients as $row): ?>
        <form method="post" class="row" style="align-items: flex-end; flex-wrap: wrap; margin-bottom: 0.5rem; gap: 0.5rem;">
            <span>
                #<?= (int)$row['id'] ?> — <strong><?= h($row['name']) ?></strong> (<?= h($row['email']) ?>) | Wallet: Rs <?= h(number_format((float)$row['wallet_balance'], 2)) ?>
            </span>
            <input type="hidden" name="user_id" value="<?= (int)$row['id'] ?>">
            <input type="hidden" name="set_role" value="1">
            <input type="hidden" name="new_role" value="freelancer">
            <button type="submit" name="reassign" value="1" onclick="return confirm('Move this user to Freelancer?');">Set as Freelancer</button>
        </form>
    <?php endforeach; ?>
</section>

<section class="card">
    <h3>Freelancers</h3>
    <?php if (!$freelancers): ?><p class="muted">No freelancer accounts yet.</p><?php endif; ?>
    <?php foreach ($freelancers as $row): ?>
        <form method="post" class="row" style="align-items: flex-end; flex-wrap: wrap; margin-bottom: 0.5rem; gap: 0.5rem;">
            <span>
                #<?= (int)$row['id'] ?> — <strong><?= h($row['name']) ?></strong> (<?= h($row['email']) ?>) | Rating: <?= h((string)$row['avg_rating']) ?>
            </span>
            <input type="hidden" name="user_id" value="<?= (int)$row['id'] ?>">
            <input type="hidden" name="set_role" value="1">
            <input type="hidden" name="new_role" value="client">
            <button type="submit" name="reassign" value="1" onclick="return confirm('Move this user to Client?');">Set as Client</button>
        </form>
    <?php endforeach; ?>
</section>

<section class="card">
    <h3>Platform staff</h3>
    <p class="muted">Admins and super-admins. Roles are set in the database, not on this form.</p>
    <?php foreach ($staff as $row): ?>
        <p>#<?= (int)$row['id'] ?> — <?= h($row['name']) ?> (<?= h($row['email']) ?>) | <?= h($row['role']) ?></p>
    <?php endforeach; ?>
    <?php if (!$staff): ?><p class="muted">No staff users.</p><?php endif; ?>
</section>

<section class="card">
    <h3>Projects</h3>
    <?php foreach ($projects as $row): ?>
        <p>#<?= (int)$row['id'] ?> - <?= h($row['title']) ?> | <?= h($row['status']) ?> | Client: <?= h($row['client_name']) ?></p>
    <?php endforeach; ?>
</section>

<section class="card">
    <h3>Disputes</h3>
    <?php foreach ($disputes as $row): ?>
        <p>#<?= (int)$row['id'] ?> - Project #<?= (int)$row['project_id'] ?> | <?= h($row['status']) ?> | By <?= h($row['raised_by_name']) ?></p>
    <?php endforeach; ?>
    <?php if (!$disputes): ?><p class="muted">No disputes raised.</p><?php endif; ?>
</section>

<section class="card">
    <h3>Payment Tracking</h3>
    <?php foreach ($payments as $row): ?>
        <p>#<?= (int)$row['id'] ?> - Project #<?= (int)$row['project_id'] ?> | Rs <?= h(number_format((float)$row['amount'], 2)) ?> | <?= h($row['status']) ?></p>
    <?php endforeach; ?>
    <?php if (!$payments): ?><p class="muted">No payment records yet.</p><?php endif; ?>
</section>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
