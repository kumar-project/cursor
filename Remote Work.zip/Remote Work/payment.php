<?php
declare(strict_types=1);

$wideMain = true;
$page_title = 'Payments';

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/payment_gateways.php';

require_active_client_session();
$user = current_user();
$superAdmin = is_super_admin($user);
$error = '';
$success = '';
if (!empty($_SESSION['payment_flash_success'])) {
    $success = (string) $_SESSION['payment_flash_success'];
    unset($_SESSION['payment_flash_success']);
}
if (!empty($_SESSION['payment_flash_error'])) {
    $error = (string) $_SESSION['payment_flash_error'];
    unset($_SESSION['payment_flash_error']);
}

$tab = (string) ($_GET['tab'] ?? 'billing');
if (!in_array($tab, ['guide', 'billing', 'gateways', 'withdrawals'], true)) {
    $tab = 'billing';
}

$billingGateway = (string) ($_POST['payment_gateway'] ?? $_GET['gateway'] ?? payment_gateway_default());
$billingMethod = (string) ($_POST['billing_method'] ?? $_GET['method'] ?? 'card');
$resolved = payment_gateway_resolve($billingGateway, $billingMethod);
$billingGateway = $resolved['gateway'];
$billingMethod = $resolved['method'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_wallet'])) {
    $tab = 'billing';
    $amount = (float) ($_POST['amount'] ?? 0);
    $billingGateway = (string) ($_POST['payment_gateway'] ?? payment_gateway_default());
    $billingMethod = (string) ($_POST['billing_method'] ?? 'card');
    $resolved = payment_gateway_resolve($billingGateway, $billingMethod);
    $billingGateway = $resolved['gateway'];
    $billingMethod = $resolved['method'];

    if (!payment_gateway_is_valid($billingGateway)) {
        $_SESSION['payment_flash_error'] = 'Select a valid payment gateway.';
    } elseif ($amount < 100) {
        $_SESSION['payment_flash_error'] = 'Minimum top-up amount is ₹100.';
    } elseif ($amount > 500000) {
        $_SESSION['payment_flash_error'] = 'Maximum top-up amount is ₹5,00,000 per transaction.';
    } else {
        try {
            $pdo = db();
            $pdo->beginTransaction();
            $stmt = $pdo->prepare('UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?');
            $stmt->execute([$amount, (int) $user['id']]);
            $ref = payment_gateway_create_topup($pdo, (int) $user['id'], $amount, $billingGateway, $billingMethod);
            $pdo->commit();

            $mode = payment_gateway_has_credentials($billingGateway) ? 'processed' : 'simulated';
            $_SESSION['payment_flash_success'] = '₹' . number_format($amount, 2)
                . ' added via ' . payment_gateway_label($billingGateway)
                . ' (' . payment_billing_method_label($billingMethod) . ', ' . $mode . '). Ref: ' . $ref;
        } catch (Throwable) {
            if (isset($pdo) && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $_SESSION['payment_flash_error'] = 'Could not add funds. Please try again.';
        }
    }

    header(
        'Location: ' . BASE_URL . '/payment.php?tab=billing'
        . '&gateway=' . rawurlencode($billingGateway)
        . '&method=' . rawurlencode($billingMethod)
    );
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['withdraw_wallet'])) {
    $tab = 'withdrawals';
    $withdrawAmount = (float) ($_POST['withdraw_amount'] ?? 0);
    $withdrawMethod = trim((string) ($_POST['withdraw_method'] ?? ''));
    $allowedWithdrawMethods = ['bank', 'paypal', 'payoneer'];
    $currentWallet = (float) (current_user()['wallet_balance'] ?? 0);

    if ($withdrawAmount <= 0) {
        $error = 'Enter a valid withdrawal amount.';
    } elseif (!in_array($withdrawMethod, $allowedWithdrawMethods, true)) {
        $error = 'Select a valid withdrawal method.';
    } elseif ($withdrawAmount > $currentWallet) {
        $error = 'Insufficient wallet balance for this withdrawal.';
    } else {
        $stmt = db()->prepare('UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?');
        $stmt->execute([$withdrawAmount, (int) $user['id']]);
        $success = 'Withdrawal request submitted. ₹' . number_format($withdrawAmount, 2) . ' will be sent via ' . ucfirst($withdrawMethod) . ' (demo).';
    }
}

$walletStmt = db()->prepare('SELECT wallet_balance FROM users WHERE id = ?');
$walletStmt->execute([(int) $user['id']]);
$wallet = (float) ($walletStmt->fetch()['wallet_balance'] ?? 0);

$recentPayments = [];
$recentConfirmations = [];
$recentTopups = [];
try {
    $paymentsStmt = db()->prepare(
        "SELECT p.*, pr.title AS project_title
         FROM payments p
         LEFT JOIN projects pr ON pr.id = p.project_id AND p.project_id > 0
         WHERE p.payer_id = ? OR p.payee_id = ?
         ORDER BY p.created_at DESC
         LIMIT 15"
    );
    $paymentsStmt->execute([(int) $user['id'], (int) $user['id']]);
    $recentPayments = $paymentsStmt->fetchAll();

    $confirmStmt = db()->prepare(
        "SELECT ppc.*, pr.title AS project_title
         FROM project_payment_confirmations ppc
         JOIN projects pr ON pr.id = ppc.project_id
         WHERE ppc.client_id = ? OR ppc.freelancer_id = ?
         ORDER BY ppc.client_submitted_at DESC
         LIMIT 15"
    );
    $confirmStmt->execute([(int) $user['id'], (int) $user['id']]);
    $recentConfirmations = $confirmStmt->fetchAll();

    $topupsStmt = db()->prepare(
        'SELECT * FROM wallet_topups WHERE user_id = ? ORDER BY created_at DESC LIMIT 15'
    );
    $topupsStmt->execute([(int) $user['id']]);
    $recentTopups = $topupsStmt->fetchAll();
} catch (Throwable) {
    $recentPayments = [];
    $recentConfirmations = [];
    $recentTopups = [];
}

$gatewayCatalog = payment_gateway_catalog();

require_once __DIR__ . '/includes/layout.php';
?>
<div class="page-shell">
<section class="settings-shell payment-shell">
    <aside class="settings-sidebar card payment-sidebar">
        <h2 class="settings-title">Payment Center</h2>
        <p class="muted">Manage billing, wallet, and payouts in one place.</p>
        <div class="settings-group">
            <h4>Billing</h4>
            <a href="<?= BASE_URL ?>/payment.php?tab=billing" class="<?= $tab === 'billing' ? 'is-active' : '' ?>">Billing &amp; wallet</a>
            <a href="<?= BASE_URL ?>/payment.php?tab=gateways" class="<?= $tab === 'gateways' ? 'is-active' : '' ?>">Payment gateways</a>
            <a href="<?= BASE_URL ?>/payment.php?tab=withdrawals" class="<?= $tab === 'withdrawals' ? 'is-active' : '' ?>">Withdrawals</a>
            <a href="<?= BASE_URL ?>/payment.php?tab=guide" class="<?= $tab === 'guide' ? 'is-active' : '' ?>">Payment guide</a>
        </div>
        <div class="payment-sidebar__wallet">
            <small>Available balance</small>
            <strong>₹ <?= h(number_format($wallet, 2)) ?></strong>
            <span class="payment-sidebar__gateway muted">Gateway: <?= h(payment_gateway_label($billingGateway)) ?></span>
        </div>
        <p class="payment-sidebar__back"><a href="<?= BASE_URL ?>/dashboard.php">← Back to dashboard</a></p>
    </aside>

    <div class="settings-content payment-content">
        <?php if ($error !== ''): ?><p class="danger payment-flash"><?= h($error) ?></p><?php endif; ?>
        <?php if ($success !== ''): ?><p class="success payment-flash"><?= h($success) ?></p><?php endif; ?>

        <?php if ($tab === 'billing'): ?>
            <?php require __DIR__ . '/includes/partials/payment_billing_tab.php'; ?>
        <?php elseif ($tab === 'gateways'): ?>
            <?php require __DIR__ . '/includes/partials/payment_gateways_tab.php'; ?>
        <?php elseif ($tab === 'withdrawals'): ?>
            <section class="card settings-card payment-hero payment-hero--withdraw">
                <span class="payment-hero__eyebrow">Payout operations</span>
                <h2>Withdraw your earnings</h2>
                <p>Choose a secure disbursement method and move funds from your wallet to your preferred payout channel.</p>
            </section>

            <section class="card settings-card">
                <div class="withdraw-shell payment-withdraw-shell">
                    <section class="withdraw-card">
                        <div class="withdraw-card__head">
                            <h4>Disbursement methods</h4>
                            <span class="withdraw-balance">Available: ₹ <?= h(number_format($wallet, 2)) ?></span>
                        </div>
                        <p class="withdraw-subtext">Select where your funds should be sent. This demo mirrors a production payout flow.</p>
                        <div class="withdraw-method-list">
                            <label class="withdraw-method">
                                <input type="radio" name="withdraw_method_view" checked disabled>
                                <span class="withdraw-method__meta">
                                    <strong>Direct to local bank</strong>
                                    <small>Typically 2–5 business days</small>
                                </span>
                                <span class="withdraw-method__status">Primary</span>
                            </label>
                            <label class="withdraw-method">
                                <input type="radio" name="withdraw_method_view" disabled>
                                <span class="withdraw-method__meta">
                                    <strong>PayPal</strong>
                                    <small>Usually within 24 hours</small>
                                </span>
                                <span class="withdraw-method__status">Available</span>
                            </label>
                            <label class="withdraw-method">
                                <input type="radio" name="withdraw_method_view" disabled>
                                <span class="withdraw-method__meta">
                                    <strong>Payoneer</strong>
                                    <small>Low-fee global payout</small>
                                </span>
                                <span class="withdraw-method__status">Available</span>
                            </label>
                        </div>
                    </section>

                    <section class="withdraw-card payment-withdraw-form-card">
                        <div class="withdraw-card__head">
                            <h4>Request payout</h4>
                        </div>
                        <form method="post" class="withdraw-form payment-withdraw-form">
                            <label for="withdraw_method">Withdrawal method</label>
                            <select id="withdraw_method" name="withdraw_method" required>
                                <option value="bank">Direct to local bank</option>
                                <option value="paypal">PayPal</option>
                                <option value="payoneer">Payoneer</option>
                            </select>

                            <label for="withdraw_amount">Amount (INR)</label>
                            <input id="withdraw_amount" type="number" name="withdraw_amount" step="0.01" min="1" max="<?= h((string) max(0, $wallet)) ?>" placeholder="Enter amount" required>

                            <div class="withdraw-note">
                                Funds are deducted from your demo wallet immediately after you submit.
                            </div>

                            <input type="hidden" name="withdraw_wallet" value="1">
                            <button type="submit" class="withdraw-submit payment-checkout-submit">Withdraw funds</button>
                        </form>
                    </section>
                </div>
            </section>
        <?php else: ?>
            <section class="card settings-card payment-hero">
                <span class="payment-hero__eyebrow">Payments intelligence</span>
                <h2>How online payments work</h2>
                <p>Choose a gateway, authorize payment, and track settlement through the platform wallet and project escrow flow.</p>
            </section>

            <section class="card settings-card">
                <h3>Integrated payment gateways</h3>
                <div class="payment-method-grid">
                    <?php foreach ($gatewayCatalog as $gid => $g): ?>
                        <article class="payment-method-tile">
                            <h4><?= h((string) ($g['name'] ?? $gid)) ?></h4>
                            <p><?= h((string) ($g['description'] ?? '')) ?></p>
                            <p class="muted" style="margin-top:8px;font-size:0.82rem;"><?= h(payment_gateway_mode_label($gid)) ?></p>
                        </article>
                    <?php endforeach; ?>
                </div>
            </section>

            <section class="card settings-card">
                <h3>Payment processing lifecycle</h3>
                <div class="payment-timeline">
                    <div class="payment-timeline__item"><strong>1. Gateway selection</strong> — Client picks Razorpay, Stripe, PayPal, PayU, or Cashfree.</div>
                    <div class="payment-timeline__item"><strong>2. Authorization</strong> — Gateway validates funds with the bank or wallet network.</div>
                    <div class="payment-timeline__item"><strong>3. Escrow / hold</strong> — Funds are reserved until project milestones are met.</div>
                    <div class="payment-timeline__item"><strong>4. Confirmation</strong> — Freelancer confirms receipt on the project page.</div>
                    <div class="payment-timeline__item"><strong>5. Settlement</strong> — Balance is released to the freelancer wallet or bank account.</div>
                </div>
            </section>

            <section class="card settings-card">
                <p class="muted">
                    <a href="<?= BASE_URL ?>/payment.php?tab=gateways">View gateway settings</a>
                    · <a href="<?= BASE_URL ?>/payment.php?tab=billing">Add wallet funds</a>
                </p>
            </section>
        <?php endif; ?>
    </div>
</section>
</div>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
