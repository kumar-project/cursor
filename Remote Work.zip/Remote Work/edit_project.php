<?php
declare(strict_types=1);

$wideMain = true;

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/project_reminder.php';
require_once __DIR__ . '/includes/skills_catalog.php';
require_once __DIR__ . '/config.php';

require_login();
require_client_portal();

$user = current_user();
/** Prefer POST so save works even if the query string is dropped on submit. */
$projectId = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
if ($projectId <= 0) {
    http_response_code(404);
    echo 'Project not found';
    exit;
}

$stmt = db()->prepare('SELECT * FROM projects WHERE id = ?');
$stmt->execute([$projectId]);
$project = $stmt->fetch();
if (!$project) {
    http_response_code(404);
    echo 'Project not found';
    exit;
}

if (!can_manage_project_as_client($user, $project)) {
    http_response_code(403);
    echo 'You cannot edit this project.';
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $budget = (float) ($_POST['budget'] ?? 0);
    $skillsRequired = nk_normalize_skills_post((string) ($_POST['skills_required'] ?? ''));
    $qualifications = trim((string) ($_POST['qualifications'] ?? ''));
    $qualifications = $qualifications === '' ? null : $qualifications;

    if ($title === '' || $description === '' || $budget <= 0) {
        $error = 'Please provide title, description and valid budget.';
    } else {
        $reminderAt = project_parse_reminder_from_post($_POST);
        try {
            $upd = db()->prepare(
                'UPDATE projects SET title = ?, description = ?, budget = ?, reminder_at = ?, skills_required = ?, qualifications = ? WHERE id = ?'
            );
            $upd->execute([$title, $description, $budget, $reminderAt, $skillsRequired, $qualifications, $projectId]);
            header('Location: ' . BASE_URL . '/dashboard.php?project_updated=1');
            exit;
        } catch (Throwable $e) {
            $error = 'Could not save changes. Run database setup if columns are missing (reminder_at, skills_required, qualifications).';
        }
    }
}

if ($error !== '' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $project['title'] = trim((string) ($_POST['title'] ?? ''));
    $project['description'] = trim((string) ($_POST['description'] ?? ''));
    $project['budget'] = (string) ($_POST['budget'] ?? '0');
    $project['skills_required'] = trim((string) ($_POST['skills_required'] ?? ''));
    $project['qualifications'] = trim((string) ($_POST['qualifications'] ?? ''));
}

$split = project_reminder_split($project['reminder_at'] ?? null);
$pr_reminder_date = $split['date'];
$pr_reminder_time = $split['time'];
$pr_skills_required = (string) ($project['skills_required'] ?? '');
$pr_qualifications = (string) ($project['qualifications'] ?? '');
if ($error !== '' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $pr_reminder_date = trim((string) ($_POST['reminder_date'] ?? ''));
    $pr_reminder_time = trim((string) ($_POST['reminder_time'] ?? ''));
    $pr_skills_required = (string) ($_POST['skills_required'] ?? '');
    $pr_qualifications = (string) ($_POST['qualifications'] ?? '');
}

require_once __DIR__ . '/includes/layout.php';
?>
<div class="page-shell">
<section class="card project-form-card">
    <h2>Edit project</h2>
    <p class="muted"><a href="<?= BASE_URL ?>/project.php?id=<?= (int) $project['id'] ?>">View project page</a></p>
    <form method="post" action="<?= h(BASE_URL . '/edit_project.php?id=' . (int) $project['id']) ?>">
        <input type="hidden" name="id" value="<?= (int) $project['id'] ?>">
        <label>Project Title</label>
        <input name="title" required value="<?= h((string) $project['title']) ?>">

        <label>Description</label>
        <textarea name="description" rows="6" required><?= h((string) $project['description']) ?></textarea>

        <label>Budget (INR)</label>
        <input type="number" step="0.01" name="budget" required value="<?= h((string) $project['budget']) ?>">

        <?php require __DIR__ . '/includes/partials/project_skills_qualification_fields.php'; ?>
        <?php require __DIR__ . '/includes/partials/project_reminder_fields.php'; ?>
        <p class="muted" style="margin-top:-8px;">Clear both date and time to remove the reminder.</p>

        <button type="submit">Save changes</button>
    </form>
</section>
</div>
<?php if ($error !== ''): ?>
<script>
window.addEventListener('DOMContentLoaded', function () {
    alert(<?= json_encode($error, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) ?>);
});
</script>
<?php endif; ?>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
