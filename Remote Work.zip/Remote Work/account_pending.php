<?php
declare(strict_types=1);

$wideMain = true;
$page_title = 'Account pending';

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config.php';

require_login();
$user = current_user();
if (!client_account_pending($user)) {
    if (is_platform_staff($user)) {
        header('Location: ' . BASE_URL . '/admin.php');
    } elseif (($user['role'] ?? '') === 'freelancer') {
        header('Location: ' . BASE_URL . '/index.php');
    } else {
        header('Location: ' . BASE_URL . '/dashboard.php');
    }
    exit;
}

require_once __DIR__ . '/includes/layout.php';
?>
<div class="page-shell">
    <section class="card login-form-card" style="max-width: 560px; margin: 0 auto;">
        <h1 style="margin-top:0;">Client account pending approval</h1>
        <p class="muted">Your email <strong><?= h((string) ($user['email'] ?? '')) ?></strong> is registered as a client, but a Super Admin has not approved it yet.</p>
        <p class="muted">After a Super Admin approves your account, you can post projects, assign work, and use the client dashboard. Refresh this page later, or use <a href="<?= BASE_URL ?>/account_pending.php">check again</a>.</p>
        <p class="muted">You can still browse open jobs on the <a href="<?= BASE_URL ?>/index.php">home page</a>.</p>
    </section>
</div>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
