<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_PORT, DB_NAME);
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    ensure_users_role_enum($pdo);
    ensure_super_admin_credentials_table($pdo);
    ensure_users_freelancer_onboarding_columns($pdo);
    ensure_users_client_approval_column($pdo);
    ensure_users_mobile_column($pdo);
    ensure_projects_extra_columns($pdo);
    ensure_blog_tables($pdo);
    ensure_wallet_topups_table($pdo);
    return $pdo;
}

/**
 * Older databases may have users.role ENUM without super_admin; that breaks staff login.
 */
function ensure_users_role_enum(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    $schema = DB_NAME;
    $stmt = $pdo->prepare(
        'SELECT COLUMN_TYPE FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?'
    );
    $stmt->execute([$schema, 'users', 'role']);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        return;
    }
    $columnType = (string) ($row['COLUMN_TYPE'] ?? '');
    if (stripos($columnType, 'super_admin') !== false) {
        return;
    }

    try {
        $pdo->exec(
            "ALTER TABLE users MODIFY COLUMN role ENUM('client', 'freelancer', 'admin', 'super_admin') NOT NULL DEFAULT 'freelancer'"
        );
        $pdo->exec(
            "UPDATE users SET role = 'super_admin' WHERE LOWER(email) = LOWER('admin@mini.local')"
        );
    } catch (Throwable) {
    }
}

/**
 * Super Admin login: username and password are read from super_admin_credentials only (user_name + password column).
 * staff_user_id links the credential row to a users row for the session when user_name is not the staff email.
 */
function migrate_super_admin_credentials_to_user_name(PDO $pdo, string $schema): void
{
    $col = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?'
    );
    $col->execute([$schema, 'super_admin_credentials', 'user_id']);
    if ((int) $col->fetchColumn() === 0) {
        return;
    }

    try {
        $fk = $pdo->prepare(
            'SELECT DISTINCT CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE
             WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ? AND REFERENCED_TABLE_NAME IS NOT NULL'
        );
        $fk->execute([$schema, 'super_admin_credentials', 'user_id']);
        while ($r = $fk->fetch(PDO::FETCH_ASSOC)) {
            $name = (string) ($r['CONSTRAINT_NAME'] ?? '');
            if ($name !== '') {
                $pdo->exec('ALTER TABLE super_admin_credentials DROP FOREIGN KEY `' . str_replace('`', '``', $name) . '`');
            }
        }
    } catch (Throwable) {
    }

    foreach (['uq_super_admin_credentials_user', 'uq_super_admin_credentials_user_id'] as $idx) {
        try {
            $pdo->exec('ALTER TABLE super_admin_credentials DROP INDEX `' . str_replace('`', '``', $idx) . '`');
        } catch (Throwable) {
        }
    }

    try {
        $col->execute([$schema, 'super_admin_credentials', 'user_name']);
        if ((int) $col->fetchColumn() === 0) {
            $pdo->exec('ALTER TABLE super_admin_credentials ADD COLUMN user_name VARCHAR(150) NULL AFTER id');
        }
    } catch (Throwable) {
    }

    try {
        $pdo->exec(
            'UPDATE super_admin_credentials c
             INNER JOIN users u ON u.id = c.user_id
             SET c.user_name = u.email'
        );
    } catch (Throwable) {
    }

    try {
        $pdo->exec("DELETE FROM super_admin_credentials WHERE user_name IS NULL OR TRIM(user_name) = ''");
    } catch (Throwable) {
    }

    try {
        $pdo->exec('ALTER TABLE super_admin_credentials DROP COLUMN user_id');
    } catch (Throwable) {
    }

    try {
        $pdo->exec('ALTER TABLE super_admin_credentials MODIFY user_name VARCHAR(150) NOT NULL');
    } catch (Throwable) {
    }

    try {
        $pdo->exec('ALTER TABLE super_admin_credentials ADD UNIQUE KEY uq_super_admin_credentials_user_name (user_name)');
    } catch (Throwable) {
    }
}

function ensure_super_admin_credentials_table(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    $schema = DB_NAME;
    $check = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?'
    );
    $check->execute([$schema, 'super_admin_credentials']);
    if ((int) $check->fetchColumn() === 0) {
        $pdo->exec(
            'CREATE TABLE super_admin_credentials (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_name VARCHAR(150) NOT NULL,
                password VARCHAR(255) NOT NULL,
                staff_user_id INT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY uq_super_admin_credentials_user_name (user_name),
                CONSTRAINT fk_super_admin_credentials_staff_user FOREIGN KEY (staff_user_id) REFERENCES users(id) ON DELETE SET NULL
            )'
        );
    } else {
        migrate_super_admin_credentials_to_user_name($pdo, $schema);
    }

    ensure_super_admin_credentials_staff_user_id($pdo, $schema);

    try {
        $pdo->exec(
            "INSERT INTO super_admin_credentials (user_name, password, staff_user_id)
             SELECT u.email, u.password, u.id FROM users u
             WHERE u.role IN ('admin', 'super_admin')
             AND NOT EXISTS (
                 SELECT 1 FROM super_admin_credentials c
                 WHERE LOWER(TRIM(c.user_name)) = LOWER(TRIM(u.email))
             )"
        );
    } catch (Throwable) {
    }

    try {
        $pdo->exec(
            'UPDATE super_admin_credentials c
             INNER JOIN users u ON LOWER(TRIM(c.user_name)) = LOWER(TRIM(u.email))
             SET c.staff_user_id = u.id
             WHERE c.staff_user_id IS NULL AND u.role IN (\'admin\', \'super_admin\')'
        );
    } catch (Throwable) {
    }
}

function ensure_super_admin_credentials_staff_user_id(PDO $pdo, string $schema): void
{
    $check = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?'
    );
    $check->execute([$schema, 'super_admin_credentials', 'staff_user_id']);
    if ((int) $check->fetchColumn() > 0) {
        return;
    }

    try {
        $pdo->exec('ALTER TABLE super_admin_credentials ADD COLUMN staff_user_id INT NULL');
    } catch (Throwable) {
        return;
    }

    try {
        $pdo->exec(
            'ALTER TABLE super_admin_credentials
             ADD CONSTRAINT fk_super_admin_credentials_staff_user
             FOREIGN KEY (staff_user_id) REFERENCES users(id) ON DELETE SET NULL'
        );
    } catch (Throwable) {
    }

    try {
        $pdo->exec(
            'UPDATE super_admin_credentials c
             INNER JOIN users u ON LOWER(TRIM(c.user_name)) = LOWER(TRIM(u.email))
             SET c.staff_user_id = u.id
             WHERE u.role IN (\'admin\', \'super_admin\')'
        );
    } catch (Throwable) {
    }
}

function super_admin_verify_stored_password(string $plain, string $stored): bool
{
    $stored = (string) $stored;
    if ($stored === '' || $plain === '') {
        return false;
    }
    $info = password_get_info($stored);
    if (($info['algo'] ?? 0) !== 0) {
        return password_verify($plain, $stored);
    }

    return hash_equals($stored, $plain);
}

function super_admin_upgrade_plaintext_password(PDO $pdo, int $credentialId, string $plain, string $stored): void
{
    $info = password_get_info($stored);
    if (($info['algo'] ?? 0) !== 0) {
        return;
    }
    try {
        $hash = password_hash($plain, PASSWORD_DEFAULT);
        $u = $pdo->prepare('UPDATE super_admin_credentials SET password = ? WHERE id = ?');
        $u->execute([$hash, $credentialId]);
    } catch (Throwable) {
    }
}

/**
 * Ensures at least one staff row exists (admin or super_admin). Mirrors setup.php seed when the DB has only clients/freelancers.
 */
function ensure_platform_staff_user_id(PDO $pdo): ?int
{
    try {
        $r = $pdo->query(
            "SELECT id FROM users WHERE role IN ('super_admin', 'admin') ORDER BY id ASC LIMIT 1"
        );
        $row = $r ? $r->fetch(PDO::FETCH_ASSOC) : false;
        if ($row) {
            return (int) $row['id'];
        }
    } catch (Throwable) {
        return null;
    }

    $seedEmail = 'admin@mini.local';
    $seedName = 'Platform Super Admin';

    try {
        $hash = password_hash('admin123', PASSWORD_DEFAULT);
        $ins = $pdo->prepare('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)');
        $ins->execute([$seedName, $seedEmail, $hash, 'super_admin']);

        return (int) $pdo->lastInsertId();
    } catch (Throwable) {
        try {
            $up = $pdo->prepare('UPDATE users SET role = ? WHERE LOWER(email) = LOWER(?)');
            $up->execute(['super_admin', $seedEmail]);
            $sel = $pdo->prepare(
                "SELECT id FROM users WHERE LOWER(email) = LOWER(?) AND role IN ('admin', 'super_admin') LIMIT 1"
            );
            $sel->execute([$seedEmail]);
            $u = $sel->fetch(PDO::FETCH_ASSOC);

            return $u ? (int) $u['id'] : null;
        } catch (Throwable) {
            return null;
        }
    }
}

/**
 * Maps a verified super_admin_credentials row to a staff users.id.
 * Ignores staff_user_id if it does not point to an admin/super_admin (common after bad manual edits).
 */
function resolve_super_admin_session_user_id(PDO $pdo, array $cred): int
{
    $cand = (int) ($cred['staff_user_id'] ?? 0);
    if ($cand > 0) {
        $q = $pdo->prepare(
            "SELECT id FROM users WHERE id = ? AND role IN ('admin', 'super_admin') LIMIT 1"
        );
        $q->execute([$cand]);
        if ($q->fetch(PDO::FETCH_ASSOC)) {
            return $cand;
        }
    }

    $uname = trim((string) ($cred['user_name'] ?? ''));
    if ($uname !== '') {
        $link = $pdo->prepare(
            "SELECT id FROM users
             WHERE LOWER(TRIM(email)) = LOWER(TRIM(?)) AND role IN ('admin', 'super_admin')
             LIMIT 1"
        );
        $link->execute([$uname]);
        $linked = $link->fetch(PDO::FETCH_ASSOC);
        if ($linked) {
            return (int) $linked['id'];
        }
    }

    try {
        $fallback = $pdo->query(
            "SELECT id FROM users WHERE role IN ('super_admin', 'admin') ORDER BY id ASC LIMIT 1"
        );
        $fb = $fallback ? $fallback->fetch(PDO::FETCH_ASSOC) : false;
        if ($fb) {
            return (int) $fb['id'];
        }
    } catch (Throwable) {
    }

    $ensured = ensure_platform_staff_user_id($pdo);

    return $ensured ?? 0;
}

/**
 * When no super_admin_credentials row exists for this email but a staff user exists in users with the same password,
 * insert the missing row (repairs DBs that never ran backfill or had a failed migration).
 */
function bootstrap_super_admin_credentials_row(string $email, string $plainPassword): void
{
    $email = trim($email);
    if ($email === '' || $plainPassword === '') {
        return;
    }
    try {
        $chk = db()->prepare(
            'SELECT 1 FROM super_admin_credentials WHERE LOWER(TRIM(user_name)) = LOWER(TRIM(?)) LIMIT 1'
        );
        $chk->execute([$email]);
        if ($chk->fetch()) {
            return;
        }
        $u = db()->prepare(
            "SELECT id, email, password FROM users
             WHERE LOWER(TRIM(email)) = LOWER(TRIM(?)) AND role IN ('admin', 'super_admin')
             LIMIT 1"
        );
        $u->execute([$email]);
        $staff = $u->fetch();
        if (
            !$staff
            || !isset($staff['password'])
            || (string) $staff['password'] === ''
            || !password_verify($plainPassword, (string) $staff['password'])
        ) {
            return;
        }
        $ins = db()->prepare(
            'INSERT INTO super_admin_credentials (user_name, password, staff_user_id) VALUES (?, ?, ?)'
        );
        $ins->execute([(string) $staff['email'], (string) $staff['password'], (int) $staff['id']]);
    } catch (Throwable) {
    }
}

/**
 * Blog CMS: categories and posts (managed from Super Admin).
 */
function ensure_wallet_topups_table(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS wallet_topups (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            amount DECIMAL(10,2) NOT NULL,
            gateway VARCHAR(50) NOT NULL,
            billing_method VARCHAR(30) NOT NULL,
            transaction_ref VARCHAR(150) NULL,
            status ENUM(\'pending\', \'completed\', \'failed\') NOT NULL DEFAULT \'completed\',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_wallet_topups_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            KEY idx_wallet_topups_user_created (user_id, created_at)
        )'
    );
}

function ensure_blog_tables(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS blog_categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(120) NOT NULL,
            slug VARCHAR(140) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_blog_categories_slug (slug)
        )'
    );
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS blog_posts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            category_id INT NOT NULL,
            author_id INT NOT NULL,
            title VARCHAR(255) NOT NULL,
            slug VARCHAR(280) NOT NULL,
            content MEDIUMTEXT NOT NULL,
            excerpt VARCHAR(500) NULL,
            featured_image_path VARCHAR(500) NULL,
            status ENUM(\'draft\', \'published\') NOT NULL DEFAULT \'draft\',
            published_at DATETIME NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            CONSTRAINT fk_blog_posts_category FOREIGN KEY (category_id) REFERENCES blog_categories(id),
            CONSTRAINT fk_blog_posts_author FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE KEY uq_blog_posts_slug (slug),
            KEY idx_blog_posts_status_published (status, published_at)
        )'
    );

    try {
        if ((int) $pdo->query('SELECT COUNT(*) FROM blog_categories')->fetchColumn() === 0) {
            $pdo->exec("INSERT INTO blog_categories (name, slug) VALUES ('General', 'general')");
        }
    } catch (Throwable) {
    }
}

/**
 * Adds optional project columns (reminder, skills, qualifications) if missing.
 */
function ensure_projects_extra_columns(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    $schema = DB_NAME;
    $check = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?'
    );

    $columns = [
        'reminder_at' => 'ALTER TABLE projects ADD COLUMN reminder_at DATETIME NULL',
        'skills_required' => 'ALTER TABLE projects ADD COLUMN skills_required TEXT NULL',
        'qualifications' => 'ALTER TABLE projects ADD COLUMN qualifications TEXT NULL',
    ];

    foreach ($columns as $columnName => $alterSql) {
        $check->execute([$schema, 'projects', $columnName]);
        if ((int) $check->fetchColumn() === 0) {
            $pdo->exec($alterSql);
        }
    }
}

/**
 * Adds freelancer onboarding columns to `users` if missing (older DBs created before these fields).
 */
function ensure_users_freelancer_onboarding_columns(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    $schema = DB_NAME;
    $alters = [
        'remote_work_type' => 'ALTER TABLE users ADD COLUMN remote_work_type VARCHAR(40) NULL',
        'availability_timeline' => 'ALTER TABLE users ADD COLUMN availability_timeline VARCHAR(40) NULL',
        'freelancer_onboarding_skipped' => 'ALTER TABLE users ADD COLUMN freelancer_onboarding_skipped TINYINT(1) NOT NULL DEFAULT 0',
        'cv_file_path' => 'ALTER TABLE users ADD COLUMN cv_file_path VARCHAR(255) NULL',
    ];

    $check = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?'
    );

    foreach ($alters as $column => $sql) {
        $check->execute([$schema, 'users', $column]);
        if ((int) $check->fetchColumn() === 0) {
            $pdo->exec($sql);
        }
    }
}

/**
 * New self-registered clients start as client_approved = 0 until staff approves.
 * Existing rows get DEFAULT 1 when the column is added.
 */
function ensure_users_client_approval_column(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    $schema = DB_NAME;
    $check = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?'
    );
    $check->execute([$schema, 'users', 'client_approved']);
    if ((int) $check->fetchColumn() > 0) {
        return;
    }

    try {
        $pdo->exec(
            'ALTER TABLE users ADD COLUMN client_approved TINYINT(1) NOT NULL DEFAULT 1'
        );
    } catch (Throwable) {
        return;
    }
    try {
        $pdo->exec(
            "UPDATE users SET client_approved = 1 WHERE role IN ('freelancer', 'admin', 'super_admin')"
        );
        $pdo->exec("UPDATE users SET client_approved = 1 WHERE role = 'client'");
    } catch (Throwable) {
    }
}

function ensure_users_mobile_column(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    $schema = DB_NAME;
    $check = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?'
    );
    $check->execute([$schema, 'users', 'mobile']);
    if ((int) $check->fetchColumn() > 0) {
        return;
    }

    try {
        $pdo->exec('ALTER TABLE users ADD COLUMN mobile VARCHAR(32) NULL');
    } catch (Throwable) {
    }
}

