<?php
declare(strict_types=1);

session_start();
session_destroy();
require_once __DIR__ . '/config.php';
header('Location: ' . BASE_URL . '/login.php');
exit;

