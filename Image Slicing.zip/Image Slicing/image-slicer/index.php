<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Image Slicer</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .panel { border: 1px solid #ddd; padding: 14px; margin-bottom: 14px; border-radius: 8px; }
        .row { display: flex; gap: 18px; flex-wrap: wrap; align-items: flex-end; }
        .field { display: flex; flex-direction: column; gap: 6px; min-width: 140px; }
        input[type="number"] { width: 120px; padding: 4px; }
        input[type="range"] { width: 180px; }
        button { padding: 8px 12px; cursor: pointer; }
        #previewCanvas { border: 1px solid #bbb; background: #f7f7f7; display: block; }
        .preview-wrap { max-width: 100%; max-height: 70vh; overflow: auto; border: 1px solid #e0e0e0; background: #fcfcfc; }
        #sliceContainer { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 12px; margin-top: 14px; }
        .slice-card { border: 1px solid #ddd; border-radius: 8px; padding: 10px; text-align: center; }
        .slice-card img { max-width: 100%; border: 1px solid #ccc; margin-bottom: 8px; }
        .muted { color: #666; font-size: 13px; }
        .hidden { display: none; }
        .preset-wrap { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 6px; }
        .preset-btn { border: 1px solid #bbb; background: #f4f4f4; border-radius: 999px; padding: 5px 10px; cursor: pointer; }
        .preset-btn.active { background: #1f6feb; border-color: #1f6feb; color: #fff; }
        .workspace-layout { display: flex; gap: 14px; align-items: flex-start; }
        .image-area { flex: 0 0 var(--image-panel-width, 70%); max-width: var(--image-panel-width, 70%); }
        .settings-area { flex: 1 1 auto; min-width: 260px; }
        .tool-row { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; margin-bottom: 10px; }
        .tool-btn { border: 1px solid #bbb; background: #f8f8f8; border-radius: 6px; padding: 6px 10px; }
        .tool-btn.active { background: #1f6feb; border-color: #1f6feb; color: #fff; }
        .tiny-btn { padding: 5px 8px; font-size: 12px; }
        .section-head { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 10px; }
        .section-head h3 { margin: 0; }
        .toggle-label { font-size: 13px; color: #444; user-select: none; display: inline-flex; align-items: center; gap: 6px; }
        .section-panel.is-closed { opacity: 0.9; }
        .section-body.is-closed { display: none; }
        @media (max-width: 980px) {
            .workspace-layout { flex-direction: column; }
            .image-area, .settings-area { max-width: 100%; flex-basis: 100%; }
        }
    </style>
</head>
<body>
<h2>Upload, Crop, Edit, and Slice Image</h2>

<div class="panel">
    <div class="field">
        <label for="imageInput"><strong>Select Image</strong></label>
        <input id="imageInput" type="file" accept="image/jpeg,image/png,image/gif">
        <span class="muted">Upload first, then set crop/edit/slice options.</span>
    </div>
</div>

<div id="workspace" class="hidden">
    <div class="workspace-layout">
        <div class="image-area">
            <div class="panel">
                <h3>Uploaded Image (Default 70%)</h3>
                <div class="tool-row">
                    <button id="cropToolBtn" class="tool-btn active" type="button">&#9986; Crop Tool</button>
                    <button id="sliceToolBtn" class="tool-btn" type="button">&#9633; Slice Tool</button>
                    <button id="undoRegionBtn" class="tiny-btn" type="button">Undo Region</button>
                    <button id="clearRegionsBtn" class="tiny-btn" type="button">Clear Regions</button>
                    <button id="zoomOutBtn" class="tiny-btn" type="button">-</button>
                    <button id="zoomInBtn" class="tiny-btn" type="button">+</button>
                    <button id="zoomResetBtn" class="tiny-btn" type="button">Reset Zoom</button>
                    <input id="zoomSlider" type="range" min="25" max="300" value="100" style="width:120px;">
                    <span class="muted">Zoom: <span id="zoomVal">100</span>%</span>
                    <span id="toolHint" class="muted">Drag on image to set crop box.</span>
                </div>
                <div class="preview-wrap">
                    <canvas id="previewCanvas"></canvas>
                </div>
            </div>
        </div>

        <div class="settings-area">
            <div id="settingsPanel" class="panel section-panel">
                <div class="section-head">
                    <h3>Settings (Default 30%)</h3>
                    <label class="toggle-label"><input id="toggleSettings" type="checkbox" checked> <span class="toggle-state">Open</span></label>
                </div>
                <div id="settingsBody" class="section-body">
                    <div class="field">
                        <label>Image Area Width: <span id="layoutSplitVal">70</span>%</label>
                        <input id="layoutSplit" type="range" min="50" max="85" value="70">
                        <span class="muted">Customize how much space image vs settings use.</span>
                    </div>
                </div>
            </div>

            <div id="cropPanel" class="panel section-panel">
                <div class="section-head">
                    <h3>Crop</h3>
                    <label class="toggle-label"><input id="toggleCrop" type="checkbox" checked> <span class="toggle-state">Open</span></label>
                </div>
                <div id="cropBody" class="section-body">
                    <div class="row">
                        <div class="field"><label>X</label><input id="cropX" type="number" min="0" value="0"></div>
                        <div class="field"><label>Y</label><input id="cropY" type="number" min="0" value="0"></div>
                        <div class="field"><label>Width</label><input id="cropW" type="number" min="1" value="1"></div>
                        <div class="field"><label>Height</label><input id="cropH" type="number" min="1" value="1"></div>
                        <button id="cropMinBtn" type="button">Minimize Crop</button>
                        <button id="cropMaxBtn" type="button">Maximize Crop</button>
                        <div class="field">
                            <label>Crop Scale</label>
                            <input id="cropScaleSlider" type="range" min="50" max="200" value="100">
                        </div>
                        <button id="applyCropBtn" type="button">Apply Crop</button>
                        <button id="saveCropBtn" type="button">Save Crop</button>
                        <button id="resetCropBtn" type="button">Reset Crop</button>
                    </div>
                </div>
            </div>

            <div id="editPanel" class="panel section-panel">
                <div class="section-head">
                    <h3>Edit</h3>
                    <label class="toggle-label"><input id="toggleEdit" type="checkbox" checked> <span class="toggle-state">Open</span></label>
                </div>
                <div id="editBody" class="section-body">
                    <div class="row">
                        <div class="field">
                            <label>Brightness: <span id="brightnessVal">100</span>%</label>
                            <input id="brightness" type="range" min="20" max="200" value="100">
                        </div>
                        <div class="field">
                            <label>Contrast: <span id="contrastVal">100</span>%</label>
                            <input id="contrast" type="range" min="20" max="200" value="100">
                        </div>
                        <div class="field">
                            <label>Grayscale: <span id="grayscaleVal">0</span>%</label>
                            <input id="grayscale" type="range" min="0" max="100" value="0">
                        </div>
                        <button id="resetEditBtn" type="button">Reset Edit</button>
                    </div>
                </div>
            </div>

            <div id="slicingPanel" class="panel section-panel">
                <div class="section-head">
                    <h3>Custom Slicing</h3>
                    <label class="toggle-label"><input id="toggleSlicing" type="checkbox" checked> <span class="toggle-state">Open</span></label>
                </div>
                <div id="slicingBody" class="section-body">
                    <div class="row">
                        <div class="field">
                            <label>Total slices</label>
                            <input id="sliceCount" type="number" min="1" value="4">
                            <input id="sliceSlider" type="range" min="1" max="400" value="4">
                            <div id="presetWrap" class="preset-wrap">
                                <button class="preset-btn" data-value="1" type="button">1</button>
                                <button class="preset-btn active" data-value="4" type="button">4</button>
                                <button class="preset-btn" data-value="9" type="button">9</button>
                                <button class="preset-btn" data-value="16" type="button">16</button>
                                <button class="preset-btn" data-value="25" type="button">25</button>
                                <button class="preset-btn" data-value="100" type="button">100</button>
                            </div>
                        </div>
                        <div class="field">
                            <label>
                                <input id="useCustomGrid" type="checkbox"> Use custom rows/columns
                            </label>
                        </div>
                        <div class="field">
                            <label>Rows</label>
                            <input id="rows" type="number" min="1" value="2" disabled>
                        </div>
                        <div class="field">
                            <label>Columns</label>
                            <input id="cols" type="number" min="1" value="2" disabled>
                        </div>
                        <div class="field">
                            <label>
                                <input id="useFixedSliceSize" type="checkbox"> Fixed size in Slice Tool
                            </label>
                        </div>
                        <div class="field">
                            <label>Slice Width</label>
                            <input id="sliceBoxW" type="number" min="1" value="120">
                        </div>
                        <div class="field">
                            <label>Slice Height</label>
                            <input id="sliceBoxH" type="number" min="1" value="120">
                        </div>
                        <button id="sliceBtn" type="button">Slice Image</button>
                        <button id="downloadAllBtn" type="button" disabled>Download All Slices</button>
                    </div>
                    <p class="muted">Free-form selector: switch to Slice Tool and draw custom regions on image.</p>
                    <p id="sliceMeta" class="muted"></p>
                </div>
            </div>
        </div>
    </div>

    <div class="panel">
        <h3>Sliced Images</h3>
        <div id="sliceContainer"></div>
    </div>
</div>

<script>
const imageInput = document.getElementById('imageInput');
const workspace = document.getElementById('workspace');
const previewCanvas = document.getElementById('previewCanvas');
const previewCtx = previewCanvas.getContext('2d');
const sliceContainer = document.getElementById('sliceContainer');
const downloadAllBtn = document.getElementById('downloadAllBtn');
const sliceMeta = document.getElementById('sliceMeta');
const cropToolBtn = document.getElementById('cropToolBtn');
const sliceToolBtn = document.getElementById('sliceToolBtn');
const undoRegionBtn = document.getElementById('undoRegionBtn');
const clearRegionsBtn = document.getElementById('clearRegionsBtn');
const toolHint = document.getElementById('toolHint');
const zoomOutBtn = document.getElementById('zoomOutBtn');
const zoomInBtn = document.getElementById('zoomInBtn');
const zoomResetBtn = document.getElementById('zoomResetBtn');
const zoomSlider = document.getElementById('zoomSlider');
const zoomVal = document.getElementById('zoomVal');
const layoutSplit = document.getElementById('layoutSplit');
const layoutSplitVal = document.getElementById('layoutSplitVal');
const settingsPanel = document.getElementById('settingsPanel');
const cropPanel = document.getElementById('cropPanel');
const editPanel = document.getElementById('editPanel');
const slicingPanel = document.getElementById('slicingPanel');
const settingsBody = document.getElementById('settingsBody');
const cropBody = document.getElementById('cropBody');
const editBody = document.getElementById('editBody');
const slicingBody = document.getElementById('slicingBody');
const toggleSettings = document.getElementById('toggleSettings');
const toggleCrop = document.getElementById('toggleCrop');
const toggleEdit = document.getElementById('toggleEdit');
const toggleSlicing = document.getElementById('toggleSlicing');

const cropX = document.getElementById('cropX');
const cropY = document.getElementById('cropY');
const cropW = document.getElementById('cropW');
const cropH = document.getElementById('cropH');
const cropMinBtn = document.getElementById('cropMinBtn');
const cropMaxBtn = document.getElementById('cropMaxBtn');
const cropScaleSlider = document.getElementById('cropScaleSlider');
const applyCropBtn = document.getElementById('applyCropBtn');
const saveCropBtn = document.getElementById('saveCropBtn');
const resetCropBtn = document.getElementById('resetCropBtn');

const brightness = document.getElementById('brightness');
const contrast = document.getElementById('contrast');
const grayscale = document.getElementById('grayscale');
const brightnessVal = document.getElementById('brightnessVal');
const contrastVal = document.getElementById('contrastVal');
const grayscaleVal = document.getElementById('grayscaleVal');
const resetEditBtn = document.getElementById('resetEditBtn');

const sliceCountInput = document.getElementById('sliceCount');
const sliceSlider = document.getElementById('sliceSlider');
const presetWrap = document.getElementById('presetWrap');
const useCustomGrid = document.getElementById('useCustomGrid');
const rowsInput = document.getElementById('rows');
const colsInput = document.getElementById('cols');
const useFixedSliceSize = document.getElementById('useFixedSliceSize');
const sliceBoxW = document.getElementById('sliceBoxW');
const sliceBoxH = document.getElementById('sliceBoxH');
const sliceBtn = document.getElementById('sliceBtn');

let originalCanvas = document.createElement('canvas');
let currentCanvas = document.createElement('canvas');
let sliceItems = [];
let toolMode = 'crop';
let customRegions = [];
let isSelecting = false;
let dragStart = null;
let dragCurrent = null;
let selectedCropRect = null;
let zoomLevel = 100;
const sectionState = {
    settings: true,
    crop: true,
    edit: true,
    slicing: true,
};

function setCanvasFromImage(img) {
    originalCanvas.width = img.naturalWidth;
    originalCanvas.height = img.naturalHeight;
    originalCanvas.getContext('2d').drawImage(img, 0, 0);
    resetCrop();
}

function resetCrop() {
    currentCanvas.width = originalCanvas.width;
    currentCanvas.height = originalCanvas.height;
    currentCanvas.getContext('2d').drawImage(originalCanvas, 0, 0);
    customRegions = [];
    selectedCropRect = null;
    cropX.value = 0;
    cropY.value = 0;
    cropW.value = currentCanvas.width;
    cropH.value = currentCanvas.height;
    renderPreview();
}

function getFilterString() {
    if (!sectionState.edit) {
        return 'brightness(100%) contrast(100%) grayscale(0%)';
    }
    return `brightness(${brightness.value}%) contrast(${contrast.value}%) grayscale(${grayscale.value}%)`;
}

function applySectionToggle(key, enabled) {
    sectionState[key] = enabled;
    const mapping = {
        settings: { panel: settingsPanel, body: settingsBody },
        crop: { panel: cropPanel, body: cropBody },
        edit: { panel: editPanel, body: editBody },
        slicing: { panel: slicingPanel, body: slicingBody },
    };
    const target = mapping[key];
    if (!target) return;
    target.panel.classList.toggle('is-closed', !enabled);
    target.body.classList.toggle('is-closed', !enabled);
}

function syncToggleLabel(checkboxEl) {
    if (!checkboxEl || !checkboxEl.parentElement) return;
    const stateEl = checkboxEl.parentElement.querySelector('.toggle-state');
    if (stateEl) {
        stateEl.textContent = checkboxEl.checked ? 'Open' : 'Close';
    }
}

function renderPreview() {
    if (!currentCanvas.width || !currentCanvas.height) return;
    previewCanvas.width = currentCanvas.width;
    previewCanvas.height = currentCanvas.height;
    previewCtx.clearRect(0, 0, previewCanvas.width, previewCanvas.height);
    previewCtx.filter = getFilterString();
    previewCtx.drawImage(currentCanvas, 0, 0);
    previewCtx.filter = 'none';

    if (!customRegions.length) {
        const { rows, cols } = getSliceLayout();
        drawGridOverlay(rows, cols);
    }
    drawCustomRegionOverlay();
    drawSavedCropOverlay();
    drawSelectionRect();
    applyZoom();
}

function drawGridOverlay(rows, cols) {
    if (rows < 1 || cols < 1) return;
    previewCtx.save();
    previewCtx.strokeStyle = 'rgba(255, 0, 0, 0.8)';
    previewCtx.lineWidth = 1;
    for (let c = 1; c < cols; c++) {
        const x = Math.floor((c * previewCanvas.width) / cols) + 0.5;
        previewCtx.beginPath();
        previewCtx.moveTo(x, 0);
        previewCtx.lineTo(x, previewCanvas.height);
        previewCtx.stroke();
    }
    for (let r = 1; r < rows; r++) {
        const y = Math.floor((r * previewCanvas.height) / rows) + 0.5;
        previewCtx.beginPath();
        previewCtx.moveTo(0, y);
        previewCtx.lineTo(previewCanvas.width, y);
        previewCtx.stroke();
    }
    previewCtx.restore();
}

function drawCustomRegionOverlay() {
    if (!customRegions.length) return;
    previewCtx.save();
    previewCtx.strokeStyle = 'rgba(0, 120, 255, 0.95)';
    previewCtx.fillStyle = 'rgba(0, 120, 255, 0.15)';
    previewCtx.lineWidth = 2;
    customRegions.forEach((region, index) => {
        previewCtx.fillRect(region.x, region.y, region.w, region.h);
        previewCtx.strokeRect(region.x, region.y, region.w, region.h);
        previewCtx.fillStyle = 'rgba(0, 0, 0, 0.7)';
        previewCtx.fillRect(region.x, region.y, 22, 16);
        previewCtx.fillStyle = '#fff';
        previewCtx.font = '11px Arial';
        previewCtx.fillText(String(index + 1), region.x + 6, region.y + 12);
        previewCtx.fillStyle = 'rgba(0, 120, 255, 0.15)';
    });
    previewCtx.restore();
}

function drawSavedCropOverlay() {
    if (!selectedCropRect || toolMode !== 'crop') return;
    previewCtx.save();
    previewCtx.strokeStyle = 'rgba(255, 160, 0, 1)';
    previewCtx.fillStyle = 'rgba(255, 160, 0, 0.18)';
    previewCtx.lineWidth = 2;
    previewCtx.fillRect(selectedCropRect.x, selectedCropRect.y, selectedCropRect.w, selectedCropRect.h);
    previewCtx.strokeRect(selectedCropRect.x, selectedCropRect.y, selectedCropRect.w, selectedCropRect.h);
    previewCtx.restore();
}

function drawSelectionRect() {
    if (!isSelecting || !dragStart || !dragCurrent) return;
    const rect = normalizeRect(dragStart.x, dragStart.y, dragCurrent.x, dragCurrent.y);
    previewCtx.save();
    previewCtx.strokeStyle = toolMode === 'slice' ? 'rgba(0, 120, 255, 1)' : 'rgba(255, 160, 0, 1)';
    previewCtx.setLineDash([6, 4]);
    previewCtx.lineWidth = 2;
    previewCtx.strokeRect(rect.x, rect.y, rect.w, rect.h);
    previewCtx.restore();
}

function normalizeRect(x1, y1, x2, y2) {
    const x = Math.max(0, Math.min(x1, x2));
    const y = Math.max(0, Math.min(y1, y2));
    const maxX = Math.min(currentCanvas.width, Math.max(x1, x2));
    const maxY = Math.min(currentCanvas.height, Math.max(y1, y2));
    return {
        x,
        y,
        w: Math.max(1, maxX - x),
        h: Math.max(1, maxY - y),
    };
}

function getCanvasPointFromEvent(event) {
    const rect = previewCanvas.getBoundingClientRect();
    const scaleX = previewCanvas.width / rect.width;
    const scaleY = previewCanvas.height / rect.height;
    const x = (event.clientX - rect.left) * scaleX;
    const y = (event.clientY - rect.top) * scaleY;
    return {
        x: Math.max(0, Math.min(previewCanvas.width, x)),
        y: Math.max(0, Math.min(previewCanvas.height, y)),
    };
}

function applyZoom() {
    const scale = zoomLevel / 100;
    previewCanvas.style.width = `${Math.max(1, Math.round(previewCanvas.width * scale))}px`;
    previewCanvas.style.height = `${Math.max(1, Math.round(previewCanvas.height * scale))}px`;
    zoomVal.textContent = String(zoomLevel);
    zoomSlider.value = String(zoomLevel);
}

function setZoom(nextZoom) {
    zoomLevel = Math.max(25, Math.min(300, Math.round(nextZoom)));
    applyZoom();
}

function setToolMode(mode) {
    if (mode === 'crop' && !sectionState.crop) {
        alert('Crop section is OFF. Turn it ON to use Crop Tool.');
        return;
    }
    if (mode === 'slice' && !sectionState.slicing) {
        alert('Custom Slicing section is OFF. Turn it ON to use Slice Tool.');
        return;
    }
    toolMode = mode;
    cropToolBtn.classList.toggle('active', mode === 'crop');
    sliceToolBtn.classList.toggle('active', mode === 'slice');
    toolHint.textContent = mode === 'slice'
        ? 'Drag on image to add custom free-form slice regions.'
        : 'Drag on image to set crop box.';
    renderPreview();
}

function onPreviewPointerDown(event) {
    if (!currentCanvas.width || !currentCanvas.height) return;
    if ((toolMode === 'crop' && !sectionState.crop) || (toolMode === 'slice' && !sectionState.slicing)) return;
    isSelecting = true;
    dragStart = getCanvasPointFromEvent(event);
    dragCurrent = dragStart;
    renderPreview();
}

function onPreviewPointerMove(event) {
    if (!isSelecting) return;
    dragCurrent = getCanvasPointFromEvent(event);
    renderPreview();
}

function onPreviewPointerUp(event) {
    if (!isSelecting) return;
    dragCurrent = getCanvasPointFromEvent(event);
    isSelecting = false;
    const rect = normalizeRect(dragStart.x, dragStart.y, dragCurrent.x, dragCurrent.y);
    dragStart = null;
    dragCurrent = null;

    if (rect.w < 3 || rect.h < 3) {
        renderPreview();
        return;
    }

    if (toolMode === 'crop') {
        cropX.value = Math.floor(rect.x);
        cropY.value = Math.floor(rect.y);
        cropW.value = Math.floor(rect.w);
        cropH.value = Math.floor(rect.h);
        selectedCropRect = {
            x: Math.floor(rect.x),
            y: Math.floor(rect.y),
            w: Math.floor(rect.w),
            h: Math.floor(rect.h),
        };
    } else {
        let regionX = Math.floor(rect.x);
        let regionY = Math.floor(rect.y);
        let regionW = Math.floor(rect.w);
        let regionH = Math.floor(rect.h);

        if (useFixedSliceSize.checked) {
            regionW = Math.max(1, parseInt(sliceBoxW.value || 1, 10));
            regionH = Math.max(1, parseInt(sliceBoxH.value || 1, 10));
            regionW = Math.min(regionW, currentCanvas.width);
            regionH = Math.min(regionH, currentCanvas.height);
            regionX = Math.max(0, Math.min(regionX, currentCanvas.width - regionW));
            regionY = Math.max(0, Math.min(regionY, currentCanvas.height - regionH));
        }

        customRegions.push({
            x: regionX,
            y: regionY,
            w: regionW,
            h: regionH,
        });
    }
    refreshLayoutMeta();
}

function syncCropRectFromInputs() {
    if (!currentCanvas.width || !currentCanvas.height) return;

    const x = Math.max(0, parseInt(cropX.value || 0, 10));
    const y = Math.max(0, parseInt(cropY.value || 0, 10));
    const maxW = Math.max(1, currentCanvas.width - x);
    const maxH = Math.max(1, currentCanvas.height - y);
    const w = Math.max(1, Math.min(parseInt(cropW.value || 1, 10), maxW));
    const h = Math.max(1, Math.min(parseInt(cropH.value || 1, 10), maxH));

    selectedCropRect = { x, y, w, h };
    cropX.value = x;
    cropY.value = y;
    cropW.value = w;
    cropH.value = h;
    renderPreview();
}

function resizeCropSelection(scaleFactor) {
    if (!currentCanvas.width || !currentCanvas.height) return;
    if (!selectedCropRect) {
        syncCropRectFromInputs();
    }
    if (!selectedCropRect) return;

    const centerX = selectedCropRect.x + (selectedCropRect.w / 2);
    const centerY = selectedCropRect.y + (selectedCropRect.h / 2);

    let newW = Math.max(1, Math.round(selectedCropRect.w * scaleFactor));
    let newH = Math.max(1, Math.round(selectedCropRect.h * scaleFactor));
    newW = Math.min(newW, currentCanvas.width);
    newH = Math.min(newH, currentCanvas.height);

    let newX = Math.round(centerX - (newW / 2));
    let newY = Math.round(centerY - (newH / 2));
    newX = Math.max(0, Math.min(newX, currentCanvas.width - newW));
    newY = Math.max(0, Math.min(newY, currentCanvas.height - newH));

    selectedCropRect = { x: newX, y: newY, w: newW, h: newH };
    cropX.value = newX;
    cropY.value = newY;
    cropW.value = newW;
    cropH.value = newH;
    renderPreview();
}

function cropCurrentCanvasFromSelection(persistToOriginal = false) {
    if (!sectionState.crop) {
        alert('Crop section is OFF. Turn it ON first.');
        return false;
    }
    const x = Math.max(0, parseInt(cropX.value || selectedCropRect?.x || 0, 10));
    const y = Math.max(0, parseInt(cropY.value || selectedCropRect?.y || 0, 10));
    const w = Math.max(1, parseInt(cropW.value || selectedCropRect?.w || 1, 10));
    const h = Math.max(1, parseInt(cropH.value || selectedCropRect?.h || 1, 10));

    const maxW = currentCanvas.width - x;
    const maxH = currentCanvas.height - y;
    if (maxW <= 0 || maxH <= 0) {
        alert('Crop area starts outside image bounds.');
        return false;
    }

    const cropWidth = Math.min(w, maxW);
    const cropHeight = Math.min(h, maxH);
    const nextCanvas = document.createElement('canvas');
    nextCanvas.width = cropWidth;
    nextCanvas.height = cropHeight;
    nextCanvas.getContext('2d').drawImage(currentCanvas, x, y, cropWidth, cropHeight, 0, 0, cropWidth, cropHeight);
    currentCanvas = nextCanvas;

    if (persistToOriginal) {
        originalCanvas.width = currentCanvas.width;
        originalCanvas.height = currentCanvas.height;
        originalCanvas.getContext('2d').drawImage(currentCanvas, 0, 0);
    }

    selectedCropRect = null;
    customRegions = [];
    cropX.value = 0;
    cropY.value = 0;
    cropW.value = currentCanvas.width;
    cropH.value = currentCanvas.height;
    renderPreview();
    return true;
}

function applyCrop() {
    cropCurrentCanvasFromSelection(false);
}

function saveCroppedImage() {
    if (!currentCanvas.width || !currentCanvas.height) {
        alert('Please upload an image first.');
        return;
    }

    const ok = cropCurrentCanvasFromSelection(true);
    if (ok) {
        sliceMeta.textContent = 'Crop saved to image (no download).';
    }
}

function updateEditLabels() {
    brightnessVal.textContent = brightness.value;
    contrastVal.textContent = contrast.value;
    grayscaleVal.textContent = grayscale.value;
}

function getProcessedCanvas() {
    const out = document.createElement('canvas');
    out.width = currentCanvas.width;
    out.height = currentCanvas.height;
    const ctx = out.getContext('2d');
    ctx.filter = getFilterString();
    ctx.drawImage(currentCanvas, 0, 0);
    ctx.filter = 'none';
    return out;
}

function autoGrid(total) {
    let rows = Math.floor(Math.sqrt(total));
    while (rows > 1 && total % rows !== 0) rows--;
    return { rows, cols: Math.ceil(total / rows) };
}

function setPresetActive(targetValue) {
    const buttons = presetWrap.querySelectorAll('.preset-btn');
    buttons.forEach((btn) => {
        btn.classList.toggle('active', parseInt(btn.dataset.value, 10) === targetValue);
    });
}

function refreshLayoutMeta() {
    if (!sectionState.slicing) {
        sliceMeta.textContent = 'Custom Slicing is OFF.';
        renderPreview();
        return;
    }
    const { total, rows, cols } = getSliceLayout();
    if (customRegions.length) {
        sliceMeta.textContent = `Custom selector: ${customRegions.length} free-form region(s) ready for slicing.`;
    } else {
        const cropInfo = selectedCropRect ? ` | Crop selected: ${selectedCropRect.w} x ${selectedCropRect.h}` : '';
        const fixedInfo = useFixedSliceSize.checked
            ? ` | Fixed slice size: ${Math.max(1, parseInt(sliceBoxW.value || 1, 10))}x${Math.max(1, parseInt(sliceBoxH.value || 1, 10))}`
            : '';
        sliceMeta.textContent = `Grid preview: ${rows} x ${cols} (${total} slices)${cropInfo}${fixedInfo}`;
    }
    renderPreview();
}

function syncSelectorState() {
    const custom = useCustomGrid.checked;
    sliceSlider.disabled = custom;
    presetWrap.querySelectorAll('.preset-btn').forEach((btn) => {
        btn.disabled = custom;
    });
}

function getSliceLayout() {
    const total = Math.max(1, parseInt(sliceCountInput.value || 1, 10));
    if (useCustomGrid.checked) {
        const rows = Math.max(1, parseInt(rowsInput.value || 1, 10));
        const cols = Math.max(1, parseInt(colsInput.value || 1, 10));
        return { total: rows * cols, rows, cols };
    }
    const grid = autoGrid(total);
    return { total, rows: grid.rows, cols: grid.cols };
}

function clearSlices() {
    sliceContainer.innerHTML = '';
    sliceItems = [];
    downloadAllBtn.disabled = true;
}

function renderSlices(slices) {
    clearSlices();
    for (const item of slices) {
        const card = document.createElement('div');
        card.className = 'slice-card';
        card.innerHTML = `
            <img src="${item.dataUrl}" alt="Slice ${item.index}">
            <div>Slice ${item.index}</div>
            <a href="${item.dataUrl}" download="slice_${item.index}.png">Download</a>
        `;
        sliceContainer.appendChild(card);
    }
    sliceItems = slices;
    downloadAllBtn.disabled = slices.length === 0;
}

function sliceImage() {
    if (!sectionState.slicing) {
        alert('Custom Slicing section is OFF. Turn it ON to slice.');
        return;
    }
    if (!currentCanvas.width || !currentCanvas.height) {
        alert('Please upload an image first.');
        return;
    }

    const processed = getProcessedCanvas();

    const result = [];
    if (customRegions.length) {
        customRegions.forEach((region, i) => {
            const x = Math.max(0, Math.min(region.x, processed.width - 1));
            const y = Math.max(0, Math.min(region.y, processed.height - 1));
            const w = Math.max(1, Math.min(region.w, processed.width - x));
            const h = Math.max(1, Math.min(region.h, processed.height - y));
            const tile = document.createElement('canvas');
            tile.width = w;
            tile.height = h;
            tile.getContext('2d').drawImage(processed, x, y, w, h, 0, 0, w, h);
            result.push({
                index: i + 1,
                dataUrl: tile.toDataURL('image/png'),
            });
        });
        sliceMeta.textContent = `Generated ${result.length} custom slice(s) from free-form selector.`;
    } else {
        const { total, rows, cols } = getSliceLayout();
        if (processed.width < cols || processed.height < rows) {
            alert('Image is too small for this many slices. Use fewer slices.');
            return;
        }

        for (let i = 0; i < total; i++) {
            const r = Math.floor(i / cols);
            const c = i % cols;
            const x1 = Math.floor((c * processed.width) / cols);
            const x2 = Math.floor(((c + 1) * processed.width) / cols);
            const y1 = Math.floor((r * processed.height) / rows);
            const y2 = Math.floor(((r + 1) * processed.height) / rows);
            const w = Math.max(1, x2 - x1);
            const h = Math.max(1, y2 - y1);

            const tile = document.createElement('canvas');
            tile.width = w;
            tile.height = h;
            tile.getContext('2d').drawImage(processed, x1, y1, w, h, 0, 0, w, h);
            result.push({
                index: i + 1,
                dataUrl: tile.toDataURL('image/png'),
            });
        }
        sliceMeta.textContent = `Generated ${result.length} slices (${rows} x ${cols}).`;
    }
    renderSlices(result);
}

function downloadAll() {
    if (!sliceItems.length) return;
    downloadAllBtn.disabled = true;
    const oldText = downloadAllBtn.textContent;
    downloadAllBtn.textContent = 'Preparing ZIP...';

    const folderName = `sliced_images_${Date.now()}`;
    const payload = {
        folder_name: folderName,
        slices: sliceItems.map((item) => ({
            name: `slice_${item.index}.png`,
            data: item.dataUrl.split(',')[1],
        })),
    };

    fetch('download_zip.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
    }).then((response) => {
        if (!response.ok) {
            return response.text().then((txt) => {
                throw new Error(txt || 'ZIP creation failed.');
            });
        }
        return response.blob();
    }).then((blob) => {
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `${folderName}.zip`;
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(link.href), 2000);
    }).catch((err) => {
        alert(`Could not create ZIP file. ${err.message || 'Try again.'}`);
    }).finally(() => {
        downloadAllBtn.disabled = false;
        downloadAllBtn.textContent = oldText;
    });
}

imageInput.addEventListener('change', (e) => {
    clearSlices();
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function (evt) {
        const img = new Image();
        img.onload = function () {
            setCanvasFromImage(img);
            workspace.classList.remove('hidden');
        };
        img.src = evt.target.result;
    };
    reader.readAsDataURL(file);
});

[brightness, contrast, grayscale].forEach((input) => {
    input.addEventListener('input', () => {
        updateEditLabels();
        renderPreview();
    });
});

useCustomGrid.addEventListener('change', () => {
    rowsInput.disabled = !useCustomGrid.checked;
    colsInput.disabled = !useCustomGrid.checked;
    syncSelectorState();
    refreshLayoutMeta();
});

sliceCountInput.addEventListener('input', () => {
    const count = Math.max(1, parseInt(sliceCountInput.value || 1, 10));
    if (count <= parseInt(sliceSlider.max, 10)) {
        sliceSlider.value = count;
    }
    setPresetActive(count);
    refreshLayoutMeta();
});

sliceSlider.addEventListener('input', () => {
    const count = Math.max(1, parseInt(sliceSlider.value || 1, 10));
    sliceCountInput.value = count;
    setPresetActive(count);
    refreshLayoutMeta();
});

presetWrap.addEventListener('click', (event) => {
    const btn = event.target.closest('.preset-btn');
    if (!btn || btn.disabled) return;
    const value = Math.max(1, parseInt(btn.dataset.value || 1, 10));
    sliceCountInput.value = value;
    sliceSlider.value = Math.min(value, parseInt(sliceSlider.max, 10));
    setPresetActive(value);
    refreshLayoutMeta();
});

[rowsInput, colsInput].forEach((input) => {
    input.addEventListener('input', refreshLayoutMeta);
});
[useFixedSliceSize, sliceBoxW, sliceBoxH].forEach((input) => {
    input.addEventListener('input', refreshLayoutMeta);
});

cropToolBtn.addEventListener('click', () => setToolMode('crop'));
sliceToolBtn.addEventListener('click', () => setToolMode('slice'));
undoRegionBtn.addEventListener('click', () => {
    if (customRegions.length) {
        customRegions.pop();
        refreshLayoutMeta();
    }
});
clearRegionsBtn.addEventListener('click', () => {
    customRegions = [];
    refreshLayoutMeta();
});
previewCanvas.addEventListener('mousedown', onPreviewPointerDown);
previewCanvas.addEventListener('mousemove', onPreviewPointerMove);
window.addEventListener('mouseup', onPreviewPointerUp);
cropMinBtn.addEventListener('click', () => resizeCropSelection(0.9));
cropMaxBtn.addEventListener('click', () => resizeCropSelection(1.1));
cropScaleSlider.addEventListener('input', () => {
    const scalePercent = Math.max(50, Math.min(200, parseInt(cropScaleSlider.value || 100, 10)));
    resizeCropSelection(scalePercent / 100);
    cropScaleSlider.value = '100';
});
[cropX, cropY, cropW, cropH].forEach((input) => {
    input.addEventListener('input', syncCropRectFromInputs);
});
zoomOutBtn.addEventListener('click', () => setZoom(zoomLevel - 10));
zoomInBtn.addEventListener('click', () => setZoom(zoomLevel + 10));
zoomResetBtn.addEventListener('click', () => setZoom(100));
zoomSlider.addEventListener('input', () => setZoom(parseInt(zoomSlider.value || 100, 10)));

applyCropBtn.addEventListener('click', applyCrop);
saveCropBtn.addEventListener('click', saveCroppedImage);
resetCropBtn.addEventListener('click', resetCrop);
resetEditBtn.addEventListener('click', () => {
    brightness.value = 100;
    contrast.value = 100;
    grayscale.value = 0;
    updateEditLabels();
    renderPreview();
});
sliceBtn.addEventListener('click', sliceImage);
downloadAllBtn.addEventListener('click', downloadAll);
layoutSplit.addEventListener('input', () => {
    if (!sectionState.settings) return;
    const pct = Math.max(50, Math.min(85, parseInt(layoutSplit.value || 70, 10)));
    layoutSplitVal.textContent = pct;
    workspace.style.setProperty('--image-panel-width', `${pct}%`);
});
toggleSettings.addEventListener('change', () => {
    applySectionToggle('settings', toggleSettings.checked);
    syncToggleLabel(toggleSettings);
});
toggleCrop.addEventListener('change', () => {
    applySectionToggle('crop', toggleCrop.checked);
    syncToggleLabel(toggleCrop);
    if (!toggleCrop.checked && toolMode === 'crop') {
        setToolMode('slice');
    }
});
toggleEdit.addEventListener('change', () => {
    applySectionToggle('edit', toggleEdit.checked);
    syncToggleLabel(toggleEdit);
    renderPreview();
});
toggleSlicing.addEventListener('change', () => {
    applySectionToggle('slicing', toggleSlicing.checked);
    syncToggleLabel(toggleSlicing);
    if (!toggleSlicing.checked && toolMode === 'slice') {
        setToolMode('crop');
    }
    refreshLayoutMeta();
});

updateEditLabels();
syncSelectorState();
refreshLayoutMeta();
workspace.style.setProperty('--image-panel-width', `${layoutSplit.value}%`);
applySectionToggle('settings', toggleSettings.checked);
applySectionToggle('crop', toggleCrop.checked);
applySectionToggle('edit', toggleEdit.checked);
applySectionToggle('slicing', toggleSlicing.checked);
syncToggleLabel(toggleSettings);
syncToggleLabel(toggleCrop);
syncToggleLabel(toggleEdit);
syncToggleLabel(toggleSlicing);
setToolMode('crop');
setZoom(100);
</script>
</body>
</html>
