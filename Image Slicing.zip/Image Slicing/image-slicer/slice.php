<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

if (!extension_loaded('gd')) {
    die("GD extension is not enabled in PHP. Enable 'extension=gd' in php.ini and restart Apache. <a href='index.php'>Back</a>");
}

$sliceCount = max(1, intval($_POST['slice_count'] ?? 1));
$maxSlices = 10000;
if ($sliceCount > $maxSlices) {
    die("Please choose {$maxSlices} slices or fewer. <a href='index.php'>Back</a>");
}

$uploadDir = "uploads/";
$outputDir = "output/";

if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}
if (!is_dir($outputDir)) {
    mkdir($outputDir, 0755, true);
}

if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
    die("Upload failed. Please try again from <a href='index.php'>the upload form</a>.");
}

$base = preg_replace('/[^a-zA-Z0-9._-]/', '_', basename($_FILES['image']['name']));
$fileName = time() . "_" . $base;
$filePath = $uploadDir . $fileName;

if (!move_uploaded_file($_FILES['image']['tmp_name'], $filePath)) {
    die("Could not save file. <a href='index.php'>Back</a>");
}

$imageInfo = @getimagesize($filePath);
if ($imageInfo === false) {
    @unlink($filePath);
    die("Invalid image file. <a href='index.php'>Back</a>");
}

switch ($imageInfo[2]) {
    case IMAGETYPE_JPEG:
        if (!function_exists('imagecreatefromjpeg')) {
            @unlink($filePath);
            die("JPEG support is missing in GD. Enable full GD support in php.ini. <a href='index.php'>Back</a>");
        }
        $source = imagecreatefromjpeg($filePath);
        break;
    case IMAGETYPE_PNG:
        if (!function_exists('imagecreatefrompng')) {
            @unlink($filePath);
            die("PNG support is missing in GD. Enable full GD support in php.ini. <a href='index.php'>Back</a>");
        }
        $source = imagecreatefrompng($filePath);
        break;
    case IMAGETYPE_GIF:
        if (!function_exists('imagecreatefromgif')) {
            @unlink($filePath);
            die("GIF support is missing in GD. Enable full GD support in php.ini. <a href='index.php'>Back</a>");
        }
        $source = imagecreatefromgif($filePath);
        break;
    default:
        @unlink($filePath);
        die("Unsupported image format. <a href='index.php'>Back</a>");
}

if ($source === false) {
    @unlink($filePath);
    die("Could not load image. <a href='index.php'>Back</a>");
}

if (!function_exists('imagecrop') || !function_exists('imagejpeg')) {
    imagedestroy($source);
    @unlink($filePath);
    die("Required GD image functions are unavailable. Enable full GD support in php.ini. <a href='index.php'>Back</a>");
}

$width = imagesx($source);
$height = imagesy($source);

$rows = (int) floor(sqrt($sliceCount));
while ($rows > 1 && $sliceCount % $rows !== 0) {
    $rows--;
}
$cols = (int) ($sliceCount / $rows);

if ($width < $cols || $height < $rows) {
    imagedestroy($source);
    die("Image is too small for {$sliceCount} slices. Try fewer slices. <a href='index.php'>Back</a>");
}

$count = 1;
$requestPrefix = str_replace('.', '_', uniqid('slice_', true));

echo "<h3>Generated {$sliceCount} slices ({$rows} x {$cols})</h3>";

for ($i = 0; $i < $sliceCount; $i++) {
    $r = (int) floor($i / $cols);
    $c = $i % $cols;

    $x1 = (int) floor(($c * $width) / $cols);
    $x2 = (int) floor((($c + 1) * $width) / $cols);
    $y1 = (int) floor(($r * $height) / $rows);
    $y2 = (int) floor((($r + 1) * $height) / $rows);

    $crop = [
        'x' => $x1,
        'y' => $y1,
        'width' => max(1, $x2 - $x1),
        'height' => max(1, $y2 - $y1),
    ];

    $slice = imagecrop($source, $crop);

    if ($slice !== false) {
        $outputFile = $outputDir . $requestPrefix . "_slice_" . $count . ".jpg";
        imagejpeg($slice, $outputFile, 90);
        imagedestroy($slice);

        $safe = htmlspecialchars($outputFile, ENT_QUOTES, 'UTF-8');
        echo "<img src='{$safe}' style='margin:5px; border:1px solid #ccc; width:120px; height:auto;'>";

        $count++;
    }
}

imagedestroy($source);

echo "<br><br><a href='index.php'>Upload Another</a>";
