<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo 'Method not allowed.';
    exit;
}

if (!class_exists('ZipArchive')) {
    http_response_code(500);
    echo 'ZipArchive extension is not enabled on server.';
    exit;
}

$rawBody = file_get_contents('php://input');
$payload = json_decode($rawBody, true);

if (!is_array($payload) || !isset($payload['slices']) || !is_array($payload['slices'])) {
    http_response_code(400);
    echo 'Invalid request payload.';
    exit;
}

$folderName = preg_replace('/[^a-zA-Z0-9_-]/', '_', (string) ($payload['folder_name'] ?? 'sliced_images'));
if ($folderName === '') {
    $folderName = 'sliced_images';
}

$slices = $payload['slices'];
$maxSlices = 1000;
if (count($slices) < 1 || count($slices) > $maxSlices) {
    http_response_code(400);
    echo "Slice count must be between 1 and {$maxSlices}.";
    exit;
}

$tmpDir = __DIR__ . DIRECTORY_SEPARATOR . 'tmp';
if (!is_dir($tmpDir)) {
    mkdir($tmpDir, 0755, true);
}

$zipPath = $tmpDir . DIRECTORY_SEPARATOR . $folderName . '_' . uniqid() . '.zip';
$zip = new ZipArchive();
if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
    http_response_code(500);
    echo 'Could not create ZIP file.';
    exit;
}

foreach ($slices as $i => $slice) {
    if (!is_array($slice)) {
        continue;
    }

    $fileName = preg_replace('/[^a-zA-Z0-9._-]/', '_', (string) ($slice['name'] ?? ('slice_' . ($i + 1) . '.png')));
    if ($fileName === '') {
        $fileName = 'slice_' . ($i + 1) . '.png';
    }

    $b64 = (string) ($slice['data'] ?? '');
    if ($b64 === '') {
        continue;
    }

    $binary = base64_decode($b64, true);
    if ($binary === false) {
        continue;
    }

    $zip->addFromString($folderName . '/' . $fileName, $binary);
}

$zip->close();

if (!is_file($zipPath)) {
    http_response_code(500);
    echo 'ZIP file was not created.';
    exit;
}

header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . $folderName . '.zip"');
header('Content-Length: ' . filesize($zipPath));
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

readfile($zipPath);
@unlink($zipPath);

