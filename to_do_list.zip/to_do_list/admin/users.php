<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$pageTitle = 'User Management';
$currentPage = 'users';
$pdo = db();
$user = currentUser();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $role = $_POST['role'] ?? 'user';

        $result = registerUser($name, $phone, $role, $email);
        if ($result['success']) {
            flash('success', 'User created successfully.');
        } else {
            flash('error', $result['message']);
        }
    } elseif ($action === 'toggle' && isset($_POST['user_id'])) {
        $uid = (int)$_POST['user_id'];
        if ($uid !== $user['id']) {
            $pdo->prepare('UPDATE users SET is_active = NOT is_active WHERE id = ?')->execute([$uid]);
            flash('success', 'User status updated.');
        }
    } elseif ($action === 'delete' && isset($_POST['user_id'])) {
        $uid = (int)$_POST['user_id'];
        if ($uid !== $user['id']) {
            $pdo->prepare('DELETE FROM users WHERE id = ?')->execute([$uid]);
            flash('success', 'User deleted.');
        }
    }
    redirect(baseUrl('admin/users.php'));
}

$users = $pdo->query("SELECT id, name, email, phone, role, is_active, created_at FROM users ORDER BY created_at DESC")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">All Users</h2>
        <button class="btn btn-primary btn-sm" data-modal="userModal">+ Add User</button>
    </div>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Mobile</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Joined</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                <tr>
                    <td><?= sanitize($u['name']) ?></td>
                    <td><?= sanitize(formatPhone($u['phone'] ?? '')) ?></td>
                    <td><?= sanitize($u['email'] ?? '-') ?></td>
                    <td><span class="badge"><?= ucfirst($u['role']) ?></span></td>
                    <td><?= $u['is_active'] ? '<span class="badge badge-active">Active</span>' : '<span class="badge badge-inactive">Inactive</span>' ?></td>
                    <td><?= formatDate($u['created_at']) ?></td>
                    <td>
                        <?php if ($u['id'] != $user['id']): ?>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="action" value="toggle">
                            <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                            <button type="submit" class="btn btn-sm btn-outline"><?= $u['is_active'] ? 'Deactivate' : 'Activate' ?></button>
                        </form>
                        <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this user?');">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                        </form>
                        <?php else: ?>
                        <span class="text-muted">You</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal-overlay" id="userModal">
    <div class="modal">
        <div class="modal-header">
            <h3>Add New User</h3>
            <button class="modal-close">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST">
                <input type="hidden" name="action" value="create">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Mobile Number *</label>
                    <input type="tel" name="phone" class="form-control" required inputmode="numeric" placeholder="10-digit mobile">
                </div>
                <div class="form-group">
                    <label>Email (optional)</label>
                    <input type="email" name="email" class="form-control">
                </div>
                <div class="form-group">
                    <label>Role</label>
                    <select name="role" class="form-control">
                        <option value="user">User</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Create User</button>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
