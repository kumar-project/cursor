<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$pageTitle = 'Dashboard';
$currentPage = 'dashboard';

$pdo = db();

$stats = [
    'users' => $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'user'")->fetchColumn(),
    'schedules' => $pdo->query('SELECT COUNT(*) FROM schedules')->fetchColumn(),
    'tasks' => $pdo->query('SELECT COUNT(*) FROM tasks')->fetchColumn(),
    'pending' => $pdo->query("SELECT COUNT(*) FROM tasks WHERE status = 'pending'")->fetchColumn(),
];

$recentTasks = $pdo->query("
    SELECT t.*, u.name as creator_name,
           (SELECT GROUP_CONCAT(us.name SEPARATOR ', ') FROM task_assignments ta JOIN users us ON ta.user_id = us.id WHERE ta.task_id = t.id) as assignees
    FROM tasks t
    JOIN users u ON t.created_by = u.id
    ORDER BY t.created_at DESC LIMIT 8
")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-value"><?= (int)$stats['users'] ?></div>
        <div class="stat-label">Total Users</div>
    </div>
    <div class="stat-card info">
        <div class="stat-value"><?= (int)$stats['schedules'] ?></div>
        <div class="stat-label">Schedules</div>
    </div>
    <div class="stat-card success">
        <div class="stat-value"><?= (int)$stats['tasks'] ?></div>
        <div class="stat-label">Total Tasks</div>
    </div>
    <div class="stat-card warning">
        <div class="stat-value"><?= (int)$stats['pending'] ?></div>
        <div class="stat-label">Pending Tasks</div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Recent Tasks</h2>
        <a href="<?= baseUrl('admin/tasks.php') ?>" class="btn btn-primary btn-sm">Manage Tasks</a>
    </div>
    <?php if (empty($recentTasks)): ?>
    <div class="empty-state"><div class="empty-state-icon"><?= icon('tasks-empty') ?></div><p>No tasks yet. Create your first task!</p></div>
    <?php else: ?>
    <ul class="task-list">
        <?php foreach ($recentTasks as $task): ?>
        <li class="task-item">
            <div class="task-info">
                <div class="task-title"><?= sanitize($task['title']) ?></div>
                <div class="task-meta">
                    <?= formatTaskScheduled($task['start_datetime']) ?> — <?= sanitize($task['assignees'] ?? 'Unassigned') ?>
                </div>
            </div>
            <div class="task-actions">
                <?= priorityBadge($task['priority']) ?>
                <?= statusBadge($task['status']) ?>
            </div>
        </li>
        <?php endforeach; ?>
    </ul>
    <?php endif; ?>
</div>

<div class="card mt-2">
    <div class="card-header">
        <h2 class="card-title">Quick Actions</h2>
    </div>
    <div class="btn-group">
        <a href="<?= baseUrl('admin/users.php') ?>" class="btn btn-outline"><?= icon('users') ?> Manage Users</a>
        <a href="<?= baseUrl('admin/schedules.php') ?>" class="btn btn-outline"><?= icon('schedules') ?> Create Schedule</a>
        <a href="<?= baseUrl('admin/make-task.php') ?>" class="btn btn-outline"><?= icon('tasks') ?> Make a Task</a>
        <a href="<?= baseUrl('admin/calendar.php') ?>" class="btn btn-outline"><?= icon('calendar') ?> View Calendar</a>
        <a href="<?= baseUrl('admin/reports.php') ?>" class="btn btn-outline"><?= icon('reports') ?> View Reports</a>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
