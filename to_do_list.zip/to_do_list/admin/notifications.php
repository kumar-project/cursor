<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$pageTitle = 'Notifications';
$currentPage = 'notifications';
$pdo = db();
$user = currentUser();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'send') {
        $title = trim($_POST['title'] ?? '');
        $message = trim($_POST['message'] ?? '');
        $target = $_POST['target'] ?? 'all';

        if ($title && $message) {
            if ($target === 'all') {
                $recipients = $pdo->query('SELECT id FROM users WHERE id != ' . (int)$user['id'])->fetchAll(PDO::FETCH_COLUMN);
            } else {
                $recipients = [(int)$target];
            }
            foreach ($recipients as $uid) {
                createNotification((int)$uid, $title, $message, 'system');
            }
            flash('success', 'Notification sent to ' . count($recipients) . ' user(s).');
        }
    } elseif ($action === 'mark_read') {
        $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?')->execute([$user['id']]);
        flash('success', 'All notifications marked as read.');
    }
    redirect(baseUrl('admin/notifications.php'));
}

if (isset($_GET['read']) && is_numeric($_GET['read'])) {
    $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?')->execute([(int)$_GET['read'], $user['id']]);
    redirect(baseUrl('admin/notifications.php'));
}

$notifications = $pdo->prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50');
$notifications->execute([$user['id']]);
$notifications = $notifications->fetchAll();

$allUsers = $pdo->query("SELECT id, name FROM users WHERE role = 'user' AND is_active = 1")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Send Notification</h2>
    </div>
    <form method="POST" class="mb-2">
        <input type="hidden" name="action" value="send">
        <div class="form-row cols-2">
            <div class="form-group">
                <label>Title</label>
                <input type="text" name="title" class="form-control" required placeholder="Notification title">
            </div>
            <div class="form-group">
                <label>Send To</label>
                <select name="target" class="form-control">
                    <option value="all">All Users</option>
                    <?php foreach ($allUsers as $u): ?>
                    <option value="<?= $u['id'] ?>"><?= sanitize($u['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label>Message</label>
            <textarea name="message" class="form-control" rows="2" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Send Notification</button>
    </form>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">My Notifications</h2>
        <form method="POST" style="display:inline;">
            <input type="hidden" name="action" value="mark_read">
            <button type="submit" class="btn btn-outline btn-sm">Mark All Read</button>
        </form>
    </div>
    <?php if (empty($notifications)): ?>
    <div class="empty-state"><div class="empty-state-icon"><?= icon('bell-empty') ?></div><p>No notifications.</p></div>
    <?php else: ?>
    <ul class="notif-list">
        <?php foreach ($notifications as $n): ?>
        <li class="notif-item <?= !$n['is_read'] ? 'unread' : '' ?>">
            <div class="notif-icon"><?= notifIcon($n['type']) ?></div>
            <div class="notif-content">
                <div class="notif-title"><?= sanitize($n['title']) ?></div>
                <p><?= sanitize($n['message']) ?></p>
                <div class="notif-time"><?= formatDateTime($n['created_at']) ?></div>
            </div>
            <?php if (!$n['is_read']): ?>
            <a href="?read=<?= $n['id'] ?>" class="btn btn-sm btn-outline">Mark Read</a>
            <?php endif; ?>
        </li>
        <?php endforeach; ?>
    </ul>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
