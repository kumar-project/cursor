<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$pageTitle = 'Calendar';
$currentPage = 'calendar';
$extraCss = [
    'https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.css'
];
$extraJs = [
    'https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.js',
    assetUrl('js/calendar.js')
];

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Calendar View</h2>
        <div class="btn-group">
            <a href="<?= baseUrl('admin/make-task.php') ?>" class="btn btn-primary btn-sm"><?= icon('tasks') ?> Make a Task</a>
        </div>
    </div>
    <div id="calendar"></div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
