<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$pageTitle = 'Assign Tasks';
$currentPage = 'tasks';
$pdo = db();
$user = currentUser();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'delete' && isset($_POST['id'])) {
        $pdo->prepare('DELETE FROM tasks WHERE id = ?')->execute([(int)$_POST['id']]);
        flash('success', 'Task deleted.');
    }
    redirect(baseUrl('admin/tasks.php'));
}

$tasks = $pdo->query("
    SELECT t.*, s.title as schedule_title,
           (SELECT GROUP_CONCAT(u.name SEPARATOR ', ') FROM task_assignments ta JOIN users u ON ta.user_id = u.id WHERE ta.task_id = t.id) as assignees
    FROM tasks t
    LEFT JOIN schedules s ON t.schedule_id = s.id
    ORDER BY t.start_datetime DESC
")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">All Tasks</h2>
        <a href="<?= baseUrl('admin/make-task.php') ?>" class="btn btn-primary btn-sm"><?= icon('tasks') ?> Make a Task</a>
    </div>
    <?php if (empty($tasks)): ?>
    <div class="empty-state"><div class="empty-state-icon"><?= icon('tasks-empty') ?></div><p>No tasks yet.</p></div>
    <?php else: ?>
    <ul class="task-list">
        <?php foreach ($tasks as $task): ?>
        <li class="task-item">
            <div class="task-info">
                <div class="task-title"><?= sanitize($task['title']) ?></div>
                <div class="task-meta">
                    Scheduled: <?= formatTaskScheduled($task['start_datetime']) ?>
                    <?php if ($task['schedule_title']): ?> | <?= sanitize($task['schedule_title']) ?><?php endif; ?>
                    <br>Assigned: <?= sanitize($task['assignees'] ?? 'None') ?>
                </div>
            </div>
            <div class="task-actions">
                <?= priorityBadge($task['priority']) ?>
                <?= statusBadge($task['status']) ?>
                <form method="POST" style="display:inline;" onsubmit="return confirm('Delete task?');">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= $task['id'] ?>">
                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                </form>
            </div>
        </li>
        <?php endforeach; ?>
    </ul>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
