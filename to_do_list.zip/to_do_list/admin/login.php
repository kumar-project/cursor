<?php
$authRole = 'admin';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/auth-page.php';

if (isLoggedIn()) {
    redirect(authDashboardUrl());
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = trim($_POST['phone'] ?? '');

    $result = loginUser($phone, $authRole);
    if ($result['success']) {
        flash('success', $result['message']);
        redirect(authDashboardUrl());
    }
    $error = $result['message'];
}

authPageHead('Admin Login');
?>
<div class="auth-main auth-main-admin">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-logo">
                <h1><?= icon('logo') ?> <?= APP_NAME ?></h1>
                <p>Admin sign in with mobile number</p>
            </div>
            <?php authRoleSwitcher($authRole, 'login'); ?>
            <?php if ($error): ?><div class="alert alert-error"><?= sanitize($error) ?></div><?php endif; ?>
            <?php $flash = getFlash(); if ($flash): ?><div class="alert alert-<?= $flash['type'] ?>"><?= sanitize($flash['message']) ?></div><?php endif; ?>
            <form method="POST" action="" novalidate>
                <div class="form-group">
                    <label for="phone">Mobile Number</label>
                    <input type="tel" id="phone" name="phone" class="form-control" required
                           autocomplete="tel" inputmode="numeric" maxlength="14"
                           value="<?= sanitize($_POST['phone'] ?? '') ?>" placeholder="10-digit mobile number">
                    <small class="text-muted">Example: <?= DEMO_ADMIN_PHONE ?></small>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Admin Sign In</button>
            </form>
            <p class="auth-links">Need an admin account? <a href="<?= authRegisterUrl('admin') ?>">Register as admin</a></p>
            <p class="auth-links text-muted" style="font-size:.8rem;margin-top:.5rem;">
                Demo admin mobile: <?= DEMO_ADMIN_PHONE ?><br>
                <a href="<?= baseUrl('fix-demo-accounts.php') ?>" style="font-size:.75rem;">Reset demo accounts</a>
            </p>
        </div>
    </div>
</div>
<?php authPageFoot(); ?>
