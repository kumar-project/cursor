<?php
$authRole = 'admin';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/auth-page.php';

if (isLoggedIn()) {
    redirect(authDashboardUrl());
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');

    $result = registerUser($name, $phone, $authRole, $email);
    if ($result['success']) {
        flash('success', $result['message']);
        redirect(authLoginUrl($authRole));
    }
    $error = $result['message'];
}

authPageHead('Admin Register');
?>
<div class="auth-main auth-main-admin">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-logo">
                <h1><?= icon('logo') ?> <?= APP_NAME ?></h1>
                <p>Create an administrator account</p>
            </div>
            <?php authRoleSwitcher($authRole, 'register'); ?>
            <?php if ($error): ?><div class="alert alert-error"><?= sanitize($error) ?></div><?php endif; ?>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="name">Full Name *</label>
                    <input type="text" id="name" name="name" class="form-control" required
                           value="<?= sanitize($_POST['name'] ?? '') ?>" placeholder="Admin Name">
                </div>
                <div class="form-group">
                    <label for="phone">Mobile Number *</label>
                    <input type="tel" id="phone" name="phone" class="form-control" required
                           inputmode="numeric" maxlength="14"
                           value="<?= sanitize($_POST['phone'] ?? '') ?>" placeholder="10-digit mobile number">
                </div>
                <div class="form-group">
                    <label for="email">Email (optional)</label>
                    <input type="email" id="email" name="email" class="form-control"
                           value="<?= sanitize($_POST['email'] ?? '') ?>" placeholder="admin@example.com">
                </div>
                <button type="submit" class="btn btn-primary btn-block">Create Admin Account</button>
            </form>
            <p class="auth-links">Already have an account? <a href="<?= authLoginUrl('admin') ?>">Admin sign in</a></p>
        </div>
    </div>
</div>
<?php authPageFoot(); ?>
