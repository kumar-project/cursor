<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$pageTitle = 'Schedules';
$currentPage = 'schedules';
$pdo = db();
$user = currentUser();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $stmt = $pdo->prepare('INSERT INTO schedules (title, description, start_date, end_date, color, created_by) VALUES (?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            trim($_POST['title']),
            trim($_POST['description'] ?? ''),
            $_POST['start_date'],
            $_POST['end_date'],
            $_POST['color'] ?? '#4f46e5',
            $user['id'],
        ]);
        flash('success', 'Schedule created.');
    } elseif ($action === 'delete' && isset($_POST['id'])) {
        $pdo->prepare('DELETE FROM schedules WHERE id = ?')->execute([(int)$_POST['id']]);
        flash('success', 'Schedule deleted.');
    }
    redirect(baseUrl('admin/schedules.php'));
}

$schedules = $pdo->query("
    SELECT s.*, u.name as creator_name
    FROM schedules s
    JOIN users u ON s.created_by = u.id
    ORDER BY s.start_date DESC
")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">All Schedules</h2>
        <button class="btn btn-primary btn-sm" data-modal="scheduleModal">+ New Schedule</button>
    </div>
    <?php if (empty($schedules)): ?>
    <div class="empty-state"><div class="empty-state-icon"><?= icon('schedules-empty') ?></div><p>No schedules yet.</p></div>
    <?php else: ?>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Color</th>
                    <th>Title</th>
                    <th>Start</th>
                    <th>End</th>
                    <th>Created By</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($schedules as $s): ?>
                <tr>
                    <td><span style="display:inline-block;width:20px;height:20px;border-radius:4px;background:<?= sanitize($s['color']) ?>;"></span></td>
                    <td><strong><?= sanitize($s['title']) ?></strong><br><small class="text-muted"><?= sanitize(substr($s['description'] ?? '', 0, 60)) ?></small></td>
                    <td><?= formatDate($s['start_date']) ?></td>
                    <td><?= formatDate($s['end_date']) ?></td>
                    <td><?= sanitize($s['creator_name']) ?></td>
                    <td>
                        <form method="POST" style="display:inline;" onsubmit="return confirm('Delete schedule?');">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= $s['id'] ?>">
                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<div class="modal-overlay" id="scheduleModal">
    <div class="modal">
        <div class="modal-header">
            <h3>Create Schedule</h3>
            <button class="modal-close">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST">
                <input type="hidden" name="action" value="create">
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" class="form-control" rows="3"></textarea>
                </div>
                <div class="form-row cols-2">
                    <div class="form-group">
                        <label>Start Date</label>
                        <input type="date" name="start_date" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>End Date</label>
                        <input type="date" name="end_date" class="form-control" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>Color</label>
                    <input type="color" name="color" class="form-control" value="#4f46e5" style="height:44px;padding:4px;">
                </div>
                <button type="submit" class="btn btn-primary btn-block">Create Schedule</button>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
