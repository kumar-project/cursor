<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$pageTitle = 'Reports';
$currentPage = 'reports';
$pdo = db();

$taskStats = $pdo->query("
    SELECT status, COUNT(*) as count FROM tasks GROUP BY status
")->fetchAll(PDO::FETCH_KEY_PAIR);

$priorityStats = $pdo->query("
    SELECT priority, COUNT(*) as count FROM tasks GROUP BY priority
")->fetchAll(PDO::FETCH_KEY_PAIR);

$userTaskStats = $pdo->query("
    SELECT u.name, COUNT(ta.id) as assigned,
           SUM(CASE WHEN t.status = 'completed' THEN 1 ELSE 0 END) as completed
    FROM users u
    LEFT JOIN task_assignments ta ON u.id = ta.user_id
    LEFT JOIN tasks t ON ta.task_id = t.id
    WHERE u.role = 'user'
    GROUP BY u.id, u.name
    ORDER BY assigned DESC
")->fetchAll();

$monthlyTasks = $pdo->query("
    SELECT DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as count
    FROM tasks
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY month ORDER BY month
")->fetchAll();

$totalTasks = array_sum($taskStats);
$completedTasks = $taskStats['completed'] ?? 0;
$completionRate = $totalTasks > 0 ? round(($completedTasks / $totalTasks) * 100) : 0;

require_once __DIR__ . '/../includes/header.php';
?>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-value"><?= $totalTasks ?></div>
        <div class="stat-label">Total Tasks</div>
    </div>
    <div class="stat-card success">
        <div class="stat-value"><?= $completedTasks ?></div>
        <div class="stat-label">Completed</div>
    </div>
    <div class="stat-card warning">
        <div class="stat-value"><?= $taskStats['pending'] ?? 0 ?></div>
        <div class="stat-label">Pending</div>
    </div>
    <div class="stat-card info">
        <div class="stat-value"><?= $completionRate ?>%</div>
        <div class="stat-label">Completion Rate</div>
    </div>
</div>

<div class="card">
    <div class="card-header"><h2 class="card-title">Tasks by Status</h2></div>
    <div class="chart-container">
        <div class="bar-chart">
            <?php
            $statusLabels = ['pending' => 'Pending', 'in_progress' => 'In Progress', 'completed' => 'Completed', 'cancelled' => 'Cancelled'];
            $maxStatus = max(array_merge($taskStats, [1]));
            foreach ($statusLabels as $key => $label):
                $count = $taskStats[$key] ?? 0;
                $height = $maxStatus > 0 ? ($count / $maxStatus) * 200 : 0;
            ?>
            <div class="bar-item">
                <div class="bar" style="height:<?= max(4, $height) ?>px;" title="<?= $count ?>"></div>
                <span class="bar-label"><?= $label ?></span>
                <strong><?= $count ?></strong>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header"><h2 class="card-title">Tasks by Priority</h2></div>
    <div class="btn-group">
        <?php foreach (['low', 'medium', 'high'] as $p): ?>
        <div class="stat-card" style="flex:1;min-width:120px;">
            <div class="stat-value"><?= $priorityStats[$p] ?? 0 ?></div>
            <div class="stat-label"><?= ucfirst($p) ?> Priority</div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="card">
    <div class="card-header"><h2 class="card-title">User Performance</h2></div>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>User</th>
                    <th>Assigned Tasks</th>
                    <th>Completed</th>
                    <th>Rate</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($userTaskStats as $row): ?>
                <?php $rate = $row['assigned'] > 0 ? round(($row['completed'] / $row['assigned']) * 100) : 0; ?>
                <tr>
                    <td><?= sanitize($row['name']) ?></td>
                    <td><?= (int)$row['assigned'] ?></td>
                    <td><?= (int)$row['completed'] ?></td>
                    <td><?= $rate ?>%</td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($userTaskStats)): ?>
                <tr><td colspan="4" class="text-center text-muted">No user data yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if (!empty($monthlyTasks)): ?>
<div class="card">
    <div class="card-header"><h2 class="card-title">Tasks Created (Last 6 Months)</h2></div>
    <div class="bar-chart">
        <?php $maxMonth = max(array_column($monthlyTasks, 'count')); ?>
        <?php foreach ($monthlyTasks as $m): ?>
        <?php $h = $maxMonth > 0 ? ($m['count'] / $maxMonth) * 200 : 0; ?>
        <div class="bar-item">
            <div class="bar" style="height:<?= max(4, $h) ?>px;"></div>
            <span class="bar-label"><?= date('M Y', strtotime($m['month'] . '-01')) ?></span>
            <strong><?= $m['count'] ?></strong>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
