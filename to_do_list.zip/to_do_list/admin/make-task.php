<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$pageTitle = 'Make a Task';
$currentPage = 'make-task';
$pdo = db();
$user = currentUser();

$schedules = $pdo->query('SELECT id, title FROM schedules ORDER BY title')->fetchAll();
$usersList = $pdo->query("SELECT id, name, phone FROM users WHERE role = 'user' AND is_active = 1 ORDER BY name")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $times = parseScheduledFromRequest();
    $start = $times['start'];
    $end = $times['end'];

    if ($title === '' || $times['scheduled'] === '') {
        flash('error', 'Please fill in title, scheduled date, and scheduled time.');
        redirect(baseUrl('admin/make-task.php'));
    }

    $scheduleId = !empty($_POST['schedule_id']) ? (int)$_POST['schedule_id'] : null;
    $ringtone = processTaskRingtoneFromRequest((int)$user['id']);
    $speechVoice = speechVoiceFromRequest(null, $ringtone);
    $vibrate = taskVibrateFromRequest();
    $stmt = $pdo->prepare('INSERT INTO tasks (schedule_id, title, description, start_datetime, end_datetime, priority, ringtone, speech_voice, vibrate, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([
        $scheduleId,
        $title,
        trim($_POST['description'] ?? ''),
        $start,
        $end,
        $_POST['priority'] ?? 'medium',
        $ringtone,
        $speechVoice,
        $vibrate,
        $user['id'],
    ]);
    $taskId = (int)$pdo->lastInsertId();

    $assignees = $_POST['assignees'] ?? [];
    if (!empty($assignees)) {
        $assignStmt = $pdo->prepare('INSERT INTO task_assignments (task_id, user_id, assigned_by) VALUES (?, ?, ?)');
        foreach ($assignees as $uid) {
            $uid = (int)$uid;
            if ($uid > 0) {
                $assignStmt->execute([$taskId, $uid, $user['id']]);
                createNotification(
                    $uid,
                    'New Task Assigned',
                    'You have been assigned: ' . $title,
                    'assignment',
                    baseUrl('user/edit-task.php?id=' . $taskId),
                    $taskId
                );
            }
        }
    }

    flash('success', 'Task created successfully.');
    redirect(baseUrl('admin/tasks.php'));
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title"><?= icon('tasks') ?> Make a Task</h2>
        <a href="<?= baseUrl('admin/tasks.php') ?>" class="btn btn-outline btn-sm">View All Tasks</a>
    </div>
    <form method="POST" action="" enctype="multipart/form-data">
        <div class="form-group">
            <label for="title">Task Title *</label>
            <input type="text" id="title" name="title" class="form-control" required
                   value="<?= sanitize($_POST['title'] ?? '') ?>" placeholder="e.g. Team meeting prep">
        </div>
        <div class="form-group">
            <label for="description">Description</label>
            <textarea id="description" name="description" class="form-control" rows="3"
                      placeholder="Task details..."><?= sanitize($_POST['description'] ?? '') ?></textarea>
        </div>
        <div class="form-group">
            <label for="schedule_id">Schedule (optional)</label>
            <select id="schedule_id" name="schedule_id" class="form-control">
                <option value="">— None —</option>
                <?php foreach ($schedules as $s): ?>
                <option value="<?= $s['id'] ?>" <?= (($_POST['schedule_id'] ?? '') == $s['id']) ? 'selected' : '' ?>>
                    <?= sanitize($s['title']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php $dtDefaults = defaultTaskDateTimes(); require __DIR__ . '/../includes/datetime-fields.php'; ?>
        <?php
        $selectedRingtone = $_POST['ringtone'] ?? 'speech';
        $vibrateEnabled = isset($_POST['vibrate']) ? 1 : 1;
        $previewTaskTitle = trim($_POST['title'] ?? '');
        $selectedSpeechVoice = sanitizeSpeechVoice($_POST['speech_voice'] ?? null) ?? '';
        require __DIR__ . '/../includes/ringtone-field.php';
        ?>
        <div class="form-group">
            <label for="priority">Priority</label>
            <select id="priority" name="priority" class="form-control">
                <option value="low" <?= ($_POST['priority'] ?? '') === 'low' ? 'selected' : '' ?>>Low</option>
                <option value="medium" <?= ($_POST['priority'] ?? 'medium') === 'medium' ? 'selected' : '' ?>>Medium</option>
                <option value="high" <?= ($_POST['priority'] ?? '') === 'high' ? 'selected' : '' ?>>High</option>
            </select>
        </div>
        <div class="form-group">
            <label>Assign To</label>
            <?php if (empty($usersList)): ?>
            <p class="text-muted">No users available. <a href="<?= baseUrl('admin/users.php') ?>">Create users</a> first.</p>
            <?php else: ?>
            <div class="assignee-list">
                <?php foreach ($usersList as $u): ?>
                <label class="assignee-item">
                    <input type="checkbox" name="assignees[]" value="<?= $u['id'] ?>"
                        <?= in_array($u['id'], array_map('intval', (array)($_POST['assignees'] ?? []))) ? 'checked' : '' ?>>
                    <?= sanitize($u['name']) ?> <span class="text-muted">(<?= sanitize(formatPhone($u['phone'] ?? '')) ?>)</span>
                </label>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        <div class="btn-group">
            <button type="submit" class="btn btn-primary"><?= icon('tasks') ?> Create Task</button>
            <a href="<?= baseUrl('admin/tasks.php') ?>" class="btn btn-outline">Cancel</a>
        </div>
    </form>
</div>

<?php
$extraJs = [assetUrl('js/ringtones.js')];
require_once __DIR__ . '/../includes/footer.php';
?>
