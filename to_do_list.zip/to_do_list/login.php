<?php
$authRole = 'user';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/auth-page.php';

if (isLoggedIn()) {
    redirect(authDashboardUrl());
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = trim($_POST['phone'] ?? '');

    $result = loginUser($phone, $authRole);
    if ($result['success']) {
        flash('success', $result['message']);
        redirect(authDashboardUrl());
    }
    $error = $result['message'];
}

authPageHead('User Login');
?>
<div class="auth-main">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-logo">
                <h1><?= icon('logo') ?> <?= APP_NAME ?></h1>
                <p>Sign in with your mobile number</p>
            </div>
            <?php authRoleSwitcher($authRole, 'login'); ?>
            <?php if ($error): ?><div class="alert alert-error"><?= sanitize($error) ?></div><?php endif; ?>
            <?php $flash = getFlash(); if ($flash): ?><div class="alert alert-<?= $flash['type'] ?>"><?= sanitize($flash['message']) ?></div><?php endif; ?>
            <form method="POST" action="" novalidate>
                <div class="form-group">
                    <label for="phone">Mobile Number</label>
                    <input type="tel" id="phone" name="phone" class="form-control" required
                           autocomplete="tel" inputmode="numeric" maxlength="14"
                           pattern="[0-9+\s-]{10,14}"
                           value="<?= sanitize($_POST['phone'] ?? '') ?>" placeholder="10-digit mobile number">
                    <small class="text-muted">Example: 8888888888</small>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Sign In</button>
            </form>
            <p class="auth-links">Don't have an account? <a href="<?= authRegisterUrl('user') ?>">Register as user</a></p>
            <p class="auth-links text-muted" style="font-size:.8rem;margin-top:.5rem;">
                Demo user mobile: <?= DEMO_USER_PHONE ?><br>
                <a href="fix-demo-accounts.php" style="font-size:.75rem;">Reset demo accounts</a>
            </p>
        </div>
    </div>
</div>
<?php authPageFoot(); ?>
