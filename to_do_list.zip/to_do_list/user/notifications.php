<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

$pageTitle = 'Notifications';
$currentPage = 'notifications';
$pdo = db();
$user = currentUser();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'mark_read') {
    $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?')->execute([$user['id']]);
    flash('success', 'All notifications marked as read.');
    redirect(baseUrl('user/notifications.php'));
}

if (isset($_GET['read']) && is_numeric($_GET['read'])) {
    $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?')->execute([(int)$_GET['read'], $user['id']]);
    redirect(baseUrl('user/notifications.php'));
}

$notifications = $pdo->prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50');
$notifications->execute([$user['id']]);
$notifications = $notifications->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Notifications & Reminders</h2>
        <form method="POST" style="display:inline;">
            <input type="hidden" name="action" value="mark_read">
            <button type="submit" class="btn btn-outline btn-sm">Mark All Read</button>
        </form>
    </div>
    <p class="text-muted mb-2" style="padding:0 0 0 0;">Enable browser notifications for task reminders. Your browser will alert you about new assignments.</p>
    <?php if (empty($notifications)): ?>
    <div class="empty-state"><div class="empty-state-icon"><?= icon('bell-empty') ?></div><p>No notifications yet.</p></div>
    <?php else: ?>
    <ul class="notif-list">
        <?php foreach ($notifications as $n): ?>
        <li class="notif-item <?= !$n['is_read'] ? 'unread' : '' ?>">
            <div class="notif-icon"><?= notifIcon($n['type']) ?></div>
            <div class="notif-content">
                <div class="notif-title"><?= sanitize($n['title']) ?></div>
                <p><?= sanitize($n['message']) ?></p>
                <div class="notif-time"><?= formatDateTime($n['created_at']) ?></div>
                <?php if ($n['link']): ?>
                <a href="<?= sanitize($n['link']) ?>" class="btn btn-sm btn-outline mt-1">View</a>
                <?php endif; ?>
            </div>
            <?php if (!$n['is_read']): ?>
            <a href="?read=<?= $n['id'] ?>" class="btn btn-sm btn-outline">Mark Read</a>
            <?php endif; ?>
        </li>
        <?php endforeach; ?>
    </ul>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
