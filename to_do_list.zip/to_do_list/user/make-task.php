<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin();
if (isAdmin()) redirect(baseUrl('admin/make-task.php'));

$pageTitle = 'Make a Task';
$currentPage = 'make-task';
$pdo = db();
$user = currentUser();

$schedules = $pdo->query('SELECT id, title FROM schedules ORDER BY title')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $times = parseScheduledFromRequest();
    $start = $times['start'];
    $end = $times['end'];

    if ($title === '' || $times['scheduled'] === '') {
        flash('error', 'Please fill in title, scheduled date, and scheduled time.');
        redirect(baseUrl('user/make-task.php'));
    }

    $scheduleId = !empty($_POST['schedule_id']) ? (int)$_POST['schedule_id'] : null;
    $ringtone = processTaskRingtoneFromRequest((int)$user['id']);
    $speechVoice = speechVoiceFromRequest(null, $ringtone);
    if (!empty($_FILES['custom_ringtone']['name']) && $_FILES['custom_ringtone']['error'] !== UPLOAD_ERR_NO_FILE && strpos($ringtone, 'custom:') !== 0) {
        flash('error', 'Custom ringtone upload failed. Use MP3, WAV, OGG, or M4A (max 5MB).');
        redirect(baseUrl('user/make-task.php'));
    }
    $vibrate = taskVibrateFromRequest();
    $stmt = $pdo->prepare('INSERT INTO tasks (schedule_id, title, description, start_datetime, end_datetime, priority, ringtone, speech_voice, vibrate, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([
        $scheduleId,
        $title,
        trim($_POST['description'] ?? ''),
        $start,
        $end,
        $_POST['priority'] ?? 'medium',
        $ringtone,
        $speechVoice,
        $vibrate,
        $user['id'],
    ]);
    $taskId = (int)$pdo->lastInsertId();

    $pdo->prepare('INSERT INTO task_assignments (task_id, user_id, assigned_by) VALUES (?, ?, ?)')
        ->execute([$taskId, $user['id'], $user['id']]);

    $admins = $pdo->query("SELECT id FROM users WHERE role = 'admin' AND is_active = 1")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($admins as $adminId) {
        createNotification(
            (int)$adminId,
            'New Task Created',
            $user['name'] . ' created task: ' . $title,
            'info',
            baseUrl('admin/tasks.php')
        );
    }

    flash('success', 'Your task has been created.');
    redirect(baseUrl('user/tasks.php'));
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title"><?= icon('tasks') ?> Make a Task</h2>
        <a href="<?= baseUrl('user/tasks.php') ?>" class="btn btn-outline btn-sm">My Tasks</a>
    </div>
    <p class="text-muted mb-2">Create a personal task. It will be added to your task list and calendar.</p>
    <form method="POST" action="" enctype="multipart/form-data">
        <div class="form-group">
            <label for="title">Task Title *</label>
            <input type="text" id="title" name="title" class="form-control" required
                   value="<?= sanitize($_POST['title'] ?? '') ?>" placeholder="What do you need to do?">
        </div>
        <div class="form-group">
            <label for="description">Description</label>
            <textarea id="description" name="description" class="form-control" rows="3"
                      placeholder="Optional details..."><?= sanitize($_POST['description'] ?? '') ?></textarea>
        </div>
        <?php if (!empty($schedules)): ?>
        <div class="form-group">
            <label for="schedule_id">Schedule (optional)</label>
            <select id="schedule_id" name="schedule_id" class="form-control">
                <option value="">— None —</option>
                <?php foreach ($schedules as $s): ?>
                <option value="<?= $s['id'] ?>" <?= (($_POST['schedule_id'] ?? '') == $s['id']) ? 'selected' : '' ?>>
                    <?= sanitize($s['title']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
        <?php $dtDefaults = defaultTaskDateTimes(); require __DIR__ . '/../includes/datetime-fields.php'; ?>
        <?php
        $selectedRingtone = $_POST['ringtone'] ?? 'speech';
        $vibrateEnabled = isset($_POST['vibrate']) ? 1 : 1;
        $previewTaskTitle = trim($_POST['title'] ?? '');
        $selectedSpeechVoice = sanitizeSpeechVoice($_POST['speech_voice'] ?? null) ?? '';
        require __DIR__ . '/../includes/ringtone-field.php';
        ?>
        <div class="form-group">
            <label for="priority">Priority</label>
            <select id="priority" name="priority" class="form-control">
                <option value="low" <?= ($_POST['priority'] ?? '') === 'low' ? 'selected' : '' ?>>Low</option>
                <option value="medium" <?= ($_POST['priority'] ?? 'medium') === 'medium' ? 'selected' : '' ?>>Medium</option>
                <option value="high" <?= ($_POST['priority'] ?? '') === 'high' ? 'selected' : '' ?>>High</option>
            </select>
        </div>
        <div class="btn-group">
            <button type="submit" class="btn btn-primary"><?= icon('tasks') ?> Create Task</button>
            <a href="<?= baseUrl('user/tasks.php') ?>" class="btn btn-outline">Cancel</a>
        </div>
    </form>
</div>

<?php
$extraJs = [assetUrl('js/ringtones.js')];
require_once __DIR__ . '/../includes/footer.php';
?>
