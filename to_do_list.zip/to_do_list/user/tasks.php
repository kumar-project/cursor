<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin();
if (isAdmin()) redirect(baseUrl('admin/tasks.php'));

$pageTitle = 'My Tasks';
$currentPage = 'tasks';
$pdo = db();
$user = currentUser();

$filter = $_GET['status'] ?? 'all';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['task_id'], $_POST['status'])) {
    $taskId = (int)$_POST['task_id'];
    $newStatus = $_POST['status'];
    $allowed = ['pending', 'in_progress', 'completed', 'cancelled'];

    if (in_array($newStatus, $allowed)) {
        $check = $pdo->prepare('SELECT t.id, t.title, t.created_by FROM tasks t JOIN task_assignments ta ON t.id = ta.task_id WHERE t.id = ? AND ta.user_id = ?');
        $check->execute([$taskId, $user['id']]);
        $task = $check->fetch();

        if ($task) {
            $pdo->prepare('UPDATE tasks SET status = ? WHERE id = ?')->execute([$newStatus, $taskId]);
            createNotification(
                $task['created_by'],
                'Task Status Updated',
                $user['name'] . ' marked "' . $task['title'] . '" as ' . str_replace('_', ' ', $newStatus),
                'status',
                baseUrl('admin/tasks.php')
            );
            flash('success', 'Task status updated.');
        }
    }
    redirect(baseUrl('user/tasks.php' . ($filter !== 'all' ? '?status=' . $filter : '')));
}

$sql = "
    SELECT t.*, s.title as schedule_title
    FROM tasks t
    JOIN task_assignments ta ON t.id = ta.task_id
    LEFT JOIN schedules s ON t.schedule_id = s.id
    WHERE ta.user_id = ?
";
$params = [$user['id']];

if ($filter !== 'all' && in_array($filter, ['pending', 'in_progress', 'completed', 'cancelled'])) {
    $sql .= ' AND t.status = ?';
    $params[] = $filter;
}
$sql .= ' ORDER BY t.start_datetime DESC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$tasks = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Assigned Tasks</h2>
        <div class="btn-group" style="flex-wrap:wrap;">
            <a href="<?= baseUrl('user/make-task.php') ?>" class="btn btn-primary btn-sm"><?= icon('tasks') ?> Make a Task</a>
            <a href="?status=all" class="btn btn-sm <?= $filter === 'all' ? 'btn-primary' : 'btn-outline' ?>">All</a>
            <a href="?status=pending" class="btn btn-sm <?= $filter === 'pending' ? 'btn-primary' : 'btn-outline' ?>">Pending</a>
            <a href="?status=in_progress" class="btn btn-sm <?= $filter === 'in_progress' ? 'btn-primary' : 'btn-outline' ?>">In Progress</a>
            <a href="?status=completed" class="btn btn-sm <?= $filter === 'completed' ? 'btn-primary' : 'btn-outline' ?>">Completed</a>
        </div>
    </div>
    <?php if (empty($tasks)): ?>
    <div class="empty-state"><div class="empty-state-icon"><?= icon('tasks-empty') ?></div><p>No tasks found.</p></div>
    <?php else: ?>
    <ul class="task-list">
        <?php foreach ($tasks as $task): ?>
        <li class="task-item">
            <div class="task-info">
                <div class="task-title"><?= sanitize($task['title']) ?></div>
                <div class="task-meta">
                    <i class="fa-solid fa-clock"></i> Scheduled: <?= formatTaskScheduled($task['start_datetime']) ?>
                    <?php if ($task['schedule_title']): ?> | <?= sanitize($task['schedule_title']) ?><?php endif; ?>
                </div>
                <?php if ($task['description']): ?>
                <p class="text-muted mt-1" style="font-size:.85rem;"><?= sanitize($task['description']) ?></p>
                <?php endif; ?>
                <?php
                $rt = $task['ringtone'] ?? 'speech';
                if (!isValidRingtone($rt)) $rt = 'speech';
                if ($rt !== 'none'):
                    $customUrl = ringtonePlayUrl($rt) ?? '';
                    $vib = (int)($task['vibrate'] ?? 1);
                ?>
                <div class="task-ringtone-tag">
                    <i class="fa-solid fa-volume-high"></i> <?= ringtoneLabel($rt) ?>
                    <?php if ($vib): ?><span class="text-muted">· <i class="fa-solid fa-mobile-screen"></i> vibrate</span><?php endif; ?>
                    <button type="button" class="play-task-ringtone"
                            data-ringtone="<?= sanitize($rt) ?>"
                            data-vibrate="<?= $vib ?>"
                            data-custom-url="<?= sanitize($customUrl) ?>"
                            data-task-title="<?= sanitize($task['title']) ?>"
                            data-speech-voice="<?= sanitize($task['speech_voice'] ?? '') ?>">Play</button>
                </div>
                <?php endif; ?>
            </div>
            <div class="task-actions">
                <?= priorityBadge($task['priority']) ?>
                <?= statusBadge($task['status']) ?>
                <a href="<?= baseUrl('user/edit-task.php?id=' . (int)$task['id']) ?>" class="btn btn-sm btn-outline" title="Edit task">
                    <?= icon('edit') ?> Edit
                </a>
                <form method="POST" class="d-flex gap-1 flex-wrap task-status-form">
                    <input type="hidden" name="task_id" value="<?= $task['id'] ?>">
                    <select name="status" class="form-control" style="width:auto;padding:.4rem .6rem;font-size:.85rem;">
                        <option value="pending" <?= $task['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                        <option value="in_progress" <?= $task['status'] === 'in_progress' ? 'selected' : '' ?>>In Progress</option>
                        <option value="completed" <?= $task['status'] === 'completed' ? 'selected' : '' ?>>Completed</option>
                        <option value="cancelled" <?= $task['status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                    </select>
                    <button type="submit" class="btn btn-sm btn-primary">Update</button>
                </form>
            </div>
        </li>
        <?php endforeach; ?>
    </ul>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
