<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin();
if (isAdmin()) redirect(baseUrl('admin/tasks.php'));

$taskId = (int)($_GET['id'] ?? $_POST['task_id'] ?? 0);
if ($taskId < 1) {
    flash('error', 'Invalid task.');
    redirect(baseUrl('user/tasks.php'));
}

$pageTitle = 'Edit Task';
$currentPage = 'tasks';
$pdo = db();
$user = currentUser();

$task = getUserAssignedTask($pdo, $taskId, $user['id']);
if (!$task) {
    flash('error', 'Task not found or you are not assigned to it.');
    redirect(baseUrl('user/tasks.php'));
}

$schedules = $pdo->query('SELECT id, title FROM schedules ORDER BY title')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $times = parseScheduledFromRequest();
    $start = $times['start'];
    $end = $times['end'];
    $status = $_POST['status'] ?? $task['status'];
    $allowedStatus = ['pending', 'in_progress', 'completed', 'cancelled'];

    if ($title === '' || $times['scheduled'] === '') {
        flash('error', 'Please fill in title, scheduled date, and scheduled time.');
        redirect(baseUrl('user/edit-task.php?id=' . $taskId));
    }

    if (!in_array($status, $allowedStatus, true)) {
        $status = $task['status'];
    }

    $scheduleId = !empty($_POST['schedule_id']) ? (int)$_POST['schedule_id'] : null;
    $priority = $_POST['priority'] ?? 'medium';
    if (!in_array($priority, ['low', 'medium', 'high'], true)) {
        $priority = 'medium';
    }

    $ringtone = processTaskRingtoneFromRequest((int)$user['id'], $task['ringtone'] ?? null);
    $speechVoice = speechVoiceFromRequest(null, $ringtone);
    $vibrate = taskVibrateFromRequest();
    $pdo->prepare('
        UPDATE tasks SET
            schedule_id = ?, title = ?, description = ?,
            start_datetime = ?, end_datetime = ?,
            priority = ?, status = ?, ringtone = ?, speech_voice = ?, vibrate = ?
        WHERE id = ?
    ')->execute([
        $scheduleId,
        $title,
        trim($_POST['description'] ?? ''),
        $start,
        $end,
        $priority,
        $status,
        $ringtone,
        $speechVoice,
        $vibrate,
        $taskId,
    ]);

    if ((int)$task['created_by'] !== (int)$user['id']) {
        createNotification(
            (int)$task['created_by'],
            'Task Updated',
            $user['name'] . ' updated task: ' . $title,
            'status',
            baseUrl('admin/tasks.php')
        );
    }

    flash('success', 'Task updated successfully.');
    redirect(baseUrl('user/tasks.php'));
}

$dtDefaults = taskToDateTimeDefaults($task);

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title"><?= icon('edit') ?> Edit Task</h2>
        <a href="<?= baseUrl('user/tasks.php') ?>" class="btn btn-outline btn-sm">Back to My Tasks</a>
    </div>
    <form method="POST" action="" enctype="multipart/form-data">
        <input type="hidden" name="task_id" value="<?= (int)$task['id'] ?>">
        <div class="form-group">
            <label for="title">Task Title *</label>
            <input type="text" id="title" name="title" class="form-control" required
                   value="<?= sanitize($_POST['title'] ?? $task['title']) ?>"
                   placeholder="Task title">
        </div>
        <div class="form-group">
            <label for="description">Description</label>
            <textarea id="description" name="description" class="form-control" rows="3"
                      placeholder="Optional details..."><?= sanitize($_POST['description'] ?? $task['description'] ?? '') ?></textarea>
        </div>
        <?php if (!empty($schedules)): ?>
        <div class="form-group">
            <label for="schedule_id">Schedule (optional)</label>
            <select id="schedule_id" name="schedule_id" class="form-control">
                <option value="">— None —</option>
                <?php
                $selSchedule = $_POST['schedule_id'] ?? $task['schedule_id'] ?? '';
                foreach ($schedules as $s):
                ?>
                <option value="<?= $s['id'] ?>" <?= (string)$selSchedule === (string)$s['id'] ? 'selected' : '' ?>>
                    <?= sanitize($s['title']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
        <?php require __DIR__ . '/../includes/datetime-fields.php'; ?>
        <?php
        $selectedRingtone = $_POST['ringtone'] ?? ($task['ringtone'] ?? 'speech');
        $vibrateEnabled = isset($_POST['vibrate']) ? (int)$_POST['vibrate'] : (int)($task['vibrate'] ?? 1);
        $previewTaskTitle = trim($_POST['title'] ?? $task['title'] ?? '');
        $selectedSpeechVoice = sanitizeSpeechVoice($_POST['speech_voice'] ?? ($task['speech_voice'] ?? null)) ?? '';
        require __DIR__ . '/../includes/ringtone-field.php';
        ?>
        <div class="form-row cols-2">
            <div class="form-group">
                <label for="priority">Priority</label>
                <select id="priority" name="priority" class="form-control">
                    <?php $prio = $_POST['priority'] ?? $task['priority']; ?>
                    <option value="low" <?= $prio === 'low' ? 'selected' : '' ?>>Low</option>
                    <option value="medium" <?= $prio === 'medium' ? 'selected' : '' ?>>Medium</option>
                    <option value="high" <?= $prio === 'high' ? 'selected' : '' ?>>High</option>
                </select>
            </div>
            <div class="form-group">
                <label for="status">Status</label>
                <select id="status" name="status" class="form-control">
                    <?php $st = $_POST['status'] ?? $task['status']; ?>
                    <option value="pending" <?= $st === 'pending' ? 'selected' : '' ?>>Pending</option>
                    <option value="in_progress" <?= $st === 'in_progress' ? 'selected' : '' ?>>In Progress</option>
                    <option value="completed" <?= $st === 'completed' ? 'selected' : '' ?>>Completed</option>
                    <option value="cancelled" <?= $st === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                </select>
            </div>
        </div>
        <div class="btn-group">
            <button type="submit" class="btn btn-primary"><?= icon('edit') ?> Save Changes</button>
            <a href="<?= baseUrl('user/tasks.php') ?>" class="btn btn-outline">Cancel</a>
        </div>
    </form>
</div>

<?php
$extraJs = [assetUrl('js/ringtones.js')];
require_once __DIR__ . '/../includes/footer.php';
?>
