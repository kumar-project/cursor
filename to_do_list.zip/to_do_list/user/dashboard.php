<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin();
if (isAdmin()) redirect(baseUrl('admin/dashboard.php'));

$pageTitle = 'Dashboard';
$currentPage = 'dashboard';
$pdo = db();
$user = currentUser();

$stats = [
    'assigned' => 0,
    'pending' => 0,
    'in_progress' => 0,
    'completed' => 0,
];

$stmt = $pdo->prepare("
    SELECT t.status, COUNT(*) as cnt
    FROM tasks t
    JOIN task_assignments ta ON t.id = ta.task_id
    WHERE ta.user_id = ?
    GROUP BY t.status
");
$stmt->execute([$user['id']]);
foreach ($stmt->fetchAll() as $row) {
    $stats['assigned'] += $row['cnt'];
    if (isset($stats[$row['status']])) {
        $stats[$row['status']] = $row['cnt'];
    }
}

$todayTasks = $pdo->prepare("
    SELECT t.* FROM tasks t
    JOIN task_assignments ta ON t.id = ta.task_id
    WHERE ta.user_id = ? AND DATE(t.start_datetime) <= CURDATE() AND DATE(t.end_datetime) >= CURDATE()
    ORDER BY t.start_datetime ASC LIMIT 5
");
$todayTasks->execute([$user['id']]);
$todayTasks = $todayTasks->fetchAll();

$upcoming = $pdo->prepare("
    SELECT t.* FROM tasks t
    JOIN task_assignments ta ON t.id = ta.task_id
    WHERE ta.user_id = ? AND t.start_datetime > NOW() AND t.status != 'completed'
    ORDER BY t.start_datetime ASC LIMIT 5
");
$upcoming->execute([$user['id']]);
$upcoming = $upcoming->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-value"><?= $stats['assigned'] ?></div>
        <div class="stat-label">Assigned Tasks</div>
    </div>
    <div class="stat-card warning">
        <div class="stat-value"><?= $stats['pending'] ?></div>
        <div class="stat-label">Pending</div>
    </div>
    <div class="stat-card info">
        <div class="stat-value"><?= $stats['in_progress'] ?></div>
        <div class="stat-label">In Progress</div>
    </div>
    <div class="stat-card success">
        <div class="stat-value"><?= $stats['completed'] ?></div>
        <div class="stat-label">Completed</div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Today's Tasks</h2>
        <div class="btn-group">
            <a href="<?= baseUrl('user/make-task.php') ?>" class="btn btn-primary btn-sm"><?= icon('tasks') ?> Make a Task</a>
            <a href="<?= baseUrl('user/tasks.php') ?>" class="btn btn-outline btn-sm">View All</a>
        </div>
    </div>
    <?php if (empty($todayTasks)): ?>
    <div class="empty-state"><div class="empty-state-icon"><?= icon('check') ?></div><p>No tasks scheduled for today.</p></div>
    <?php else: ?>
    <ul class="task-list">
        <?php foreach ($todayTasks as $task): ?>
        <li class="task-item">
            <div class="task-info">
                <div class="task-title"><?= sanitize($task['title']) ?></div>
                <div class="task-meta">Scheduled: <?= formatTaskScheduled($task['start_datetime']) ?></div>
            </div>
            <?= statusBadge($task['status']) ?>
        </li>
        <?php endforeach; ?>
    </ul>
    <?php endif; ?>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Upcoming Tasks</h2>
        <a href="<?= baseUrl('user/calendar.php') ?>" class="btn btn-outline btn-sm">Calendar</a>
    </div>
    <?php if (empty($upcoming)): ?>
    <div class="empty-state"><p>No upcoming tasks.</p></div>
    <?php else: ?>
    <ul class="task-list">
        <?php foreach ($upcoming as $task): ?>
        <li class="task-item">
            <div class="task-info">
                <div class="task-title"><?= sanitize($task['title']) ?></div>
                <div class="task-meta">Scheduled: <?= formatTaskScheduled($task['start_datetime']) ?></div>
            </div>
            <?= priorityBadge($task['priority']) ?>
        </li>
        <?php endforeach; ?>
    </ul>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
