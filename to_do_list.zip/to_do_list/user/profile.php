<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

$pageTitle = 'Profile';
$currentPage = 'profile';
$pdo = db();
$user = currentUser();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');

        if ($name) {
            if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                flash('error', 'Please enter a valid email address.');
            } else {
                $phoneNorm = normalizePhone($user['phone'] ?? '');
                $emailVal = resolveStoredEmail($email !== '' ? $email : null, $phoneNorm);

                if ($email !== '' && !isPlaceholderEmail($emailVal)) {
                    $stmt = $pdo->prepare('SELECT id FROM users WHERE LOWER(email) = ? AND id != ?');
                    $stmt->execute([strtolower($email), $user['id']]);
                    if ($stmt->fetch()) {
                        flash('error', 'This email is already in use.');
                        redirect(baseUrl('user/profile.php'));
                    }
                }

                $avatar = $user['avatar'];
                if (!empty($_FILES['avatar']['name'])) {
                    $newAvatar = uploadAvatar($_FILES['avatar']);
                    if ($newAvatar) {
                        if ($avatar && file_exists(UPLOAD_DIR . $avatar)) {
                            unlink(UPLOAD_DIR . $avatar);
                        }
                        $avatar = $newAvatar;
                    }
                }
                $pdo->prepare('UPDATE users SET name = ?, email = ?, avatar = ? WHERE id = ?')
                    ->execute([$name, $emailVal, $avatar, $user['id']]);
                flash('success', 'Profile updated.');
            }
        }
    } elseif ($action === 'reminder_settings') {
        $emailRem = isset($_POST['email_reminders']) ? 1 : 0;
        $browserRem = isset($_POST['browser_reminders']) ? 1 : 0;
        $minutes = max(5, min(1440, (int)($_POST['reminder_minutes'] ?? 30)));

        $pdo->prepare('
            INSERT INTO reminder_settings (user_id, email_reminders, browser_reminders, reminder_minutes)
            VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE email_reminders = ?, browser_reminders = ?, reminder_minutes = ?
        ')->execute([$user['id'], $emailRem, $browserRem, $minutes, $emailRem, $browserRem, $minutes]);
        flash('success', 'Reminder settings saved.');
    }
    redirect(baseUrl('user/profile.php'));
}

$stmt = $pdo->prepare('SELECT * FROM reminder_settings WHERE user_id = ?');
$stmt->execute([$user['id']]);
$reminders = $stmt->fetch() ?: ['email_reminders' => 1, 'browser_reminders' => 1, 'reminder_minutes' => 30];

$user = currentUser();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="profile-header">
        <img src="<?= avatarUrl($user['avatar'] ?? null) ?>" alt="Avatar" class="profile-avatar">
        <div>
            <h2><?= sanitize($user['name']) ?></h2>
            <p class="text-muted"><?= formatPhone($user['phone'] ?? '') ?></p>
            <?php if (!empty($user['email']) && !isPlaceholderEmail($user['email'])): ?>
            <p class="text-muted" style="font-size:.9rem;"><?= sanitize($user['email']) ?></p>
            <?php endif; ?>
            <span class="badge"><?= ucfirst($user['role']) ?></span>
        </div>
    </div>
</div>

<div class="card profile-section" id="edit-profile">
    <div class="card-header"><h2 class="card-title">Edit Profile</h2></div>
    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="update_profile">
        <div class="form-group">
            <label>Profile Photo</label>
            <input type="file" name="avatar" class="form-control" accept="image/*">
        </div>
        <div class="form-group">
            <label>Full Name</label>
            <input type="text" name="name" class="form-control" value="<?= sanitize($user['name']) ?>" required>
        </div>
        <div class="form-group">
            <label>Mobile Number</label>
            <input type="text" class="form-control" value="<?= sanitize(formatPhone($user['phone'] ?? '')) ?>" disabled>
            <small class="text-muted">Mobile number is used to sign in and cannot be changed here.</small>
        </div>
        <div class="form-group">
            <label>Email (optional)</label>
            <input type="email" name="email" class="form-control"
                   value="<?= sanitize(isPlaceholderEmail($user['email'] ?? null) ? '' : ($user['email'] ?? '')) ?>"
                   placeholder="For reminders only">
        </div>
        <button type="submit" class="btn btn-primary">Save Profile</button>
    </form>
</div>

<div class="card profile-section" id="reminder-settings">
    <div class="card-header"><h2 class="card-title">Reminder Settings</h2></div>
    <form method="POST">
        <input type="hidden" name="action" value="reminder_settings">
        <div class="form-group">
            <label>
                <input type="checkbox" name="email_reminders" <?= $reminders['email_reminders'] ? 'checked' : '' ?>>
                Email reminders (requires mail server setup)
            </label>
        </div>
        <div class="form-group">
            <label>
                <input type="checkbox" name="browser_reminders" <?= $reminders['browser_reminders'] ? 'checked' : '' ?>>
                Browser push notifications
            </label>
        </div>
        <div class="form-group">
            <label>Remind me before task (minutes)</label>
            <input type="number" name="reminder_minutes" class="form-control" value="<?= (int)$reminders['reminder_minutes'] ?>" min="5" max="1440">
        </div>
        <button type="submit" class="btn btn-primary">Save Settings</button>
    </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
