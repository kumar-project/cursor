<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

$pageTitle = 'Calendar';
$currentPage = 'calendar';
$extraCss = [
    'https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.css'
];
$extraJs = [
    'https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.js',
    assetUrl('js/calendar.js')
];

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">My Calendar</h2>
        <span class="text-muted">Daily & Weekly views</span>
    </div>
    <div id="calendar"></div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
