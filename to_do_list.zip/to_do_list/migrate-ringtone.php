<?php
/**
 * Add ringtone & vibrate columns to tasks (run once if upgrading).
 */
require_once __DIR__ . '/includes/db.php';

$messages = [];
$ok = true;

try {
    $pdo = db();
    if (!is_dir(RINGTONE_DIR)) {
        mkdir(RINGTONE_DIR, 0755, true);
    }

    $cols = $pdo->query("SHOW COLUMNS FROM tasks LIKE 'ringtone'")->fetch();
    if (!$cols) {
        $pdo->exec("ALTER TABLE tasks ADD COLUMN ringtone VARCHAR(120) NOT NULL DEFAULT 'default' AFTER status");
        $messages[] = 'Added ringtone column.';
    } else {
        $pdo->exec("ALTER TABLE tasks MODIFY COLUMN ringtone VARCHAR(120) NOT NULL DEFAULT 'default'");
        $messages[] = 'Ringtone column updated (supports custom uploads).';
    }

    $vcol = $pdo->query("SHOW COLUMNS FROM tasks LIKE 'vibrate'")->fetch();
    if (!$vcol) {
        $pdo->exec("ALTER TABLE tasks ADD COLUMN vibrate TINYINT(1) NOT NULL DEFAULT 1 AFTER ringtone");
        $messages[] = 'Added vibrate column.';
    } else {
        $messages[] = 'Vibrate column already exists.';
    }

    $messages[] = 'Done! Custom ringtones and vibration are ready.';
} catch (Exception $e) {
    $ok = false;
    $messages[] = 'Error: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Update</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="auth-main">
    <div class="auth-container">
        <div class="auth-card">
            <h2 class="text-center mb-2">Task Alert Update</h2>
            <?php foreach ($messages as $msg): ?>
            <div class="alert alert-<?= $ok ? 'success' : 'error' ?>"><?= htmlspecialchars($msg) ?></div>
            <?php endforeach; ?>
            <a href="user/make-task.php" class="btn btn-primary btn-block">Make a Task</a>
        </div>
    </div>
</div>
</body>
</html>
