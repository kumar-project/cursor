<?php
require_once __DIR__ . '/includes/auth.php';

if (isLoggedIn()) {
  redirect(isAdmin() ? baseUrl('admin/dashboard.php') : baseUrl('user/dashboard.php'));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= APP_NAME ?> - Smart Task Scheduling</title>
    <?= fontAwesomeCss() ?>
    <link rel="stylesheet" href="<?= assetUrl('css/style.css') ?>">
</head>
<body class="landing">
    <nav class="landing-nav">
        <a href="index.php" class="logo"><span class="logo-icon"><?= icon('logo') ?></span> <?= APP_NAME ?></a>
        <div class="btn-group landing-auth-btns">
            <a href="login.php" class="btn btn-outline" style="color:#fff;border-color:#fff;">User Login</a>
            <a href="register.php" class="btn btn-primary">User Register</a>
            <a href="admin/login.php" class="btn btn-outline" style="color:#fff;border-color:rgba(255,255,255,.85);">Admin Login</a>
        </div>
    </nav>
    <section class="landing-hero">
        <h1>Schedule Smarter, Work Better</h1>
        <p>Complete scheduler application with admin panel, task assignments, calendar views, notifications, and mobile-friendly interface.</p>
        <div class="btn-group" style="justify-content:center;flex-wrap:wrap;gap:.75rem;">
            <a href="register.php" class="btn btn-primary" style="padding:1rem 2rem;">Register as User</a>
            <a href="login.php" class="btn btn-outline" style="color:#fff;border-color:#fff;padding:1rem 2rem;">User Sign In</a>
            <a href="admin/register.php" class="btn btn-outline" style="color:#fff;border-color:#fff;padding:1rem 2rem;">Admin Register</a>
        </div>
    </section>
    <section class="landing-features">
        <div class="feature-card">
            <div class="feature-icon"><?= icon('schedules') ?></div>
            <h3>Create Schedules</h3>
            <p class="text-muted">Plan projects with date ranges and color-coded schedules.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon"><?= icon('tasks') ?></div>
            <h3>Assign Tasks</h3>
            <p class="text-muted">Assign tasks to team members with priorities and deadlines.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon"><?= icon('calendar') ?></div>
            <h3>Calendar View</h3>
            <p class="text-muted">Daily and weekly calendar powered by FullCalendar.js.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon"><?= icon('notifications') ?></div>
            <h3>Notifications</h3>
            <p class="text-muted">In-app and browser reminders for upcoming tasks.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon"><?= icon('dashboard') ?></div>
            <h3>Reports & Dashboard</h3>
            <p class="text-muted">Track completion rates and team performance.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon"><?= icon('mobile') ?></div>
            <h3>Mobile Friendly</h3>
            <p class="text-muted">Responsive design works on phones, tablets, and desktop.</p>
        </div>
    </section>
</body>
</html>
