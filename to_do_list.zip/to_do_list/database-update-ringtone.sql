-- Run in phpMyAdmin or open migrate-ringtone.php in browser
USE scheduler_app;
ALTER TABLE tasks MODIFY COLUMN ringtone VARCHAR(120) NOT NULL DEFAULT 'default';
ALTER TABLE tasks ADD COLUMN vibrate TINYINT(1) NOT NULL DEFAULT 1 AFTER ringtone;
