<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();
redirect(isAdmin() ? baseUrl('admin/dashboard.php') : baseUrl('user/dashboard.php'));
