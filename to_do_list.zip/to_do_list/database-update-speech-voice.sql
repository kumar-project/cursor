-- Add speech voice column (existing database only — safe to re-run)
-- Or open upgrade-database.php in your browser instead.
USE scheduler_app;

SET @sql = IF(
    (SELECT COUNT(*) FROM information_schema.columns
     WHERE table_schema = DATABASE() AND table_name = 'tasks' AND column_name = 'speech_voice') = 0,
    'ALTER TABLE tasks ADD COLUMN speech_voice VARCHAR(255) DEFAULT NULL AFTER ringtone',
    'SELECT ''speech_voice column already exists'' AS status'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
