<?php
require_once __DIR__ . '/includes/auth.php';
logoutUser();
flash('success', 'You have been logged out.');
redirect(baseUrl('login.php'));
