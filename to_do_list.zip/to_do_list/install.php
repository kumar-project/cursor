<?php
/**
 * One-time setup: creates database tables and default users.
 * Delete this file after installation for security.
 */
require_once __DIR__ . '/includes/config.php';

$messages = [];
$success = false;

try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';charset=utf8mb4', DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);

    $sql = file_get_contents(__DIR__ . '/database.sql');
    $pdo->exec($sql);

    $pdo->exec('USE ' . DB_NAME);

    require_once __DIR__ . '/includes/auth.php';
    ensureDemoAccounts($pdo);

    try {
        $pdo->exec('ALTER TABLE tasks ADD COLUMN speech_voice VARCHAR(255) DEFAULT NULL AFTER ringtone');
    } catch (PDOException $e) {}

    try {
        $pdo->exec('ALTER TABLE tasks ADD COLUMN ringtone VARCHAR(120) NOT NULL DEFAULT \'default\' AFTER status');
    } catch (PDOException $e) {}
    try {
        $pdo->exec('ALTER TABLE tasks ADD COLUMN vibrate TINYINT(1) NOT NULL DEFAULT 1 AFTER ringtone');
    } catch (PDOException $e) {}
    if (!is_dir(RINGTONE_DIR)) {
        mkdir(RINGTONE_DIR, 0755, true);
    }

    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0755, true);
    }

    $messages[] = 'Database installed successfully!';
    $messages[] = 'Admin mobile: ' . DEMO_ADMIN_PHONE;
    $messages[] = 'User mobile: ' . DEMO_USER_PHONE;
    $messages[] = 'Sign in using mobile number only (no password).';
    $messages[] = 'Please delete install.php after setup.';
    $success = true;
} catch (Exception $e) {
    $messages[] = 'Error: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Install - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="auth-main">
    <div class="auth-container">
        <div class="auth-card">
            <h2 class="text-center mb-2">Installation</h2>
            <?php foreach ($messages as $msg): ?>
            <div class="alert alert-<?= $success ? 'success' : 'error' ?>"><?= htmlspecialchars($msg) ?></div>
            <?php endforeach; ?>
            <?php if ($success): ?>
            <p class="text-muted text-center" style="font-size:.85rem;margin-bottom:1rem;">
                User: <a href="login.php">login.php</a> · Admin: <a href="admin/login.php">admin/login.php</a>
            </p>
            <a href="login.php" class="btn btn-primary btn-block">User Login</a>
            <a href="admin/login.php" class="btn btn-outline btn-block" style="margin-top:.5rem;">Admin Login</a>
            <?php else: ?>
            <p class="text-muted text-center">Ensure MySQL is running in XAMPP and DB credentials in includes/config.php are correct.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>
