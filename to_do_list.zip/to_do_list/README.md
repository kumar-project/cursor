# Scheduler Pro

A complete PHP + MySQL scheduler application with admin panel, user panel, calendar views, notifications, and mobile-friendly responsive UI.

## Features

### Admin Panel
- Dashboard with statistics
- User management (create, activate/deactivate, delete)
- Create schedules with color coding
- Assign tasks to users with priorities
- FullCalendar.js calendar view
- Send notifications to users
- Reports and analytics

### User Panel
- Login / Register
- View assigned tasks with status filters
- Daily / Weekly / Monthly calendar
- Update task status
- In-app and browser reminder notifications
- Profile management with avatar upload

## Requirements

- PHP 7.4+ (PHP 8 recommended)
- MySQL 5.7+ / MariaDB
- Apache (XAMPP)
- Modern web browser

## Installation (XAMPP)

1. Place project in `htdocs/to do list` (already done)
2. Start **Apache** and **MySQL** in XAMPP Control Panel
3. Open browser: `http://localhost/to%20do%20list/install.php`
4. After success, **delete `install.php`** for security
5. Login at `http://localhost/to%20do%20list/login.php`

### Manual Database Setup

Alternatively, import `database.sql` in phpMyAdmin, then run `install.php` once.

If upgrading from email/password login, import `database-update-mobile-auth.sql` in phpMyAdmin.

### Default credentials (mobile login)

| Role  | Mobile number |
|-------|----------------|
| Admin | 9999999999     |
| User  | 8888888888     |

Sign in with the 10-digit mobile number only (no password). Use `fix-demo-accounts.php` if demo login fails.

## Configuration

Edit `includes/config.php`:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'scheduler_app');
define('DB_USER', 'root');
define('DB_PASS', '');
```

## Project Structure

```
├── admin/          Admin panel pages
├── user/           User panel pages
├── api/            JSON API endpoints
├── assets/         CSS, JavaScript
├── includes/       db.php, auth.php, config
├── uploads/        Profile avatars
├── cron/           Reminder cron script
├── index.php       Landing page
├── login.php
├── register.php
└── database.sql
```

## Reminder Cron Job

Run periodically to send task reminders:

**Windows Task Scheduler:**
```
php "d:\xamp\htdocs\to do list\cron\reminders.php"
```

**Linux cron:**
```
*/15 * * * * php /path/to/cron/reminders.php
```

## Firebase / SMS (Optional)

Browser notifications work out of the box. For Firebase Cloud Messaging:

1. Add your FCM server key in `includes/config.php`
2. Set `FCM_ENABLED` to `true`
3. Integrate FCM SDK in frontend (extend `assets/js/notifications.js`)

## Tech Stack

- **Backend:** PHP with PDO
- **Database:** MySQL
- **Frontend:** HTML5, CSS3, JavaScript
- **Calendar:** FullCalendar.js v6
- **Auth:** Session-based login with unique mobile number

## License

MIT - Free to use and modify.
