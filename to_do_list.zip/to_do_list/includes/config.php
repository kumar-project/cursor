<?php
/**
 * Application configuration
 */
define('APP_NAME', 'Scheduler Pro');
define('APP_URL', 'http://localhost/to%20do%20list');
define('BASE_PATH', dirname(__DIR__));

// Database
define('DB_HOST', 'localhost');
define('DB_NAME', 'scheduler_app');
define('DB_USER', 'root');
define('DB_PASS', '');

// Session
define('SESSION_LIFETIME', 3600 * 8);

// Uploads
define('UPLOAD_DIR', BASE_PATH . '/uploads/');
define('UPLOAD_URL', 'uploads/');
define('MAX_UPLOAD_SIZE', 2 * 1024 * 1024); // 2MB

// Custom ringtones
define('RINGTONE_DIR', UPLOAD_DIR . 'ringtones/');
define('RINGTONE_URL', UPLOAD_URL . 'ringtones/');
define('MAX_RINGTONE_SIZE', 5 * 1024 * 1024); // 5MB

// Firebase Cloud Messaging (optional - add your server key)
define('FCM_SERVER_KEY', '');
define('FCM_ENABLED', false);

// Timezone
date_default_timezone_set('Asia/Kolkata');
