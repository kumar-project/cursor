<?php
$user = currentUser();
$unreadCount = $user ? getUnreadNotificationCount($user['id']) : 0;
$isAdminPage = strpos($_SERVER['SCRIPT_NAME'], '/admin/') !== false;
$panelPrefix = $isAdminPage ? 'admin' : 'user';
?>
<!DOCTYPE html>
<html lang="en-IN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="theme-color" content="#4f46e5">
    <title><?= isset($pageTitle) ? sanitize($pageTitle) . ' - ' : '' ?><?= APP_NAME ?></title>
    <?= fontAwesomeCss() ?>
    <link rel="stylesheet" href="<?= assetUrl('css/style.css') ?>">
    <?php if (!empty($extraCss)): foreach ((array)$extraCss as $css): ?>
    <link rel="stylesheet" href="<?= $css ?>">
    <?php endforeach; endif; ?>
</head>
<body class="<?= $isAdminPage ? 'admin-panel' : 'user-panel' ?>">
    <div class="app-layout">
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <a href="<?= baseUrl($panelPrefix . '/dashboard.php') ?>" class="logo">
                    <span class="logo-icon"><?= icon('logo') ?></span>
                    <span class="logo-text"><?= APP_NAME ?></span>
                </a>
                <button class="sidebar-close" id="sidebarClose" aria-label="Close menu"><?= icon('close') ?></button>
            </div>
            <nav class="sidebar-nav">
                <?php if ($isAdminPage): ?>
                <a href="<?= baseUrl('admin/dashboard.php') ?>" class="nav-item <?= ($currentPage ?? '') === 'dashboard' ? 'active' : '' ?>">
                    <span class="nav-icon"><?= icon('dashboard') ?></span> Dashboard
                </a>
                <a href="<?= baseUrl('admin/users.php') ?>" class="nav-item <?= ($currentPage ?? '') === 'users' ? 'active' : '' ?>">
                    <span class="nav-icon"><?= icon('users') ?></span> Users
                </a>
                <a href="<?= baseUrl('admin/schedules.php') ?>" class="nav-item <?= ($currentPage ?? '') === 'schedules' ? 'active' : '' ?>">
                    <span class="nav-icon"><?= icon('schedules') ?></span> Schedules
                </a>
                <a href="<?= baseUrl('admin/make-task.php') ?>" class="nav-item <?= ($currentPage ?? '') === 'make-task' ? 'active' : '' ?>">
                    <span class="nav-icon"><?= icon('tasks') ?></span> Make a Task
                </a>
                <a href="<?= baseUrl('admin/tasks.php') ?>" class="nav-item <?= ($currentPage ?? '') === 'tasks' ? 'active' : '' ?>">
                    <span class="nav-icon"><?= icon('tasks-empty') ?></span> All Tasks
                </a>
                <a href="<?= baseUrl('admin/calendar.php') ?>" class="nav-item <?= ($currentPage ?? '') === 'calendar' ? 'active' : '' ?>">
                    <span class="nav-icon"><?= icon('calendar') ?></span> Calendar
                </a>
                <a href="<?= baseUrl('admin/notifications.php') ?>" class="nav-item <?= ($currentPage ?? '') === 'notifications' ? 'active' : '' ?>">
                    <span class="nav-icon"><?= icon('notifications') ?></span> Notifications
                    <?php if ($unreadCount > 0): ?><span class="nav-badge"><?= $unreadCount ?></span><?php endif; ?>
                </a>
                <a href="<?= baseUrl('admin/reports.php') ?>" class="nav-item <?= ($currentPage ?? '') === 'reports' ? 'active' : '' ?>">
                    <span class="nav-icon"><?= icon('reports') ?></span> Reports
                </a>
                <?php else: ?>
                <a href="<?= baseUrl('user/dashboard.php') ?>" class="nav-item <?= ($currentPage ?? '') === 'dashboard' ? 'active' : '' ?>">
                    <span class="nav-icon"><?= icon('dashboard') ?></span> Dashboard
                </a>
                <a href="<?= baseUrl('user/make-task.php') ?>" class="nav-item <?= ($currentPage ?? '') === 'make-task' ? 'active' : '' ?>">
                    <span class="nav-icon"><?= icon('tasks') ?></span> Make a Task
                </a>
                <a href="<?= baseUrl('user/tasks.php') ?>" class="nav-item <?= ($currentPage ?? '') === 'tasks' ? 'active' : '' ?>">
                    <span class="nav-icon"><?= icon('tasks-empty') ?></span> My Tasks
                </a>
                <a href="<?= baseUrl('user/calendar.php') ?>" class="nav-item <?= ($currentPage ?? '') === 'calendar' ? 'active' : '' ?>">
                    <span class="nav-icon"><?= icon('calendar') ?></span> Calendar
                </a>
                <a href="<?= baseUrl('user/notifications.php') ?>" class="nav-item <?= ($currentPage ?? '') === 'notifications' ? 'active' : '' ?>">
                    <span class="nav-icon"><?= icon('notifications') ?></span> Notifications
                    <?php if ($unreadCount > 0): ?><span class="nav-badge"><?= $unreadCount ?></span><?php endif; ?>
                </a>
                <?php endif; ?>
            </nav>
        </aside>
        <div class="sidebar-overlay" id="sidebarOverlay"></div>
        <main class="main-content">
            <header class="topbar">
                <button class="menu-toggle" id="menuToggle" aria-label="Open menu">
                    <span></span><span></span><span></span>
                </button>
                <h1 class="page-heading"><?= sanitize($pageTitle ?? 'Dashboard') ?></h1>
                <div class="topbar-actions">
                    <a href="<?= baseUrl($panelPrefix . '/notifications.php') ?>" class="notification-btn" title="Notifications">
                        <?= icon('notifications') ?>
                        <?php if ($unreadCount > 0): ?><span class="notif-count"><?= $unreadCount ?></span><?php endif; ?>
                    </a>
                    <div class="user-menu" id="userMenu">
                        <button type="button" class="user-menu-toggle" id="userMenuToggle"
                                aria-expanded="false" aria-haspopup="true" aria-controls="userMenuDropdown">
                            <img src="<?= avatarUrl($user['avatar'] ?? null) ?>" alt="" class="user-avatar">
                            <span class="user-name"><?= sanitize($user['name']) ?></span>
                            <span class="user-menu-chevron" aria-hidden="true"><?= icon('chevron-down') ?></span>
                        </button>
                        <?php
                        $profileBase = baseUrl('user/profile.php');
                        $onProfile = ($currentPage ?? '') === 'profile';
                        ?>
                        <div class="user-menu-dropdown" id="userMenuDropdown" role="menu">
                            <div class="user-menu-group<?= $onProfile ? ' submenu-open' : '' ?>">
                                <button type="button" class="user-menu-item user-menu-parent" id="userMenuProfileToggle"
                                        aria-expanded="<?= $onProfile ? 'true' : 'false' ?>" aria-controls="userMenuProfileSubmenu">
                                    <span class="user-menu-item-label"><?= icon('profile') ?> Profile</span>
                                    <span class="user-menu-sub-chevron" aria-hidden="true"><?= icon('chevron-right') ?></span>
                                </button>
                                <div class="user-menu-submenu" id="userMenuProfileSubmenu" role="menu">
                                    <a href="<?= $profileBase ?>#edit-profile" role="menuitem" class="user-menu-subitem">
                                        <?= icon('edit') ?> Edit Profile
                                    </a>
                                    <a href="<?= $profileBase ?>#reminder-settings" role="menuitem" class="user-menu-subitem">
                                        <?= icon('notifications') ?> Reminder Settings
                                    </a>
                                </div>
                            </div>
                            <a href="<?= baseUrl('logout.php') ?>" role="menuitem" class="user-menu-item user-menu-item-logout">
                                <?= icon('logout') ?> Logout
                            </a>
                        </div>
                    </div>
                </div>
            </header>
            <div class="content-area">
                <?php $flash = getFlash(); if ($flash): ?>
                <div class="alert alert-<?= $flash['type'] ?>"><?= sanitize($flash['message']) ?></div>
                <?php endif; ?>
