<?php
require_once __DIR__ . '/functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('DEMO_ADMIN_PHONE', '9999999999');
define('DEMO_USER_PHONE', '8888888888');
define('PLACEHOLDER_EMAIL_DOMAIN', '@mobile.scheduler');

/** Upgrade DB columns for mobile-only auth (safe to run repeatedly). */
function ensureMobileAuthSchema(): void {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    $pdo = db();
    $alters = [
        'ALTER TABLE users MODIFY email VARCHAR(150) DEFAULT NULL',
        'ALTER TABLE users MODIFY password VARCHAR(255) DEFAULT NULL',
        'ALTER TABLE users MODIFY phone VARCHAR(15) NOT NULL',
        'ALTER TABLE users ADD UNIQUE KEY uk_users_phone (phone)',
    ];
    foreach ($alters as $sql) {
        try {
            $pdo->exec($sql);
        } catch (PDOException $e) {
            // Ignore if already applied or incompatible row data
        }
    }
}

/** Email for DB when user leaves email blank (required if column is NOT NULL). */
function placeholderEmailForPhone(string $phone): string {
    return $phone . PLACEHOLDER_EMAIL_DOMAIN;
}

function isPlaceholderEmail(?string $email): bool {
    if ($email === null || $email === '') {
        return false;
    }
    $suffix = PLACEHOLDER_EMAIL_DOMAIN;
    return strlen($email) >= strlen($suffix) && substr($email, -strlen($suffix)) === $suffix;
}

function resolveStoredEmail(?string $email, string $phone): string {
    $email = $email !== null ? strtolower(trim($email)) : '';
    if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return $email;
    }
    return placeholderEmailForPhone($phone);
}

function isLoggedIn(): bool {
    return isset($_SESSION['user_id']);
}

function currentUser(): ?array {
    if (!isLoggedIn()) {
        return null;
    }

    static $user = null;
    if ($user === null) {
        $stmt = db()->prepare('SELECT id, name, email, role, phone, avatar, is_active FROM users WHERE id = ?');
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch() ?: null;
    }
    return $user;
}

function isAdmin(): bool {
    $user = currentUser();
    return $user && $user['role'] === 'admin';
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        flash('error', 'Please login to continue.');
        redirect(baseUrl('login.php'));
    }
}

function requireAdmin(): void {
    if (!isLoggedIn()) {
        flash('error', 'Please sign in as administrator.');
        redirect(authLoginUrl('admin'));
    }
    if (!isAdmin()) {
        flash('error', 'Access denied. Admin only.');
        redirect(baseUrl('user/dashboard.php'));
    }
}

function requireUser(): void {
    requireLogin();
}

function loginUser(string $phone, ?string $expectedRole = null): array {
    ensureMobileAuthSchema();
    $phone = normalizePhone($phone);

    if ($phone === '') {
        return ['success' => false, 'message' => 'Please enter your mobile number.'];
    }

    if (!validatePhone($phone)) {
        return ['success' => false, 'message' => 'Enter a valid 10-digit mobile number.'];
    }

    $stmt = db()->prepare('SELECT * FROM users WHERE phone = ? AND is_active = 1');
    $stmt->execute([$phone]);
    $user = $stmt->fetch();

    if (!$user) {
        return ['success' => false, 'message' => 'Mobile number not registered or account is inactive.'];
    }

    if ($expectedRole !== null && $user['role'] !== $expectedRole) {
        $label = $expectedRole === 'admin' ? 'administrator' : 'user';
        return ['success' => false, 'message' => "This number is not registered as a {$label}. Use the correct login page."];
    }

    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_role'] = $user['role'];
    $_SESSION['user_name'] = $user['name'];

    return ['success' => true, 'message' => 'Welcome back!'];
}

function registerUser(string $name, string $phone, string $role = 'user', string $email = ''): array {
    ensureMobileAuthSchema();
    $name = trim($name);
    $phone = normalizePhone($phone);
    $emailInput = trim($email);

    if (!in_array($role, ['user', 'admin'], true)) {
        return ['success' => false, 'message' => 'Invalid account type.'];
    }

    if ($name === '' || $phone === '') {
        return ['success' => false, 'message' => 'Please fill in all required fields.'];
    }

    if (!validatePhone($phone)) {
        return ['success' => false, 'message' => 'Enter a valid 10-digit mobile number.'];
    }

    if ($emailInput !== '' && !filter_var($emailInput, FILTER_VALIDATE_EMAIL)) {
        return ['success' => false, 'message' => 'Please enter a valid email address or leave it blank.'];
    }

    $stmt = db()->prepare('SELECT id FROM users WHERE phone = ?');
    $stmt->execute([$phone]);
    if ($stmt->fetch()) {
        return ['success' => false, 'message' => 'This mobile number is already registered.'];
    }

    $storedEmail = resolveStoredEmail($emailInput !== '' ? $emailInput : null, $phone);

    if ($emailInput !== '') {
        $stmt = db()->prepare('SELECT id FROM users WHERE LOWER(email) = ?');
        $stmt->execute([strtolower($emailInput)]);
        if ($stmt->fetch()) {
            return ['success' => false, 'message' => 'This email is already in use.'];
        }
    }

    $stmt = db()->prepare('INSERT INTO users (name, email, password, phone, role) VALUES (?, ?, NULL, ?, ?)');
    $stmt->execute([$name, $storedEmail, $phone, $role]);
    $userId = (int) db()->lastInsertId();

    $stmt = db()->prepare('INSERT INTO reminder_settings (user_id) VALUES (?)');
    $stmt->execute([$userId]);

    $roleLabel = $role === 'admin' ? 'Admin' : 'User';
    return ['success' => true, 'message' => "{$roleLabel} registration successful! Sign in with your mobile number."];
}

function authLoginUrl(string $role = 'user'): string {
    return $role === 'admin' ? baseUrl('admin/login.php') : baseUrl('login.php');
}

function authRegisterUrl(string $role = 'user'): string {
    return $role === 'admin' ? baseUrl('admin/register.php') : baseUrl('register.php');
}

function authDashboardUrl(?array $user = null): string {
    $user = $user ?? currentUser();
    return ($user && $user['role'] === 'admin')
        ? baseUrl('admin/dashboard.php')
        : baseUrl('user/dashboard.php');
}

function logoutUser(): void {
    session_destroy();
    session_start();
}

function ensureDemoAccounts(PDO $pdo): void {
    ensureMobileAuthSchema();
    $demos = [
        ['name' => 'Administrator', 'phone' => DEMO_ADMIN_PHONE, 'role' => 'admin'],
        ['name' => 'Demo User', 'phone' => DEMO_USER_PHONE, 'role' => 'user'],
    ];

    foreach ($demos as $demo) {
        $stmt = $pdo->prepare('SELECT id FROM users WHERE phone = ?');
        $stmt->execute([$demo['phone']]);
        if ($stmt->fetch()) {
            $pdo->prepare('UPDATE users SET name = ?, role = ?, is_active = 1, password = NULL WHERE phone = ?')
                ->execute([$demo['name'], $demo['role'], $demo['phone']]);
            continue;
        }

        $email = placeholderEmailForPhone($demo['phone']);
        $pdo->prepare('INSERT INTO users (name, email, password, phone, role) VALUES (?, ?, NULL, ?, ?)')
            ->execute([$demo['name'], $email, $demo['phone'], $demo['role']]);
        $newId = (int) $pdo->lastInsertId();
        $pdo->prepare('INSERT INTO reminder_settings (user_id) VALUES (?)')->execute([$newId]);
    }
}
