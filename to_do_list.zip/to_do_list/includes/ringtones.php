<?php

function getRingtones(): array {
    return [
        'speech' => ['label' => 'Speak task title', 'icon' => 'fa-comment-dots'],
        'default' => ['label' => 'Classic Bell', 'icon' => 'fa-bell'],
        'chime' => ['label' => 'Soft Chime', 'icon' => 'fa-music'],
        'digital' => ['label' => 'Digital Beep', 'icon' => 'fa-microchip'],
        'alert' => ['label' => 'Urgent Alert', 'icon' => 'fa-triangle-exclamation'],
        'gentle' => ['label' => 'Gentle Tone', 'icon' => 'fa-feather'],
        'melody' => ['label' => 'Happy Melody', 'icon' => 'fa-face-smile'],
        'none' => ['label' => 'No Sound', 'icon' => 'fa-volume-xmark'],
    ];
}

function isBuiltinRingtone(?string $key): bool {
    return $key !== null && array_key_exists($key, getRingtones());
}

function isCustomRingtone(?string $key): bool {
    if (!$key || strpos($key, 'custom:') !== 0) {
        return false;
    }
    $file = substr($key, 7);
    return $file !== '' && preg_match('/^ringtone_[a-zA-Z0-9_\-]+\.(mp3|wav|ogg|m4a)$/i', $file)
        && file_exists(RINGTONE_DIR . $file);
}

function isValidRingtone(?string $key): bool {
    return isBuiltinRingtone($key) || isCustomRingtone($key);
}

function sanitizeRingtone(?string $key): string {
    if (isValidRingtone($key)) {
        return $key;
    }
    return 'speech';
}

function ringtoneLabel(?string $key): string {
    if (isCustomRingtone($key)) {
        $file = substr($key, 7);
        $name = preg_replace('/^ringtone_\d+_\d+_/', '', pathinfo($file, PATHINFO_FILENAME));
        $name = str_replace(['_', '-'], ' ', $name);
        return 'Custom: ' . ucfirst($name ?: 'Audio');
    }
    $tones = getRingtones();
    $key = isBuiltinRingtone($key) ? $key : 'speech';
    return $tones[$key]['label'] ?? 'Speak task title';
}

function ringtonePlayUrl(?string $key): ?string {
    if (!isCustomRingtone($key)) {
        return null;
    }
    return baseUrl(RINGTONE_URL . substr($key, 7));
}

function uploadCustomRingtone(array $file, int $userId): ?string {
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return null;
    }

    $allowed = [
        'audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/x-wav',
        'audio/ogg', 'audio/webm', 'audio/mp4', 'audio/x-m4a',
    ];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowedExt = ['mp3', 'wav', 'ogg', 'm4a', 'webm'];

    if (!in_array($ext, $allowedExt, true)) {
        return null;
    }
    if ($file['size'] > MAX_RINGTONE_SIZE) {
        return null;
    }
    $mimeOk = in_array($file['type'], $allowed, true) || $file['type'] === 'application/octet-stream' || $file['type'] === '';
    if (!$mimeOk && !in_array($ext, ['mp3', 'wav', 'ogg', 'm4a'], true)) {
        return null;
    }

    if (!is_dir(RINGTONE_DIR)) {
        mkdir(RINGTONE_DIR, 0755, true);
    }

    $safeBase = preg_replace('/[^a-zA-Z0-9]/', '_', pathinfo($file['name'], PATHINFO_FILENAME));
    $safeBase = substr($safeBase, 0, 40) ?: 'tone';
    $filename = 'ringtone_' . $userId . '_' . time() . '_' . $safeBase . '.' . $ext;
    $destination = RINGTONE_DIR . $filename;

    if (move_uploaded_file($file['tmp_name'], $destination)) {
        return $filename;
    }
    return null;
}

function deleteCustomRingtoneFile(?string $ringtoneKey): void {
    if (!isCustomRingtone($ringtoneKey)) {
        return;
    }
    $path = RINGTONE_DIR . substr($ringtoneKey, 7);
    if (file_exists($path)) {
        unlink($path);
    }
}

function getUserCustomRingtones(int $userId): array {
    $list = [];
    if (!is_dir(RINGTONE_DIR)) {
        return $list;
    }
    $pattern = RINGTONE_DIR . 'ringtone_' . $userId . '_*';
    foreach (glob($pattern) as $path) {
        if (!is_file($path)) {
            continue;
        }
        $file = basename($path);
        $key = 'custom:' . $file;
        $list[$key] = [
            'label' => ringtoneLabel($key),
            'url' => baseUrl(RINGTONE_URL . $file),
            'file' => $file,
        ];
    }
    return $list;
}

function processTaskRingtoneFromRequest(int $userId, ?string $currentRingtone = null): string {
    if (!empty($_FILES['custom_ringtone']['name']) && $_FILES['custom_ringtone']['error'] !== UPLOAD_ERR_NO_FILE) {
        $filename = uploadCustomRingtone($_FILES['custom_ringtone'], $userId);
        if ($filename) {
            if ($currentRingtone && isCustomRingtone($currentRingtone)) {
                deleteCustomRingtoneFile($currentRingtone);
            }
            return 'custom:' . $filename;
        }
        return $currentRingtone ? sanitizeRingtone($currentRingtone) : 'default';
    }

    $selected = $_POST['ringtone'] ?? ($currentRingtone ?? 'speech');
    return sanitizeRingtone($selected);
}

function taskVibrateFromRequest(?array $source = null): int {
    $source = $source ?? $_POST;
    return !empty($source['vibrate']) ? 1 : 0;
}

function sanitizeSpeechVoice(?string $voice): ?string {
    $voice = trim($voice ?? '');
    if ($voice === '') {
        return null;
    }
    return mb_substr($voice, 0, 255);
}

function speechVoiceFromRequest(?array $source = null, ?string $ringtone = null): ?string {
    $source = $source ?? $_POST;
    $ringtone = $ringtone ?? ($source['ringtone'] ?? 'speech');
    if (sanitizeRingtone($ringtone) !== 'speech') {
        return null;
    }
    return sanitizeSpeechVoice($source['speech_voice'] ?? null);
}

/** Extract related task id from a notification row. */
function resolveTaskIdFromNotification(array $notif): ?int {
    if (!empty($notif['link']) && preg_match('/[?&](?:id|task)=(\d+)/', $notif['link'], $m)) {
        return (int) $m[1];
    }
    if (!empty($notif['message']) && preg_match('/task #(\d+)/i', $notif['message'], $m)) {
        return (int) $m[1];
    }
    return null;
}

/**
 * Ringtone + speech payload for browser alert (uses task's selected ringtone when linked).
 * @return array{title: string, message: string, link: ?string, ringtone: string, vibrate: int, custom_url: string, speech_text: string}
 */
function notificationAlertPayload(array $notif): array {
    $title = $notif['title'] ?? '';
    $message = $notif['message'] ?? '';
    $link = $notif['link'] ?? null;
    $ringtone = 'default';
    $vibrate = 1;
    $customUrl = '';
    $speechText = '';

    $speechVoice = null;

    $taskId = resolveTaskIdFromNotification($notif);
    if ($taskId) {
        $stmt = db()->prepare('SELECT title, ringtone, speech_voice, vibrate FROM tasks WHERE id = ?');
        $stmt->execute([$taskId]);
        $task = $stmt->fetch();
        if ($task) {
            $ringtone = sanitizeRingtone($task['ringtone']);
            $vibrate = (int) $task['vibrate'];
            $customUrl = ringtonePlayUrl($ringtone) ?? '';
            $speechText = $task['title'];
            $speechVoice = $task['speech_voice'] ?? null;
        }
    } elseif (in_array($notif['type'] ?? '', ['assignment', 'reminder', 'status'], true)) {
        if (preg_match('/"([^"]+)"/u', $message, $m)) {
            $speechText = $m[1];
        } elseif (preg_match('/assigned:\s*(.+)$/u', $message, $m)) {
            $speechText = trim($m[1]);
        }
        if ($speechText !== '') {
            $ringtone = 'speech';
        }
    }

    return [
        'title' => $title,
        'message' => $message,
        'link' => $link,
        'ringtone' => $ringtone,
        'vibrate' => $vibrate,
        'custom_url' => $customUrl,
        'speech_text' => $speechText,
        'speech_voice' => $speechVoice,
    ];
}

function formatNotificationAlertForClient(array $notif): array {
    $alert = notificationAlertPayload($notif);
    $alert['id'] = (int) ($notif['id'] ?? 0);
    $alert['type'] = $notif['type'] ?? 'info';
    return $alert;
}
