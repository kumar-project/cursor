<?php
require_once __DIR__ . '/config.php';

class Database {
    private static ?PDO $instance = null;

    public static function getConnection(): PDO {
        if (self::$instance === null) {
            try {
                $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
                self::$instance = new PDO($dsn, DB_USER, DB_PASS, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]);
                self::syncDbTimezone(self::$instance);
            } catch (PDOException $e) {
                die('Database connection failed. Please import database.sql and check config.php');
            }
        }
        return self::$instance;
    }

    /** Keep MySQL NOW() aligned with PHP app timezone. */
    private static function syncDbTimezone(PDO $pdo): void {
        try {
            $offset = (new DateTime('now'))->format('P');
            $pdo->exec("SET time_zone = " . $pdo->quote($offset));
        } catch (PDOException $e) {
            // Non-fatal if MySQL timezone tables are missing
        }
    }
}

function db(): PDO {
    return Database::getConnection();
}
