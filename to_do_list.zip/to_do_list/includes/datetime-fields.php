<?php
/** @var array $dtDefaults from defaultTaskDateTimes() */
$dtDefaults = $dtDefaults ?? defaultTaskDateTimes();
$selHour = taskDateTimeValue('scheduled_hour', $dtDefaults);
$selMinute = taskDateTimeValue('scheduled_minute', $dtDefaults);
$selAmpm = taskDateTimeValue('scheduled_ampm', $dtDefaults);
if ($selAmpm !== 'AM' && $selAmpm !== 'PM') {
    $selAmpm = 'AM';
}
?>
<div class="datetime-section">
    <h3 class="datetime-section-title">Scheduled</h3>
    <p class="text-muted" style="font-size:.85rem;margin:0 0 .75rem;">
        When this task is due — voice reminder and alert run at this date and time.
    </p>
    <div class="datetime-row">
        <div class="form-group">
            <label for="scheduled_date">Scheduled date *</label>
            <input type="date" id="scheduled_date" name="scheduled_date" class="form-control" required
                   value="<?= taskDateTimeValue('scheduled_date', $dtDefaults) ?>">
        </div>
        <div class="form-group">
            <label>Scheduled time *</label>
            <div class="time-12-picker" role="group" aria-label="Scheduled time">
                <select id="scheduled_hour" name="scheduled_hour" class="form-control time-12-hour" required aria-label="Hour">
                    <?php for ($h = 1; $h <= 12; $h++): ?>
                    <option value="<?= $h ?>" <?= (string) $selHour === (string) $h ? 'selected' : '' ?>><?= $h ?></option>
                    <?php endfor; ?>
                </select>
                <span class="time-12-sep" aria-hidden="true">:</span>
                <select id="scheduled_minute" name="scheduled_minute" class="form-control time-12-minute" required aria-label="Minute">
                    <?php for ($m = 0; $m < 60; $m++): ?>
                    <?php $mv = sprintf('%02d', $m); ?>
                    <option value="<?= $mv ?>" <?= $selMinute === $mv ? 'selected' : '' ?>><?= $mv ?></option>
                    <?php endfor; ?>
                </select>
                <select id="scheduled_ampm" name="scheduled_ampm" class="form-control time-12-ampm" required aria-label="AM or PM">
                    <option value="AM" <?= $selAmpm === 'AM' ? 'selected' : '' ?>>AM</option>
                    <option value="PM" <?= $selAmpm === 'PM' ? 'selected' : '' ?>>PM</option>
                </select>
            </div>
        </div>
    </div>
</div>
