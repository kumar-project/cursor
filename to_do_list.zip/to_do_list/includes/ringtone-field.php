<?php
/** @var string $selectedRingtone */
/** @var int $vibrateEnabled */
$selectedRingtone = $selectedRingtone ?? 'speech';
if (!isValidRingtone($selectedRingtone)) {
    $selectedRingtone = 'speech';
}
$vibrateEnabled = isset($vibrateEnabled) ? (int)$vibrateEnabled : 1;
$tones = getRingtones();
$user = currentUser();
$customTones = $user ? getUserCustomRingtones((int)$user['id']) : [];
$customUrl = isCustomRingtone($selectedRingtone) ? ringtonePlayUrl($selectedRingtone) : '';
$previewTaskTitle = $previewTaskTitle ?? trim($_POST['title'] ?? '');
$selectedSpeechVoice = $selectedSpeechVoice ?? sanitizeSpeechVoice($_POST['speech_voice'] ?? null) ?? '';
$showSpeechVoice = ($selectedRingtone === 'speech');
?>
<div class="form-group ringtone-section">
    <label>Task Ringtone & Alert</label>
    <p class="text-muted" style="font-size:.85rem;margin-bottom:.75rem;">
        <strong>Speak task title</strong> reads your task name aloud at the <strong>scheduled date &amp; time</strong>. Keep this app open in your browser for reminders. Upload custom audio (MP3, WAV, OGG, M4A — max 5MB).
    </p>

    <label class="assignee-item" style="margin-bottom:.75rem;">
        <input type="checkbox" name="vibrate" value="1" id="taskVibrate" <?= $vibrateEnabled ? 'checked' : '' ?>>
        <i class="fa-solid fa-mobile-screen-button"></i> Vibrate on reminder (phones & supported devices)
    </label>

    <div class="form-group" style="margin-bottom:.75rem;">
        <label for="ringtone">Built-in ringtone</label>
        <div class="ringtone-picker">
            <select id="ringtone" name="ringtone" class="form-control ringtone-select">
                <?php foreach ($tones as $key => $tone): ?>
                <option value="<?= sanitize($key) ?>" <?= $selectedRingtone === $key ? 'selected' : '' ?>>
                    <?= sanitize($tone['label']) ?>
                </option>
                <?php endforeach; ?>
                <?php foreach ($customTones as $key => $custom): ?>
                <option value="<?= sanitize($key) ?>" data-url="<?= sanitize($custom['url']) ?>"
                    <?= $selectedRingtone === $key ? 'selected' : '' ?>>
                    <?= sanitize($custom['label']) ?>
                </option>
                <?php endforeach; ?>
            </select>
            <button type="button" class="btn btn-outline ringtone-preview-btn" id="ringtonePreview" title="Preview ringtone"
                    data-task-title="<?= sanitize($previewTaskTitle) ?>">
                <i class="fa-solid fa-play"></i> Preview
            </button>
        </div>
        <p id="ringtonePreviewHint" class="text-muted" style="font-size:.8rem;margin-top:.45rem;<?= !$showSpeechVoice ? 'display:none;' : '' ?>">
            Preview speaks the <strong>Task Title</strong> using the voice you select below.
        </p>
    </div>

    <div class="form-group speech-voice-picker" id="speechVoicePicker" style="<?= $showSpeechVoice ? '' : 'display:none;' ?>">
        <label for="speech_voice"><i class="fa-solid fa-microphone-lines"></i> Speech voice</label>
        <p class="text-muted" style="font-size:.8rem;margin:0 0 .5rem;">
            Choose a voice — list comes from your browser/device. Click Preview to hear your task title.
        </p>
        <div class="speech-voice-row">
            <select id="speech_voice" name="speech_voice" class="form-control speech-voice-select"
                    data-selected="<?= sanitize($selectedSpeechVoice) ?>">
                <option value="">Loading voices…</option>
            </select>
            <button type="button" class="btn btn-outline btn-sm" id="speechVoicePreviewBtn" title="Preview selected voice">
                <i class="fa-solid fa-volume-high"></i> Preview voice
            </button>
        </div>
        <p id="speechVoiceCount" class="text-muted" style="font-size:.75rem;margin-top:.35rem;"></p>
    </div>

    <div class="form-group custom-ringtone-upload">
        <label for="custom_ringtone"><i class="fa-solid fa-upload"></i> Upload custom ringtone</label>
        <input type="file" id="custom_ringtone" name="custom_ringtone" class="form-control"
               accept="audio/mpeg,audio/mp3,audio/wav,audio/ogg,audio/mp4,.mp3,.wav,.ogg,.m4a">
        <p class="text-muted" style="font-size:.8rem;margin-top:.35rem;">
            Uploading a file uses it for this task (overrides built-in selection above).
        </p>
        <?php if ($customUrl): ?>
        <p class="mt-1" style="font-size:.85rem;">
            Current custom: <strong><?= ringtoneLabel($selectedRingtone) ?></strong>
            <audio controls preload="none" style="max-width:100%;margin-top:.5rem;display:block;">
                <source src="<?= sanitize($customUrl) ?>">
            </audio>
        </p>
        <?php endif; ?>
    </div>
</div>
