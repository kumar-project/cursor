            </div>
        </main>
    </div>

    <script src="<?= assetUrl('js/app.js') ?>"></script>
    <?php if (!empty($extraJs)): foreach ((array)$extraJs as $js): ?>
    <script src="<?= $js ?>"></script>
    <?php endforeach; endif; ?>
    <?php if (!empty($user)): ?>
    <script>
        window.APP_BASE = '<?= baseUrl() ?>';
        window.CURRENT_USER_ID = <?= (int)$user['id'] ?>;
    </script>
    <script src="<?= assetUrl('js/ringtones.js') ?>"></script>
    <script src="<?= assetUrl('js/notifications.js') ?>"></script>
    <?php endif; ?>
</body>
</html>
