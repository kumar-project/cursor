<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/ringtones.php';

function sanitize(string $input): string {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/** Strip to digits; keep last 10 for Indian numbers (optional +91 / 0 prefix). */
function normalizePhone(string $phone): string {
    $digits = preg_replace('/\D/', '', $phone);
    if (strlen($digits) > 10) {
        $digits = substr($digits, -10);
    }
    return $digits;
}

function validatePhone(string $phone): bool {
    return (bool) preg_match('/^[6-9]\d{9}$/', $phone);
}

function formatPhone(?string $phone): string {
    if (!$phone) {
        return '-';
    }
    $p = normalizePhone($phone);
    if (strlen($p) === 10) {
        return '+91 ' . substr($p, 0, 5) . ' ' . substr($p, 5);
    }
    return $phone;
}

function redirect(string $url): void {
    header('Location: ' . $url);
    exit;
}

function flash(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash(): ?array {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function formatDate(?string $date, string $format = 'M d, Y'): string {
    if (!$date) return '-';
    return date($format, strtotime($date));
}

function formatDateTime(?string $datetime, string $format = 'M d, Y h:i A'): string {
    if (!$datetime) return '-';
    return date($format, strtotime($datetime));
}

function priorityBadge(string $priority): string {
    $classes = ['low' => 'badge-low', 'medium' => 'badge-medium', 'high' => 'badge-high'];
    return '<span class="badge ' . ($classes[$priority] ?? '') . '">' . ucfirst($priority) . '</span>';
}

function statusBadge(string $status): string {
    $classes = [
        'pending' => 'badge-pending',
        'in_progress' => 'badge-progress',
        'completed' => 'badge-completed',
        'cancelled' => 'badge-cancelled',
    ];
    $label = str_replace('_', ' ', $status);
    return '<span class="badge ' . ($classes[$status] ?? '') . '">' . ucfirst($label) . '</span>';
}

function createNotification(int $userId, string $title, string $message, string $type = 'info', ?string $link = null, ?int $taskId = null): void {
    if ($taskId !== null && ($link === null || $link === '')) {
        $link = baseUrl('user/edit-task.php?id=' . $taskId);
    }
    $stmt = db()->prepare('INSERT INTO notifications (user_id, title, message, type, link) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$userId, $title, $message, $type, $link]);
}

function getUnreadNotificationCount(int $userId): int {
    $stmt = db()->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0');
    $stmt->execute([$userId]);
    return (int) $stmt->fetchColumn();
}

function baseUrl(string $path = ''): string {
    static $base = null;
    if ($base === null) {
        $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
        if (preg_match('#/(admin|user|api)/#', $script)) {
            $base = dirname(dirname($script));
        } else {
            $base = dirname($script);
        }
        $base = rtrim($base, '/');
        if ($base === '' || $base === '.') {
            $base = '';
        }
    }
    $url = $base . ($path ? '/' . ltrim(str_replace('\\', '/', $path), '/') : '');
    return $url ?: '/';
}

function assetUrl(string $path): string {
    return baseUrl('assets/' . ltrim($path, '/'));
}

function uploadAvatar(array $file): ?string {
    if ($file['error'] !== UPLOAD_ERR_OK) return null;

    $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!in_array($file['type'], $allowed) || $file['size'] > MAX_UPLOAD_SIZE) {
        return null;
    }

    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0755, true);
    }

    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'avatar_' . uniqid() . '.' . $ext;
    $destination = UPLOAD_DIR . $filename;

    if (move_uploaded_file($file['tmp_name'], $destination)) {
        return $filename;
    }
    return null;
}

function avatarUrl(?string $avatar): string {
    if ($avatar && file_exists(UPLOAD_DIR . $avatar)) {
        return baseUrl(UPLOAD_URL . $avatar);
    }
    return 'https://ui-avatars.com/api/?name=User&background=4f46e5&color=fff&size=128';
}

function fontAwesomeCss(): string {
    return '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">';
}

function icon(string $name, string $extraClass = ''): string {
    $map = [
        'logo' => 'fa-calendar-days',
        'dashboard' => 'fa-chart-pie',
        'users' => 'fa-users',
        'schedules' => 'fa-clipboard-list',
        'tasks' => 'fa-list-check',
        'calendar' => 'fa-calendar',
        'notifications' => 'fa-bell',
        'reports' => 'fa-chart-column',
        'profile' => 'fa-user',
        'logout' => 'fa-right-from-bracket',
        'mobile' => 'fa-mobile-screen-button',
        'tasks-empty' => 'fa-clipboard-check',
        'schedules-empty' => 'fa-clipboard-list',
        'bell-empty' => 'fa-bell-slash',
        'chevron-down' => 'fa-chevron-down',
        'chevron-right' => 'fa-chevron-right',
        'lock' => 'fa-lock',
        'close' => 'fa-xmark',
        'check' => 'fa-circle-check',
        'edit' => 'fa-pen-to-square',
    ];
    $fa = $map[$name] ?? 'fa-circle';
    $class = trim('fa-solid ' . $fa . ' ' . $extraClass);
    return '<i class="' . $class . '" aria-hidden="true"></i>';
}

function combineDateTime(string $date, string $time): string {
    $date = trim($date);
    $time = trim($time);
    if ($date === '' || $time === '') {
        return '';
    }
    if (strlen($time) === 5) {
        $time .= ':00';
    }
    return $date . ' ' . $time;
}

/** @return array{hour: string, minute: string, ampm: string} */
function time12hFormFields(?string $datetime = null): array {
    if (!$datetime) {
        $ts = time();
    } else {
        $ts = strtotime($datetime);
        if ($ts === false) {
            $ts = time();
        }
    }
    return [
        'hour' => (string) (int) date('g', $ts),
        'minute' => date('i', $ts),
        'ampm' => date('A', $ts),
    ];
}

function combineScheduledDateTime(string $date, string $hour, string $minute, string $ampm): string {
    $date = trim($date);
    $hour = (int) trim($hour);
    $minute = (int) trim($minute);
    $ampm = strtoupper(trim($ampm));

    if ($date === '' || $hour < 1 || $hour > 12 || $minute < 0 || $minute > 59) {
        return '';
    }
    if ($ampm !== 'AM' && $ampm !== 'PM') {
        return '';
    }

    if ($ampm === 'PM' && $hour !== 12) {
        $hour += 12;
    } elseif ($ampm === 'AM' && $hour === 12) {
        $hour = 0;
    }

    return combineDateTime($date, sprintf('%02d:%02d', $hour, $minute));
}

function parseDateTimeField(string $prefix, array $source = null): array {
    $source = $source ?? $_POST;
    return [
        'date' => trim($source[$prefix . '_date'] ?? ''),
        'time' => trim($source[$prefix . '_time'] ?? ''),
        'datetime' => combineDateTime(
            $source[$prefix . '_date'] ?? '',
            $source[$prefix . '_time'] ?? ''
        ),
    ];
}

/** Minutes added to scheduled time for calendar display (internal end_datetime). */
define('TASK_SCHEDULED_DURATION_MINUTES', 30);

function defaultTaskDateTimes(): array {
    $time = time12hFormFields();
    return [
        'scheduled_date' => date('Y-m-d'),
        'scheduled_hour' => $time['hour'],
        'scheduled_minute' => $time['minute'],
        'scheduled_ampm' => $time['ampm'],
    ];
}

/**
 * Build start/end datetimes from scheduled date + time form fields.
 * @return array{scheduled: string, start: string, end: string}
 */
function parseScheduledFromRequest(?array $source = null): array {
    $source = $source ?? $_POST;
    $date = trim($source['scheduled_date'] ?? '');

    if ($date !== '' && isset($source['scheduled_hour'], $source['scheduled_ampm'])) {
        $scheduled = combineScheduledDateTime(
            $date,
            (string) ($source['scheduled_hour'] ?? ''),
            (string) ($source['scheduled_minute'] ?? '00'),
            (string) ($source['scheduled_ampm'] ?? '')
        );
    } else {
        $scheduled = combineDateTime($date, $source['scheduled_time'] ?? '');
    }

    if ($scheduled === '') {
        return ['scheduled' => '', 'start' => '', 'end' => ''];
    }
    $end = date('Y-m-d H:i:s', strtotime($scheduled . ' +' . TASK_SCHEDULED_DURATION_MINUTES . ' minutes'));
    return ['scheduled' => $scheduled, 'start' => $scheduled, 'end' => $end];
}

function formatTaskScheduled(?string $startDatetime): string {
    if (!$startDatetime) {
        return '-';
    }
    return formatDateTime($startDatetime);
}

function taskDateTimeValue(string $field, array $defaults): string {
    if (isset($_POST[$field]) && $_POST[$field] !== '') {
        return sanitize($_POST[$field]);
    }
    return sanitize($defaults[$field] ?? '');
}

function dateTimeToFormFields(?string $datetime): array {
    if (!$datetime) {
        return ['date' => date('Y-m-d'), 'time' => '09:00'];
    }
    $ts = strtotime($datetime);
    return ['date' => date('Y-m-d', $ts), 'time' => date('H:i', $ts)];
}

function taskToDateTimeDefaults(array $task): array {
    $date = dateTimeToFormFields($task['start_datetime'] ?? null);
    $time = time12hFormFields($task['start_datetime'] ?? null);
    return [
        'scheduled_date' => $date['date'],
        'scheduled_hour' => $time['hour'],
        'scheduled_minute' => $time['minute'],
        'scheduled_ampm' => $time['ampm'],
    ];
}

function getUserAssignedTask(PDO $pdo, int $taskId, int $userId): ?array {
    $stmt = $pdo->prepare('
        SELECT t.* FROM tasks t
        INNER JOIN task_assignments ta ON t.id = ta.task_id
        WHERE t.id = ? AND ta.user_id = ?
    ');
    $stmt->execute([$taskId, $userId]);
    return $stmt->fetch() ?: null;
}

function notifIcon(string $type, string $extraClass = ''): string {
    $map = [
        'info' => 'fa-circle-info',
        'reminder' => 'fa-clock',
        'assignment' => 'fa-thumbtack',
        'status' => 'fa-arrows-rotate',
        'system' => 'fa-bullhorn',
    ];
    $fa = $map[$type] ?? 'fa-circle-info';
    $class = trim('fa-solid ' . $fa . ' ' . $extraClass);
    return '<i class="' . $class . '" aria-hidden="true"></i>';
}
