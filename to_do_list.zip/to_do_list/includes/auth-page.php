<?php
/**
 * Shared login / register UI. Set $authRole to 'user' or 'admin' before including.
 */
if (!isset($authRole) || !in_array($authRole, ['user', 'admin'], true)) {
    $authRole = 'user';
}

function authPageHead(string $title): void {
    ?>
<!DOCTYPE html>
<html lang="en-IN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($title) ?> - <?= APP_NAME ?></title>
    <?= fontAwesomeCss() ?>
    <link rel="stylesheet" href="<?= assetUrl('css/style.css') ?>">
</head>
<body>
    <?php
}

function authPageFoot(): void {
    ?>
</body>
</html>
    <?php
}

function authRoleSwitcher(string $authRole, string $page): void {
    $isAdmin = $authRole === 'admin';
    $userUrl = $page === 'login' ? authLoginUrl('user') : authRegisterUrl('user');
    $adminUrl = $page === 'login' ? authLoginUrl('admin') : authRegisterUrl('admin');
    ?>
<div class="auth-role-tabs" role="tablist">
    <a href="<?= $userUrl ?>" class="auth-role-tab<?= !$isAdmin ? ' active' : '' ?>" role="tab">User</a>
    <a href="<?= $adminUrl ?>" class="auth-role-tab<?= $isAdmin ? ' active' : '' ?>" role="tab">Admin</a>
</div>
    <?php
}
