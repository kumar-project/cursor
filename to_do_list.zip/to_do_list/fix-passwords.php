<?php
header('Location: fix-demo-accounts.php');
exit;
