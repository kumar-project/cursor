<?php
/**
 * Reset demo accounts for mobile login (run once if login fails).
 * Delete this file after use.
 */
require_once __DIR__ . '/includes/auth.php';

$messages = [];
$success = false;

try {
  ensureDemoAccounts(db());
    $messages[] = 'Demo accounts ready for mobile login.';
    $messages[] = 'Admin mobile: ' . DEMO_ADMIN_PHONE;
    $messages[] = 'User mobile: ' . DEMO_USER_PHONE;
    $success = true;
} catch (Exception $e) {
    $messages[] = 'Error: ' . $e->getMessage();
    $messages[] = 'Run install.php or import database.sql first.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fix Demo Accounts - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="auth-main">
    <div class="auth-container">
        <div class="auth-card">
            <h2 class="text-center mb-2">Reset Demo Accounts</h2>
            <?php foreach ($messages as $msg): ?>
            <div class="alert alert-<?= $success ? 'success' : 'error' ?>"><?= htmlspecialchars($msg) ?></div>
            <?php endforeach; ?>
            <?php if ($success): ?>
            <a href="login.php" class="btn btn-primary btn-block">User Login</a>
            <a href="admin/login.php" class="btn btn-outline btn-block" style="margin-top:.5rem;">Admin Login</a>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>
