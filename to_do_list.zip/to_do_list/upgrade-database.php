<?php
/**
 * Safe one-click database upgrade for existing installations.
 * Open in browser: http://localhost/to%20do%20list/upgrade-database.php
 */
require_once __DIR__ . '/includes/db.php';

$messages = [];
$ok = true;

function columnExists(PDO $pdo, string $table, string $column): bool {
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.columns
         WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?'
    );
    $stmt->execute([$table, $column]);
    return (int) $stmt->fetchColumn() > 0;
}

function indexExists(PDO $pdo, string $table, string $index): bool {
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.statistics
         WHERE table_schema = DATABASE() AND table_name = ? AND index_name = ?'
    );
    $stmt->execute([$table, $index]);
    return (int) $stmt->fetchColumn() > 0;
}

try {
    $pdo = db();

    if (!is_dir(RINGTONE_DIR)) {
        mkdir(RINGTONE_DIR, 0755, true);
        $messages[] = 'Created ringtones upload folder.';
    }

    foreach ([
        'ALTER TABLE users MODIFY email VARCHAR(150) DEFAULT NULL',
        'ALTER TABLE users MODIFY password VARCHAR(255) DEFAULT NULL',
    ] as $sql) {
        try {
            $pdo->exec($sql);
        } catch (PDOException $e) {
        }
    }

    $pdo->exec("UPDATE users SET phone = '9999999999' WHERE (phone IS NULL OR phone = '') AND role = 'admin' LIMIT 1");
    $pdo->exec("UPDATE users SET phone = '8888888888' WHERE (phone IS NULL OR phone = '') AND role = 'user' LIMIT 1");
    $pdo->exec("UPDATE users SET phone = CONCAT('9', LPAD(id, 9, '0')) WHERE phone IS NULL OR phone = ''");

    try {
        $pdo->exec('ALTER TABLE users MODIFY phone VARCHAR(15) NOT NULL');
    } catch (PDOException $e) {
    }

    $pdo->exec("UPDATE users SET phone = '9999999999', email = NULL, password = NULL, role = 'admin'
        WHERE email = 'admin@scheduler.com' OR (role = 'admin' AND (phone IS NULL OR phone = '')) LIMIT 1");
    $pdo->exec("UPDATE users SET phone = '8888888888', email = NULL, password = NULL, role = 'user'
        WHERE email = 'user@scheduler.com' LIMIT 1");

    if (!indexExists($pdo, 'users', 'uk_users_phone')) {
        try {
            $pdo->exec('ALTER TABLE users ADD UNIQUE KEY uk_users_phone (phone)');
            $messages[] = 'Added unique mobile number index on users.';
        } catch (PDOException $e) {
            $messages[] = 'Could not add phone unique index (check for duplicate phone numbers).';
        }
    } else {
        $messages[] = 'Mobile login schema already up to date.';
    }

    if (!columnExists($pdo, 'tasks', 'ringtone')) {
        $pdo->exec("ALTER TABLE tasks ADD COLUMN ringtone VARCHAR(120) NOT NULL DEFAULT 'speech' AFTER status");
        $messages[] = 'Added ringtone column.';
    } else {
        $pdo->exec("ALTER TABLE tasks MODIFY COLUMN ringtone VARCHAR(120) NOT NULL DEFAULT 'speech'");
        $messages[] = 'Ringtone column OK.';
    }

    if (!columnExists($pdo, 'tasks', 'speech_voice')) {
        $pdo->exec('ALTER TABLE tasks ADD COLUMN speech_voice VARCHAR(255) DEFAULT NULL AFTER ringtone');
        $messages[] = 'Added speech_voice column.';
    } else {
        $messages[] = 'Speech voice column already exists.';
    }

    if (!columnExists($pdo, 'tasks', 'vibrate')) {
        $after = columnExists($pdo, 'tasks', 'speech_voice') ? 'speech_voice' : 'ringtone';
        $pdo->exec("ALTER TABLE tasks ADD COLUMN vibrate TINYINT(1) NOT NULL DEFAULT 1 AFTER {$after}");
        $messages[] = 'Added vibrate column.';
    } else {
        $messages[] = 'Vibrate column already exists.';
    }

    $pdo->exec("INSERT INTO users (name, email, password, role, phone)
        SELECT 'Administrator', NULL, NULL, 'admin', '9999999999 FROM DUAL
        WHERE NOT EXISTS (SELECT 1 FROM users WHERE phone = '9999999999')");
    $pdo->exec("INSERT INTO users (name, email, password, role, phone)
        SELECT 'Demo User', NULL, NULL, 'user', '8888888888' FROM DUAL
        WHERE NOT EXISTS (SELECT 1 FROM users WHERE phone = '8888888888')");

    $pdo->exec('INSERT INTO reminder_settings (user_id, email_reminders, browser_reminders, reminder_minutes)
        SELECT u.id, 1, 1, 30 FROM users u
        LEFT JOIN reminder_settings rs ON rs.user_id = u.id
        WHERE rs.user_id IS NULL');

    $messages[] = 'Upgrade complete. Your existing data was kept.';
} catch (Exception $e) {
    $ok = false;
    $messages[] = 'Error: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Upgrade</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="auth-main">
    <div class="auth-container">
        <div class="auth-card">
            <h2 class="text-center mb-2">Database Upgrade</h2>
            <p class="text-muted text-center" style="font-size:.9rem;margin-bottom:1rem;">
                Use this for an <strong>existing</strong> database. Do not import <code>database.sql</code> again.
            </p>
            <?php foreach ($messages as $msg): ?>
            <div class="alert alert-<?= $ok ? 'success' : 'error' ?>"><?= htmlspecialchars($msg) ?></div>
            <?php endforeach; ?>
            <a href="login.php" class="btn btn-primary btn-block">Go to Login</a>
        </div>
    </div>
</div>
</body>
</html>
