/**
 * Task ringtones — speech (task title), built-in Web Audio, custom files, vibration
 */
window.SchedulerRingtones = (function () {
    var audioCtx = null;
    var customAudio = null;

    var vibratePatterns = {
        speech: [150, 80, 150, 80, 200],
        default: [200, 100, 200],
        chime: [100, 80, 100, 80, 200],
        digital: [80, 50, 80, 50, 80, 50, 150],
        alert: [300, 100, 300, 100, 300, 100, 300],
        gentle: [150, 100, 150],
        melody: [100, 50, 100, 50, 100, 50, 250],
        custom: [200, 120, 200, 120, 250]
    };

    function getContext() {
        if (!audioCtx) {
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        }
        if (audioCtx.state === 'suspended') {
            audioCtx.resume();
        }
        return audioCtx;
    }

    function vibrate(key, enabled) {
        if (!enabled || !navigator.vibrate) return;
        var pattern = vibratePatterns.custom;
        if (key && key.indexOf('custom:') !== 0 && vibratePatterns[key]) {
            pattern = vibratePatterns[key];
        }
        try {
            navigator.vibrate(pattern);
        } catch (e) {}
    }

    function tone(freq, start, duration, type, volume) {
        var ctx = getContext();
        var osc = ctx.createOscillator();
        var gain = ctx.createGain();
        osc.type = type || 'sine';
        osc.frequency.value = freq;
        gain.gain.setValueAtTime(volume || 0.25, start);
        gain.gain.exponentialRampToValueAtTime(0.001, start + duration);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(start);
        osc.stop(start + duration + 0.05);
    }

    var patterns = {
        default: function (t) {
            tone(880, t, 0.35);
            tone(1100, t + 0.12, 0.35);
        },
        chime: function (t) {
            [523, 659, 784, 1047].forEach(function (f, i) {
                tone(f, t + i * 0.18, 0.4, 'sine', 0.2);
            });
        },
        digital: function (t) {
            [1200, 900, 1200, 900].forEach(function (f, i) {
                tone(f, t + i * 0.12, 0.08, 'square', 0.15);
            });
        },
        alert: function (t) {
            for (var i = 0; i < 5; i++) {
                tone(1400, t + i * 0.15, 0.1, 'square', 0.22);
            }
        },
        gentle: function (t) {
            tone(440, t, 0.6, 'sine', 0.18);
            tone(554, t + 0.35, 0.6, 'sine', 0.15);
        },
        melody: function (t) {
            [392, 494, 587, 698, 784].forEach(function (f, i) {
                tone(f, t + i * 0.14, 0.22, 'triangle', 0.2);
            });
        },
        none: function () {},
        speech: function () {}
    };

    function playBuiltin(key) {
        if (key === 'speech') return;
        var fn = patterns[key] || patterns.default;
        fn(getContext().currentTime);
    }

    function getTaskTitleFromPage() {
        var el = document.getElementById('title') || document.querySelector('input[name="title"]');
        if (el && el.value && el.value.trim()) {
            return el.value.trim();
        }
        var hidden = document.getElementById('task_title_preview');
        if (hidden && hidden.value && hidden.value.trim()) {
            return hidden.value.trim();
        }
        var previewBtn = document.getElementById('ringtonePreview');
        if (previewBtn && previewBtn.getAttribute('data-task-title')) {
            return previewBtn.getAttribute('data-task-title').trim();
        }
        return '';
    }

    function resolveSpeechVoice(voiceUri) {
        if (!window.speechSynthesis) return null;
        var voices = window.speechSynthesis.getVoices();
        if (!voiceUri) return pickSpeechVoice();

        var exact = voices.find(function (v) { return v.voiceURI === voiceUri; });
        if (exact) return exact;

        var byName = voices.find(function (v) { return v.name === voiceUri; });
        if (byName) return byName;

        return pickSpeechVoice();
    }

    function getSelectedSpeechVoiceUri() {
        var sel = document.getElementById('speech_voice');
        return sel && sel.value ? sel.value : '';
    }

    function voiceGroupLabel(v) {
        var l = (v.lang || '').toLowerCase().replace('_', '-');
        if (l.indexOf('en-in') === 0) return 'Indian English';
        if (l.indexOf('hi') === 0) return 'Hindi';
        if (l.indexOf('en-gb') === 0) return 'English (UK)';
        if (l.indexOf('en-us') === 0) return 'English (US)';
        if (l.indexOf('en-au') === 0) return 'English (Australia)';
        if (l.indexOf('en') === 0) return 'English (Other)';
        if (l.indexOf('ta') === 0) return 'Tamil';
        if (l.indexOf('te') === 0) return 'Telugu';
        if (l.indexOf('mr') === 0) return 'Marathi';
        if (l.indexOf('bn') === 0) return 'Bengali';
        return 'Other languages';
    }

    function voiceOptionLabel(v) {
        var lang = (v.lang || '').replace('_', '-');
        return v.name + ' (' + lang + ')';
    }

    function populateSpeechVoiceSelect() {
        var select = document.getElementById('speech_voice');
        if (!select || !window.speechSynthesis) return;

        var voices = window.speechSynthesis.getVoices();
        var selected = select.getAttribute('data-selected') || '';
        var countEl = document.getElementById('speechVoiceCount');

        select.innerHTML = '';
        var autoOpt = document.createElement('option');
        autoOpt.value = '';
        autoOpt.textContent = 'Auto — best Indian English voice';
        select.appendChild(autoOpt);

        if (!voices.length) {
            autoOpt.textContent = 'No voices found — using browser default';
            if (countEl) countEl.textContent = '';
            return;
        }

        var groups = {};
        voices.forEach(function (v) {
            var g = voiceGroupLabel(v);
            if (!groups[g]) groups[g] = [];
            groups[g].push(v);
        });

        var order = ['Indian English', 'Hindi', 'English (UK)', 'English (US)', 'English (Australia)', 'English (Other)', 'Tamil', 'Telugu', 'Marathi', 'Bengali', 'Other languages'];
        order.forEach(function (g) {
            if (!groups[g] || !groups[g].length) return;
            var og = document.createElement('optgroup');
            og.label = g;
            groups[g].sort(function (a, b) { return a.name.localeCompare(b.name); });
            groups[g].forEach(function (v) {
                var opt = document.createElement('option');
                opt.value = v.voiceURI;
                opt.textContent = voiceOptionLabel(v);
                opt.setAttribute('data-name', v.name);
                if (selected && (selected === v.voiceURI || selected === v.name)) {
                    opt.selected = true;
                }
                og.appendChild(opt);
            });
            select.appendChild(og);
        });

        Object.keys(groups).forEach(function (g) {
            if (order.indexOf(g) >= 0) return;
            var og = document.createElement('optgroup');
            og.label = g;
            groups[g].forEach(function (v) {
                var opt = document.createElement('option');
                opt.value = v.voiceURI;
                opt.textContent = voiceOptionLabel(v);
                if (selected && selected === v.voiceURI) opt.selected = true;
                og.appendChild(opt);
            });
            select.appendChild(og);
        });

        if (countEl) {
            countEl.textContent = voices.length + ' voices available on this device';
        }
    }

    function toggleSpeechVoicePicker(show) {
        var picker = document.getElementById('speechVoicePicker');
        var hint = document.getElementById('ringtonePreviewHint');
        if (picker) picker.style.display = show ? '' : 'none';
        if (hint) hint.style.display = show ? '' : 'none';
    }

    function pickSpeechVoice() {
        if (!window.speechSynthesis) return null;
        var voices = window.speechSynthesis.getVoices();
        if (!voices.length) return null;

        var indianHints = ['en-in', 'india', 'indian', 'raveena', 'veena', 'lekha', 'hindi', 'english india'];
        var lang = function (v) { return (v.lang || '').toLowerCase().replace('_', '-'); };
        var label = function (v) { return ((v.name || '') + ' ' + lang(v)).toLowerCase(); };

        var enInVoices = voices.filter(function (v) {
            return lang(v).indexOf('en-in') === 0;
        });
        if (enInVoices.length) {
            var named = enInVoices.find(function (v) {
                return indianHints.some(function (h) { return label(v).indexOf(h) >= 0; });
            });
            return named || enInVoices[0];
        }

        var byHint = voices.find(function (v) {
            return indianHints.some(function (h) { return label(v).indexOf(h) >= 0; });
        });
        if (byHint) return byHint;

        var enGb = voices.find(function (v) { return lang(v).indexOf('en-gb') === 0; });
        if (enGb) return enGb;

        return voices.find(function (v) { return lang(v).indexOf('en') === 0; }) || voices[0];
    }

    function preloadSpeechVoices() {
        if (!window.speechSynthesis) return;
        function refresh() {
            populateSpeechVoiceSelect();
        }
        refresh();
        window.speechSynthesis.onvoiceschanged = refresh;
    }

    function waitForVoices() {
        return new Promise(function (resolve) {
            if (!window.speechSynthesis) {
                resolve([]);
                return;
            }
            var voices = window.speechSynthesis.getVoices();
            if (voices.length) {
                resolve(voices);
                return;
            }
            var done = false;
            function finish() {
                if (done) return;
                done = true;
                resolve(window.speechSynthesis.getVoices());
            }
            window.speechSynthesis.onvoiceschanged = finish;
            setTimeout(finish, 300);
        });
    }

    /**
     * Speak task title using browser text-to-speech (built-in ringtone).
     * @param {string} text
     * @returns {Promise<void>}
     */
    function speakText(text, voiceUri) {
        text = (text || '').trim();
        if (!text || !window.speechSynthesis) {
            return Promise.resolve(false);
        }
        return waitForVoices().then(function () {
            return new Promise(function (resolve) {
                try {
                    window.speechSynthesis.cancel();
                    var utter = new SpeechSynthesisUtterance(text);
                    var voice = resolveSpeechVoice(voiceUri || getSelectedSpeechVoiceUri());
                    if (voice) {
                        utter.voice = voice;
                        utter.lang = voice.lang || 'en-IN';
                    } else {
                        utter.lang = 'en-IN';
                    }
                    utter.rate = 0.72;
                    utter.pitch = 1;
                    utter.volume = 1;
                    utter.onend = function () { resolve(true); };
                    utter.onerror = function () { resolve(false); };
                    window.speechSynthesis.speak(utter);
                } catch (e) {
                    resolve(false);
                }
            });
        });
    }

    function shouldSpeakTaskTitle(key, speechText) {
        if (!speechText || !key || key === 'none') {
            return false;
        }
        return key.indexOf('custom:') !== 0;
    }

    function playCustomUrl(url, callback) {
        if (!url) {
            if (callback) callback();
            return;
        }
        try {
            if (customAudio) {
                customAudio.pause();
                customAudio = null;
            }
            customAudio = new Audio(url);
            customAudio.onended = function () {
                if (callback) callback();
            };
            customAudio.onerror = function () {
                if (callback) callback();
            };
            customAudio.play().catch(function () {
                if (callback) callback();
            });
        } catch (e) {
            if (callback) callback();
        }
    }

    function playPreviewFile(fileInput) {
        var file = fileInput && fileInput.files && fileInput.files[0];
        if (!file) return false;
        var url = URL.createObjectURL(file);
        playCustomUrl(url);
        return true;
    }

    /**
     * @param {string} key - ringtone key or custom:filename
     * @param {object} opts - { vibrate, customUrl, speechText, speechVoice }
     */
    function play(key, opts) {
        opts = opts || {};
        key = key || 'speech';
        var doVibrate = opts.vibrate !== false;
        var speechText = (opts.speechText || '').trim();
        var speechVoice = opts.speechVoice || opts.speech_voice || '';

        if (doVibrate) {
            vibrate(key === 'speech' ? 'gentle' : key, true);
        }

        if (key === 'none') return;

        if (key.indexOf('custom:') === 0 && opts.customUrl) {
            playCustomUrl(opts.customUrl);
            return;
        }

        if (key.indexOf('custom:') === 0) {
            return;
        }

        if (shouldSpeakTaskTitle(key, speechText)) {
            speakText(speechText, speechVoice);
            if (key === 'speech') {
                return;
            }
        }

        try {
            playBuiltin(key);
        } catch (e) {
            console.warn('Ringtone playback failed', e);
        }
    }

    function previewSpeechTitle() {
        var title = getTaskTitleFromPage();
        if (!title) {
            window.alert('Please enter a task title first, then click Preview.');
            var titleInput = document.getElementById('title') || document.querySelector('input[name="title"]');
            if (titleInput) titleInput.focus();
            return;
        }
        var vibrateEl = document.getElementById('taskVibrate');
        if (vibrateEl && vibrateEl.checked) {
            vibrate('speech', true);
        }
        speakText(title, getSelectedSpeechVoiceUri());
    }

    function previewSelectedVoice() {
        var title = getTaskTitleFromPage();
        if (!title) {
            window.alert('Please enter a task title first.');
            return;
        }
        var vibrateEl = document.getElementById('taskVibrate');
        if (vibrateEl && vibrateEl.checked) {
            vibrate('speech', true);
        }
        speakText(title, getSelectedSpeechVoiceUri());
    }

    function getPreviewOptions() {
        var vibrateEl = document.getElementById('taskVibrate');
        var select = document.getElementById('ringtone');
        var fileInput = document.getElementById('custom_ringtone');
        var opts = { vibrate: vibrateEl ? vibrateEl.checked : true };

        if (fileInput && fileInput.files && fileInput.files[0]) {
            playPreviewFile(fileInput);
            if (opts.vibrate) vibrate('custom', true);
            return null;
        }

        var key = select ? select.value : 'speech';
        if (key.indexOf('custom:') === 0) {
            var opt = select.options[select.selectedIndex];
            var url = opt && opt.getAttribute('data-url');
            opts.customUrl = url;
        }
        opts.speechText = getTaskTitleFromPage();
        opts.speechVoice = getSelectedSpeechVoiceUri();
        return { key: key, opts: opts };
    }

    function runPreview() {
        var select = document.getElementById('ringtone');
        var key = select ? select.value : 'speech';
        var fileInput = document.getElementById('custom_ringtone');

        if (fileInput && fileInput.files && fileInput.files[0]) {
            var vibrateEl = document.getElementById('taskVibrate');
            playPreviewFile(fileInput);
            if (vibrateEl && vibrateEl.checked) vibrate('custom', true);
            return;
        }

        if (key === 'speech') {
            previewSpeechTitle();
            return;
        }

        var result = getPreviewOptions();
        if (result) {
            if (!result.opts.speechText && result.key !== 'none' && result.key.indexOf('custom:') !== 0) {
                window.alert('Please enter a task title first to preview how it will sound.');
                return;
            }
            play(result.key, result.opts);
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        preloadSpeechVoices();

        var previewBtn = document.getElementById('ringtonePreview');
        if (previewBtn) {
            previewBtn.addEventListener('click', function () {
                runPreview();
            });
        }

        var ringtoneSelect = document.getElementById('ringtone');
        if (ringtoneSelect) {
            ringtoneSelect.addEventListener('change', function () {
                toggleSpeechVoicePicker(ringtoneSelect.value === 'speech');
            });
            toggleSpeechVoicePicker(ringtoneSelect.value === 'speech');
        }

        var speechVoicePreviewBtn = document.getElementById('speechVoicePreviewBtn');
        if (speechVoicePreviewBtn) {
            speechVoicePreviewBtn.addEventListener('click', previewSelectedVoice);
        }

        document.querySelectorAll('.play-task-ringtone').forEach(function (btn) {
            btn.addEventListener('click', function () {
                play(btn.getAttribute('data-ringtone'), {
                    vibrate: btn.getAttribute('data-vibrate') === '1',
                    customUrl: btn.getAttribute('data-custom-url') || '',
                    speechText: btn.getAttribute('data-task-title') || '',
                    speechVoice: btn.getAttribute('data-speech-voice') || ''
                });
            });
        });
    });

    return {
        play: play,
        speakText: speakText,
        populateSpeechVoiceSelect: populateSpeechVoiceSelect,
        vibrate: vibrate,
        playCustomUrl: playCustomUrl
    };
})();
