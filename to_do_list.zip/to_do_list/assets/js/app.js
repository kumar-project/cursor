/**
 * Scheduler Pro - Main Application JS
 */
document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    const menuToggle = document.getElementById('menuToggle');
    const sidebarClose = document.getElementById('sidebarClose');

    function openSidebar() {
        sidebar?.classList.add('open');
        overlay?.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeSidebar() {
        sidebar?.classList.remove('open');
        overlay?.classList.remove('active');
        document.body.style.overflow = '';
    }

    menuToggle?.addEventListener('click', openSidebar);
    sidebarClose?.addEventListener('click', closeSidebar);
    overlay?.addEventListener('click', closeSidebar);

    // User menu dropdown (Profile submenu + Logout)
    const userMenu = document.getElementById('userMenu');
    const userMenuToggle = document.getElementById('userMenuToggle');
    const profileToggle = document.getElementById('userMenuProfileToggle');
    const profileGroup = profileToggle?.closest('.user-menu-group');

    function closeUserMenu() {
        userMenu?.classList.remove('open');
        userMenuToggle?.setAttribute('aria-expanded', 'false');
    }

    function closeProfileSubmenu() {
        profileGroup?.classList.remove('submenu-open');
        profileToggle?.setAttribute('aria-expanded', 'false');
    }

    userMenuToggle?.addEventListener('click', function (e) {
        e.stopPropagation();
        const isOpen = userMenu.classList.toggle('open');
        userMenuToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        if (!isOpen) closeProfileSubmenu();
    });

    profileToggle?.addEventListener('click', function (e) {
        e.stopPropagation();
        const isOpen = profileGroup.classList.toggle('submenu-open');
        profileToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });

    userMenu?.querySelectorAll('.user-menu-subitem, .user-menu-item-logout').forEach(function (link) {
        link.addEventListener('click', function () {
            closeUserMenu();
            closeProfileSubmenu();
        });
    });

    document.addEventListener('click', function (e) {
        if (userMenu && !userMenu.contains(e.target)) {
            closeUserMenu();
            closeProfileSubmenu();
        }
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            closeUserMenu();
            closeProfileSubmenu();
        }
    });

    // Scroll to profile section when opened via submenu hash link
    if (window.location.hash) {
        const section = document.querySelector(window.location.hash);
        if (section?.classList.contains('profile-section')) {
            setTimeout(function () { section.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 100);
        }
    }

    // Close sidebar on nav click (mobile)
    document.querySelectorAll('.sidebar-nav .nav-item').forEach(function (link) {
        link.addEventListener('click', function () {
            if (window.innerWidth < 992) closeSidebar();
        });
    });

    // Modal helpers
    document.querySelectorAll('[data-modal]').forEach(function (trigger) {
        trigger.addEventListener('click', function (e) {
            e.preventDefault();
            const modalId = this.getAttribute('data-modal');
            document.getElementById(modalId)?.classList.add('active');
        });
    });

    document.querySelectorAll('.modal-close, .modal-overlay').forEach(function (el) {
        el.addEventListener('click', function (e) {
            if (e.target === this || this.classList.contains('modal-close')) {
                this.closest('.modal-overlay')?.classList.remove('active');
            }
        });
    });

    // Auto-hide alerts
    document.querySelectorAll('.alert').forEach(function (alert) {
        setTimeout(function () {
            alert.style.opacity = '0';
            alert.style.transition = 'opacity .3s';
            setTimeout(function () { alert.remove(); }, 300);
        }, 5000);
    });

    // Confirm delete
    document.querySelectorAll('[data-confirm]').forEach(function (el) {
        el.addEventListener('click', function (e) {
            if (!confirm(this.getAttribute('data-confirm') || 'Are you sure?')) {
                e.preventDefault();
            }
        });
    });
});

function openModal(id) {
    document.getElementById(id)?.classList.add('active');
}

function closeModal(id) {
    document.getElementById(id)?.classList.remove('active');
}
