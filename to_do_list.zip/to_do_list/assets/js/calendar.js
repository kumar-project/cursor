/**
 * FullCalendar integration for Scheduler Pro
 */
document.addEventListener('DOMContentLoaded', function () {
    const calendarEl = document.getElementById('calendar');
    if (!calendarEl || typeof FullCalendar === 'undefined') return;

    const base = window.APP_BASE || '';

    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: window.innerWidth < 768 ? 'listWeek' : 'dayGridMonth',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
        },
        height: 'auto',
        navLinks: true,
        editable: false,
        selectable: false,
        nowIndicator: true,
        events: base + '/api/events.php',
        eventClick: function (info) {
            const props = info.event.extendedProps;
            let msg = info.event.title + '\n\n';
            if (props.description) msg += props.description + '\n\n';
            msg += 'Start: ' + info.event.start.toLocaleString() + '\n';
            if (info.event.end) msg += 'End: ' + info.event.end.toLocaleString() + '\n';
            if (props.status) msg += 'Status: ' + props.status + '\n';
            if (props.priority) msg += 'Priority: ' + props.priority + '\n';
            if (props.assignees) msg += 'Assigned: ' + props.assignees;
            alert(msg);
        },
        eventDidMount: function (info) {
            if (info.event.extendedProps.priority === 'high') {
                info.el.style.fontWeight = 'bold';
            }
        },
        windowResize: function () {
            if (window.innerWidth < 768 && calendar.view.type === 'dayGridMonth') {
                calendar.changeView('listWeek');
            }
        }
    });

    calendar.render();
});
