/**
 * Browser notifications + task ringtones (user-selected ringtone with each alert)
 */
(function () {
    if (!window.CURRENT_USER_ID) return;

    const base = window.APP_BASE || '';
    const playedReminders = {};
    const scheduledTimers = {};
    const playedNotificationIds = {};
    const STORAGE_KEY = 'schedulerTaskRemindersPlayed';
    const NOTIF_STORAGE_KEY = 'schedulerNotifAlertsPlayed';
    const CATCHUP_MS = 30 * 60 * 1000;
    const MAX_SCHEDULE_MS = 7 * 24 * 60 * 60 * 1000;

    let lastNotifId = 0;

    function loadStored(key) {
        try {
            return JSON.parse(localStorage.getItem(key) || '{}');
        } catch (e) {
            return {};
        }
    }

    function markStored(key, storageKey) {
        var stored = loadStored(storageKey);
        stored[key] = Date.now();
        var cutoff = Date.now() - 8 * 24 * 60 * 60 * 1000;
        Object.keys(stored).forEach(function (k) {
            if (stored[k] < cutoff) delete stored[k];
        });
        try {
            localStorage.setItem(storageKey, JSON.stringify(stored));
        } catch (e) {}
    }

    function wasPlayed(key, storageKey) {
        if (playedReminders[key]) return true;
        return !!loadStored(storageKey)[key];
    }

    function markPlayed(key) {
        playedReminders[key] = true;
        markStored(key, STORAGE_KEY);
    }

    function parseLocalDateTime(str) {
        if (!str) return null;
        var normalized = String(str).trim().replace(' ', 'T');
        var d = new Date(normalized);
        return isNaN(d.getTime()) ? null : d;
    }

    function requestNotificationPermission() {
        if ('Notification' in window && Notification.permission === 'default') {
            Notification.requestPermission();
        }
    }

    function playRingtone(key, vibrate, customUrl, speechText, speechVoice) {
        if (!window.SchedulerRingtones || !key || key === 'none') return;
        SchedulerRingtones.play(key, {
            vibrate: vibrate !== false && vibrate !== 0,
            customUrl: customUrl || '',
            speechText: speechText || '',
            speechVoice: speechVoice || ''
        });
    }

    function showNotification(title, body, link) {
        if (!('Notification' in window) || Notification.permission !== 'granted') return;
        var n = new Notification(title, {
            body: body,
            icon: base + '/assets/css/favicon.png'
        });
        if (link) {
            n.onclick = function () {
                window.focus();
                window.location.href = link;
            };
        }
    }

    /** Play selected ringtone and show browser notification together. */
    function alertWithRingtone(alert, browserReminders) {
        if (browserReminders === false) return;

        var ringtone = alert.ringtone || 'default';
        var speechText = alert.speech_text || alert.speechText || '';
        if (!speechText && ringtone === 'speech') {
            speechText = alert.title || '';
        }

        playRingtone(
            ringtone,
            alert.vibrate,
            alert.custom_url || alert.customUrl || '',
            speechText,
            alert.speech_voice || alert.speechVoice || ''
        );

        showNotification(
            alert.title || 'Notification',
            alert.message || '',
            alert.link || null
        );
    }

    function reminderKey(taskId, kind) {
        return 'task-' + taskId + '-' + kind;
    }

    function fireTaskReminder(task, kind, browserReminders) {
        var key = reminderKey(task.id, kind);
        if (wasPlayed(key, STORAGE_KEY)) return;
        markPlayed(key);

        var title = (task.title || '').trim();
        var ringtone = task.ringtone || 'speech';
        var speechText = title;
        var notifTitle = 'Task Reminder';
        var notifBody = title || 'Your scheduled task';

        if (kind === 'start') {
            notifTitle = 'Scheduled task';
            notifBody = title ? title + ' — it is time now' : 'Your task is due now';
        } else if (kind === 'end') {
            notifTitle = 'Task end time';
            notifBody = title || 'Task end time reached';
        } else if (kind === 'upcoming') {
            notifTitle = 'Task Reminder';
            notifBody = (title || 'Task') + ' starts soon';
        }

        alertWithRingtone({
            title: notifTitle,
            message: notifBody,
            ringtone: ringtone,
            vibrate: task.vibrate,
            custom_url: task.custom_url || '',
            speech_text: speechText,
            speech_voice: task.speech_voice || ''
        }, browserReminders);
    }

    function scheduleTask(task, browserReminders) {
        if (!task || !task.id) return;

        var startMs = parseLocalDateTime(task.start_at);
        var endMs = parseLocalDateTime(task.end_at);
        var slots = [{ kind: 'start', at: task.start_at }];
        if (startMs && endMs && (endMs.getTime() - startMs.getTime() > 35 * 60 * 1000)) {
            slots.push({ kind: 'end', at: task.end_at });
        }

        slots.forEach(function (slot) {
            if (!slot.at) return;
            var key = reminderKey(task.id, slot.kind);
            var target = parseLocalDateTime(slot.at);
            if (!target) return;

            var diff = target.getTime() - Date.now();

            if (diff > 0 && diff <= MAX_SCHEDULE_MS) {
                if (scheduledTimers[key]) clearTimeout(scheduledTimers[key]);
                scheduledTimers[key] = setTimeout(function () {
                    fireTaskReminder(task, slot.kind, browserReminders);
                }, diff);
            } else if (diff <= 0 && diff >= -CATCHUP_MS) {
                fireTaskReminder(task, slot.kind, browserReminders);
            }
        });
    }

    function applyReminderPayload(data) {
        if (!data || !data.success) return;

        var browserReminders = data.browser_reminders !== false;

        if (Array.isArray(data.scheduled)) {
            data.scheduled.forEach(function (task) {
                scheduleTask(task, browserReminders);
            });
        }

        if (Array.isArray(data.reminders)) {
            data.reminders.forEach(function (task) {
                var kind = 'start';
                if (task.reminder_type === 'due_end') kind = 'end';
                else if (task.reminder_type === 'upcoming') kind = 'upcoming';

                fireTaskReminder(task, kind, browserReminders);
            });
        }
    }

    function checkTaskReminders() {
        fetch(base + '/api/notifications.php?action=reminders')
            .then(function (r) { return r.json(); })
            .then(applyReminderPayload)
            .catch(function () {});
    }

    function playNotificationAlert(alert, browserReminders) {
        var id = alert.id || 0;
        var playKey = 'notif-' + id;
        if (id && (playedNotificationIds[id] || loadStored(NOTIF_STORAGE_KEY)[playKey])) {
            return;
        }
        if (id) {
            playedNotificationIds[id] = true;
            markStored(playKey, NOTIF_STORAGE_KEY);
            if (id > lastNotifId) lastNotifId = id;
        }
        alertWithRingtone(alert, browserReminders);
    }

    function checkNotifications() {
        fetch(base + '/api/notifications.php?action=count')
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.success) {
                    updateBadge(data.unread || 0);
                }
            })
            .catch(function () {});

        fetch(base + '/api/notifications.php?action=new&since=' + lastNotifId)
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (!data.success || !Array.isArray(data.alerts)) return;
                data.alerts.forEach(function (alert) {
                    playNotificationAlert(alert, true);
                });
            })
            .catch(function () {});
    }

    function bootstrapNotificationCursor() {
        fetch(base + '/api/notifications.php?action=latest')
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.success && data.notification && data.notification.id) {
                    lastNotifId = data.notification.id;
                }
            })
            .catch(function () {});
    }

    function updateBadge(count) {
        document.querySelectorAll('.notif-count, .nav-badge').forEach(function (el) {
            if (count > 0) {
                el.textContent = count;
                el.style.display = '';
            } else {
                el.style.display = 'none';
            }
        });
    }

    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) {
            checkTaskReminders();
            checkNotifications();
        }
    });

    requestNotificationPermission();
    bootstrapNotificationCursor();
    checkNotifications();
    checkTaskReminders();
    setInterval(checkNotifications, 15000);
    setInterval(checkTaskReminders, 5000);
})();
