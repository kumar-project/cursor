<?php
/**
 * Task reminder cron job - run every 5-15 minutes via Windows Task Scheduler or cron:
 * php "d:\xamp\htdocs\to do list\cron\reminders.php"
 */
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

$pdo = db();

$users = $pdo->query("
    SELECT u.id, u.name, rs.reminder_minutes, rs.email_reminders
    FROM users u
    JOIN reminder_settings rs ON u.id = rs.user_id
    WHERE u.is_active = 1
")->fetchAll();

$sent = 0;

foreach ($users as $user) {
    $minutes = (int)$user['reminder_minutes'];

    $stmt = $pdo->prepare("
        SELECT t.id, t.title, t.start_datetime
        FROM tasks t
        JOIN task_assignments ta ON t.id = ta.task_id
        WHERE ta.user_id = ?
          AND t.status NOT IN ('completed', 'cancelled')
          AND t.start_datetime BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL ? MINUTE)
          AND NOT EXISTS (
              SELECT 1 FROM notifications n
              WHERE n.user_id = ? AND n.type = 'reminder'
                AND n.message LIKE CONCAT('%', t.id, '%')
                AND n.created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)
          )
    ");
    $stmt->execute([$user['id'], $minutes, $user['id']]);
    $tasks = $stmt->fetchAll();

    foreach ($tasks as $task) {
        createNotification(
            $user['id'],
            'Task Reminder',
            'Upcoming task #' . $task['id'] . ': "' . $task['title'] . '" starts at ' . formatDateTime($task['start_datetime']),
            'reminder',
            baseUrl('user/edit-task.php?id=' . $task['id']),
            (int) $task['id']
        );
        $sent++;
    }
}

echo date('Y-m-d H:i:s') . " - Sent $sent reminder(s)\n";
