<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$pdo = db();
$user = currentUser();
$action = $_GET['action'] ?? '';

/** @return array<string, mixed> */
function formatTaskReminderRow(array $row, string $reminderType, string $triggerAt): array {
    $row['reminder_type'] = $reminderType;
    $row['trigger_at'] = $triggerAt;
    $row['vibrate'] = (int)($row['vibrate'] ?? 1);
    $row['custom_url'] = ringtonePlayUrl($row['ringtone'] ?? '') ?? '';
    return $row;
}

switch ($action) {
    case 'count':
        $unread = getUnreadNotificationCount($user['id']);
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ?');
        $stmt->execute([$user['id']]);
        echo json_encode([
            'success' => true,
            'count' => (int)$stmt->fetchColumn(),
            'unread' => $unread,
        ]);
        break;

    case 'latest':
        $stmt = $pdo->prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 1');
        $stmt->execute([$user['id']]);
        $notif = $stmt->fetch();
        echo json_encode([
            'success' => true,
            'notification' => $notif ? formatNotificationAlertForClient($notif) : null,
        ]);
        break;

    case 'new':
        $sinceId = max(0, (int)($_GET['since'] ?? 0));
        $stmt = $pdo->prepare('SELECT * FROM notifications WHERE user_id = ? AND id > ? ORDER BY id ASC LIMIT 20');
        $stmt->execute([$user['id'], $sinceId]);
        $alerts = [];
        foreach ($stmt->fetchAll() as $notif) {
            $alerts[] = formatNotificationAlertForClient($notif);
        }
        echo json_encode(['success' => true, 'alerts' => $alerts]);
        break;

    case 'mark_read':
        if (isset($_GET['id'])) {
            $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?')
                ->execute([(int)$_GET['id'], $user['id']]);
        }
        echo json_encode(['success' => true]);
        break;

    case 'reminders':
        $stmt = $pdo->prepare('SELECT reminder_minutes, browser_reminders FROM reminder_settings WHERE user_id = ?');
        $stmt->execute([$user['id']]);
        $settings = $stmt->fetch();
        $minutes = $settings ? (int)$settings['reminder_minutes'] : 30;
        $browserReminders = !$settings || (int)$settings['browser_reminders'] === 1;

        $stmt = $pdo->prepare("
            SELECT t.id, t.title,
                   t.start_datetime,
                   t.end_datetime,
                   COALESCE(t.ringtone, 'speech') AS ringtone,
                   t.speech_voice,
                   COALESCE(t.vibrate, 1) AS vibrate
            FROM tasks t
            JOIN task_assignments ta ON t.id = ta.task_id
            WHERE ta.user_id = ?
              AND t.status NOT IN ('completed', 'cancelled')
              AND (
                  t.end_datetime >= DATE_SUB(NOW(), INTERVAL 30 MINUTE)
                  OR t.start_datetime >= DATE_SUB(NOW(), INTERVAL 30 MINUTE)
              )
              AND t.start_datetime <= DATE_ADD(NOW(), INTERVAL 7 DAY)
        ");
        $stmt->execute([$user['id']]);
        $scheduled = [];
        foreach ($stmt->fetchAll() as $row) {
            $scheduled[] = [
                'id' => (int)$row['id'],
                'title' => $row['title'],
                'start_at' => $row['start_datetime'],
                'end_at' => $row['end_datetime'],
                'ringtone' => $row['ringtone'],
                'speech_voice' => $row['speech_voice'] ?? null,
                'vibrate' => (int)$row['vibrate'],
                'custom_url' => ringtonePlayUrl($row['ringtone']) ?? '',
            ];
        }

        $reminders = [];
        $baseSql = "
            SELECT t.id, t.title,
                   t.start_datetime,
                   t.end_datetime,
                   COALESCE(t.ringtone, 'speech') AS ringtone,
                   t.speech_voice,
                   COALESCE(t.vibrate, 1) AS vibrate
            FROM tasks t
            JOIN task_assignments ta ON t.id = ta.task_id
            WHERE ta.user_id = ?
              AND t.status NOT IN ('completed', 'cancelled')
        ";

        $stmt = $pdo->prepare($baseSql . "
              AND t.start_datetime <= NOW()
              AND t.start_datetime >= DATE_SUB(NOW(), INTERVAL 30 MINUTE)
        ");
        $stmt->execute([$user['id']]);
        foreach ($stmt->fetchAll() as $row) {
            $reminders[] = formatTaskReminderRow($row, 'due_start', $row['start_datetime']);
        }

        $stmt = $pdo->prepare($baseSql . "
              AND t.start_datetime > NOW()
              AND t.start_datetime <= DATE_ADD(NOW(), INTERVAL ? MINUTE)
        ");
        $stmt->execute([$user['id'], $minutes]);
        foreach ($stmt->fetchAll() as $row) {
            $reminders[] = formatTaskReminderRow($row, 'upcoming', $row['start_datetime']);
        }

        echo json_encode([
            'success' => true,
            'browser_reminders' => $browserReminders,
            'server_time' => date('Y-m-d H:i:s'),
            'scheduled' => $scheduled,
            'reminders' => $reminders,
        ]);
        break;

    default:
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
}
