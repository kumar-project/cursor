<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$pdo = db();
$user = currentUser();
$events = [];

$priorityColors = [
    'low' => '#3b82f6',
    'medium' => '#f59e0b',
    'high' => '#ef4444',
];

if (isAdmin()) {
    // Admin sees all tasks and schedules
    $tasks = $pdo->query("
        SELECT t.id, t.title, t.description, t.start_datetime, t.end_datetime,
               t.priority, t.status,
               (SELECT GROUP_CONCAT(u.name SEPARATOR ', ') FROM task_assignments ta JOIN users u ON ta.user_id = u.id WHERE ta.task_id = t.id) as assignees
        FROM tasks t
    ")->fetchAll();

    foreach ($tasks as $task) {
        $events[] = [
            'id' => 'task-' . $task['id'],
            'title' => $task['title'],
            'start' => $task['start_datetime'],
            'end' => $task['end_datetime'],
            'backgroundColor' => $priorityColors[$task['priority']] ?? '#4f46e5',
            'borderColor' => $priorityColors[$task['priority']] ?? '#4f46e5',
            'extendedProps' => [
                'type' => 'task',
                'description' => $task['description'],
                'status' => $task['status'],
                'priority' => $task['priority'],
                'assignees' => $task['assignees'],
            ],
        ];
    }

    $schedules = $pdo->query('SELECT id, title, description, start_date, end_date, color FROM schedules')->fetchAll();
    foreach ($schedules as $s) {
        $events[] = [
            'id' => 'schedule-' . $s['id'],
            'title' => '[Schedule] ' . $s['title'],
            'start' => $s['start_date'],
            'end' => date('Y-m-d', strtotime($s['end_date'] . ' +1 day')),
            'allDay' => true,
            'backgroundColor' => $s['color'],
            'borderColor' => $s['color'],
            'display' => 'background',
            'extendedProps' => [
                'type' => 'schedule',
                'description' => $s['description'],
            ],
        ];
    }
} else {
    // User sees only assigned tasks
    $stmt = $pdo->prepare("
        SELECT t.id, t.title, t.description, t.start_datetime, t.end_datetime, t.priority, t.status
        FROM tasks t
        JOIN task_assignments ta ON t.id = ta.task_id
        WHERE ta.user_id = ?
    ");
    $stmt->execute([$user['id']]);
    $tasks = $stmt->fetchAll();

    foreach ($tasks as $task) {
        $color = $priorityColors[$task['priority']] ?? '#4f46e5';
        if ($task['status'] === 'completed') $color = '#10b981';
        if ($task['status'] === 'cancelled') $color = '#94a3b8';

        $events[] = [
            'id' => 'task-' . $task['id'],
            'title' => $task['title'],
            'start' => $task['start_datetime'],
            'end' => $task['end_datetime'],
            'backgroundColor' => $color,
            'borderColor' => $color,
            'extendedProps' => [
                'type' => 'task',
                'description' => $task['description'],
                'status' => $task['status'],
                'priority' => $task['priority'],
            ],
        ];
    }
}

echo json_encode($events);
