<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$taskId = (int)($data['task_id'] ?? 0);
$status = $data['status'] ?? '';
$allowed = ['pending', 'in_progress', 'completed', 'cancelled'];

if (!$taskId || !in_array($status, $allowed)) {
    echo json_encode(['success' => false, 'error' => 'Invalid data']);
    exit;
}

$pdo = db();
$user = currentUser();

$check = $pdo->prepare('SELECT t.id, t.title, t.created_by FROM tasks t JOIN task_assignments ta ON t.id = ta.task_id WHERE t.id = ? AND ta.user_id = ?');
$check->execute([$taskId, $user['id']]);
$task = $check->fetch();

if (!$task && !isAdmin()) {
    echo json_encode(['success' => false, 'error' => 'Task not found']);
    exit;
}

if (isAdmin()) {
    $pdo->prepare('UPDATE tasks SET status = ? WHERE id = ?')->execute([$status, $taskId]);
} else {
    $pdo->prepare('UPDATE tasks SET status = ? WHERE id = ?')->execute([$status, $taskId]);
    createNotification(
        $task['created_by'],
        'Task Status Updated',
        $user['name'] . ' marked "' . $task['title'] . '" as ' . str_replace('_', ' ', $status),
        'status',
        baseUrl('user/edit-task.php?id=' . $taskId),
        $taskId
    );
}

echo json_encode(['success' => true, 'status' => $status]);
