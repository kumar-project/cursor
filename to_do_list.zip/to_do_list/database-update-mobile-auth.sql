-- Run once in phpMyAdmin if upgrading from email/password login
USE scheduler_app;

ALTER TABLE users MODIFY email VARCHAR(150) DEFAULT NULL;
ALTER TABLE users MODIFY password VARCHAR(255) DEFAULT NULL;

-- Set phone from old data before NOT NULL (adjust if needed)
UPDATE users SET phone = '9999999999' WHERE (phone IS NULL OR phone = '') AND role = 'admin' LIMIT 1;
UPDATE users SET phone = '8888888888' WHERE (phone IS NULL OR phone = '') AND role = 'user' LIMIT 1;
UPDATE users SET phone = CONCAT('9', LPAD(id, 9, '0')) WHERE phone IS NULL OR phone = '';

ALTER TABLE users MODIFY phone VARCHAR(15) NOT NULL;

-- Remove duplicate phones before adding unique index (keep lowest id)
DELETE u1 FROM users u1
INNER JOIN users u2 ON u1.phone = u2.phone AND u1.id > u2.id
WHERE u1.phone IS NOT NULL AND u1.phone != '';

UPDATE users SET phone = '9999999999', email = NULL, password = NULL, role = 'admin'
WHERE email = 'admin@scheduler.com' OR phone IS NULL OR phone = '';

UPDATE users SET phone = '8888888888', email = NULL, password = NULL, role = 'user'
WHERE email = 'user@scheduler.com';

ALTER TABLE users ADD UNIQUE KEY uk_users_phone (phone);
