-- ============================================================
-- UPGRADE existing scheduler_app database (safe to re-run)
-- Use this when tables already exist — do NOT run database.sql
-- ============================================================
USE scheduler_app;

-- ---- users: mobile-only login ----
ALTER TABLE users MODIFY email VARCHAR(150) DEFAULT NULL;
ALTER TABLE users MODIFY password VARCHAR(255) DEFAULT NULL;

UPDATE users SET phone = '9999999999' WHERE (phone IS NULL OR phone = '') AND role = 'admin' LIMIT 1;
UPDATE users SET phone = '8888888888' WHERE (phone IS NULL OR phone = '') AND role = 'user' LIMIT 1;
UPDATE users SET phone = CONCAT('9', LPAD(id, 9, '0')) WHERE phone IS NULL OR phone = '';

ALTER TABLE users MODIFY phone VARCHAR(15) NOT NULL;

UPDATE users SET phone = '9999999999', email = NULL, password = NULL, role = 'admin'
WHERE email = 'admin@scheduler.com' OR (role = 'admin' AND (phone IS NULL OR phone = '')) LIMIT 1;

UPDATE users SET phone = '8888888888', email = NULL, password = NULL, role = 'user'
WHERE email = 'user@scheduler.com' LIMIT 1;

-- uk_users_phone (skip if already exists)
SET @sql = IF(
    (SELECT COUNT(*) FROM information_schema.statistics
     WHERE table_schema = DATABASE() AND table_name = 'users' AND index_name = 'uk_users_phone') = 0,
    'ALTER TABLE users ADD UNIQUE KEY uk_users_phone (phone)',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ---- tasks: ringtone ----
SET @sql = IF(
    (SELECT COUNT(*) FROM information_schema.columns
     WHERE table_schema = DATABASE() AND table_name = 'tasks' AND column_name = 'ringtone') = 0,
    'ALTER TABLE tasks ADD COLUMN ringtone VARCHAR(120) NOT NULL DEFAULT ''speech'' AFTER status',
    'ALTER TABLE tasks MODIFY COLUMN ringtone VARCHAR(120) NOT NULL DEFAULT ''speech'''
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ---- tasks: speech_voice ----
SET @sql = IF(
    (SELECT COUNT(*) FROM information_schema.columns
     WHERE table_schema = DATABASE() AND table_name = 'tasks' AND column_name = 'speech_voice') = 0,
    'ALTER TABLE tasks ADD COLUMN speech_voice VARCHAR(255) DEFAULT NULL AFTER ringtone',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ---- tasks: vibrate ----
SET @sql = IF(
    (SELECT COUNT(*) FROM information_schema.columns
     WHERE table_schema = DATABASE() AND table_name = 'tasks' AND column_name = 'vibrate') = 0,
    'ALTER TABLE tasks ADD COLUMN vibrate TINYINT(1) NOT NULL DEFAULT 1 AFTER speech_voice',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Demo accounts (mobile login)
INSERT INTO users (name, email, password, role, phone)
SELECT 'Administrator', NULL, NULL, 'admin', '9999999999'
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM users WHERE phone = '9999999999');

INSERT INTO users (name, email, password, role, phone)
SELECT 'Demo User', NULL, NULL, 'user', '8888888888'
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM users WHERE phone = '8888888888');

INSERT INTO reminder_settings (user_id, email_reminders, browser_reminders, reminder_minutes)
SELECT u.id, 1, 1, 30
FROM users u
LEFT JOIN reminder_settings rs ON rs.user_id = u.id
WHERE rs.user_id IS NULL;

SELECT 'Upgrade complete.' AS status;
